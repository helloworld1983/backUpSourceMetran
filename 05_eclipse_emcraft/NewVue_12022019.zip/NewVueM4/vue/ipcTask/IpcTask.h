/*
 * ipc_task.h
 *
 *  Created on: Nov 22, 2018
 *      Author: qsbk0
 */

#ifndef IPCTASK_IPCTASK_H_
#define IPCTASK_IPCTASK_H_

#include <IpcCommonTypes.h>

void ipc_Create(void);

#endif /* IPCTASK_IPCTASK_H_ */
