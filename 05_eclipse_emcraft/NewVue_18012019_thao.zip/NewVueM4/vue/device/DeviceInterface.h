/*
 * DeviceInterface.h
 *
 *  Created on: Dec 25, 2018
 *      Author: qsbk0
 */

#ifndef DEVICE_DEVICEINTERFACE_H_
#define DEVICE_DEVICEINTERFACE_H_

#include "ipc/IpcInterface.h"

void devIf_HandleMsgQueueRecv(void);
bool devIf_sendSettingMsg(Setting* msg);
bool devIf_sendCommandMsg(Command* msg);
void devIf_Init(void);
void devIf_Run();
bool devIf_IsA53Ready();
RealTimeM4ToA53* devIf_UpdateMonitorStruct(void);
SettingA53ToM4* devIf_GetSetting(void);

#endif /* DEVICE_DEVICEINTERFACE_H_ */
