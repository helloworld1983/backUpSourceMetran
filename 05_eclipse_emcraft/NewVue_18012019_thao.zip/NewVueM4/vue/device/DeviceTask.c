/*
 * DeviceTask.c
 *
 *  Created on: Dec 3, 2018
 *      Author: qsbk0
 */
#include "FreeRTOS.h"
#include "task.h"
#include "fsl_uart.h"
#include "fsl_debug_console.h"
#include "DeviceTask.h"
#include "RS485Sensor.h"
#include "uart.h"
#include "spi.h"
#include "i2c.h"
#include "DeviceInterface.h"
#include "Delay.h"
#include "ipc_task.h"
#include "rpmsg_lite.h"
#include "DigitalIO.h"
#define DEVICE_TASK_STACK_SIZE 512
#define WAIT_TIME_BETWEEN_PING 1000
static TaskHandle_t s_devTaskHandle = NULL;

static void devTsk_loop(void *param)
{
	devTsk_Init();
	static uint32_t s_cnt = 0;
	//	static uint32_t s_cntSendRealTimeMsg = 0;
	bool status = false;
	TickType_t xLastWakeTime;
	xLastWakeTime = xTaskGetTickCount();
	static bool s_state = false;
	for (;;)
	{
		DigitalIO_SetState(eOilPump,status);
		status = !status;
		devIf_HandleMsgQueueRecv();
		if(devIf_IsA53Ready())
		{
//			devIf_Run();
			RealTimeM4ToA53 sendMsg;
			RealTimeM4ToA53* ptr = devIf_UpdateMonitorStruct();
			memcpy(&sendMsg,ptr,sizeof(RealTimeM4ToA53));
			ipc_sendRealTimeMsg(&sendMsg);
		}
		else
		{
			if(s_cnt == 0)
			{
				ipc_sendReadyMessage();
			}
			s_cnt++;
			if(s_cnt>WAIT_TIME_BETWEEN_PING/DEVICE_TASK_DELAY_TIME)
				s_cnt=0;

		}
//		DigitalIO_SetState(eOilPump,eOffSolenoidValve);
		vTaskDelayUntil( &xLastWakeTime, DEVICE_TASK_DELAY_TIME/portTICK_PERIOD_MS );
	}
	return;
}

/*!
 * @brief ipc_create function
 */
void devTsk_Create(void)
{
	devIf_Init();
	if (xTaskCreate(devTsk_loop, "DEV_TASK", DEVICE_TASK_STACK_SIZE, NULL, tskIDLE_PRIORITY + 2, &s_devTaskHandle) != pdPASS)
	{
		PRINTF("\r\nFailed to create application task\r\n");
		while (1)
			;
	}
	return;
}

void devTsk_Init(void)
{
	devIf_Init();
}
