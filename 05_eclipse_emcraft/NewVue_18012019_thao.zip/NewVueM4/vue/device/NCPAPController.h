/*
 * NCPAPController.h
 *
 *  Created on: 2 thg 1, 2019
 *      Author: haxua
 */

#ifndef DEVICE_NCPAPCONTROLLER_H_
#define DEVICE_NCPAPCONTROLLER_H_
#include "stdint.h"
#include "ipc/IpcInterface.h"
void NCPAPController_Run();
void NCPAPController_Calculate();
void NCPAPController_SetTargetFlow(int32_t);
void NCPAPController_ResetIMVStaticVariables();
int16_t NCPAPController_ExValveFilter(int16_t);
void NCPAPController_Enable();
void NCPAPController_Disable();
bool NCPAPController_IsEnable();

#endif /* DEVICE_NCPAPCONTROLLER_H_ */
