var searchData=
[
  ['rpmsg_5flite_5fendpoint',['rpmsg_lite_endpoint',['../group__rpmsg__lite.html#structrpmsg__lite__endpoint',1,'']]],
  ['rpmsg_5flite_5fept_5fstatic_5fcontext',['rpmsg_lite_ept_static_context',['../group__rpmsg__lite.html#structrpmsg__lite__ept__static__context',1,'']]],
  ['rpmsg_5flite_5finstance',['rpmsg_lite_instance',['../group__rpmsg__lite.html#structrpmsg__lite__instance',1,'']]],
  ['rpmsg_5fns_5fcallback_5fdata',['rpmsg_ns_callback_data',['../group__rpmsg__ns.html#structrpmsg__ns__callback__data',1,'']]],
  ['rpmsg_5fns_5fcontext',['rpmsg_ns_context',['../group__rpmsg__ns.html#structrpmsg__ns__context',1,'']]],
  ['rpmsg_5fns_5fstatic_5fcontext_5fcontainer',['rpmsg_ns_static_context_container',['../group__rpmsg__ns.html#structrpmsg__ns__static__context__container',1,'']]]
];
