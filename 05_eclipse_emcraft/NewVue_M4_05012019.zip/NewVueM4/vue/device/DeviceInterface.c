/*
 * DeviceInterface.c
 *
 *  Created on: Dec 25, 2018
 *      Author: qsbk0
 */
#include "fsl_debug_console.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "DeviceInterface.h"
#include "ipc/ipc_task.h"
#include "DigitalIO.h"
#include "CMVController.h"
#include "VCVController.h"
#include "ActivePressureSensor.h"
#include "FlowController.h"
#include "ExhController.h"
#include "ADCSensor.h"
#include "HFOController.h"
#include "HFOServo.h"
#include "NCPAPController.h"
#include "RS485Sensor.h"
#include "I2CSensor.h"
#define DEVICE_QUEUE_WAIT_TIME 10
#define DEV_QUEUE_LENGTH 8

static QueueHandle_t s_devTskQueue;
static HFOSetting gs_hfoSetting;
static PCVSetting gs_pcvSetting;
static VCVSetting gs_vcvSetting;
static IpcRealTimeDataA53ToM4 gs_realTimeA53ToM4;
static IpcRealTimeDataM4ToA53 gs_realTimeM4ToA53;
void devIf_handleSingleSettingMsg(IpcData* singleSettingMsg)
{
	switch(singleSettingMsg->singleSetting.settingId)
	{
	case eCompRateSettingId:
		if(gs_realTimeA53ToM4.currentMode==ePcvMixedMode ||
				gs_realTimeA53ToM4.currentMode==ePcvACMode ||
				gs_realTimeA53ToM4.currentMode==ePcvSpontMode)
			gs_pcvSetting.compRate = singleSettingMsg->singleSetting.value;
		else
			if(gs_realTimeA53ToM4.currentMode==eVcvMixedMode ||
					gs_realTimeA53ToM4.currentMode==eVcvACMode ||
					gs_realTimeA53ToM4.currentMode==eVcvSpontMode)
				gs_vcvSetting.compRate = singleSettingMsg->singleSetting.value;
		break;
	case eBaseFlowSettingId:
		if(gs_realTimeA53ToM4.currentMode==ePcvMixedMode ||
				gs_realTimeA53ToM4.currentMode==ePcvACMode ||
				gs_realTimeA53ToM4.currentMode==ePcvSpontMode)
			gs_pcvSetting.baseFlow = singleSettingMsg->singleSetting.value;
		else
			if(gs_realTimeA53ToM4.currentMode==eVcvMixedMode ||
					gs_realTimeA53ToM4.currentMode==eVcvACMode ||
					gs_realTimeA53ToM4.currentMode==eVcvSpontMode)
				gs_vcvSetting.baseFlow = singleSettingMsg->singleSetting.value;
		break;
	case eTubeLengthSettingId:
		if(gs_realTimeA53ToM4.currentMode==ePcvMixedMode ||
				gs_realTimeA53ToM4.currentMode==ePcvACMode ||
				gs_realTimeA53ToM4.currentMode==ePcvSpontMode)
			gs_pcvSetting.tubeLength = singleSettingMsg->singleSetting.value;
		else
			if(gs_realTimeA53ToM4.currentMode==eVcvMixedMode ||
					gs_realTimeA53ToM4.currentMode==eVcvACMode ||
					gs_realTimeA53ToM4.currentMode==eVcvSpontMode)
				gs_vcvSetting.tubeLength = singleSettingMsg->singleSetting.value;
		break;
	case eTubeDiameterSettingId:
		if(gs_realTimeA53ToM4.currentMode==ePcvMixedMode ||
				gs_realTimeA53ToM4.currentMode==ePcvACMode ||
				gs_realTimeA53ToM4.currentMode==ePcvSpontMode)
			gs_pcvSetting.tubeDiameter = singleSettingMsg->singleSetting.value;
		else
			if(gs_realTimeA53ToM4.currentMode==eVcvMixedMode ||
					gs_realTimeA53ToM4.currentMode==eVcvACMode ||
					gs_realTimeA53ToM4.currentMode==eVcvSpontMode)
				gs_vcvSetting.tubeDiameter = singleSettingMsg->singleSetting.value;
		break;
	case eHFOMapSettingId:
		gs_hfoSetting.map = singleSettingMsg->singleSetting.value;
		break;
	case eFreshGasSettingId:
		gs_hfoSetting.freshGas = singleSettingMsg->singleSetting.value;
		break;
	case eSISettingId:
		gs_hfoSetting.si = singleSettingMsg->singleSetting.value;
		break;
	case eHFOFrequencySettingId:
		gs_hfoSetting.frequency = singleSettingMsg->singleSetting.value;
		break;
	case eHFOStrokeVolumeSettingId:
		gs_hfoSetting.strokeVolume = singleSettingMsg->singleSetting.value;
		break;
	case eAmplitudeSettingId:
		gs_hfoSetting.amplitude = singleSettingMsg->singleSetting.value;
		break;
	default:
		break;
	}

}
HFOSetting* const  devIf_getHFOSetting()
{
	return &gs_hfoSetting;
}

PCVSetting* const  devIf_getPCVSetting()
{
	return &gs_pcvSetting;
}

VCVSetting* const  devIf_getVCVSetting()
{
	return &gs_vcvSetting;
}

IpcRealTimeDataA53ToM4* const  devIf_getIPCRealTimeDataA53ToM4()
{
	return &gs_realTimeA53ToM4;
}

static void  devIf_setHFOSetting(IpcData* setting)
{
	memcpy(&gs_hfoSetting,setting,sizeof(gs_hfoSetting));
}

static void   devIf_setPCVSetting(IpcData* setting)
{
	memcpy(&gs_pcvSetting,setting,sizeof(gs_pcvSetting));
}

static void    devIf_setVCVSetting(IpcData* setting)
{
	memcpy(&gs_vcvSetting,setting,sizeof(gs_vcvSetting));
}

static void    devIf_setIPCRealTimeDataA53ToM4(IpcData* data)
{
	memcpy(&gs_realTimeA53ToM4,data,sizeof(gs_realTimeA53ToM4));
}
bool devIf_sendMsg(IpcMessage* msg)
{
	if(xQueueSend(s_devTskQueue, msg,DEVICE_QUEUE_WAIT_TIME) == pdFALSE)
	{
		PRINTF("\n Failure send");
		return false;
	}
	return true;
}

void devIf_HandleMsgQueueRecv(void)
{
	static IpcMessage s_ipcMsgData;
	if(xQueueReceive(s_devTskQueue, &s_ipcMsgData, 0) == pdTRUE)
	{
		PRINTF("%s\n",s_ipcMsgData);
		switch(s_ipcMsgData.type)
		{
		case eNone:
			break;
		case eSingleSetting:
			devIf_handleSingleSettingMsg(&s_ipcMsgData.data);
			PRINTF("Change Setting: %d %d\n",s_ipcMsgData.data.singleSetting.settingId
					,s_ipcMsgData.data.singleSetting.value);
			break;
		case eHfoSetting:
			devIf_setHFOSetting(&s_ipcMsgData.data);
			PRINTF("HFO Setting: %d %d %d %d %d %d\n",s_ipcMsgData.data.hfo.amplitude
					,s_ipcMsgData.data.hfo.frequency
					,s_ipcMsgData.data.hfo.freshGas
					,s_ipcMsgData.data.hfo.map
					,s_ipcMsgData.data.hfo.si
					,s_ipcMsgData.data.hfo.strokeVolume);
			break;
		case ePcvSetting:
			devIf_setPCVSetting(&s_ipcMsgData.data);
			PRINTF("PCV Setting: %d %d %d %d\n",s_ipcMsgData.data.pcv.baseFlow
					,s_ipcMsgData.data.pcv.compRate
					,s_ipcMsgData.data.pcv.tubeDiameter
					,s_ipcMsgData.data.pcv.tubeLength);
			break;
		case eVcvSetting:
			devIf_setVCVSetting(&s_ipcMsgData.data);
			PRINTF("VCV Setting: %d %d %d %d\n",s_ipcMsgData.data.vcv.baseFlow
					,s_ipcMsgData.data.vcv.compRate
					,s_ipcMsgData.data.vcv.tubeDiameter
					,s_ipcMsgData.data.vcv.tubeLength);
			break;
		case eRealTime:
			devIf_setIPCRealTimeDataA53ToM4(&s_ipcMsgData.data);
			break;
		case eSetImpedanceLineState:
			DigitalIO_SetState(eImpedanceLine,s_ipcMsgData.data.command.state);
			break;
		case eSetImpedanceLineStateDirect:
			DigitalIO_SetStateDirect(eImpedanceLine,s_ipcMsgData.data.command.state);
			break;
		case eSetImpedanceLineDesiredState:
			DigitalIO_SetDesiredState(eImpedanceLine,s_ipcMsgData.data.command.state);
			break;
		case eSetSafetyValveDesiredState:
			DigitalIO_SetDesiredState(eSafetyValve,s_ipcMsgData.data.command.state);
			break;
		case eSetSafetyValveStateDirect:
			DigitalIO_SetStateDirect(eSafetyValve,s_ipcMsgData.data.command.state);
			break;
		case eCMVServoEnable:
			CMVController_Enable();
			break;
		case eCMVServoDisable:
			CMVController_Disable();
			break;
		case eSetCMVBiasFlow:
			//None Use
			break;
		case eSetCMVInhalationTarget:
			CMVController_SetInhalationTarget(s_ipcMsgData.data.command.inhTarget.targetPressure,
					s_ipcMsgData.data.command.inhTarget.riseTime);
			break;
		case eSetCMVExhlationTarget:
			CMVController_SetExhalationTarget(s_ipcMsgData.data.command.targetPress);
			break;
		case eCMVResetIMVStaticVariables:
			CMVController_ResetIMVStaticVariables();
			break;
		case eVCVServoEnable:
			VCVController_Enable();
			break;
		case eVCVServoDisable:
			VCVController_Disable();
			break;
		case eVCVSetSpecificPhase:
			VCVController_SetSepecificPhase((E_SpecificPhaseId)s_ipcMsgData.data.command.specificPhaseId);
			break;
		case eVCVSetBiasFlow:
			//None Use
			break;
		case eVCVSetExhalationTarget:
			VCVController_SetExhalationTarget(s_ipcMsgData.data.command.targetPress);
			break;
		case eVCVSetInhalationTarget:
			VCVController_SetInhalationTarget(s_ipcMsgData.data.command.inhTarget.targetPressure,
					s_ipcMsgData.data.command.inhTarget.riseTime);
			break;
		case eVCVResetIMVStaticVariables:
			VCVController_ResetIMVStaticVariables();
			break;
		case eVCVSetDesiredFlow:
			VCVController_SetDesiredFlow(s_ipcMsgData.data.command.desiredAirFlow,
					s_ipcMsgData.data.command.desiredO2Flow);
			break;
		case eCommunicateProxySensor:
			//None Use
			break;
		case eSetPrimaryActivePress:
			ActivePressureSensor_SetPrimary(s_ipcMsgData.data.command.primary);
			break;
		case eSetProxyFlowResetLineStateDirect:
			DigitalIO_SetStateDirect(eProxyFlowResetLine,s_ipcMsgData.data.command.state);
			break;
		case eSetProxyFlowResetLineDesiredState:
			DigitalIO_SetDesiredState(eProxyFlowResetLine,s_ipcMsgData.data.command.state);
			break;
		case eSetExhPressZeroDesiredState:
			DigitalIO_SetDesiredState(eExhPressureZero,s_ipcMsgData.data.command.state);
			break;
		case eSetExhPressZeroStateDirect:
			DigitalIO_SetStateDirect(eExhPressureZero,s_ipcMsgData.data.command.state);
			break;
		case eSetInhPressZeroDesiredState:
			DigitalIO_SetDesiredState(eInhPressureZero,s_ipcMsgData.data.command.state);
			break;
		case eSetInhPressZeroStateDirect:
			DigitalIO_SetStateDirect(eInhPressureZero,s_ipcMsgData.data.command.state);
			break;
		case eSetPurgeFlowStateDirect:
			DigitalIO_SetStateDirect(ePurgeFlow,s_ipcMsgData.data.command.state);
			break;
		case eSetPurgeFlowDesiredState:
			DigitalIO_SetDesiredState(ePurgeFlow,s_ipcMsgData.data.command.state);
			break;
		case eSetOilPumpStateDirect:
			DigitalIO_SetStateDirect(eOilPump,s_ipcMsgData.data.command.state);
			break;
		case eSetOilPumpDesiredState:
			DigitalIO_SetDesiredState(eOilPump,s_ipcMsgData.data.command.state);
			break;
		case eAirFlowControllerEnable:
			FlowController_SetEnable(eAirFlowController,true);
			break;
		case eAirFlowControllerDisable:
			FlowController_SetEnable(eAirFlowController,false);
			break;
		case eO2FlowControllerEnable:
			FlowController_SetEnable(eO2FlowController,true);
			break;
		case eO2FlowControllerDisable:
			FlowController_SetEnable(eO2FlowController,false);
			break;
		case eExhControllerEnable:
			ExhController_Enable();
			break;
		case eExhControllerDisable:
			ExhController_Disable();
			break;
		case eHfoRequestDoSVCtr:
			HFOServo_RequestDoSVCtr();
			break;
		case eHfoRequestDoAmpCtr:
			HFOServo_RequestDoAmpCtr();
			break;
		case eStopHfoDoAmpCtr:
			HFOServo_StopDoAmpCtr();
			break;
		case eStopHfoDoSVCtr:
			HFOServo_StopDoAmpCtr();
			break;
		case eHfoSetExhValveLimit:
			HFOController_SetExhValveLimit(s_ipcMsgData.data.command.exhValveLimit);
			break;
		case eHfoValveRampToPosition:
			HFOServo_HFOMotorMoveToStepPosition(s_ipcMsgData.data.command.position);
			break;
		case eHfoServoEnable:
			HFOServo_Enable();
			break;
		case eHfoServoDisable:
			HFOServo_Disable();
			break;
		case eHfoControllerEnable:
			HFOController_Enable();
			break;
		case eHfoControllerDisable:
			HFOController_Diable();
			break;
		case eExhValveRampToPosition:
			MotorController_MoveToStepPositionOld(eExhMotor,s_ipcMsgData.data.command.position);
			break;
		case eO2ValveRampToPosition:
			MotorController_MoveToStepPositionOld(eO2Motor,s_ipcMsgData.data.command.position);
			break;
		case eAirValveRampToPosition:
			MotorController_MoveToStepPositionOld(eAirMotor,s_ipcMsgData.data.command.position);
			break;
		case eResetHFOStaticVariables:
			HFOController_ResetHFOStaticVariables();
			break;
		case eClearHfoServoStaticVariables:
			HFOServo_ClearStaticVariable();
			break;
		case eResetHfoServoPIDStatic:
			HFOServo_ResetPIDStatic();
			break;
		case eResetHfoServo_20sTimer:
			//None Use
			break;
		case eSetHfoConstFlow:
			HFOController_SetConstFlow(s_ipcMsgData.data.command.constFlowFlag);
			break;
		case eSetHfoControllerSIRequest:
			HFOController_SetSIRequest(s_ipcMsgData.data.command.siRequestFlag);
			break;
		case eSetHfoServoSIRequest:
			HFOServo_SetSIRequest(s_ipcMsgData.data.command.siRequestFlag);
			break;
		case eSetHfoControllerSIType:
			HFOController_SetSIType(s_ipcMsgData.data.command.siType);
			break;
		case eSetAirStepPostion:
			MotorController_MoveToStepPositionOld(eAirMotor,s_ipcMsgData.data.command.position);
			break;
		case eSetO2StepPostion:
			MotorController_MoveToStepPositionOld(eO2Motor,s_ipcMsgData.data.command.position);
			break;
		case eSetExhStepPostion:
			MotorController_MoveToStepPositionOld(eExhMotor,s_ipcMsgData.data.command.position);
			break;
		case eSetHfoStepPostion:
			HFOServo_HFOMotorMoveToStepPosition(s_ipcMsgData.data.command.position);
			break;
		case eSetHfoValveFreq:
			MotorController_SetHFOFreq(s_ipcMsgData.data.command.freq);
			break;
		case eSetHfoAlarmInactiveTimer:
			HFOController_SetHFOAlarmInactiveTimer(s_ipcMsgData.data.command.inactiveTimer);
			break;
		case eSetCMVAlarmInactiveTimer:
			//None Use
			break;
		case eNCPAPResetIMVStaticVariables:
			NCPAPController_ResetIMVStaticVariables();
			break;
		case eNCPAPControllerEnable:
			NCPAPController_Enable();
			break;
		case eNCPAPControllerDisable:
			NCPAPController_Disable();
			break;
		case eSetNCPAPTargetFlow:
			NCPAPController_SetTargetFlow(s_ipcMsgData.data.command.targetFlow);
			break;
		case eAirFlowControllerReset:
			FlowController_Reset(eAirFlowController);
			break;
		case eO2FlowControllerReset:
			FlowController_Reset(eO2FlowController);
			break;
		case eExhControllerReset:
			ExhController_Reset();
			break;
		case eHfoFlowControllerReset:
			//None Use
			break;
		case eDisableHfoMotorErrorCheck:
			//None Use
			break;
		case eDisableO2MotorErrorCheck:
			//None Use
			break;
		case eDisableAirMotorErrorCheck:
			//None Use
			break;
		case eDisableExhMotorErrorCheck:
			//None Use
			break;
		case eEnableHfoMotorErrorCheck:
			//None Use
			break;
		case eEnableO2MotorErrorCheck:
			//None Use
			break;
		case eEnableAirMotorErrorCheck:
			//None Use
			break;
		case eEnableExhMotorErrorCheck:
			//None Use
			break;
		case eSetAirPressSwitchFault:
			//None Use
			break;
		case eSetO2PressSwitchFault:
			//None Use
			break;
		case eSetCauseOfAlarm:
			//None Use
			break;
		case eSendOilPumpRequestKey:
			//None Use
			break;
		case eRunHfoServo:
			//None Use
			break;
		case eRunHfoController:
			//None Use
			break;
		case eRunCMVServoController:
			//None Use
			break;
		case eRunVCVServoController:
			//None Use
			break;
		case eRunAirFlowController:
			//None Use
			break;
		case eRunO2FlowController:
			//None Use
			break;
		case eRunNCPAPController:
			//None Use
			break;
		case eRunExhController:
			ExhController_Run();
			break;
		case eRunHfoValveHFOMode:
			//None Use
			break;
		case eSetDesiredAirFlowController:
			FlowController_SetDesiredFlow(eAirFlowController,s_ipcMsgData.data.command.desiredAirFlow);
			break;
		case eSetDesiredO2FlowController:
			FlowController_SetDesiredFlow(eO2FlowController,s_ipcMsgData.data.command.desiredO2Flow);
			break;
		case eSetDesiredExhController:
			ExhController_SetDesired(s_ipcMsgData.data.command.desiredExhPressure);
			break;
		case eSetCurrentAction:
			RS485ProxySensor_SetCurrentAction(s_ipcMsgData.data.command.action);
			break;
		case eComputeProxySensorOffset:
			RS485ProxySensor_SetCurrentAction(s_ipcMsgData.data.command.action);
			break;
		case eSetA11:
			if(gs_realTimeA53ToM4.currentMode==ePcvMixedMode ||
					gs_realTimeA53ToM4.currentMode==ePcvACMode ||
					gs_realTimeA53ToM4.currentMode==ePcvSpontMode)
				CMVController_SetA11(s_ipcMsgData.data.command.aValue);
			else
				if(gs_realTimeA53ToM4.currentMode==eVcvMixedMode ||
						gs_realTimeA53ToM4.currentMode==eVcvACMode ||
						gs_realTimeA53ToM4.currentMode==eVcvSpontMode)
					VCVController_SetA11(s_ipcMsgData.data.command.aValue);
			break;
		case eSetA12:
			if(gs_realTimeA53ToM4.currentMode==ePcvMixedMode ||
					gs_realTimeA53ToM4.currentMode==ePcvACMode ||
					gs_realTimeA53ToM4.currentMode==ePcvSpontMode)
				CMVController_SetA12(s_ipcMsgData.data.command.aValue);
			else
				if(gs_realTimeA53ToM4.currentMode==eVcvMixedMode ||
						gs_realTimeA53ToM4.currentMode==eVcvACMode ||
						gs_realTimeA53ToM4.currentMode==eVcvSpontMode)
					VCVController_SetA12(s_ipcMsgData.data.command.aValue);
			break;
		case eSetA13:
			if(gs_realTimeA53ToM4.currentMode==ePcvMixedMode ||
					gs_realTimeA53ToM4.currentMode==ePcvACMode ||
					gs_realTimeA53ToM4.currentMode==ePcvSpontMode)
				CMVController_SetA13(s_ipcMsgData.data.command.aValue);
			else
				if(gs_realTimeA53ToM4.currentMode==eVcvMixedMode ||
						gs_realTimeA53ToM4.currentMode==eVcvACMode ||
						gs_realTimeA53ToM4.currentMode==eVcvSpontMode)
					VCVController_SetA13(s_ipcMsgData.data.command.aValue);
			break;
		case eSetA14:
			if(gs_realTimeA53ToM4.currentMode==ePcvMixedMode ||
					gs_realTimeA53ToM4.currentMode==ePcvACMode ||
					gs_realTimeA53ToM4.currentMode==ePcvSpontMode)
				CMVController_SetA14(s_ipcMsgData.data.command.aValue);
			else
				if(gs_realTimeA53ToM4.currentMode==eVcvMixedMode ||
						gs_realTimeA53ToM4.currentMode==eVcvACMode ||
						gs_realTimeA53ToM4.currentMode==eVcvSpontMode)
					VCVController_SetA14(s_ipcMsgData.data.command.aValue);
			break;
		case eSetA21:
			if(gs_realTimeA53ToM4.currentMode==ePcvMixedMode ||
					gs_realTimeA53ToM4.currentMode==ePcvACMode ||
					gs_realTimeA53ToM4.currentMode==ePcvSpontMode)
				CMVController_SetA21(s_ipcMsgData.data.command.aValue);
			else
				if(gs_realTimeA53ToM4.currentMode==eVcvMixedMode ||
						gs_realTimeA53ToM4.currentMode==eVcvACMode ||
						gs_realTimeA53ToM4.currentMode==eVcvSpontMode)
					VCVController_SetA21(s_ipcMsgData.data.command.aValue);
			break;
		case eSetA22:
			if(gs_realTimeA53ToM4.currentMode==ePcvMixedMode ||
					gs_realTimeA53ToM4.currentMode==ePcvACMode ||
					gs_realTimeA53ToM4.currentMode==ePcvSpontMode)
				CMVController_SetA22(s_ipcMsgData.data.command.aValue);
			else
				if(gs_realTimeA53ToM4.currentMode==eVcvMixedMode ||
						gs_realTimeA53ToM4.currentMode==eVcvACMode ||
						gs_realTimeA53ToM4.currentMode==eVcvSpontMode)
					VCVController_SetA22(s_ipcMsgData.data.command.aValue);
			break;
		case eSetA23:
			if(gs_realTimeA53ToM4.currentMode==ePcvMixedMode ||
					gs_realTimeA53ToM4.currentMode==ePcvACMode ||
					gs_realTimeA53ToM4.currentMode==ePcvSpontMode)
				CMVController_SetA23(s_ipcMsgData.data.command.aValue);
			else
				if(gs_realTimeA53ToM4.currentMode==eVcvMixedMode ||
						gs_realTimeA53ToM4.currentMode==eVcvACMode ||
						gs_realTimeA53ToM4.currentMode==eVcvSpontMode)
					VCVController_SetA23(s_ipcMsgData.data.command.aValue);
			break;
		case eSetA24:
			if(gs_realTimeA53ToM4.currentMode==ePcvMixedMode ||
					gs_realTimeA53ToM4.currentMode==ePcvACMode ||
					gs_realTimeA53ToM4.currentMode==ePcvSpontMode)
				CMVController_SetA24(s_ipcMsgData.data.command.aValue);
			else
				if(gs_realTimeA53ToM4.currentMode==eVcvMixedMode ||
						gs_realTimeA53ToM4.currentMode==eVcvACMode ||
						gs_realTimeA53ToM4.currentMode==eVcvSpontMode)
					VCVController_SetA24(s_ipcMsgData.data.command.aValue);
			break;
		case eSetFiO2ConversionFactor:
			ADCSensorFiO2_SetConversionFactor(s_ipcMsgData.data.command.conversion.factor,
					s_ipcMsgData.data.command.conversion.offset);
			break;
		case eSetHfoStrokeVol:
			MotorController_SetHFOStrokeVolume(s_ipcMsgData.data.command.strokeVol);
			break;
		case eSetHfoValveOffsetPosition:
			MotorController_SetHFOOffSetPosition(s_ipcMsgData.data.command.offsetPosition);
			break;
		case eSetExhValveLiftOff:
			MotorController_SetLiftOff( eExhMotor,s_ipcMsgData.data.command.liftOff);
			break;
		case eSetAirValveLiftOff:
			MotorController_SetLiftOff( eAirMotor,s_ipcMsgData.data.command.liftOff);
			break;
		case eSetO2ValveLiftOff:
			MotorController_SetLiftOff( eO2Motor,s_ipcMsgData.data.command.liftOff);
			break;
		case eSetHfoValveLiftOff:
			MotorController_SetLiftOff( eHFOMotor,s_ipcMsgData.data.command.liftOff);
			break;
		case eSetDesiredSolenoidState:
			DigitalIO_SetState(s_ipcMsgData.data.command.solenoid.id,
					s_ipcMsgData.data.command.solenoid.state);
			break;
		case eSetExhPressZeroOffset:
			ADCSensorExh_SetZeroOffSet(s_ipcMsgData.data.command.zeroOffset);
			break;
		case eSetInhPressZeroOffset:
			ADCSensorInh_SetZeroOffSet(s_ipcMsgData.data.command.zeroOffset);
			break;
		case eSetRemoteAlarmLow:
			DigitalIO_SetState(eRemoteAlarm,eOffSolenoidValve);
			break;
		case eSetFiO2Offset:
			//None Use
			break;
		case eSetFiO2PassCalibration:
			ADCSensorFiO2_SetIsCalibrated(s_ipcMsgData.data.command.fiO2PassCalibration);
			break;
		case eSetElevationSetting:
			//None Use
			break;
		case eDisableTrigger:
			//None Use
			break;
		case eEnableTrigger:
			//None Use
			break;
		case eProxyVersionGUIEvent:
			//None Use
			break;
		case eLogPostCustomEvent:
			//None Use
			break;
		case eUpdateSettingsHfoServo:
			//None Use
			break;
		default:
			break;
		}
	}
	return;
}

void devIf_Init(void)
{
	s_devTskQueue = xQueueCreate(DEV_QUEUE_LENGTH, sizeof(IpcMessage));
	ADCSensorFiO2_Init();
	HFOServo_Init();
	I2CSensor_Init();
	MotorController_Init();
	RS485ProxySensor_Init();
}
static void devIf_WriteDOutput()
{
    if(DigitalIO_GetState(eProxyFlowResetLine) != DigitalIO_GetDesiredState(eProxyFlowResetLine))
        DigitalIO_SetStateDirect(eProxyFlowResetLine,DigitalIO_GetDesiredState(eProxyFlowResetLine));

    if(DigitalIO_GetState(eExhPressureZero) != DigitalIO_GetDesiredState(eExhPressureZero))
        DigitalIO_SetStateDirect(eExhPressureZero,DigitalIO_GetDesiredState(eExhPressureZero));

    if(DigitalIO_GetState(eInhPressureZero) != DigitalIO_GetDesiredState(eInhPressureZero))
        DigitalIO_SetStateDirect(eInhPressureZero,DigitalIO_GetDesiredState(eInhPressureZero));

    if(DigitalIO_GetState(eSafetyValve) != DigitalIO_GetDesiredState(eSafetyValve))
        DigitalIO_SetStateDirect(eSafetyValve,DigitalIO_GetDesiredState(eSafetyValve));

    if(DigitalIO_GetState(eImpedanceLine) != DigitalIO_GetDesiredState(eImpedanceLine))
        DigitalIO_SetStateDirect(eImpedanceLine,DigitalIO_GetDesiredState(eImpedanceLine));

    if(DigitalIO_GetState(ePurgeFlow) != DigitalIO_GetDesiredState(ePurgeFlow))
        DigitalIO_SetStateDirect(ePurgeFlow,DigitalIO_GetDesiredState(ePurgeFlow));

    if(DigitalIO_GetState(eRemoteAlarm) != DigitalIO_GetDesiredState(eRemoteAlarm))
        DigitalIO_SetStateDirect(eRemoteAlarm,DigitalIO_GetDesiredState(eRemoteAlarm));

    if(DigitalIO_GetState(eEnableIO) != DigitalIO_GetDesiredState(eEnableIO))
        DigitalIO_SetStateDirect(eEnableIO,DigitalIO_GetDesiredState(eEnableIO));

    if(DigitalIO_GetState(eOilPump) != DigitalIO_GetDesiredState(eOilPump))
        DigitalIO_SetStateDirect(eOilPump,DigitalIO_GetDesiredState(eOilPump));
}
void devIf_Run()
{
	static uint8_t s_timer10ms=0;
	I2CSensorAirFlow_GetCurrentReading();
	I2CSensorO2Flow_GetCurrentReading();
	ADCSensorExh_GetCurrentReading();
	ADCSensorInh_GetCurrentReading();
	ActivePressureSensor_Run();
	ADCSensorFiO2_GetCurrentVolt();
	if(s_timer10ms<(10/DEVICE_TASK_DELAY_TIME))
	{
		RS485ProxySensor_CommunicateProxySensor();
		devIf_WriteDOutput();
        if(ADCSensorFiO2_IsO2SensorConnect() == eTrue)
        	ADCSensorFiO2_AddCounts();
		s_timer10ms = 0;
	}
	else
	{
		s_timer10ms++;
	}
	ProxyStatus proxyStatus = RS485ProxySensor_GetLastStatus();
	if((proxyStatus ==eCalibrated)||(proxyStatus==eResetAndRecovered))
	{
		RS485ProxySensor_GetCurrentStatus();
	}
	HFOServo_Run();
	HFOController_Run();
	CMVController_Run();
	VCVController_Run();
	FlowController_Run(eAirFlowController);
	FlowController_Run(eO2FlowController);
	NCPAPController_Run();
	ADCSensorFiO2_ReadVoltageValue();

}
IpcRealTimeDataM4ToA53* devIf_UpdateMonitorStruct(void)
{
	gs_realTimeM4ToA53.activePress.currentReading = ActivePressureSensor_GetLastReading();
	gs_realTimeM4ToA53.activePress.currentVolt = ActivePressureSensor_GetLastVoltage();
	gs_realTimeM4ToA53.activePress.lastReading = ActivePressureSensor_GetLastReading();
	gs_realTimeM4ToA53.activePress.lastVolt = ActivePressureSensor_GetLastVoltage();
	gs_realTimeM4ToA53.airFlow.currentReading = I2CSensorAirFlow_GetLastReading();
	gs_realTimeM4ToA53.airFlow.currentVolt = 0;
	gs_realTimeM4ToA53.airFlow.lastReading = I2CSensorAirFlow_GetLastReading();
	gs_realTimeM4ToA53.airFlow.lastVolt = 0;
	gs_realTimeM4ToA53.airPressSwitch.state = DigitalIO_GetSwitchState(eAirSw);
	gs_realTimeM4ToA53.airPressSwitch.stateDirect = DigitalIO_GetSwitchState(eAirSw);
	gs_realTimeM4ToA53.airValve.liftOff=130;//MotorController_GetLiftOff(eAirMotor);
	gs_realTimeM4ToA53.airValve.maxStep=140;//MotorController_GetMaxStep(eAirMotor);
	gs_realTimeM4ToA53.airValve.stepPosition=150;//(MotorController_GetLastStepPosition(eAirMotor)/MAX_STEP_POSITION_CURRENT)*MAX_STEP_POSITION_OLD;
	gs_realTimeM4ToA53.exhPress.currentReading = ADCSensorExh_GetLastReading();
	gs_realTimeM4ToA53.exhPress.currentVolt = ADCSensorExh_GetLastVolt();
	gs_realTimeM4ToA53.exhPress.lastReading = ADCSensorExh_GetLastReading();
	gs_realTimeM4ToA53.exhPress.lastVolt = ADCSensorExh_GetLastVolt();
	gs_realTimeM4ToA53.exhPressureZero.state = DigitalIO_GetState(eExhPressureZero);
	gs_realTimeM4ToA53.exhPressureZero.desiredState = DigitalIO_GetDesiredState(eExhPressureZero);
	gs_realTimeM4ToA53.exhValve.liftOff = 100;//MotorController_GetLiftOff(eExhMotor);
	gs_realTimeM4ToA53.exhValve.maxStep = 110;//MotorController_GetMaxStep(eExhMotor);
	gs_realTimeM4ToA53.exhValve.stepPosition = 120;//(MotorController_GetLastStepPosition(eExhMotor)/MAX_STEP_POSITION_CURRENT)*MAX_STEP_POSITION_OLD;
	gs_realTimeM4ToA53.fio2.avgFlow = ADCSensorFiO2_AvgFlow();
	gs_realTimeM4ToA53.fio2.avgPress = ADCSensorFiO2_AvgPress();
	gs_realTimeM4ToA53.fio2.currentReading = ADCSensorFiO2_GetCurrentReading();
	gs_realTimeM4ToA53.fio2.currentVolt = ADCSensorFiO2_GetLastVolt();
	gs_realTimeM4ToA53.fio2.isO2SensorConnected = ADCSensorFiO2_IsO2SensorConnect();
	gs_realTimeM4ToA53.fio2.isPresent = ADCSensorFiO2_GetIsPresent();
	gs_realTimeM4ToA53.fio2.lastVolt = ADCSensorFiO2_GetLastVolt();
	gs_realTimeM4ToA53.hardware.checkFlowSensor = I2CSensorO2Flow_CheckSensor() || I2CSensorAirFlow_CheckSensor();
	gs_realTimeM4ToA53.hfoDoorSwitch.state =DigitalIO_GetSwitchState(ePistonSW);
	gs_realTimeM4ToA53.hfoDoorSwitch.stateDirect =DigitalIO_GetSwitchState(ePistonSW);
	gs_realTimeM4ToA53.hfoPistonSwitch.state = DigitalIO_GetSwitchState(ePistonSW);
	gs_realTimeM4ToA53.hfoPistonSwitch.stateDirect = DigitalIO_GetSwitchState(ePistonSW);
	gs_realTimeM4ToA53.hfoValve.liftOff = MotorController_GetLiftOff(eHFOMotor);
	gs_realTimeM4ToA53.hfoValve.maxStep = MotorController_GetMaxStep(eHFOMotor);
	gs_realTimeM4ToA53.hfoValve.stepPosition = HFOServo_HFOMotorGetCurrentStepPosition();
	gs_realTimeM4ToA53.impedanceLine.state = DigitalIO_GetState(eImpedanceLine);
	gs_realTimeM4ToA53.impedanceLine.desiredState = DigitalIO_GetDesiredState(eImpedanceLine);
	gs_realTimeM4ToA53.inhPress.currentReading = ADCSensorInh_GetLastReading();
	gs_realTimeM4ToA53.inhPress.currentVolt = ADCSensorInh_GetLastVolt();
	gs_realTimeM4ToA53.inhPress.lastReading = ADCSensorInh_GetLastReading();
	gs_realTimeM4ToA53.inhPress.lastVolt = ADCSensorInh_GetLastVolt();
	gs_realTimeM4ToA53.inhPressureZero.state = DigitalIO_GetState(eInhPressureZero);
	gs_realTimeM4ToA53.inhPressureZero.desiredState = DigitalIO_GetDesiredState(eInhPressureZero);
	gs_realTimeM4ToA53.manualBreathConnection.state = eOn;
	gs_realTimeM4ToA53.manualBreathConnection.stateDirect = eOn;
	gs_realTimeM4ToA53.manualBreathInput.state = DigitalIO_GetState(eManualBreathInput);
	gs_realTimeM4ToA53.manualBreathInput.stateDirect = DigitalIO_GetDesiredState(eManualBreathInput);
	gs_realTimeM4ToA53.o2Flow.currentReading = I2CSensorO2Flow_GetLastReading();
	gs_realTimeM4ToA53.o2Flow.currentVolt = 0;
	gs_realTimeM4ToA53.o2Flow.lastReading = I2CSensorO2Flow_GetLastReading();
	gs_realTimeM4ToA53.o2Flow.lastVolt = 0;
	gs_realTimeM4ToA53.o2PressSwitch.state = DigitalIO_GetSwitchState(eO2Sw);
	gs_realTimeM4ToA53.o2PressSwitch.stateDirect = DigitalIO_GetSwitchState(eO2Sw);
	gs_realTimeM4ToA53.o2Valve.liftOff = MotorController_GetLiftOff(eO2Motor);
	gs_realTimeM4ToA53.o2Valve.maxStep = MotorController_GetMaxStep(eO2Motor);
	gs_realTimeM4ToA53.o2Valve.stepPosition = (MotorController_GetLastStepPosition(eO2Motor)/MAX_STEP_POSITION_CURRENT)*MAX_STEP_POSITION_OLD;
	gs_realTimeM4ToA53.oilPump.desiredState = DigitalIO_GetDesiredState(eOilPump);
	gs_realTimeM4ToA53.oilPump.state = DigitalIO_GetState(eOilPump);
	gs_realTimeM4ToA53.proxy.currentReading = RS485ProxySensor_GetLastReading();
	gs_realTimeM4ToA53.proxy.isNeedVersion = RS485ProxySensor_IsNeedToGetVersionStr();
	gs_realTimeM4ToA53.proxy.isOKToShutDown = RS485ProxySensor_OkToShutdown();
	gs_realTimeM4ToA53.proxy.lastStatus = RS485ProxySensor_GetLastStatus();
	gs_realTimeM4ToA53.proxyFlowResetLine.desiredState = DigitalIO_GetDesiredState(eProxyFlowResetLine);
	gs_realTimeM4ToA53.proxyFlowResetLine.state = DigitalIO_GetState(eProxyFlowResetLine);
	gs_realTimeM4ToA53.purgeFlow.desiredState = DigitalIO_GetDesiredState(ePurgeFlow);
	gs_realTimeM4ToA53.purgeFlow.state = DigitalIO_GetState(ePurgeFlow);
	gs_realTimeM4ToA53.safetyValve.desiredState = DigitalIO_GetDesiredState(eSafetyValve);
	gs_realTimeM4ToA53.safetyValve.state = DigitalIO_GetState(eSafetyValve);
	gs_realTimeM4ToA53.vcvInhVolume = VCVController_GetInhVol();
	return &gs_realTimeM4ToA53;
}

