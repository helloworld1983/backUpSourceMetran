/*
 * ActivePressureSensor.c
 *
 *  Created on: 2 thg 1, 2019
 *      Author: haxua
 */
#include "ActivePressureSensor.h"
#include "ADCSensor.h"
static E_ActivePressType gs_CurrentPressSensorType = eInhPressSensorType;
static int32_t gs_CurrentInhPress=0;
static int32_t gs_CurrentExhPress=0;
static float gs_CurrentInhVoltage=0;
static float gs_CurrentExhVoltage=0;
void ActivePressureSensor_Run()
{
	gs_CurrentInhPress=ADCSensorInh_GetLastReading();
	gs_CurrentExhPress=ADCSensorExh_GetLastReading();
	gs_CurrentInhVoltage=ADCSensorInh_GetLastVolt();
	gs_CurrentExhVoltage=ADCSensorExh_GetLastVolt();
}
void ActivePressureSensor_SetPrimary(E_ActivePressType type)
{
	gs_CurrentPressSensorType = type;
}
int32_t ActivePressureSensor_GetLastReading()
{
	if(gs_CurrentPressSensorType==eInhPressSensorType)
	{
		return gs_CurrentInhPress;
	}
	else
	{
		return gs_CurrentExhPress;
	}
}
float ActivePressureSensor_GetLastVoltage()
{
	if(gs_CurrentPressSensorType==eInhPressSensorType)
	{
		return gs_CurrentInhVoltage;
	}
	else
	{
		return gs_CurrentExhVoltage;
	}
}
