/*
 * DeviceInterface.h
 *
 *  Created on: Dec 25, 2018
 *      Author: qsbk0
 */

#ifndef DEVICE_DEVICEINTERFACE_H_
#define DEVICE_DEVICEINTERFACE_H_

#include "ipc/IpcInterface.h"

void devIf_HandleMsgQueueRecv(void);
bool devIf_sendMsg(IpcMessage* msg);
void devIf_Init(void);
void devIf_Run();
HFOSetting* const  devIf_getHFOSetting();
PCVSetting* const  devIf_getPCVSetting();
VCVSetting* const  devIf_getVCVSetting();
IpcRealTimeDataA53ToM4* const  devIf_getIPCRealTimeDataA53ToM4();
IpcRealTimeDataM4ToA53* devIf_UpdateMonitorStruct(void);
#endif /* DEVICE_DEVICEINTERFACE_H_ */
