/*
 * DeviceTask.c
 *
 *  Created on: Dec 3, 2018
 *      Author: qsbk0
 */
#include "FreeRTOS.h"
#include "task.h"
#include "fsl_uart.h"
#include "fsl_debug_console.h"
#include "DeviceTask.h"
#include "RS485Sensor.h"
#include "uart.h"
#include "spi.h"
#include "i2c.h"
#include "DeviceInterface.h"
#include "Delay.h"
#include "ipc_task.h"
#define DEVICE_TASK_STACK_SIZE 512
static TaskHandle_t s_devTaskHandle = NULL;
static void devTsk_loop(void *param)
{
	devTsk_Init();
	for (;;)
	{
		devIf_HandleMsgQueueRecv();
//		devIf_Run();
		IpcRealTimeDataM4ToA53* ptr = devIf_UpdateMonitorStruct();
		IpcMessage sendMsg;
		sendMsg.type = eRealTime;
		memcpy(&sendMsg.data,ptr,sizeof(IpcData));
		ipc_sendMsg(&sendMsg);
		vTaskDelay(DEVICE_TASK_DELAY_TIME/portTICK_PERIOD_MS);
	}
	return;
}

/*!
 * @brief ipc_create function
 */
void devTsk_Create(void)
{
	devIf_Init();
	if (xTaskCreate(devTsk_loop, "DEV_TASK", DEVICE_TASK_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, &s_devTaskHandle) != pdPASS)
	{
		PRINTF("\r\nFailed to create application task\r\n");
		while (1)
			;
	}
	return;
}

void devTsk_Init(void)
{
	devIf_Init();
}
