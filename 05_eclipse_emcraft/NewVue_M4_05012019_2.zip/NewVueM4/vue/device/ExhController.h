/*
 * ExhController.h
 *
 *  Created on: 2 thg 1, 2019
 *      Author: haxua
 */

#ifndef DEVICE_EXHCONTROLLER_H_
#define DEVICE_EXHCONTROLLER_H_
#include "stdbool.h"
#include "stdint.h"
void ExhController_Disable();
void ExhController_Enable();
bool ExhController_IsEnable();
void ExhController_Reset();
void ExhController_Run();
void ExhController_SetDesired(int32_t rate);


#endif /* DEVICE_EXHCONTROLLER_H_ */
