/*
 * FlowController.c
 *
 *  Created on: 2 thg 1, 2019
 *      Author: haxua
 */
#include "FlowController.h"
#include "MotorController.h"
static const int16_t SERVO_RATE = 500;
static const uint32_t FLOW_SCALE = 3000;//3000
static const int16_t SERVO_SCALE = 8;
static int32_t gs_DesiredAirFlow = 0;
static int32_t gs_DesiredO2Flow = 0;
static bool gs_isEnabledAirFlow = false;
static bool gs_isEnabledO2Flow = false;
static int32_t gs_PreviousMesuredAirFlow = 0;
static int32_t gs_PreviousMesuredO2Flow = 0;
static int32_t gs_CurrentMesuredAirFlow = 0;
static int32_t gs_CurrentMesuredO2Flow = 0;
static int32_t gs_OutputValueAirFlow = 0;
static int32_t gs_OutputValueO2Flow = 0;
static int32_t gs_FirstIntegratorO2=0;
static int32_t gs_FirstIntegratorAir=0;
static int16_t gs_Speed =40;//40
void FlowController_SetStaticAgr(E_FlowControllerId flowController,int32_t step)
{
	int32_t step_t = step*FLOW_SCALE;
	switch(flowController)
	{
	case eAirFlowController:
		gs_FirstIntegratorAir = (int32_t)((int32_t)(step_t/gs_Speed))<<SERVO_SCALE;

		break;
	case eO2FlowController:
		gs_FirstIntegratorO2 = (int32_t)((int32_t)(step_t/gs_Speed))<<SERVO_SCALE;

		break;
	default:
		break;
	}
}
void FlowController_SetDesiredFlow(E_FlowControllerId flowController, int32_t rate)
{
	switch(flowController)
	{
	case eAirFlowController:
		gs_DesiredAirFlow = rate;
		break;
	case eO2FlowController:
		gs_DesiredO2Flow = rate;
		break;
	default:
		break;
	}
}
void FlowController_SetEnable(E_FlowControllerId flowController,bool isEnabled)
{
	switch(flowController)
	{
	case eAirFlowController:
		gs_isEnabledAirFlow = isEnabled;
		break;
	case eO2FlowController:
		gs_isEnabledO2Flow = isEnabled;
		break;
	default:
		break;
	}
}
void FlowController_Run(E_FlowControllerId flowController)
{
	switch(flowController)
	{
	case eAirFlowController:
		if(gs_isEnabledAirFlow==true)
		{
			gs_PreviousMesuredAirFlow = gs_CurrentMesuredAirFlow;
			gs_CurrentMesuredAirFlow = I2CSensorAirFlow_GetLastReading();
			FlowController_Calculate(eAirFlowController);
		}
		break;
	case eO2FlowController:
		if(gs_isEnabledO2Flow==true)
		{
			gs_PreviousMesuredO2Flow = gs_CurrentMesuredO2Flow;
			gs_CurrentMesuredO2Flow = I2CSensorO2Flow_GetLastReading();
			FlowController_Calculate(eO2FlowController);
		}
		break;
	default:
		break;
	}
}
void FlowController_Calculate(E_FlowControllerId flowController)
{
	switch (flowController) {
	case eAirFlowController:
		gs_OutputValueAirFlow=FlowController_CompStepAirFlow();
		if(gs_OutputValueAirFlow<MotorController_GetLiftOff(eAirMotor))
		{
			gs_OutputValueAirFlow = MotorController_GetLiftOff(eAirMotor);
		}
		MotorController_MoveToStepPositionOld(eAirMotor,gs_OutputValueAirFlow);
		break;
	case eO2FlowController:
		gs_OutputValueO2Flow=FlowController_CompStepO2Flow();
		if(gs_OutputValueO2Flow<MotorController_GetLiftOff(eO2Motor))
		{
			gs_OutputValueO2Flow = MotorController_GetLiftOff(eO2Motor);
		}
		MotorController_MoveToStepPositionOld(eO2Motor,gs_OutputValueO2Flow);
		break;
	default:
		break;
	}
}
int32_t FlowController_CompStepAirFlow()
{
	int32_t error, errorGain, scaleDownIntegrator, preFilterOutput, valStep;
	int32_t scaleUpInput;

	error = gs_DesiredAirFlow - gs_CurrentMesuredAirFlow;

	errorGain = error * 100;

	scaleUpInput =  errorGain / SERVO_RATE ;
	scaleUpInput = (int32_t) (scaleUpInput << SERVO_SCALE )*3;

	scaleDownIntegrator = (int32_t) (gs_FirstIntegratorAir >> SERVO_SCALE);

	preFilterOutput = scaleDownIntegrator * gs_Speed;

	preFilterOutput /= (int16_t)FLOW_SCALE;

	if ( preFilterOutput >= MAX_STEP_POSITION_OLD)
	{
		if ( errorGain <= 0 )
		{
			gs_FirstIntegratorAir += scaleUpInput ;
		}
		preFilterOutput = MAX_STEP_POSITION_OLD;
	}
	else if ( preFilterOutput <= 0 )
	{
		if ( errorGain >= 0 )
		{
			gs_FirstIntegratorAir += scaleUpInput ;
		}
		preFilterOutput = 0;
	}
	else
	{
		gs_FirstIntegratorAir += scaleUpInput ;
	}

	valStep = preFilterOutput;

	return valStep;
}
void FlowController_Reset(E_FlowControllerId flowController)
{
	switch (flowController) {
	case eAirFlowController:
		gs_FirstIntegratorAir=0;
		break;
	case eO2FlowController:
		gs_FirstIntegratorO2=0;
		break;
	default:
		break;
	}
}
int32_t FlowController_CompStepO2Flow()
{
	int32_t error, errorGain, scaleDownIntegrator, preFilterOutput, valStep;
	int32_t scaleUpInput;

	error = gs_DesiredO2Flow - gs_CurrentMesuredO2Flow;
	errorGain = error * 100;

	scaleUpInput =  errorGain / SERVO_RATE ;
	scaleUpInput = (int32_t) (scaleUpInput << SERVO_SCALE )*3;

	scaleDownIntegrator = (int32_t) (gs_FirstIntegratorO2 >> SERVO_SCALE);

	preFilterOutput = scaleDownIntegrator * gs_Speed;

	preFilterOutput /= (int16_t)FLOW_SCALE;

	if ( preFilterOutput >= MAX_STEP_POSITION_OLD)
	{
		if ( errorGain <= 0 )
		{
			gs_FirstIntegratorO2 += scaleUpInput ;
		}
		preFilterOutput = MAX_STEP_POSITION_OLD;
	}
	else if ( preFilterOutput <= 0 )
	{
		if ( errorGain >= 0 )
		{
			gs_FirstIntegratorO2 += scaleUpInput ;
		}
		preFilterOutput = 0;
	}
	else
	{
		gs_FirstIntegratorO2 += scaleUpInput ;
	}

	valStep = preFilterOutput;

	return valStep;
}

