/*
 * FlowController.h
 *
 *  Created on: 2 thg 1, 2019
 *      Author: haxua
 */

#ifndef DEVICE_FLOWCONTROLLER_H_
#define DEVICE_FLOWCONTROLLER_H_
#include "stdbool.h"
#include "stdint.h"
#include "ipc/IpcInterface.h"

void FlowController_SetDesiredFlow(E_FlowControllerId flowController, int32_t rate);
void FlowController_SetEnable(E_FlowControllerId flowController,bool isEnabled);
void FlowController_Run(E_FlowControllerId flowController);
void FlowController_Calculate(E_FlowControllerId flowController);
int32_t FlowController_CompStepAirFlow();
int32_t FlowController_CompStepO2Flow();
void FlowController_Reset(E_FlowControllerId flowController);
void FlowController_SetStaticAgr(E_FlowControllerId flowController,int32_t step);


#endif /* DEVICE_FLOWCONTROLLER_H_ */
