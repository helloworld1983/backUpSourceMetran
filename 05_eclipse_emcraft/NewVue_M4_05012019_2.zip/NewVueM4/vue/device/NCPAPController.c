/*
 * NCPAPController.c
 *
 *  Created on: 2 thg 1, 2019
 *      Author: haxua
 */
#include "NCPAPController.h"
#include "stdbool.h"
#include "MotorController.h"
#include "FlowController.h"
#include "DeviceInterface.h"
#define MIN_STEP_POSITION 0
#define VALVE_FTR_CONST     100
#define iDT                500           //200 for 5ms interval, 500 for 2ms interval
static bool gs_IsEnabled=false;
static int32_t gs_IntExValveFtr = 0;
static int32_t gs_TargetFlow = 0;
static const uint16_t gs_Scalen        =    8;

void NCPAPController_Run()
{
	if(gs_IsEnabled==true)
	{
		NCPAPController_Calculate();
	}
	else
		return;
}
void NCPAPController_CalculateAirO2Flow(int32_t totalFlow,int32_t* desiredAirFlow,int32_t* desiredO2Flow)
{
    *desiredAirFlow = totalFlow;
    *desiredO2Flow = 0;
}
void NCPAPController_Calculate()
{
	int32_t desiredAirFlow=0;
	int32_t desiredO2Flow=0;

	MotorController_MoveToStepPositionOld(eExhMotor,NCPAPController_ExValveFilter(MIN_STEP_POSITION));
	FlowController_SetDesiredFlow(eAirFlowController,devIf_getIPCRealTimeDataA53ToM4()->desiredAirFlow);
	FlowController_SetDesiredFlow(eO2FlowController,devIf_getIPCRealTimeDataA53ToM4()->desiredO2Flow);
}
void NCPAPController_SetTargetFlow(int32_t value)
{
	gs_TargetFlow = value;
}
void NCPAPController_ResetIMVStaticVariables()
{

}
int16_t NCPAPController_ExValveFilter(int16_t u)
{
    int32_t Temp32;
    int16_t Error,Output;

    Output = (int16_t)(gs_IntExValveFtr>>gs_Scalen);
    Error = u - Output;
    Temp32 = Error;
    Temp32 = Temp32<<gs_Scalen;
    gs_IntExValveFtr += (int32_t)Temp32*VALVE_FTR_CONST/iDT;

    return(Output);
}
void NCPAPController_Enable()
{
	gs_IsEnabled=true;
}
void NCPAPController_Disable()
{
	gs_IsEnabled=false;
}

