/*
 * RS485Sensoe.c
 *
 *  Created on: 11-10-2018
 *      Author: haxua
 */
#include "RS485Sensor.h"
#include "DebugTrace.h"
#include "Delay.h"
#include "uart.h"
#include "board/board.h"
#include "ipc/IpcInterface.h"
#include "ipc/ipc_task.h"
//define for UART4 - Proxymal flow sensor SFM300
#define PROXY_FS_UART              4
#define PROXY_BAUD_RATE                   (115200U)          //Baud rate

//define for SHDLC protocol( Protocol of Flow sensor)
#define START_BYTE                  (0x7E)          //Start byte of SHDLC Frame
#define STOP_BYTE                   (0x7E)          //Stop byte of SHDLC Frame
#define START_STOP_BYTE             (0x7E)          //Special byte of SHDLC Frame
#define XON_BYTE                    (0x11)          //Special byte of SHDLC Frame
#define XOFF_BYTE                   (0x13)          //Special byte of SHDLC Frame
#define ESCAPE_BYTE                 (0x7D)          //Special byte of SHDLC Frame

#define ESCAPE_ADD_BYTE             (0x5D)          //Special byte of SHDLC Frame
#define START_STOP_ADD_BYTE         (0x5E)          //Special byte of SHDLC Frame
#define XON_ADD_BYTE                (0x31)          //Special byte of SHDLC Frame
#define XOFF_ADD_BYTE               (0x33)          //Special byte of SHDLC Frame

#define BIT_WISE                    (0xFF)          //BIT_WISE to calculate CheckSume
#define BUFFER_SIZE					270
#define TIME_TO_SEND_ONE_BYTE 	    85 //80 uc

//User for SHDLC Protocol
//static uint8_t Rx_Buff[UART_RRB_SIZE], Tx_Buff[UART_SRB_SIZE];
typedef struct
{
	//$COMMON.ATTRIBUTE$
	//    Name: Address
	//    Description: Device address of slave which is send
	//    Range: 0 - 255
	uint8_t Address;

	//$COMMON.ATTRIBUTE$
	//    Name: CMD
	//    Description: Commend ID
	//    Range: None
	uint8_t CMD;

	//$COMMON.ATTRIBUTE$
	//    Name: LengTH
	//    Description: Length of data fields
	//    Range: None
	uint8_t LengTH;

	//$COMMON.ATTRIBUTE$
	//    Name: Data
	//    Description: Data
	//    Range: None
	uint8_t Data[255];

}ProxySensorSendFrameData;

typedef struct
{
	//$COMMON.ATTRIBUTE$
	//    Name: Address
	//    Description: Device address of slave which is receive
	//    Range: 0 - 255
	uint8_t Address;

	//$COMMON.ATTRIBUTE$
	//    Name: CMD
	//    Description: Commend ID
	//    Range: None
	uint8_t CMD;

	//$COMMON.ATTRIBUTE$
	//    Name: State
	//    Description: The slave sends a state byte to report execution errors
	//    Range: None
	uint8_t State;

	//$COMMON.ATTRIBUTE$
	//    Name: LengTH
	//    Description: Length of data fields
	//    Range: None
	uint8_t LengTH;

	//$COMMON.ATTRIBUTE$
	//    Name: Data
	//    Description: Data
	//    Range: None
	uint8_t Data[255];

}ProxySensorRecFrameData;

static ProxyStatus gs_Status = eNotCalibrated;
static ProxyActions gs_ProxyTitle = eGetProxyStatus;
static uint8_t gs_StatusFromSensor=0x00;
static uint8_t gs_DataLengthReceiveFromSensor=0x00;
static bool gs_IsGotVersionStr=false;
static uint8_t gs_VersionStr[7]={'\0'};
static bool gs_IsOkToShutdown = false;
static int32_t gs_CurrentReading = 0;
static bool gs_IsGetOffSetActive = false;
static uint8_t gs_GetOffSetCnt = 0;
static float gs_GetOffSetSum = 0;
static float gs_Offset = 0;
static uint8_t RS485ProxySensor_CalcCRC(uint8_t* pBuf, uint32_t uSize)
{
	uint64_t SumAllByte = 0;
	uint8_t LeastSignificantByte = 0;
	uint8_t InvertLeastSignificantByte = 0;

	//sum all bytes in the frame content (from and including Adr to and including Data)
	for(unsigned int i = 0; i < uSize; ++i){
		SumAllByte = SumAllByte + pBuf[i];
	}

	//take the least significant byte of this sum
	LeastSignificantByte = (uint8_t)(SumAllByte & BIT_WISE);

	//invert the least significant byte
	InvertLeastSignificantByte = LeastSignificantByte ^ BIT_WISE;

	return InvertLeastSignificantByte;
}
static void RS485ProxySensor_GenerateFrameData(ProxySensorSendFrameData *data, uint8_t *FrameData, uint32_t* SizeOfFrameData)
{
	const uint32_t THE_NUMBER_OF_START_BLOCK = 1;
	//check input and output data is valid
	ASSERTION(NULL != data);
	ASSERTION(NULL != FrameData);
	uint16_t byte = 0;

	//initialize a temporary buffer to store Frame data
	uint8_t TempFrameData[BUFFER_SIZE];

	//The byte 0x7E marks the beginning of the frame
	TempFrameData[byte]=(START_BYTE);
	byte++;
	//Device Address of the slave
	TempFrameData[byte]=(data->Address);
	byte++;
	//Command ID of the command
	TempFrameData[byte]=(data->CMD);
	byte++;
	//Indicates the number of bytes sent in the Data block
	TempFrameData[byte]=(data->LengTH);
	byte++;
	//The data format depends on the command
	for(uint32_t i = 0; i < data->LengTH; ++i)
	{
		TempFrameData[byte]=(data->Data[i]);
		byte++;
	}

	//initialize a buffer to calculate Check sum
	//Size of buffer
	const uint32_t BufferSize = data->LengTH+3;
	uint8_t TempBuff[BufferSize];
	for(uint32_t i = 0; i < BufferSize; ++i)
	{
		TempBuff[i] = TempFrameData[THE_NUMBER_OF_START_BLOCK + i];
	}
	//Check sum over the frame content
	TempFrameData[byte]=RS485ProxySensor_CalcCRC(TempBuff,BufferSize);
	byte++;
	//The second byte 0x7E marks the end of the frame
	TempFrameData[byte]=STOP_BYTE;

	//Update size of Frame Data to output parameter
	*SizeOfFrameData = byte+1;

	//Copy Frame Data to output parameter
	for(uint32_t i = 0; i < *SizeOfFrameData; ++i)
	{
		FrameData[i] = TempFrameData[i];
	}
}
static void RS485ProxySensor_ConvertByteArrayToSend (uint8_t* pSourceByte,
		uint32_t uSourceSize,
		uint8_t* pDesByte,
		uint64_t* uDesSizeByte)
{

	ASSERTION(NULL != pSourceByte);
	ASSERTION(NULL != pDesByte);

	const uint8_t NUMBER_OF_START_BYTE = 1;
	const uint8_t NUMBER_OF_STOP_BYTE = 1;
	uint16_t byte = 0;
	uint8_t TempBuf[uSourceSize*2];
	//Ignore START_BYTE(0x7E);
	TempBuf[byte]=(START_BYTE);
	byte++;
	//Convert data if it has special bytes
	for(uint32_t i = (0 + NUMBER_OF_START_BYTE); i < (uSourceSize - NUMBER_OF_STOP_BYTE); ++i)
	{
		switch (pSourceByte[byte])
		{
		//Replace  0x7E   =   0x7D, 0x5E
		case START_STOP_BYTE:
			TempBuf[byte]=(ESCAPE_BYTE);
			byte++;
			TempBuf[byte]=(START_STOP_ADD_BYTE);
			byte++;
			break;
			//Replace 0x7D  =  0x7D, 0x5D
		case ESCAPE_BYTE:
			TempBuf[byte]=(ESCAPE_BYTE);
			byte++;
			TempBuf[byte]=(ESCAPE_ADD_BYTE);
			byte++;
			break;
			//Replace 0x11  =  0x7D, 0x31
		case XON_BYTE:
			TempBuf[byte]=(ESCAPE_BYTE);
			byte++;
			TempBuf[byte]=(XON_ADD_BYTE);
			byte++;
			break;
			//Replace 0x13  =  0x7D, 0x33
		case XOFF_BYTE:
			TempBuf[byte]=(ESCAPE_BYTE);
			byte++;
			TempBuf[byte]=(XOFF_ADD_BYTE);
			byte++;
			break;
			//IF it is not a special byte
		default:
			TempBuf[byte]=(pSourceByte[i]);
			byte++;
			break;
		}
	}

	//Ignore STOP_BYTE(0x7E)
	TempBuf[byte]=(STOP_BYTE);

	//Update size of pDesByte
	*uDesSizeByte = byte+1;

	//Copy data to pDesByte
	for(uint32_t i = 0; i < *uDesSizeByte; ++i)
	{
		pDesByte[i] = TempBuf[i];
	}

}
static void RS485ProxySensor_SendDataToUART (void* data, int bytes)
{
	uart_Write(PROXY_FS_UART, data, bytes);
}
static int32_t RS485ProxySensor_ReadDataFromUART (void* pData, int iBytes)
{
	// Returns -1 if there is
	// error.
	return uart_Read(PROXY_FS_UART,pData, iBytes);
}
static void RS485ProxySensor_StartContinuousMeasurement()
{
	int32_t stat = 0;
	uint8_t recData[32] = {0};

	ProxySensorSendFrameData StartContMeas;

	StartContMeas.Address = 0x00;
	StartContMeas.CMD = 0x33;
	StartContMeas.LengTH = 0x02;

	StartContMeas.Data[0] = 0x00;
	StartContMeas.Data[1] = 0x00;


	uint8_t StartContinuousMeasurement[6 + StartContMeas.LengTH];
	uint32_t SizeofStartContinuousMeasurement = 0;
	const uint16_t TempDataBufferSize=600;
	uint8_t TempData[TempDataBufferSize];
	uint64_t TempSize = 0;

	RS485ProxySensor_GenerateFrameData(&StartContMeas, StartContinuousMeasurement, &SizeofStartContinuousMeasurement);
	RS485ProxySensor_ConvertByteArrayToSend(StartContinuousMeasurement, SizeofStartContinuousMeasurement,TempData,&TempSize);
	DEBUG_RS485SENSOR("SEND = ");
	for(uint64_t i  = 0; i  < TempSize; ++i)
	{
		DEBUG_RS485SENSOR("%x \n", TempData[i]);
	}
	RS485ProxySensor_SendDataToUART(TempData, TempSize);

	stat = RS485ProxySensor_ReadDataFromUART(recData, 32);
	DEBUG_RS485SENSOR("REC = ");
	for(int i  = 0; i  < 32; ++i)
	{
		DEBUG_RS485SENSOR("%x \n", recData[i]);
	}
}
static float RS485ProxySensor_GetProxyFlow(void)
{
	static float s_FlowValue = 0;
	//	static bool s_IsMeasure=true;
	//	if(s_IsMeasure==true)
	//	{
	int num = 0;
	uint8_t recData[32] = {0};

	ProxySensorSendFrameData GetLastMeasure;

	GetLastMeasure.Address = 0x00;
	GetLastMeasure.CMD = 0x35;
	GetLastMeasure.LengTH = 0x00;

	uint8_t GetLastArr[6 + GetLastMeasure.LengTH];
	uint32_t SizeofGetLastArr = 0;
	const uint16_t TempDataBufferSize=600;
	uint8_t TempData[TempDataBufferSize];
	uint64_t TempSize = 0;

	RS485ProxySensor_GenerateFrameData(&GetLastMeasure, GetLastArr, &SizeofGetLastArr);
	RS485ProxySensor_ConvertByteArrayToSend(GetLastArr, SizeofGetLastArr, TempData,&TempSize);
	DEBUG_RS485SENSOR("SEND = ");
	for(uint64_t i  = 0; i  < TempSize; ++i)
	{
		DEBUG_RS485SENSOR("%x \n", TempData[i]);
	}
	num=RS485ProxySensor_ReadDataFromUART(recData, 32);
	RS485ProxySensor_SendDataToUART(TempData, TempSize);

	DEBUG_RS485SENSOR("REC = %d Bytes   ",num);
	for(int i  = 0; i  < num; ++i)
	{
		DEBUG_RS485SENSOR("%x ", recData[i]);
	}
	DEBUG_RS485SENSOR("\n                   %d\n", (recData[5] << 8) + recData[6]);
	uint16_t ProxyFlowValue = ((uint16_t)recData[5] << 8) + (uint16_t)recData[6];

	float realFlow=0;
	if(recData[2]==0x35 && recData[3]==0 && recData[4]==2)
	{
		realFlow = (ProxyFlowValue - 32768.0)/ 120.0;
		s_FlowValue=realFlow;
	}
	gs_StatusFromSensor = recData[3];
	gs_DataLengthReceiveFromSensor = recData[4];
	return s_FlowValue;
}

static void RS485ProxySensor_ResetDevice()
{
	int num = 0;
	uint8_t recData[32] = {0};

	ProxySensorSendFrameData ResetDevice;

	ResetDevice.Address = 0x00;
	ResetDevice.CMD = 0xD3;
	ResetDevice.LengTH = 0x00;

	uint8_t ResetDeviceBuff[6 + ResetDevice.LengTH];
	uint32_t SizeofResetDevice = 0;
	const uint16_t TempDataBufferSize=600;
	uint8_t TempData[TempDataBufferSize];
	uint64_t TempSize = 0;

	RS485ProxySensor_GenerateFrameData(&ResetDevice, ResetDeviceBuff, &SizeofResetDevice);
	RS485ProxySensor_ConvertByteArrayToSend(ResetDeviceBuff, SizeofResetDevice,TempData,&TempSize);
	DEBUG_RS485SENSOR("SEND = ");
	for(uint64_t i  = 0; i  < TempSize; ++i)
	{
		DEBUG_RS485SENSOR("%x \n", TempData[i]);
	}
	RS485ProxySensor_SendDataToUART(TempData, TempSize);
	delay_ms(1000);
	num = RS485ProxySensor_ReadDataFromUART(recData, 32);
	DEBUG_RS485SENSOR("REC = %d\n",num);
	for(int i  = 0; i  < num; ++i)
	{
		DEBUG_RS485SENSOR("%x \n", recData[i]);
	}
	delay_ms(5000);
}
void RS485ProxySensor_Init(void)
{
	uart_Init(PROXY_FS_UART,PROXY_BAUD_RATE);
	RS485ProxySensor_ResetDevice();
	RS485ProxySensor_DoGetVersionStr();
	RS485ProxySensor_StartContinuousMeasurement();

}

ProxyStatus RS485ProxySensor_GetCurrentStatus()
{
	static int s_ErrorStaticCollection = 0;
	if(gs_StatusFromSensor == 0x00 && gs_DataLengthReceiveFromSensor ==2)
	{
		gs_Status = eCalibrated;
		s_ErrorStaticCollection=0;
	}
	else
	{
		s_ErrorStaticCollection++;
		if(s_ErrorStaticCollection>10)
		{
			gs_Status = eSensorError;
		}
	}
	return gs_Status;
}
ProxyStatus RS485ProxySensor_GetLastStatus()
{
	return gs_Status;
}
void RS485ProxySensor_DoCalibration(void)
{
	if(gs_ProxyTitle!=eDoProxyCalibration)
		return;
	gs_ProxyTitle = eGetProxyStatus;
}
void RS485ProxySensor_CommunicateProxySensor()
{
	switch(gs_ProxyTitle){
	case eGetProxyVersion:
		RS485ProxySensor_DoGetVersionStr();
		break;
	case eDoProxyCalibration:
		RS485ProxySensor_DoCalibration();
		break;
	case eClearProxyCalibration:
		RS485ProxySensor_ClearCalibration();
		break;
	case eComfirmProxyReset:
		RS485ProxySensor_ConfirmProxyReset();
		break;
	default:
		RS485ProxySensor_GetCurrentStatus();
		break;
	}
}
void RS485ProxySensor_SetCurrentAction(ProxyActions title)
{
	gs_ProxyTitle = title;
}
int32_t RS485ProxySensor_GetCurrentReading()
{
	float currentValue=RS485ProxySensor_GetProxyFlow()+gs_Offset;
	if(gs_IsGetOffSetActive)
	{
		if(gs_GetOffSetCnt<10)
		{
			gs_GetOffSetSum+=currentValue;
			gs_GetOffSetCnt++;
		}
		else
		{
			gs_Offset = gs_Offset/10;
			gs_GetOffSetCnt = false;
		}
	}
	gs_CurrentReading = currentValue*100;
	return gs_CurrentReading;
}
int32_t RS485ProxySensor_GetLastReading()
{
	return gs_CurrentReading;
}
bool RS485ProxySensor_OkToShutdown()
{
	return gs_IsOkToShutdown;
}
void RS485ProxySensor_ClearCalibration()
{
	if(gs_ProxyTitle != eClearProxyCalibration)
		return;
	gs_ProxyTitle = eGetProxyStatus;
	gs_IsOkToShutdown = true;
}
void RS485ProxySensor_ConfirmProxyReset()
{
	if(gs_ProxyTitle != eComfirmProxyReset)
		return;
	gs_ProxyTitle = eGetProxyStatus;

}
void RS485ProxySensor_DoGetOffset()
{
	gs_IsGetOffSetActive=0;
	gs_GetOffSetCnt=0;
	gs_GetOffSetSum=0;
}
void RS485ProxySensor_DoGetVersionStr()
{
	int num = 0;
	uint8_t recData[32] = {0};

	ProxySensorSendFrameData GetVersionStr;

	GetVersionStr.Address = 0x00;
	GetVersionStr.CMD = 0xD1;
	GetVersionStr.LengTH = 0x00;

	uint8_t GetVersionStrBuff[6 + GetVersionStr.LengTH];
	uint32_t SizeofGetVersionStr = 0;
	const uint16_t TempDataBufferSize=600;
	uint8_t TempData[TempDataBufferSize];
	uint64_t TempSize = 0;

	RS485ProxySensor_GenerateFrameData(&GetVersionStr, GetVersionStrBuff, &SizeofGetVersionStr);
	RS485ProxySensor_ConvertByteArrayToSend(GetVersionStrBuff, SizeofGetVersionStr,TempData,&TempSize);
	DEBUG_RS485SENSOR("SEND = ");
	for(uint64_t i  = 0; i  < TempSize; ++i)
	{
		DEBUG_RS485SENSOR("%x \n", TempData[i]);
	}
	RS485ProxySensor_SendDataToUART(TempData, TempSize);
	delay_ms(2);
	num = RS485ProxySensor_ReadDataFromUART(recData, 32);
	DEBUG_RS485SENSOR("REC = %d\n",num);
	for(int i  = 0; i  < num; ++i)
	{
		DEBUG_RS485SENSOR("%x \n", recData[i]);
	}
	/************************************************************/
	/*gs_VersionStr[0] = Firmware Major Version Number [0-255]	*/
	/*gs_VersionStr[1] = Firmware Major Version Number [0-99]	*/
	/*gs_VersionStr[2] = Firmware in Debug State [bool]			*/
	/*gs_VersionStr[3] = Hardware Major [0-255]					*/
	/*gs_VersionStr[4] = Hardware Minor [0-99]					*/
	/*gs_VersionStr[5] = SHDLC Protocol Version Major [0-255]	*/
	/*gs_VersionStr[6] = SHDLC Protocol Version Minor [0-255]	*/
	/************************************************************/
	if(recData[2]==0xD1 && recData[3]==0 && recData[4]==7)
	{
		gs_IsGotVersionStr = true;
		IpcMessage sendMsg;
		sendMsg.type = eProxyVersionGUIEvent;
		for(int i = 0;i<7;i++)
		{
			gs_VersionStr[i]=recData[i+5];
			sendMsg.data.command.proxyVersion.version[i]=recData[i+5];
		}
		sendMsg.data.command.proxyVersion.version[7]='\0';
		ipc_sendMsg(&sendMsg);
		gs_ProxyTitle = eGetProxyStatus;
	}
}
bool RS485ProxySensor_IsNeedToGetVersionStr()
{
	return !gs_IsGotVersionStr;
}
