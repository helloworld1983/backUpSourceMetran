var searchData=
[
  ['tvq',['tvq',['../group__rpmsg__lite.html#ae1d9d59636e550051ebce42bd0b58816',1,'rpmsg_lite_instance']]]
];
