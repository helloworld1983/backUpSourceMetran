multicore/rpmsg_lite/readme.txt

The RPMsg Lite component is a lightweight implementation of the RPMsg protocol.
The RPMsg protocol defines a standardized binary interface used to communicate between
multiple cores in a heterogeneous multicore system.

Directory Structure

doc - Holds the documentation.
lib - Holds source code for rpmsg_lite.
