/*
 * DeviceTask.c
 *
 *  Created on: Dec 3, 2018
 *      Author: qsbk0
 */
#include "FreeRTOS.h"
#include "task.h"
#include "fsl_uart.h"
#include "fsl_debug_console.h"
#include "DeviceTask.h"
#include "RS485Sensor.h"
#include "uart.h"
#include "spi.h"
#include "DeviceInterface.h"

#define DEVICE_TASK_STACK_SIZE 512

static TaskHandle_t s_devTaskHandle = NULL;

static void devTsk_DeInit()
{
	spi_RtosDeInit();
}

static void devTsk_loop(void *param)
{
	spi_RtosInit();
	for (;;)
	{
#ifdef TEST_UART
		uint8_t buf[1024] = {0};
		uart_Read(TEST_UART,buf,8);
		uart_Write(TEST_UART,buf,8);
#endif
#ifdef TEST_SPI
		uint32_t masterRxData[64] = {0};
		uint32_t masterTxData[64] = {0};
	    for (int i = 0; i < 64; i++)
	    {
	        masterTxData[i] = i;
	    }
	    spi_Transfer(masterTxData,masterRxData,64);
	    /* Compare Tx and Rx data. */
	    for (int i = 0; i < 64; i++)
	    {
	        if (masterTxData[i] != masterRxData[i])
	        {
	        	PRINTF("\r\nFreeRTOS ECSPI loopback test fail!");
	            break;
	        }
	    }
#endif
	    devIf_HandleMsgQueueRecv();
		vTaskDelay(2);
	}
	devTsk_DeInit();
	return;
}

/*!
 * @brief ipc_create function
 */
void devTsk_Create(void)
{
	devIf_Init();
	if (xTaskCreate(devTsk_loop, "DEV_TASK", DEVICE_TASK_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, &s_devTaskHandle) != pdPASS)
	{
		PRINTF("\r\nFailed to create application task\r\n");
		while (1)
			;
	}
	return;
}

void devTsk_Init(void)
{
#ifndef TEST_UART

#else
	uart_Init(TEST_UART,115200u);
#endif
	spi_HwInit();
}
