/*
 * RS485Sensor.h
 *
 *  Created on: 11-10-2018
 *      Author: haxua
 */

#ifndef INC_RS485SENSOR_H_
#define INC_RS485SENSOR_H_
#include "stdint.h"

void RS485Sensor_Init(void);
float RS485Sensor_GetProxyFlow(void);

#endif /* INC_RS485SENSOR_H_ */
