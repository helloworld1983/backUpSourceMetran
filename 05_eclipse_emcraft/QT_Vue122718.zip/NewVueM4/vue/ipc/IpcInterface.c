/*
 * IpcInterface.c
 *
 *  Created on: Dec 25, 2018
 *      Author: qsbk0
 */
#include "IpcInterface.h"
