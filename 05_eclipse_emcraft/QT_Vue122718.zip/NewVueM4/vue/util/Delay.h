#ifndef INC_DELAY_H_
#define INC_DELAY_H_

void delay_us(unsigned long us);
void delay_ms(unsigned long ms);


#endif /* INC_DELAY_H_ */
