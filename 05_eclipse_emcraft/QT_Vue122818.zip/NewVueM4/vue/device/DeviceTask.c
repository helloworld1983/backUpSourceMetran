/*
 * DeviceTask.c
 *
 *  Created on: Dec 3, 2018
 *      Author: qsbk0
 */
#include "FreeRTOS.h"
#include "task.h"
#include "fsl_uart.h"
#include "fsl_debug_console.h"
#include "DeviceTask.h"
#include "RS485Sensor.h"
#include "uart.h"
#include "spi.h"
#include "i2c.h"
#include "DeviceInterface.h"
#include "Delay.h"

#define DEVICE_TASK_STACK_SIZE 512
#define UART_BAUDRATE (115200U)
#define I2C_BAUDRATE (100000) /* 100K */
//for adc
//#define I2C_MASTER_SLAVE_ADDR_7BIT 0x4B
//for I2C- Flow
#define I2C_MASTER_SLAVE_ADDR_7BIT 0x40

static TaskHandle_t s_devTaskHandle = NULL;

static void devTsk_DeInit()
{
#ifdef TEST_SPI
    spi_RtosDeInit();
#endif

}
#ifdef TEST_SPI
void init_motor(void)
{
    SendData(0x84, 0x4440006B); //A: 26x-SPI, B: 26x-S/D
    SendData(0xB1, 0x00B71B00); // clk 7A1200/8Mhz, 0x00B71B00/12MHz, 0x00F42400/16Mhz
    SendData(0x80, 0x00006026); // direct-a, direct-bow
    SendData(0x90, 0x00010001); // Steplength

    //Configure the TMC26x via cover datagrams

    SendData(0xEC, 0x00000000); // Using cover datagram to write to DRVCTRL of TMC26x  SendData
                                // single edge steps, disable step interpolation, microstep resolution: 256
    SendData(0xEC, 0x00091935); // Using cover datagram to write to CHOPCONF of TMC26x
                                // tbl=36, standard chopper, HDEC=16, HEND=11, HSTR=1, TOFF=5, RNDTF=off
    SendData(0xEC, 0x000A0000); // Using cover datagram to write to SMARTEN of TMC26x
                                // Disable Smarten Register
    SendData(0xEC, 0x000D0509); // Using cover datagram to write to SGCSCONF of TMC26x
                                // SGT=0,CS=24
    SendData(0xEC, 0x000EF040); // Using cover datagram to write to DRVCONF of TMC26x
                                // SLPH = 3, SLPL = 3, DISS2G = off, TS2G = 0-3.2??s, SDOFF = on, VSENSE = 0

    SendData(0xA4, 0x00000000); // v = 0
    SendData(0xA1, 0x00000000); // xactual = 0
    SendData(0xB7, 0x00000000); // xtarget = 0

    SendData(0xA0, 0x00000000); // S-Ramp + POS Mode 6 RAM \ 4 NO RAM \ 0 Velocitiy mode
    SendData(0xA4, 0x03E80000); // VMAX =  [pps] 03E80000 256K
    SendData(0xA8, 0x00001000); // AMAX F42400 4M
    SendData(0xA9, 0x00001000); // DMAX F42400
}
#endif

static void devTsk_loop(void *param)
{
#ifdef TEST_SPI
    init_motor();

    uint32_t demo = 0;
    ReadData(0x31, &demo);
#endif

#ifdef TEST_I2C
    i2c_Init(I2C3, I2C_BAUDRATE);

    //test ADC
    uint8_t GetADC[1] = {0x84};
    uint8_t result[2] = {'\0'};

    //test I2C- read flow
    uint8_t GetDataFlow[2] = {0x10, 0x00};
    uint8_t Rawflow[3] = {'\0'};
#endif

	for (;;)
	{
#ifdef TEST_UART
		uint8_t buf[1024] = {0};

		uart_Read(TEST_UART,buf,1024);
		delay_us(10);

		for(int i = 0; i < 1024; ++i){
		    PRINTF("%c", buf[i]);
		}

		uart_Write(TEST_UART,buf,1024);

#endif
#ifdef TEST_SPI
		PRINTF("TEST MOTOR\n");
        ReadData(0x31, &demo);
//		PRINTF("TEST_SPI LOOP BACK\n");
//		uint32_t masterTxData[64] = {0};
//		uint32_t masterRxData[64] = {0};
//
//		for (int i = 0; i < 64; i++)
//		{
//		    masterTxData[i] = i;
//		}
//
//		status_t status = spi_Transfer(masterTxData, masterRxData, 64);
//		delay_ms(1);
//
//		// Compare Tx and Rx data
//		int err = 0;
//		for (int i = 0; i < 64; i++)
//		{
//		    if (masterTxData[i] != masterRxData[i])
//		    {
//	            PRINTF("masterTxData = %x masterRxData = %x \n", masterTxData[i], masterRxData[i]);
//		        err++;
//		    }
//		}
//
//		if (status != kStatus_Success)
//		{
//		    PRINTF("ECSPI transfer completed with error. \r\n");
//		    vTaskSuspend(NULL);
//		}
//
//		if(err != 0){
//		    PRINTF("Test FAIL \r\n\r\n");
//		}else{
//		    PRINTF("Test PASS \r\n\r\n");
//		}
#endif

#ifdef TEST_I2C
//        PRINTF("test ADC\n");
//
//        i2c_Write(I2C3, I2C_MASTER_SLAVE_ADDR_7BIT, GetADC, 1);
//
//        delay_us(10);
//
//        i2c_Read(I2C3, I2C_MASTER_SLAVE_ADDR_7BIT, result, 2);
//
//        int raw_adc = ((result[0] & 0x0F) * 256 + result[1]);
//        PRINTF(" RAW ADC(%x %x )  = %d \n", result[0], result[1], raw_adc);
//        PRINTF(" ADC(x1000)  = %d \n", raw_adc * 3300 / 4096);

        PRINTF("test I2C ReadFlow \n");
        i2c_Write(I2C3, I2C_MASTER_SLAVE_ADDR_7BIT, GetDataFlow, 2);
        delay_us(500);

        i2c_Read(I2C3, I2C_MASTER_SLAVE_ADDR_7BIT, Rawflow, 3);

        int16_t flow = ((uint16_t)Rawflow[0] << 8) + ((uint16_t)Rawflow[1]);
        flow = (flow - 32000) * 100 / 140;

        PRINTF("Flow = %d ml/s \n", flow);


#endif
	    devIf_HandleMsgQueueRecv();
        vTaskDelay(2/portTICK_PERIOD_MS);
	}
	devTsk_DeInit();
	return;
}

/*!
 * @brief ipc_create function
 */
void devTsk_Create(void)
{
	devIf_Init();
	if (xTaskCreate(devTsk_loop, "DEV_TASK", DEVICE_TASK_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, &s_devTaskHandle) != pdPASS)
	{
		PRINTF("\r\nFailed to create application task\r\n");
		while (1)
			;
	}
	return;
}

void devTsk_Init(void)
{
#ifdef TEST_UART
	uart_Init(TEST_UART, UART_BAUDRATE);
#endif

#ifdef TEST_SPI
	spi_HwInit();
	spi_RtosInit();
#endif

}
