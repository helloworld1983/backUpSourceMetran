/*
 * DeviceTask.h
 *
 *  Created on: Dec 3, 2018
 *      Author: qsbk0
 */

void devTsk_Create(void);

void devTsk_Init(void);

