/******************************************************************************
 *
 *    File Name: uart.c
 *    @brief Copyright (c) 2018, Metran.  All Rights Reserved.
 *
 *
 *    Revision History:
 *
 *       Rev:      Date:       	Engineer:         Project:
 *        01       11/29/2018    Quyen Ngo         NewVue
 *        Description: New file
 ******************************************************************************/
#include "board/board.h"
#include "fsl_uart.h"
#include "uart.h"
#include "fsl_uart_freertos.h"
#include "fsl_debug_console.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define M4_UART_CLK_FREQ                BOARD_DEBUG_UART_CLK_FREQ
#define M4_UART_BAUDRATE                (115200U)

#define M4_UART_BUFFER                  (1024)
#define M4_UART_PRIORITY                (configMAX_PRIORITIES - 1)

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
uart_rtos_handle_t handleUart1;
uart_rtos_handle_t handleUart2;
uart_rtos_handle_t handleUart3;
uart_rtos_handle_t handleUart4;

struct _uart_handle t_handle_uart1;
struct _uart_handle t_handle_uart2;
struct _uart_handle t_handle_uart3;
struct _uart_handle t_handle_uart4;

uint8_t background_buffer[M4_UART_BUFFER];
uint8_t recv_buffer[M4_UART_BUFFER];
/*******************************************************************************
 * Code
 ******************************************************************************/

void uart_Init(uint32_t channel, uint32_t baud)
{
    uart_rtos_config_t uart_config = {
            .baudrate = baud,
            .parity = kUART_ParityDisabled,
            .stopbits = kUART_OneStopBit,
            .srcclk = M4_UART_CLK_FREQ,
            .buffer = background_buffer,
            .buffer_size = sizeof(background_buffer),
    };

    switch (channel) {
        case 1:
            uart_config.base = UART1;
            NVIC_SetPriority(UART1_IRQn, M4_UART_PRIORITY);
            if (kStatus_Success != UART_RTOS_Init(&handleUart1, &t_handle_uart1, &uart_config)){
                vTaskSuspend(NULL);
            }

            break;
        case 2:
            uart_config.base = UART2;
            NVIC_SetPriority(UART2_IRQn, M4_UART_PRIORITY);
            if (kStatus_Success != UART_RTOS_Init(&handleUart2, &t_handle_uart2, &uart_config)){
                vTaskSuspend(NULL);
            }
            break;
        case 3:
            uart_config.base = UART3;
            NVIC_SetPriority(UART3_IRQn, M4_UART_PRIORITY);
            if (kStatus_Success != UART_RTOS_Init(&handleUart3, &t_handle_uart3, &uart_config)){
                vTaskSuspend(NULL);
            }
            break;
        case 4:
            uart_config.base = UART4;
            NVIC_SetPriority(UART4_IRQn, M4_UART_PRIORITY);
            if (kStatus_Success != UART_RTOS_Init(&handleUart4, &t_handle_uart4, &uart_config)){
                vTaskSuspend(NULL);
            }
            break;
        default:
            break;
    }


}

int32_t uart_Read(uint32_t channel, uint8_t* buf, uint32_t len)
{
    status_t stat = kStatus_Fail;
    size_t n = (size_t)len;

    switch (channel) {
        case 1:
            stat = (status_t)UART_RTOS_Receive(&handleUart1, recv_buffer, sizeof(recv_buffer), &n);
            break;
        case 2:
            stat = (status_t)UART_RTOS_Receive(&handleUart2, recv_buffer, sizeof(recv_buffer), &n);
            break;
        case 3:
            stat = (status_t)UART_RTOS_Receive(&handleUart3, recv_buffer, sizeof(recv_buffer), &n);
            break;
        case 4:
            stat = (status_t)UART_RTOS_Receive(&handleUart4, recv_buffer, sizeof(recv_buffer), &n);
            break;
        default:
            break;
    }

    if (stat == kStatus_UART_RxHardwareOverrun){
        /* Notify about hardware buffer overrun */
        PRINTF("Hardware buffer overrun! \n");
    }
    if (stat == kStatus_UART_RxRingBufferOverrun){
        /* Notify about ring buffer overrun */
        PRINTF("Ring buffer overrun! \n");
    }


    if(kStatus_Success == stat){
        return 0;
    }else{
        PRINTF("Err Uart catch up in channel %d and ignored \n", channel);
        return -1;
    }
}

void uart_Write(uint32_t channel, uint8_t* buf, uint32_t len)
{
    switch (channel) {
        case 1:
            if (kStatus_Success != UART_RTOS_Send(&handleUart1, (uint8_t *)buf, len)){
                vTaskSuspend(NULL);
            }
            break;
        case 2:
            if (kStatus_Success != UART_RTOS_Send(&handleUart2, (uint8_t *)buf, len)){
                vTaskSuspend(NULL);
            }
            break;
        case 3:
            if (kStatus_Success != UART_RTOS_Send(&handleUart3, (uint8_t *)buf, len)){
                vTaskSuspend(NULL);
            }
            break;
        case 4:
            if (kStatus_Success != UART_RTOS_Send(&handleUart4, (uint8_t *)buf, len)){
                vTaskSuspend(NULL);
            }
            break;
        default:
            break;
    }
}

void uart_Deinit(uint32_t channel)
{
    switch (channel) {
        case 1:
            UART_RTOS_Deinit(&handleUart1);
            break;
        case 2:
            UART_RTOS_Deinit(&handleUart2);
            break;
        case 3:
            UART_RTOS_Deinit(&handleUart3);
            break;
        case 4:
            UART_RTOS_Deinit(&handleUart4);
            break;
        default:
            break;
    }
}
