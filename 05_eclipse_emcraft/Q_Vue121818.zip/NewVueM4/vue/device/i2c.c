/******************************************************************************
*
*    File Name: i2c.c
*    @brief Copyright (c) 2018, Metran.  All Rights Reserved.
*
*
*    Revision History:
*
*       Rev:      Date:       	Engineer:         Project:
*        01       11/29/2018    Quyen Ngo         NewVue
*        Description: New file
******************************************************************************/
#include "i2c.h"

#define I2C3_CLK_FREQ                                                                \
		CLOCK_GetPllFreq(kCLOCK_SystemPll1Ctrl) / (CLOCK_GetRootPreDivider(kCLOCK_RootI2c3)) / \
		(CLOCK_GetRootPostDivider(kCLOCK_RootI2c3)) / 5 /* SYSTEM PLL1 DIV5 */

#define I2C2_CLK_FREQ                                                                \
		CLOCK_GetPllFreq(kCLOCK_SystemPll1Ctrl) / (CLOCK_GetRootPreDivider(kCLOCK_RootI2c2)) / \
		(CLOCK_GetRootPostDivider(kCLOCK_RootI2c2)) / 5 /* SYSTEM PLL1 DIV5 */

void i2c_Init(I2C_Type* chanelBase, uint32_t baudRate)
{
	i2c_master_config_t masterConfig;
	uint32_t sourceClock;
	if(chanelBase == I2C2)
	{
		CLOCK_SetRootMux(kCLOCK_RootI2c2, kCLOCK_I2cRootmuxSysPll1Div5); /* Set I2C source to SysPLL1 Div5 160MHZ */
		CLOCK_SetRootDivider(kCLOCK_RootI2c2, 1U, 4U);                   /* Set root clock to 160MHZ / 4 = 40MHZ */
		I2C_MasterGetDefaultConfig(&masterConfig);
		masterConfig.baudRate_Bps = baudRate;
		sourceClock = I2C2_CLK_FREQ;
		I2C_MasterInit(I2C2, &masterConfig, sourceClock);
	}
	else if(chanelBase == I2C3)
	{
		CLOCK_SetRootMux(kCLOCK_RootI2c3, kCLOCK_I2cRootmuxSysPll1Div5); /* Set I2C source to SysPLL1 Div5 160MHZ */
		CLOCK_SetRootDivider(kCLOCK_RootI2c3, 1U, 4U);                   /* Set root clock to 160MHZ / 4 = 40MHZ */
		I2C_MasterGetDefaultConfig(&masterConfig);
		masterConfig.baudRate_Bps = baudRate;
		sourceClock = I2C3_CLK_FREQ;
		I2C_MasterInit(I2C3, &masterConfig, sourceClock);
	}
	return;
}

status_t i2c_Write(I2C_Type* chanelBase, uint32_t addr, uint8_t* buf, uint32_t len)
{
	i2c_master_transfer_t masterXfer;
	memset(&masterXfer, 0, sizeof(masterXfer));

	masterXfer.slaveAddress = addr;
	masterXfer.direction = kI2C_Write;
	masterXfer.subaddress = (uint32_t)NULL;
	masterXfer.subaddressSize = 0;
	masterXfer.data = buf;
	masterXfer.dataSize = len;
	masterXfer.flags = kI2C_TransferDefaultFlag;
	return I2C_MasterTransferBlocking(chanelBase, &masterXfer);
}

status_t i2c_Read(I2C_Type* chanelBase, uint32_t addr, uint8_t* buf, uint32_t len)
{
	i2c_master_transfer_t masterXfer;
	memset(&masterXfer, 0, sizeof(masterXfer));
    masterXfer.slaveAddress = addr;
    masterXfer.direction = kI2C_Read;
    masterXfer.subaddress = (uint32_t)NULL;
    masterXfer.subaddressSize = 0;
    masterXfer.data = buf;
    masterXfer.dataSize = len;
    masterXfer.flags = kI2C_TransferDefaultFlag;
    return I2C_MasterTransferBlocking(chanelBase, &masterXfer);
}
