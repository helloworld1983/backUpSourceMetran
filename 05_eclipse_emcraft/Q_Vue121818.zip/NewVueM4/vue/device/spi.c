/*
 * spi.c
 *
 *  Created on: Dec 17, 2018
 *      Author: qsbk0
 */

/* FreeRTOS kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"

#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "fsl_ecspi.h"
#include "fsl_ecspi_freertos.h"

#define EXAMPLE_ECSPI_MASTER_IRQN ECSPI1_IRQn
#define ECSPI_MAX_TRANSFER_SIZE 64
#define ECSPI_TRANSFER_BAUDRATE 1500000
#define ECSPI_MASTER_BASEADDR ECSPI1
#define ECSPI_MASTER_CLK_FREQ  \
		CLOCK_GetPllFreq(kCLOCK_SystemPll1Ctrl) / (CLOCK_GetRootPreDivider(kCLOCK_RootEcspi1)) / \
		(CLOCK_GetRootPostDivider(kCLOCK_RootEcspi1))

static ecspi_master_config_t masterConfig;
static ecspi_transfer_t masterXfer;

uint32_t masterRxData[ECSPI_MAX_TRANSFER_SIZE] = {0};
uint32_t masterTxData[ECSPI_MAX_TRANSFER_SIZE] = {0};
ecspi_rtos_handle_t master_rtos_handle;

void spi_HwInit(void)
{
	CLOCK_SetRootMux(kCLOCK_RootEcspi1, kCLOCK_EcspiRootmuxSysPll1); /* Set ECSPI1 source to SYSTEM PLL1 800MHZ */
	CLOCK_SetRootDivider(kCLOCK_RootEcspi1, 2U, 5U);                  /* Set root clock to 800MHZ / 10 = 80MHZ */
	/* Set IRQ priority for freertos_ecspi */
	NVIC_SetPriority(EXAMPLE_ECSPI_MASTER_IRQN, 2);
	return;
}

void spi_RtosInit(void)
{
	uint8_t i;
	status_t status;

	ECSPI_MasterGetDefaultConfig(&masterConfig);

	masterConfig.baudRate_Bps = ECSPI_TRANSFER_BAUDRATE;
#ifdef TEST_SPI
	masterConfig.enableLoopback = true;
#else
	masterConfig.enableLoopback = false;
#endif

	status = ECSPI_RTOS_Init(&master_rtos_handle, ECSPI_MASTER_BASEADDR, &masterConfig, ECSPI_MASTER_CLK_FREQ);

	if (status != kStatus_Success)
	{
		PRINTF("ECSPI meets error during initialization. \r\n");
		vTaskSuspend(NULL);
	}
}

void spi_RtosDeInit(void)
{
	 ECSPI_RTOS_Deinit(&master_rtos_handle);
}

int16_t spi_Transfer(uint32_t* tx, uint32_t* rx, uint32_t channel, uint32_t size)
{
	if(size > ECSPI_MAX_TRANSFER_SIZE)
	{
		assert(false);
		return -1;
	}
	status_t status;
	ecspi_channel_source_t cs = (ecspi_channel_source_t)channel;
	memcpy(masterTxData,tx,size);
	masterXfer.txData = masterTxData;
	masterXfer.rxData = masterRxData;
	masterXfer.dataSize = size;
	masterXfer.channel = cs;
	status = ECSPI_RTOS_Transfer(&master_rtos_handle, &masterXfer);
	if (status != kStatus_Success)
	{
		PRINTF("ECSPI transfer completed with error. \r\n\r\n");
		vTaskSuspend(NULL);
	}
	return 0;
}
