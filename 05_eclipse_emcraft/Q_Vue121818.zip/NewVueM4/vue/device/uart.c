/******************************************************************************
*
*    File Name: uart.c
*    @brief Copyright (c) 2018, Metran.  All Rights Reserved.
*
*
*    Revision History:
*
*       Rev:      Date:       	Engineer:         Project:
*        01       11/29/2018    Quyen Ngo         NewVue
*        Description: New file
******************************************************************************/
#include "board/board.h"
#include "fsl_uart.h"
#include "uart.h"
#include "fsl_debug_console.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define M4_UART_CLK_FREQ  BOARD_DEBUG_UART_CLK_FREQ
#define M4_UART_BAUDRATE 115200U

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/

/*******************************************************************************
 * Code
 ******************************************************************************/

void uart_Init(UART_Type* port, uint32_t baud)
{
	uart_config_t config;
    /*
     * config.baudRate_Bps = 115200U;
     * config.parityMode = kUART_ParityDisabled;
     * config.dataBitsCount = kUART_EightDataBits;
     * config.stopBitCount = kUART_OneStopBit;
     * config.txFifoWatermark = 2;
     * config.rxFifoWatermark = 1;
     * config.enableTx = false;
     * config.enableRx = false;
     */
    UART_GetDefaultConfig(&config);
    config.baudRate_Bps = baud;
    config.enableTx = true;
    config.enableRx = true;

    UART_Init(port, &config, M4_UART_CLK_FREQ);
}

int32_t uart_Read(UART_Type* port, uint8_t* buf, uint32_t len)
{
	status_t stat = UART_ReadBlocking(port, buf, len);
	if(kStatus_Success == stat)
	{
		return 0;
	}
	else
	{
		PRINTF("Err Uart catch up in channel %p and ignored \n",port);
		return -1;
	}
}

void uart_Write(UART_Type* port, uint8_t* buf, uint32_t len)
{
	UART_WriteBlocking(port, buf, len);
}
