/******************************************************************************
*
*    File Name: uart.h
*    @brief Copyright (c) 2018, Metran.  All Rights Reserved.
*
*
*    Revision History:
*
*       Rev:      Date:       	Engineer:         Project:
*        01       11/29/2018    Quyen Ngo         NewVue
*        Description: New file
******************************************************************************/

#ifndef DEVICE_UART_H_
#define DEVICE_UART_H_

//#define TEST_UART UART3

void uart_Init(UART_Type* port, uint32_t baud);
int32_t uart_Read(UART_Type* port, uint8_t* buf, uint32_t len);
void uart_Write(UART_Type* port, uint8_t* buf, uint32_t len);

#endif /* DEVICE_UART_H_ */
