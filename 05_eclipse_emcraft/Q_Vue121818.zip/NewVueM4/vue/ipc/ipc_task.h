/*
 * ipc_task.h
 *
 *  Created on: Nov 22, 2018
 *      Author: qsbk0
 */

#ifndef IPC_IPC_TASK_H_
#define IPC_IPC_TASK_H_

void ipc_create(void);

#endif /* IPC_IPC_TASK_H_ */
