/*
 * alarmtask.c
 *
 *  Created on: Sep 8, 2016
 *      Author: PhuocBui
 */

#include "alarmtask.h"

#include <guiinterface.h>
#include <motorctrlinterface.h>
#include <systeminterface.h>
#include "alarminterface.h"
#include "queue.h"
#include "PowerMonitorMocks.h"

AlarmItemStruct alarmList[eLastAlarmId];
bool isAlarmTaskEnable = false;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif
//declare alarm list

//declare flag to enable/disable alarm task
//static bool isAlarmTaskEnable = false;
static xQueueHandle systemQueue;
static xQueueHandle guiQueue;
static xQueueHandle motorQueue;
static xQueueHandle alarmQueue;

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: AlarmInit()
//
//    Processing:
//    	This operation initialize alarm list
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void AlarmInit()
{
	//initialize ID and status
	for(int i = 0; i < eLastAlarmId; i++)
	{
		alarmList[i].id = (E_AlarmId)i; // @suppress("Field cannot be resolved")
		alarmList[i].status = eDeactivated;// @suppress("Field cannot be resolved")
	}
	//initialize priority
	alarmList[eBlowerErrorId].priority = eAlarmHighPriority;// @suppress("Field cannot be resolved")
	alarmList[ePressSensorErrorId].priority = eAlarmHighPriority;// @suppress("Field cannot be resolved")
	alarmList[eFlowSensorErrorId].priority = eAlarmHighPriority;// @suppress("Field cannot be resolved")
	alarmList[ePowerFailureId].priority = eALarmMediumPriority;// @suppress("Field cannot be resolved")
	alarmList[eSdCardErrorId].priority = eALarmMediumPriority;// @suppress("Field cannot be resolved")
	alarmList[eLeakErrorId].priority = eALarmLowPriority;// @suppress("Field cannot be resolved")
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: AlarmReset()
//
//    Processing:
//    	This operation put all alarm item to deactivated status
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void AlarmReset()
{
	for(int i = 0; i < eLastAlarmId; i++)
		alarmList[i].status = eDeactivated;// @suppress("Field cannot be resolved")
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: AlarmTaskHandleEvent()
//
//    Processing:
//    	This operation read event from alarm queue, then make a decision to activate or
//		deactivated a alarm
//
//    Input Parameters:
//      AlarmEventStruct event: event to be process
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void AlarmTaskHandleEvent(AlarmEventStruct event)
{
	switch(event.id)
	{
	case eAlarmTaskEnableId:
		isAlarmTaskEnable = true;
		break;
	case eAlarmTaskDisableId:
		isAlarmTaskEnable = false;
		break;
	case eBlowerErrorActivatedId:
		//check status
		if(alarmList[eBlowerErrorId].status != eActivated)
		{
			//set activate the error
			alarmList[eBlowerErrorId].status = eActivated;
			//send event to system task to log the error
			SystemEventStruct event;
			event.Id = eSystemLogErrorEventId;
			event.Data.type2[0] = eBlowerErrorId;
			event.Data.type2[1] = 1;
			//send event to queue
			if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
			{
			}
			//SystemTaskSendEventType2(eSystemLogErrorEventId, eBlowerErrorId, (short)event.data);
		}
		break;
	case eBlowerErrorDeActivatedId:
		alarmList[eBlowerErrorId].status = eDeactivated;
		break;
	case ePressSensorErrorActivatedId:
		//check activation
		if(alarmList[ePressSensorErrorId].status != eActivated)
		{
			//set activated
			alarmList[ePressSensorErrorId].status = eActivated;
			//send event to system task to log the error
			SystemEventStruct event;
			event.Id = eSystemLogErrorEventId;
			event.Data.type2[0] = ePressSensorErrorId;
			event.Data.type2[1] = 1;
			//send event to queue
			if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
			{
			}
			//SystemTaskSendEventType2(eSystemLogErrorEventId, ePressSensorErrorId, (short)event.data);
		}
		break;
	case ePressSensorErrorDeActivatedId:
		alarmList[ePressSensorErrorId].status = eDeactivated;
		break;
	case eFlowSensorErrorActivatedId:
		//check activation
		if(alarmList[eFlowSensorErrorId].status != eActivated)
		{
			//set activated
			alarmList[eFlowSensorErrorId].status = eActivated;
			//send event to system task to log the error
			SystemEventStruct event;
			event.Id = eSystemLogErrorEventId;
			event.Data.type2[0] = eFlowSensorErrorId;
			event.Data.type2[1] = 1;
			//send event to queue
			if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
			{
			}
			//SystemTaskSendEventType2(eSystemLogErrorEventId, eFlowSensorErrorId, (short)event.data);
		}
		break;
	case eFlowSensorErrorDeActivatedId:
		alarmList[eFlowSensorErrorId].status = eDeactivated;
		break;
	case eSdCardErrorActivatedId:
		//check activation
		if(alarmList[eSdCardErrorId].status != eActivated)
		{
			//set activated
			alarmList[eSdCardErrorId].status = eActivated;
			//send event to system task to log the error
			SystemEventStruct event;
			event.Id = eSystemLogErrorEventId;
			event.Data.type2[0] = eSdCardErrorId;
			event.Data.type2[1] = 0;
			//send event to queue
			if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
			{
			}
			//SystemTaskSendEventType2(eSystemLogErrorEventId, eSdCardErrorId, 0);
		}
		break;
	case eSdCardErrorDeActivatedId:
		alarmList[eSdCardErrorId].status = eDeactivated;
		break;
	case ePowerFailedActivatedId:
		if(alarmList[ePowerFailureId].status != eActivated)
		{
			alarmList[ePowerFailureId].status = eActivated;
			//send event to system task to log the error
			SystemEventStruct event;
			event.Id = eSystemLogErrorEventId;
			event.Data.type2[0] = ePowerFailureId;
			event.Data.type2[1] = 0;
			//send event to queue
			if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
			{
			}
			//SystemTaskSendEventType2(eSystemLogErrorEventId, ePowerFailureId, 0);
		}
		break;
	case ePowerFailedDeActivatedId:
		alarmList[ePowerFailureId].status = eDeactivated;
		break;
	case eLeakActivatedId:
		if(alarmList[eLeakErrorId].status != eActivated)
		{
			alarmList[eLeakErrorId].status = eActivated;
			//send event to system task to log the error
			SystemEventStruct event;
			event.Id = eSystemLogErrorEventId;
			event.Data.type2[0] = eLeakErrorId;
			event.Data.type2[1] = 0;
			//send event to queue
			if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
			{
			}
			//SystemTaskSendEventType2(eSystemLogErrorEventId, eLeakErrorId, 0);
		}
		break;
	case eLeakDeActivatedId:
		alarmList[eLeakErrorId].status = eDeactivated;
		break;
	default:
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: AlarmTaskProcess()
//
//    Processing:
//    	This operation check alarm on alarm list and make a decision to show a activate
//		a alarm if available
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void AlarmTaskProcess()
{
	//check flag to run alarm task. if alarm task is not enable yet. then do nothing
	if(isAlarmTaskEnable == false)
		return;

	//flag to indicate an alarm is found as activated
	bool isAnAlarmActivated = false;
	//walk through the alarm list and announce the highest activated alarm
	for(int i = 0; i < eLastAlarmId; i++)
	{
		if(alarmList[i].status == eActivated)
		{
			//check alarm priority to show on GUI
			switch(alarmList[i].priority)
			{
			case eAlarmHighPriority:
			{
				//shut down motor
				unsigned char sendEvent = eMotorShutdownEventId;
				if(xQueueSendToBack(motorQueue, &sendEvent, 2) != pdPASS)
				{
				}
				//MotorTaskSendEvent(eMotorShutdownEventId);
				//stop operation and return to standby mode
				//				GuiTaskSendEvent(eGuiOperationStopId, 0);
				//do not break here
			}
			default:
			{
				//show alarm on GUI
				GuiEventStruct event;
				event.id = eGuiAlarmDialogShowId;
				event.data = alarmList[i].id;
				//send event
				if(xQueueSendToBack(guiQueue, &event, 2) != pdPASS)
				{
					xQueueReset(guiQueue);
				}
				//GuiTaskSendEvent(eGuiAlarmDialogShowId, alarmList[i].id);
				break;
			}
			}

			//set flag indicate an alarm activated is found
			isAnAlarmActivated = true;
			//once an alarm is detected, exit for loop
			break;
		}
	}

	//check if no alarm is activated, then hide alarm dialog
	if(isAnAlarmActivated == false)
	{
		GuiEventStruct event;
		event.id = eGuiAlarmDialogHideId;
		event.data = 0;
		//send event
		if(xQueueSendToBack(guiQueue, &event, 2) != pdPASS)
		{
			xQueueReset(guiQueue);
		}
		//GuiTaskSendEvent(eGuiAlarmDialogHideId, 0);
	}
}

void FuncAlarmTask(void *pvParameters)
{
	//reset alarm status at first
	AlarmReset();
	//check abnormal shutdown
	if(PowerMonitorCheckMocks() == false)
	{
		//send event to alarm task to announce abnormal shutdown
		AlarmEventStruct event;
		event.id = ePowerFailedActivatedId;
		event.data = 0;
		if(xQueueSendToBack(alarmQueue, &event, 2) != pdPASS)
		{
		}
		//ALarmTaskSendEvent(ePowerFailedActivatedId, 0);
		//clear flag in EEPROM
		PowerMonitorClearMocks();
	}

	//last event variable
	AlarmEventStruct event;
	//while(1)
	{
		//wait for queue event
		if(xQueueReceive(alarmQueue, &event, portMAX_DELAY) == pdTRUE)
		{
			//process event
			AlarmTaskHandleEvent(event);
			//process alarm
			AlarmTaskProcess();
		}
	}
}

bool ALarmTaskSendEvent(E_AlarmEventId alarmId, long alarmData)
{
	bool rtn = true;
	AlarmEventStruct event;
	event.id = alarmId;
	event.data = alarmData;
	if(xQueueSendToBack(alarmQueue, &event, 2) != pdPASS)
	{
		rtn = false;
	}
	return rtn;
}

#if defined(__cplusplus)
}
#endif

