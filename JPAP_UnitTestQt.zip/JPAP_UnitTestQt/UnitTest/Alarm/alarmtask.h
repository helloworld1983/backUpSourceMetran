/*
 * alarmtask.h
 *
 *  Created on: Feb 17, 2016
 *      Author: computer
 */

#ifndef ALARMTASK_H
#define ALARMTASK_H

//#include "FreeRTOS.h"
//#include "task.h"
//#include "semphr.h"
//#include "debuguart.h"
#include <alarminterface.h>
#include "stddef.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//define alarm task priority
#define ALARM_TASK_PRIORITY		(tskIDLE_PRIORITY + 2)

//define alarm task stack size
#define ALARM_TASK_STACK		(256)

//declare alarm queue size has 8 items
#define ALARM_QUEUE_SIZE	8

//function to handle event send to alarm task
void AlarmTaskHandleEvent(AlarmEventStruct event);
//function to run alarm processing
void AlarmTaskProcess();
//function to reset all alarm item to deactivated
void AlarmReset();
//function to initialize alarm list
void AlarmInit();
void FuncAlarmTask(void *pvParameters);
bool ALarmTaskSendEvent(E_AlarmEventId alarmId, long alarmData);

//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: FuncAlarmTask()
//
//    Processing:		This operation is the main function of the Alarm task
//						Every work of Alarm task should be performed here
//
//    Input Parameters:
//		void *pvParameters: no used
//
//    Output Parameters:
//		None
//
//    Return Values:
//		None
//
//    Pre-Conditions:
//		None
//
//    Miscellaneous:
//		None
//
//    Requirements:
//
//******************************************************************************
//static inline void FuncAlarmTask(void *pvParameters)
//{
//	//reset alarm status at first
//	AlarmReset();
//	//check abnormal shutdown
//	if(PowerMonitorCheck() == false)
//	{
//		//send event to alarm task to announce abnormal shutdown
//		ALarmTaskSendEvent(ePowerFailedActivatedId, 0);
//		//clear flag in EEPROM
//		PowerMonitorClear();
//	}
//
//	//last event variable
//	AlarmEventStruct event;
//	while(1)
//	{
//		//wait for queue event
//		if(xQueueReceive(alarmQueue, &event, portMAX_DELAY) == pdTRUE)
//		{
//			//process event
//			AlarmTaskHandleEvent(event);
//			//process alarm
//			AlarmTaskProcess();
//		}
//	}
//}

#if defined(__cplusplus)
}
#endif

#endif /* ALARM_ALARMTASK_H_ */
