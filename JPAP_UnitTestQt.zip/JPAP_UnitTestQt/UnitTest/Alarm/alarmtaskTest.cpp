/*
 * alarmtaskTest.cpp
 *
 *  Created on: Apr 10, 2018
 *      Author: Truong
 */

#include "stdafx.h"
#include "Fixture.h"
#include "alarmtask.h"

extern  AlarmItemStruct alarmList[];
extern bool isAlarmTaskEnable;

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

namespace EmbeddedCUnitTest {


class AlarmTaskTest : public TestFixture
{
public:
	AlarmTaskTest() : TestFixture(new ModuleMock) {}
};



TEST_F(AlarmTaskTest, AlarmInit)
{
	AlarmInit();
	for(int i = 0; i < eLastAlarmId; i++)
	{

		EXPECT_EQ(alarmList[i].id, (E_AlarmId)i );
		EXPECT_EQ(alarmList[i].status, eDeactivated );
	}

	EXPECT_EQ(alarmList[eBlowerErrorId].priority, eAlarmHighPriority );
	EXPECT_EQ(alarmList[ePressSensorErrorId].priority, eAlarmHighPriority);
	EXPECT_EQ(alarmList[eFlowSensorErrorId].priority, eAlarmHighPriority);
	EXPECT_EQ(alarmList[ePowerFailureId].priority, eALarmMediumPriority);
	EXPECT_EQ(alarmList[eSdCardErrorId].priority, eALarmMediumPriority);
	EXPECT_EQ(alarmList[eLeakErrorId].priority, eALarmLowPriority);
}

TEST_F(AlarmTaskTest, AlarmReset)
{
	AlarmReset();

	for(int i = 0; i < eLastAlarmId; i++)
	{
		EXPECT_EQ(alarmList[i].id, (E_AlarmId)i );
		EXPECT_EQ(alarmList[i].status, eDeactivated );
	}
}

TEST_F(AlarmTaskTest, AlarmTaskHandleEvent1)
{
	isAlarmTaskEnable = false;
	AlarmEventStruct event;
	event.id = eAlarmTaskEnableId;
	AlarmTaskHandleEvent(event);

	EXPECT_EQ(true,isAlarmTaskEnable);
}

TEST_F(AlarmTaskTest, AlarmTaskHandleEvent2)
{
	isAlarmTaskEnable = true;
	AlarmEventStruct event;
	event.id = eAlarmTaskDisableId;
	AlarmTaskHandleEvent(event);

	EXPECT_EQ(false,isAlarmTaskEnable);
}

TEST_F(AlarmTaskTest, AlarmTaskHandleEvent3)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,2)).Times(1);

	AlarmEventStruct event;
	event.id = eBlowerErrorActivatedId;
	alarmList[eBlowerErrorId].status = eDeactivated;
	AlarmTaskHandleEvent(event);

	EXPECT_EQ(eActivated,alarmList[eBlowerErrorId].status);
}

TEST_F(AlarmTaskTest, AlarmTaskHandleEvent4)
{
	AlarmEventStruct event;
	event.id = eBlowerErrorDeActivatedId;
	alarmList[eBlowerErrorId].status = eActivated;
	AlarmTaskHandleEvent(event);

	EXPECT_EQ(eDeactivated,alarmList[eBlowerErrorId].status);
}

TEST_F(AlarmTaskTest, AlarmTaskHandleEvent5)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,2)).Times(1);

	AlarmEventStruct event;
	event.id = ePressSensorErrorActivatedId;
	alarmList[ePressSensorErrorId].status = eDeactivated;
	AlarmTaskHandleEvent(event);

	EXPECT_EQ(eActivated,alarmList[ePressSensorErrorId].status);
}

TEST_F(AlarmTaskTest, AlarmTaskHandleEvent6)
{
	AlarmEventStruct event;
	event.id = ePressSensorErrorDeActivatedId;
	alarmList[ePressSensorErrorId].status = eActivated;
	AlarmTaskHandleEvent(event);

	EXPECT_EQ(eDeactivated,alarmList[ePressSensorErrorId].status);
}

TEST_F(AlarmTaskTest, AlarmTaskHandleEvent7)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,2)).Times(1);

	AlarmEventStruct event;
	event.id = eFlowSensorErrorActivatedId;
	alarmList[eFlowSensorErrorId].status = eDeactivated;
	AlarmTaskHandleEvent(event);

	EXPECT_EQ(eActivated,alarmList[eFlowSensorErrorId].status);
}

TEST_F(AlarmTaskTest, AlarmTaskHandleEvent8)
{
	AlarmEventStruct event;
	event.id = eFlowSensorErrorDeActivatedId;
	alarmList[eFlowSensorErrorId].status = eActivated;
	AlarmTaskHandleEvent(event);

	EXPECT_EQ(eDeactivated,alarmList[eFlowSensorErrorId].status);
}

TEST_F(AlarmTaskTest, AlarmTaskHandleEvent9)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,2)).Times(1);

	AlarmEventStruct event;
	event.id = eSdCardErrorActivatedId;
	alarmList[eSdCardErrorId].status = eDeactivated;
	AlarmTaskHandleEvent(event);

	EXPECT_EQ(eActivated,alarmList[eSdCardErrorId].status);
}

TEST_F(AlarmTaskTest, AlarmTaskHandleEvent10)
{
	AlarmEventStruct event;
	event.id = eSdCardErrorDeActivatedId;
	alarmList[eSdCardErrorId].status = eActivated;
	AlarmTaskHandleEvent(event);

	EXPECT_EQ(eDeactivated,alarmList[eSdCardErrorId].status);
}

TEST_F(AlarmTaskTest, AlarmTaskHandleEvent11)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,2)).Times(1);

	AlarmEventStruct event;
	event.id = ePowerFailedActivatedId;
	alarmList[ePowerFailureId].status = eDeactivated;
	AlarmTaskHandleEvent(event);

	EXPECT_EQ(eActivated,alarmList[ePowerFailureId].status);
}

TEST_F(AlarmTaskTest, AlarmTaskHandleEvent12)
{
	AlarmEventStruct event;
	event.id = ePowerFailedDeActivatedId;
	alarmList[ePowerFailureId].status = eActivated;
	AlarmTaskHandleEvent(event);

	EXPECT_EQ(eDeactivated,alarmList[ePowerFailureId].status);
}

TEST_F(AlarmTaskTest, AlarmTaskHandleEvent13)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,2)).Times(1);

	AlarmEventStruct event;
	event.id = eLeakActivatedId;
	alarmList[eLeakErrorId].status = eDeactivated;
	AlarmTaskHandleEvent(event);

	EXPECT_EQ(eActivated,alarmList[eLeakErrorId].status);
}

TEST_F(AlarmTaskTest, AlarmTaskHandleEvent14)
{
	AlarmEventStruct event;
	event.id = eLeakDeActivatedId;
	alarmList[eLeakErrorId].status = eActivated;
	AlarmTaskHandleEvent(event);

	EXPECT_EQ(eDeactivated,alarmList[eLeakErrorId].status);
}

TEST_F(AlarmTaskTest, AlarmTaskProcess1)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,2)).Times(2);

	isAlarmTaskEnable = true;

	for(int i = 0; i < eLastAlarmId; i++)
	{
		alarmList[i].id = (E_AlarmId)i;
		alarmList[i].status = eDeactivated;
	}

	alarmList[eBlowerErrorId].status = eActivated;

	AlarmTaskProcess();
}

TEST_F(AlarmTaskTest, AlarmTaskProcess2)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,2)).Times(1);

	isAlarmTaskEnable = true;

	for(int i = 0; i < eLastAlarmId; i++)
	{
		alarmList[i].id = (E_AlarmId)i;
		alarmList[i].status = eDeactivated;
	}

	AlarmTaskProcess();
}

TEST_F(AlarmTaskTest, FuncAlarmTask)
{
	EXPECT_CALL(*_PowerMonitorLib,PowerMonitorCheckMocks()).Times(1).WillOnce(Return(false));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);
	EXPECT_CALL(*_PowerMonitorLib,PowerMonitorClearMocks()).Times(1);

	isAlarmTaskEnable = true;
	FuncAlarmTask(nullptr);

	for(int i = 0; i < eLastAlarmId; i++)
	{
		EXPECT_EQ(alarmList[i].id, (E_AlarmId)i );
		EXPECT_EQ(alarmList[i].status, eDeactivated );
	}
}

TEST_F(AlarmTaskTest, ALarmTaskSendEvent1)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,2)).Times(1).WillOnce(Return(pdFAIL));

	EXPECT_EQ(false,ALarmTaskSendEvent(eBlowerErrorActivatedId,0));

}

TEST_F(AlarmTaskTest, ALarmTaskSendEvent2)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,2)).Times(1).WillOnce(Return(pdPASS));

	EXPECT_EQ(true,ALarmTaskSendEvent(eBlowerErrorActivatedId,0));

}

}

