/*
 * analyzeinterface.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#include <stdbool.h>
#include "analyzeinterface.h"
//#include "FreeRTOS.h"
//#include "task.h"

//declare a structure to store breath handler data
AnalyzeDataStruct AnalyzeData;
//declare breath event queue
xQueueHandle analyzeQueue;

//declare a binary semaphore for breath event task synchronization
xSemaphoreHandle analyzeSemphr;

// declare analyze data mutex
xSemaphoreHandle analyzeDataMutex;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//reset breath event data set
void AnalyzeDataReset()
{
	if(xSemaphoreTake(analyzeDataMutex, 2) == pdTRUE)		//wait maximum 1 tick
	{
		taskENTER_CRITICAL();
		//reset value
		AnalyzeData.baseFlow = 0;
//		AnalyzeData.differentialPressure = 0;
		AnalyzeData.rawNosePressure = 0;
		AnalyzeData.filteredNosePressure = 0;
		AnalyzeData.treatmentPressure = 0;
		AnalyzeData.phasePressure = 0;
		AnalyzeData.controlPressure = 0;
		//released semaphore
		xSemaphoreGive(analyzeDataMutex);
		taskEXIT_CRITICAL();
	}
}

//function to get base flow from BrthCtrlData
//return true if getting data success
//return false if getting data failure
bool AnalyzeDataGetBaseFlow(float* valuePtr)
{
	bool rtn = false;
	if(xSemaphoreTake(analyzeDataMutex, 2) == pdTRUE)		//wait maximum 2 tick
	{
		taskENTER_CRITICAL();
		//get value and output it
		*valuePtr = AnalyzeData.baseFlow;
		//release mutex
		xSemaphoreGive(analyzeDataMutex);
		//set return value as success
		rtn = true;
		taskEXIT_CRITICAL();
	}
	//return value
	return rtn;
}

//function to get differential pressure from BrthCtrlData
//return true if getting data success
//return false if getting data failure
//bool AnalyzeDataGetDiffPressure(float* valuePtr)
//{
//	bool rtn = false;
//	if(xSemaphoreTake(analyzeDataMutex, 2) == pdTRUE)		//wait maximum 1 tick
//	{
//		taskENTER_CRITICAL();
//		//get value and output it
//		*valuePtr = AnalyzeData.differentialPressure;
//		//release mutex
//		xSemaphoreGive(analyzeDataMutex);
//		//set return value as success
//		rtn = true;
//		taskEXIT_CRITICAL();
//	}
//	//return value
//	return rtn;
//}

//function to get pressure at user's nose from BrthCtrlData
//return true if getting data success
//return false if getting data failure
bool AnalyzeDataGetRawNosePressure(float* valuePtr)
{
	bool rtn = false;
	if(xSemaphoreTake(analyzeDataMutex, 2) == pdTRUE)		//wait maximum 1 tick
	{
		taskENTER_CRITICAL();
		//get value and output it
		*valuePtr = AnalyzeData.rawNosePressure;
		//release mutex
		xSemaphoreGive(analyzeDataMutex);
		//set return value as success
		rtn = true;
		taskEXIT_CRITICAL();
	}
//	else
//		DebugStr("\n Get nose pressure failed");
	//return value
	return rtn;
}

//function to get pressure at user's nose from BrthCtrlData
//return true if getting data success
//return false if getting data failure
bool AnalyzeDataGetFilteredNosePressure(float* valuePtr)
{
	bool rtn = false;
	if(xSemaphoreTake(analyzeDataMutex, 2) == pdTRUE)		//wait maximum 1 tick
	{
		taskENTER_CRITICAL();
		//get value and output it
		*valuePtr = AnalyzeData.filteredNosePressure;
		//release mutex
		xSemaphoreGive(analyzeDataMutex);
		//set return value as success
		rtn = true;
		taskEXIT_CRITICAL();
	}
	//return value
	return rtn;
}

//function to get treatment pressure from BrthCtrlData
//return true if getting data success
//return false if getting data failure
bool AnalyzeDataGetTreatmentPressure(float* valuePtr)
{
	bool rtn = false;
	if(xSemaphoreTake(analyzeDataMutex, 2) == pdTRUE)		//wait maximum 1 tick
	{
		taskENTER_CRITICAL();
		//get value and output it
		*valuePtr = AnalyzeData.treatmentPressure;
		//release mutex
		xSemaphoreGive(analyzeDataMutex);
		//set return value as success
		rtn = true;
		taskEXIT_CRITICAL();
	}
	//return value
	return rtn;
}

//function to get phase pressure from BrthCtrlData
//phase pressure is pressure between inhalation phase and exhalation phase
//return true if getting data success
//return false if getting data failure
bool AnalyzeDataGetPhasePressure(float* valuePtr)
{
	bool rtn = false;
	if(xSemaphoreTake(analyzeDataMutex, 2) == pdTRUE)		//wait maximum 1 tick
	{
		taskENTER_CRITICAL();
		//get value and output it
		*valuePtr = AnalyzeData.phasePressure;
		//release mutex
		xSemaphoreGive(analyzeDataMutex);
		//set return value as success
		rtn = true;
		taskEXIT_CRITICAL();
	}
	//return value
	return rtn;
}

//function to get control pressure from BrthCtrlData
//control pressure is pressure between desired send to blower
//return true if getting data success
//return false if getting data failure
bool AnalyzeDataGetCtrlPressure(float* valuePtr)
{
	bool rtn = false;
	if(xSemaphoreTake(analyzeDataMutex, 2) == pdTRUE)		//wait maximum 1 tick
	{
		taskENTER_CRITICAL();
		//get value and output it
		*valuePtr = AnalyzeData.controlPressure;
		//release mutex
		xSemaphoreGive(analyzeDataMutex);
		//set return value as success
		rtn = true;
		taskEXIT_CRITICAL();
	}
	//return value
	return rtn;
}

bool AnalyzeTaskSendEvent(char event)
{
	bool rtn = true;
	char sendEvent = event;
	if(xQueueSendToBack(analyzeQueue, &sendEvent, 2) != pdPASS)
	{
//		DebugStr("\n send failed: event to analyze task");
		rtn = false;
	}
	return rtn;
}

#if defined(__cplusplus)
}
#endif



