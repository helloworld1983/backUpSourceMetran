/*
 * analyzeinterface.h
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_ANALYZE_ANALYZEINTERFACE_H_
#define UNITTEST_ANALYZE_ANALYZEINTERFACE_H_

#include <stdbool.h>
//#include "FreeRTOS.h"
#include "queue.h"
//#include "semphr.h"
//#include "debuguart.h"

typedef enum
{
	eAnalyzeTaskResetId = 1,
	eAnalyzeEnableEventId,			// enable phase detection (inhalation and exhalation)
	eAnalyzeDisableEventId,			// disable phase detection
	eAnalyzeEnablePhaseId,
	eAnalyzeDisablePhaseId,
	eAnalyzeEnableRtDataId,
	eAnalyzeDisableRtDataId,
	eAnalyzeEnableFLEventId,		// event to enable FL detection algorithm
	eAnalyzeDisableFLEventId,		// event to disable FL detection algorithm
	eAnalyzeSetMaskOnId,			// event to set mask state is ON
	eAnalyzeSetMaskOffDryId,		// event to set mask state is OFF and drying
	eAnalyzeSetMaskOffStopId,		// event to set mask state is OFF and blower stop
	eAnalyzeEnableMaskOffId,		// event to enable algorithm to detect mask off automatically
	eAnalyzeDisableMaskOffId		// event to disable detecting mask off automatically
} E_AnalyzeEventId;

//declare a structure with content all information related to event data
typedef struct
{
	float baseFlow;
	float rawNosePressure;
	float filteredNosePressure;	//pressure at user's nose
	float treatmentPressure;	//treatment pressure apply for patient
	float phasePressure;		//pressure on phase, depend on inhalation or exhalation
	float controlPressure;		//pressure set to blower
//	float differentialPressure;	//differential pressure converted from flow
} AnalyzeDataStruct;

//a structure to store breath handler data
extern AnalyzeDataStruct AnalyzeData;

//declare breath event queue
extern xQueueHandle analyzeQueue;

//declare a binary semaphore for breath event task synchronization
extern xSemaphoreHandle analyzeSemphr;

// declare analyze data mutex
extern xSemaphoreHandle analyzeDataMutex;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//reset breath event data set
void AnalyzeDataReset();

//function to get base flow from BrthCtrlData
//return true if getting data success
//return false if getting data failure
bool AnalyzeDataGetBaseFlow(float* valuePtr);

//function to get pressure at user's nose from BrthCtrlData
//return true if getting data success
//return false if getting data failure
bool AnalyzeDataGetRawNosePressure(float* valuePtr);

//function to get pressure at user's nose from AnalyzeData
//return true if getting data success
//return false if getting data failure
bool AnalyzeDataGetFilteredNosePressure(float* valuePtr);

//function to get treatment pressure from AnalyzeData
//return true if getting data success
//return false if getting data failure
bool AnalyzeDataGetTreatmentPressure(float* valuePtr);

//function to get phase pressure from AnalyzeData
//phase pressure is pressure between inhalation phase and exhalation phase
//return true if getting data success
//return false if getting data failure
bool AnalyzeDataGetPhasePressure(float* valuePtr);

//function to get control pressure from BrthCtrlData
//control pressure is pressure between desired send to blower
//return true if getting data success
//return false if getting data failure
bool AnalyzeDataGetCtrlPressure(float* valuePtr);

bool AnalyzeTaskSendEvent(char event);

////declare breath event queue
//extern xQueueHandle analyzeQueue;
//
////declare a binary semaphore for breath event task synchronization
//extern xSemaphoreHandle analyzeSemphr;
//
//// declare analyze data mutex
//extern xSemaphoreHandle analyzeDataMutex;

//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: FuncAnalyzeTask()
//
//    Processing:		This operation send event to Analyze Task
//
//    Input Parameters:
//		void *pvParameters: don't care
//
//    Output Parameters:
//		None
//
//    Return Values:
//		bool: 	-true if event was sent successful
//				-false is event was sent failed
//
//    Pre-Conditions:
//		None
//
//    Miscellaneous:
//		None
//
//    Requirements:
//
//******************************************************************************
//inline bool AnalyzeTaskSendEvent(char event)
//{
//	bool rtn = true;
//	char sendEvent = event;
//	if(xQueueSendToBack(analyzeQueue, &sendEvent, 2) != pdPASS)
//	{
//		DebugStr("\n send failed: event to analyze task");
//		rtn = false;
//	}
//	return rtn;
//}

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_ANALYZE_ANALYZEINTERFACE_H_ */
