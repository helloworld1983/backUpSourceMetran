/*
 * analyzeinterfaceTest.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "analyzeinterface.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern AnalyzeDataStruct AnalyzeData;

namespace EmbeddedCUnitTest {


class AnalyzeInterfaceTest : public TestFixture
{
public:
	AnalyzeInterfaceTest() : TestFixture(new ModuleMock) {}
};

TEST_F(AnalyzeInterfaceTest, AnalyzeDataReset)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	AnalyzeDataReset();

	EXPECT_EQ(0,AnalyzeData.baseFlow);
	EXPECT_EQ(0,AnalyzeData.rawNosePressure);
	EXPECT_EQ(0,AnalyzeData.filteredNosePressure);
	EXPECT_EQ(0,AnalyzeData.treatmentPressure);
	EXPECT_EQ(0,AnalyzeData.phasePressure);
	EXPECT_EQ(0,AnalyzeData.controlPressure);
}

TEST_F(AnalyzeInterfaceTest, AnalyzeDataGetBaseFlow1)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	AnalyzeData.baseFlow = 12.5f;
	float valuePtr = 0.0f;
	EXPECT_EQ(true,AnalyzeDataGetBaseFlow(&valuePtr));
	EXPECT_EQ(12.5f,valuePtr);
}

TEST_F(AnalyzeInterfaceTest, AnalyzeDataGetBaseFlow2)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdFALSE));

	AnalyzeData.baseFlow = 12.5f;
	float valuePtr = 0.0f;
	EXPECT_EQ(false,AnalyzeDataGetBaseFlow(&valuePtr));
	EXPECT_EQ(0.0f,valuePtr);
}

TEST_F(AnalyzeInterfaceTest, AnalyzeDataGetRawNosePressure1)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	AnalyzeData.rawNosePressure = 10.5f;
	float valuePtr = 0.0f;
	EXPECT_EQ(true,AnalyzeDataGetRawNosePressure(&valuePtr));
	EXPECT_EQ(10.5f,valuePtr);
}

TEST_F(AnalyzeInterfaceTest, AnalyzeDataGetRawNosePressure2)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdFALSE));

	AnalyzeData.rawNosePressure = 10.5f;
	float valuePtr = 0.0f;
	EXPECT_EQ(false,AnalyzeDataGetRawNosePressure(&valuePtr));
	EXPECT_EQ(0.0f,valuePtr);
}

TEST_F(AnalyzeInterfaceTest, AnalyzeDataGetFilteredNosePressure1)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	AnalyzeData.filteredNosePressure = 9.5f;
	float valuePtr = 0.0f;
	EXPECT_EQ(true,AnalyzeDataGetFilteredNosePressure(&valuePtr));
	EXPECT_EQ(9.5f,valuePtr);
}

TEST_F(AnalyzeInterfaceTest, AnalyzeDataGetFilteredNosePressure2)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdFALSE));

	AnalyzeData.filteredNosePressure = 9.5f;
	float valuePtr = 0.0f;
	EXPECT_EQ(false,AnalyzeDataGetFilteredNosePressure(&valuePtr));
	EXPECT_EQ(0.0f,valuePtr);
}

TEST_F(AnalyzeInterfaceTest, AnalyzeDataGetTreatmentPressure1)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	AnalyzeData.treatmentPressure = 8.5f;
	float valuePtr = 0.0f;
	EXPECT_EQ(true,AnalyzeDataGetTreatmentPressure(&valuePtr));
	EXPECT_EQ(8.5f,valuePtr);
}

TEST_F(AnalyzeInterfaceTest, AnalyzeDataGetTreatmentPressure2)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdFALSE));

	AnalyzeData.treatmentPressure = 8.5f;
	float valuePtr = 0.0f;
	EXPECT_EQ(false,AnalyzeDataGetTreatmentPressure(&valuePtr));
	EXPECT_EQ(0.0f,valuePtr);
}

TEST_F(AnalyzeInterfaceTest, AnalyzeDataGetPhasePressure1)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	AnalyzeData.phasePressure = 7.5f;
	float valuePtr = 0.0f;
	EXPECT_EQ(true,AnalyzeDataGetPhasePressure(&valuePtr));
	EXPECT_EQ(7.5f,valuePtr);
}

TEST_F(AnalyzeInterfaceTest, AnalyzeDataGetPhasePressure2)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdFALSE));

	AnalyzeData.phasePressure = 7.5f;
	float valuePtr = 0.0f;
	EXPECT_EQ(false,AnalyzeDataGetPhasePressure(&valuePtr));
	EXPECT_EQ(0.0f,valuePtr);
}

TEST_F(AnalyzeInterfaceTest, AnalyzeDataGetCtrlPressure1)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	AnalyzeData.controlPressure = 6.5f;
	float valuePtr = 0.0f;
	EXPECT_EQ(true,AnalyzeDataGetCtrlPressure(&valuePtr));
	EXPECT_EQ(6.5f,valuePtr);
}

TEST_F(AnalyzeInterfaceTest, AnalyzeDataGetCtrlPressure2)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdFALSE));

	AnalyzeData.controlPressure = 6.5f;
	float valuePtr = 0.0f;
	EXPECT_EQ(false,AnalyzeDataGetCtrlPressure(&valuePtr));
	EXPECT_EQ(0.0f,valuePtr);
}

TEST_F(AnalyzeInterfaceTest, AnalyzeTaskSendEvent1)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,2)).Times(1).WillOnce(Return(pdPASS));

	EXPECT_EQ(true,AnalyzeTaskSendEvent(eAnalyzeEnableEventId));
}

TEST_F(AnalyzeInterfaceTest, AnalyzeTaskSendEvent2)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,2)).Times(1).WillOnce(Return(pdFAIL));

	EXPECT_EQ(false,AnalyzeTaskSendEvent(eAnalyzeDisableEventId));
}

}



