/*
 * analyzetask.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#include "stdio.h"
#include "analyzetask.h"
//#include "motorcmd.h"
//#include "realtimebuffer.h"
#include "EventMocks.h"
#include "PhaseMocks.h"
#include "BreathDataMocks.h"
#include "MaskOffMocks.h"
#include "MotorDataMocks.h"
#include "RtBufferMocks.h"
#include "AnalyzeDataMocks.h"

bool isEventEnable = false;
bool isPhaseEnable = false;
bool isRtDataEnable = false;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//declare global variables for event task
//variables to allow analyzer task to run mask off algorithm, phase detection algorithm
//static bool isEventEnable = false;
//static bool isPhaseEnable = false;
//static bool isRtDataEnable = false;

//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: AnalyzeTaskProcessQueue()
//
//    Processing:		This operation read data from analyze queue and process them
//
//    Input Parameters: None
//
//    Output Parameters:None
//
//    Return Values:    None
//
//    Pre-Conditions:   None
//
//    Miscellaneous:    None
//
//    Requirements:
//
//******************************************************************************
void AnalyzeTaskProcessQueue(E_AnalyzeEventId eventId)
{
	//read data from queue and handle them
//	unsigned char eventId = 0;
	//read data from queue
	while(xQueueReceive(analyzeQueue, &eventId, 1) == pdTRUE)
	{
		switch(eventId)
		{
		case eAnalyzeTaskResetId:
			//reset event detection
			EventResetMocks();
			//reset phase detection
			PhaseResetMocks();
			//reset breath information
			BreathDataResetMocks();
			//reset base flow calculation structure
			BaseFlowResetMocks();
			break;
		case eAnalyzeEnableEventId:
			//change state
			isEventEnable = true;
			break;
		case eAnalyzeDisableEventId:
			//change state
			isEventEnable = false;
			break;
		case eAnalyzeEnablePhaseId:
			//enable running phase
			isPhaseEnable = true;
			break;
		case eAnalyzeDisablePhaseId:
			//disable running phase
			isPhaseEnable = false;
			break;
		case eAnalyzeEnableRtDataId:
			isRtDataEnable = true;
			break;
		case eAnalyzeDisableRtDataId:
			isRtDataEnable = false;
			break;
		case eAnalyzeSetMaskOnId:
			MaskOffSetStateMocks(eMaskOn);
			break;
		case eAnalyzeSetMaskOffDryId:
			MaskOffSetStateMocks(eMaskOffDry);
			break;
		case eAnalyzeSetMaskOffStopId:
			MaskOffSetStateMocks(eMaskOffStop);
			break;
		case eAnalyzeEnableMaskOffId:
			MaskOffSetEnableMocks(true);
//			DebugStr("\n Enable mask off detection");
			break;
		case eAnalyzeDisableMaskOffId:
			MaskOffSetEnableMocks(false);
//			DebugStr("\n Disable mask off detection");
			break;
		case eAnalyzeEnableFLEventId:
			EventSetFLEnableMocks(true);
//			DebugStr("\n Enable FL detection");
			break;
		case eAnalyzeDisableFLEventId:
			EventSetFLEnableMocks(false);
//			DebugStr("\n Disable FL detection");
			break;
		default:
			break;
		}
	}
}

//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: AnalyzeTaskRun()
//
//    Processing:		This operation apply analyzer algorithm. the algorithm included
//						phase detection algorithm, mask off detection algorithm, breath
//						event detection algorithm
//
//    Input Parameters: None
//
//    Output Parameters:None
//
//    Return Values:    None
//
//    Pre-Conditions:   None
//
//    Miscellaneous:    None
//
//    Requirements:
//
//******************************************************************************
void AnalyzeTaskRun()
{
	float flow = 0;
	float pressure = 0;

	//get flow from blower
	if(MotorDataGetFlowMocks(&flow) == false)
		return;
	//get nose pressure
	if(AnalyzeDataGetFilteredNosePressureMocks(&pressure) == false)
		return;

	if(isPhaseEnable == true)
	{
		//call breath phase handle data
		PhaseHandleDataMocks(flow, pressure);
	}

	//only run phase handler and event handler when allowed
	if(isEventEnable == true)
	{
		//process data for event detection
		EventHandleDataMocks(flow, pressure);
	}

	if(isRtDataEnable == true)
	{
		//log data to real time buffer
		RtBufferHandleDataMocks(flow, pressure);
	}

	//do auto on/off algorithm
	MaskOffHandleDataMocks(flow, pressure);
}

#if defined(__cplusplus)
}
#endif

