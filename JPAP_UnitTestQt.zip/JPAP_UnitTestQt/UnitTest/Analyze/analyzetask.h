/*
 * analyzetask.h
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_ANALYZE_ANALYZETASK_H_
#define UNITTEST_ANALYZE_ANALYZETASK_H_

//#include <breathdata.h>
#include <stdbool.h>
//#include "FreeRTOS.h"
//#include "task.h"
//#include "semphr.h"
#include "alarminterface.h"
//#include "debuguart.h"
//#include "baseflow.h"
#include "analyzeinterface.h"
//#include "event.h"
//#include "maskoff.h"
#include "motorctrlinterface.h"
//#include "phase.h"

//define alarm task priority
#define ANALYZE_TASK_PRIORITY		(tskIDLE_PRIORITY + 2)

//define alarm task stack size
#define ANALYZE_TASK_STACK		(1024)

//define breath event queue size
#define	ANALYZE_QUEUE_SIZE 	8

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//function to process data on breath event queue
void AnalyzeTaskProcessQueue(E_AnalyzeEventId eventId);
//function to run breath event algorithm.
void AnalyzeTaskRun();
void FuncAnalyzeTask(void *pvParameters);

//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: FuncAnalyzeTask()
//
//    Processing:		This operation is the main function of the Analyze Task
//
//    Input Parameters:
//		void *pvParameters: don't care
//
//    Output Parameters:
//		None
//
//    Return Values:
//		None
//
//    Pre-Conditions:
//		None
//
//    Miscellaneous:
//		None
//
//    Requirements:
//
//******************************************************************************
//static inline void FuncAnalyzeTask(void *pvParameters)
//{
//	while(1)
//	{
//		//wait for semaphore to wake up event task
//		if(xSemaphoreTake(analyzeSemphr, portMAX_DELAY))
//		{
//			//process data on event queue
//			AnalyzeTaskProcessQueue();
//			//run breath handler
//			AnalyzeTaskRun();
//		}
//	}
//}

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_ANALYZE_ANALYZETASK_H_ */
