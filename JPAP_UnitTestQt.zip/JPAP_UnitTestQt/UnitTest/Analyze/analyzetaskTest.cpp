/*
 * analyzetaskTest.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "analyzetask.h"
#include "MaskOffMocks.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern bool isEventEnable;
extern bool isPhaseEnable;
extern bool isRtDataEnable;

namespace EmbeddedCUnitTest {


class AnalyzeTaskTest : public TestFixture
{
public:
	AnalyzeTaskTest() : TestFixture(new ModuleMock) {}
};

TEST_F(AnalyzeTaskTest, AnalyzeTaskProcessQueue1)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,1)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdFALSE));
	EXPECT_CALL(*_EventLib,EventResetMocks()).Times(1);
	EXPECT_CALL(*_PhaseLib,PhaseResetMocks()).Times(1);
	EXPECT_CALL(*_BreathDataLib,BreathDataResetMocks()).Times(1);
	EXPECT_CALL(*_BreathDataLib,BaseFlowResetMocks()).Times(1);

	AnalyzeTaskProcessQueue(eAnalyzeTaskResetId);
}

TEST_F(AnalyzeTaskTest, AnalyzeTaskProcessQueue2)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,1)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdFALSE));

	isEventEnable = false;
	AnalyzeTaskProcessQueue(eAnalyzeEnableEventId);

	EXPECT_EQ(true,isEventEnable);
}

TEST_F(AnalyzeTaskTest, AnalyzeTaskProcessQueue3)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,1)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdFALSE));

	isEventEnable = true;
	AnalyzeTaskProcessQueue(eAnalyzeDisableEventId);

	EXPECT_EQ(false,isEventEnable);
}

TEST_F(AnalyzeTaskTest, AnalyzeTaskProcessQueue4)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,1)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdFALSE));

	isPhaseEnable = false;
	AnalyzeTaskProcessQueue(eAnalyzeEnablePhaseId);

	EXPECT_EQ(true,isPhaseEnable);
}

TEST_F(AnalyzeTaskTest, AnalyzeTaskProcessQueue5)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,1)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdFALSE));

	isPhaseEnable = true;
	AnalyzeTaskProcessQueue(eAnalyzeDisablePhaseId);

	EXPECT_EQ(false,isPhaseEnable);
}

TEST_F(AnalyzeTaskTest, AnalyzeTaskProcessQueue6)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,1)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdFALSE));

	isRtDataEnable = false;
	AnalyzeTaskProcessQueue(eAnalyzeEnableRtDataId);

	EXPECT_EQ(true,isRtDataEnable);
}

TEST_F(AnalyzeTaskTest, AnalyzeTaskProcessQueue7)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,1)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdFALSE));

	isRtDataEnable = true;
	AnalyzeTaskProcessQueue(eAnalyzeDisableRtDataId);

	EXPECT_EQ(false,isRtDataEnable);
}

TEST_F(AnalyzeTaskTest, AnalyzeTaskProcessQueue8)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,1)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdFALSE));
	EXPECT_CALL(*_MaskOffLib,MaskOffSetStateMocks(eMaskOn)).Times(1);

	AnalyzeTaskProcessQueue(eAnalyzeSetMaskOnId);

}

TEST_F(AnalyzeTaskTest, AnalyzeTaskProcessQueue9)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,1)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdFALSE));
	EXPECT_CALL(*_MaskOffLib,MaskOffSetStateMocks(eMaskOffDry)).Times(1);

	AnalyzeTaskProcessQueue(eAnalyzeSetMaskOffDryId);

}

TEST_F(AnalyzeTaskTest, AnalyzeTaskProcessQueue10)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,1)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdFALSE));
	EXPECT_CALL(*_MaskOffLib,MaskOffSetStateMocks(eMaskOffStop)).Times(1);

	AnalyzeTaskProcessQueue(eAnalyzeSetMaskOffStopId);

}

TEST_F(AnalyzeTaskTest, AnalyzeTaskProcessQueue11)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,1)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdFALSE));
	EXPECT_CALL(*_MaskOffLib,MaskOffSetEnableMocks(true)).Times(1);

	AnalyzeTaskProcessQueue(eAnalyzeEnableMaskOffId);

}

TEST_F(AnalyzeTaskTest, AnalyzeTaskProcessQueue12)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,1)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdFALSE));
	EXPECT_CALL(*_MaskOffLib,MaskOffSetEnableMocks(false)).Times(1);

	AnalyzeTaskProcessQueue(eAnalyzeDisableMaskOffId);

}

TEST_F(AnalyzeTaskTest, AnalyzeTaskProcessQueue13)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,1)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdFALSE));
	EXPECT_CALL(*_EventLib,EventSetFLEnableMocks(true)).Times(1);

	AnalyzeTaskProcessQueue(eAnalyzeEnableFLEventId);

}

TEST_F(AnalyzeTaskTest, AnalyzeTaskProcessQueue14)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,1)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdFALSE));
	EXPECT_CALL(*_EventLib,EventSetFLEnableMocks(false)).Times(1);

	AnalyzeTaskProcessQueue(eAnalyzeDisableFLEventId);

}

TEST_F(AnalyzeTaskTest, AnalyzeTaskRun)
{
	EXPECT_CALL(*_MotorDataLib,MotorDataGetFlowMocks(_)).Times(1).WillOnce(Return(true));
	EXPECT_CALL(*_AnalyzeDataLib,AnalyzeDataGetFilteredNosePressureMocks(_)).Times(1).WillOnce(Return(true));
	EXPECT_CALL(*_PhaseLib,PhaseHandleDataMocks(_,_)).Times(1);
	EXPECT_CALL(*_EventLib,EventHandleDataMocks(_,_)).Times(1);
	EXPECT_CALL(*_RtBufferLib,RtBufferHandleDataMocks(_,_)).Times(1);
	EXPECT_CALL(*_MaskOffLib,MaskOffHandleDataMocks(_,_)).Times(1);

	isPhaseEnable = true;
	isEventEnable = true;
	isRtDataEnable = true;
	AnalyzeTaskRun();

}

}


