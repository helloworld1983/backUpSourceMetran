/*
 * baseflow.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */
#include "stdio.h"
#include <stdbool.h>
#include "baseflow.h"
//#include "debuguart.h"
//#include "arm_math.h"
#include "analyzeinterface.h"
//#include "FreeRTOS.h"
//#include "task.h"
#include "ArmMath.h"
#include "AnalyzeDataMocks.h"

//define buffer base flow with 1000 sample to store data in 10s
#define BASE_FLOW_BUFFER_SIZE		1000		//
//define buffer to store average base flow
#define BASE_FLOW_AVG_BUFFER_SIZE	5

//create buffer
float baseFlowBuffer[BASE_FLOW_BUFFER_SIZE] = {0};
//create buffer to get average base flow
float baseFlowAvgBuffer[BASE_FLOW_AVG_BUFFER_SIZE] = {0};
//create buffer index
int baseFlowIndex = 0;
//create variable for current base flow
float baseFlow = 0;
//create variable for average base flow
float baseFlowAvg = 0;
//declare index to manage average base flow
int baseFlowAvgIndex = 0;
bool isAvgBufferFull = false;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

////create buffer
//static float baseFlowBuffer[BASE_FLOW_BUFFER_SIZE] = {0};
////create buffer to get average base flow
//static float baseFlowAvgBuffer[BASE_FLOW_AVG_BUFFER_SIZE] = {0};
////create buffer index
//static int baseFlowIndex = 0;
////create variable for current base flow
//static float baseFlow = 0;
////create variable for average base flow
//static float baseFlowAvg = 0;
////declare index to manage average base flow
//static int baseFlowAvgIndex = 0;
//static bool isAvgBufferFull = false;

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: BaseFlowReset()
//
//    Processing:
//		This operation clear base flow buffer and buffer index
//		this function should be called 1 time when motor start OK
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void BaseFlowReset()
{
	//reset buffer index
	baseFlowIndex = 0;
	baseFlowAvgIndex = 0;
	isAvgBufferFull = false;
	//get treatment pressure
	float treatmentPressure = 0;
	AnalyzeDataGetTreatmentPressure(&treatmentPressure);
	//calculate standard base flow
	baseFlow = STANDARD_LEAK(treatmentPressure);
	baseFlowAvg = baseFlow;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: BaseFlowAdd()
//
//    Processing:
//		This operation collect data during a breath to calculate base flow
//		this function will be called during collecting data on a breath
//
//    Input Parameters:
//      float flow: new sample to add
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void BaseFlowAdd(float flow)
{
	if(baseFlowIndex >= BASE_FLOW_BUFFER_SIZE)//buffer full
	{
		//calculate base flow
		BaseFlowEnd();
		return;
	}

	//add new data to buffer
	baseFlowBuffer[baseFlowIndex++] = flow;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: BaseFlowEnd()
//
//    Processing:
//		This operation calculate base flow based on data collected during a breath
//		This function will be called after ending of a breath.
//		It must be called before BaseFlowReset()
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void BaseFlowEnd()
{
	//calculate base flow by get mean value of base flow buffer
	arm_mean_f32(&baseFlowBuffer[0], baseFlowIndex, &baseFlow);

	//check base flow by compare with standard base flow
	//get treatment pressure
	float treatmentPressure = 0;
	AnalyzeDataGetTreatmentPressure(&treatmentPressure);
	//calculate standard base flow
	float stdBaseFlow = STANDARD_LEAK(treatmentPressure);
	//check if base flow calculated is good or not
	if(baseFlow <= stdBaseFlow)
	{
		//base flow calculated can not smaller than standard base flow
		baseFlow = stdBaseFlow;
	}

	//add base flow to average buffer
	baseFlowAvgBuffer[baseFlowAvgIndex] = baseFlow;
	baseFlowAvgIndex++;
	if((baseFlowAvgIndex == BASE_FLOW_AVG_BUFFER_SIZE)&&(!isAvgBufferFull))
		isAvgBufferFull = true;

	baseFlowAvgIndex %= BASE_FLOW_AVG_BUFFER_SIZE;
	//calculate average base flow
	if(isAvgBufferFull)
	{
		arm_mean_f32(&baseFlowAvgBuffer[0], BASE_FLOW_AVG_BUFFER_SIZE, &baseFlowAvg);
	}
	else
		arm_mean_f32(&baseFlowAvgBuffer[0], baseFlowAvgIndex, &baseFlowAvg);

	//record base flow
	if(xSemaphoreTake(analyzeDataMutex, 2) == pdTRUE)		//wait maximum 2 tick
	{
		taskENTER_CRITICAL();
		//update base flow
		AnalyzeData.baseFlow = baseFlowAvg;
		//release mutex
		xSemaphoreGive(analyzeDataMutex);
		taskEXIT_CRITICAL();
	}

	//reset counter index
	baseFlowIndex = 0;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: BaseFlowCancel()
//
//    Processing:
//		This operation cancel the latest value on base flow buffer
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void BaseFlowCancel()
{
	//decrease the pointer value
	baseFlowAvgIndex--;
	//re-calculate average base flow
	if(isAvgBufferFull)
	{
		//declare a temporary buffer to store good data to re-calculated base flow
		float tempBuff[BASE_FLOW_AVG_BUFFER_SIZE - 1];
		//copy data to temporary buffer
		int i = 0; int j = 0;
		for(; i < BASE_FLOW_AVG_BUFFER_SIZE; i++)
		{
			if(i != baseFlowAvgIndex)	//should not copy latest data
				tempBuff[j++] = baseFlowAvgBuffer[i];
		}
		arm_mean_f32(&tempBuff[0], (BASE_FLOW_AVG_BUFFER_SIZE - 1), &baseFlowAvg);
	}
	else
	{
		arm_mean_f32(&baseFlowAvgBuffer[0], baseFlowAvgIndex, &baseFlowAvg);
	}

	//record base flow
	if(xSemaphoreTake(analyzeDataMutex, 2) == pdTRUE)		//wait maximum 2 tick
	{
		taskENTER_CRITICAL();
		//update base flow
		AnalyzeData.baseFlow = baseFlowAvg;
		//release mutex
		xSemaphoreGive(analyzeDataMutex);
		taskEXIT_CRITICAL();
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: BaseFlowGet()
//
//    Processing:
//		This operation get current base flow
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      float:	base flow to return
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
float BaseFlowGet()
{
	return baseFlow;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: BaseFlowGetAvg()
//
//    Processing:
//		This operation get average base flow
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      float:	average base flow to return
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
float BaseFlowGetAvg()
{
	return baseFlowAvg;
}


#if defined(__cplusplus)
}
#endif
