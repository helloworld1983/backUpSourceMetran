/*
 * baseflow.h
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_ANALYZE_BASEFLOW_H_
#define UNITTEST_ANALYZE_BASEFLOW_H_

#define STANDARD_LEAK(x)	(-0.03524642*x*x + 2.79473788*x - 1.09622565)

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//function clear base flow buffer and buffer index
void BaseFlowReset();

//function to collect data during a breath to calculate base flow
//this function will be called during collecting data on a breath
void BaseFlowAdd(float flow);

//function to calculate base flow based on data collected during a breath
//this function will be called after ending of a breath. it must be called before BaseFlowReset()
void BaseFlowEnd();

//function to get current base flow
float BaseFlowGet();

//function to cancel the latest value on base flow buffer
void BaseFlowCancel();

//function to get average base flow in 10 breath
float BaseFlowGetAvg();

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_ANALYZE_BASEFLOW_H_ */
