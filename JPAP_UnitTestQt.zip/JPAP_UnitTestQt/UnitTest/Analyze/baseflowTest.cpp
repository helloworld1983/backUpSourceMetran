/*
 * baseflowTest.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "analyzetask.h"
#include "baseflow.h"
#include "analyzeinterface.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern float baseFlowBuffer[];
extern float baseFlowAvgBuffer[];
extern int baseFlowIndex;
extern float baseFlow;
extern float baseFlowAvg;
extern int baseFlowAvgIndex;
extern bool isAvgBufferFull;

namespace EmbeddedCUnitTest {


class BaseFlowTest : public TestFixture
{
public:
	BaseFlowTest() : TestFixture(new ModuleMock) {}
};

TEST_F(BaseFlowTest, BaseFlowReset)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	AnalyzeData.treatmentPressure = 1.0;
	BaseFlowReset();

	EXPECT_EQ(0,baseFlowIndex);
	EXPECT_EQ(0,baseFlowAvgIndex);
	EXPECT_EQ(false,isAvgBufferFull);
	EXPECT_FLOAT_EQ(1.6632658, baseFlow);
	EXPECT_FLOAT_EQ(1.6632658, baseFlowAvg);
}

TEST_F(BaseFlowTest, BaseFlowEnd1)
{
	EXPECT_CALL(*_ArmMathLib,arm_mean_f32(_,1000,_)).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(2);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(2);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(2);
	EXPECT_CALL(*_ArmMathLib,arm_mean_f32(_,5,_)).Times(1);

	AnalyzeData.treatmentPressure = 1.0;
	baseFlow = 0.5;
	isAvgBufferFull = false;
	baseFlowAvgIndex = 4;
	baseFlowIndex = 1000;
	baseFlowAvg = 6.5;
	BaseFlowEnd();

	EXPECT_FLOAT_EQ(1.6632658, baseFlow);
	EXPECT_FLOAT_EQ(1.6632658, baseFlowAvgBuffer[4]);
	EXPECT_EQ(true,isAvgBufferFull);
	EXPECT_EQ(0,baseFlowAvgIndex);
	EXPECT_FLOAT_EQ(6.5,AnalyzeData.baseFlow);
	EXPECT_EQ(0,baseFlowIndex);
}

TEST_F(BaseFlowTest, BaseFlowEnd2)
{
	EXPECT_CALL(*_ArmMathLib,arm_mean_f32(_,_,_)).Times(2);
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(2);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(2);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(2);

	baseFlowIndex = 0;
	AnalyzeData.treatmentPressure = 1.0;
	baseFlow = 0.5;
	baseFlowAvgIndex = 1;
	isAvgBufferFull = true;
	baseFlowAvg = 6.5;
	BaseFlowEnd();

	EXPECT_FLOAT_EQ(1.6632658, baseFlow);
	EXPECT_FLOAT_EQ(1.6632658, baseFlowAvgBuffer[1]);
	EXPECT_EQ(2,baseFlowAvgIndex);
	EXPECT_FLOAT_EQ(6.5,AnalyzeData.baseFlow);
}

TEST_F(BaseFlowTest, BaseFlowAdd1)
{
	EXPECT_CALL(*_ArmMathLib,arm_mean_f32(_,1000,_)).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(2);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(2);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(2);
	EXPECT_CALL(*_ArmMathLib,arm_mean_f32(_,5,_)).Times(1);

	AnalyzeData.treatmentPressure = 1.0;
	baseFlow = 0.5;
	isAvgBufferFull = false;
	baseFlowAvgIndex = 4;
	baseFlowIndex = 1000;
	baseFlowAvg = 6.5;
	BaseFlowAdd(9.5);

	EXPECT_FLOAT_EQ(1.6632658, baseFlow);
	EXPECT_FLOAT_EQ(1.6632658, baseFlowAvgBuffer[4]);
	EXPECT_EQ(true,isAvgBufferFull);
	EXPECT_EQ(0,baseFlowAvgIndex);
	EXPECT_FLOAT_EQ(6.5,AnalyzeData.baseFlow);
	EXPECT_EQ(0,baseFlowIndex);
}

TEST_F(BaseFlowTest, BaseFlowAdd2)
{
	baseFlowIndex = 1;
	BaseFlowAdd(9.5);

	EXPECT_FLOAT_EQ(9.5,baseFlowBuffer[1]);
}

TEST_F(BaseFlowTest, BaseFlowCancel1)
{
	EXPECT_CALL(*_ArmMathLib,arm_mean_f32(_,4,_)).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	baseFlowAvgIndex = 2;
	isAvgBufferFull = true;
	baseFlowAvg = 10.5;
	BaseFlowCancel();

	EXPECT_EQ(1,baseFlowAvgIndex);
	EXPECT_FLOAT_EQ(10.5,AnalyzeData.baseFlow);
}

TEST_F(BaseFlowTest, BaseFlowCancel2)
{
	EXPECT_CALL(*_ArmMathLib,arm_mean_f32(_,2,_)).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	baseFlowAvgIndex = 3;
	isAvgBufferFull = false;
	baseFlowAvg = 11.5;
	BaseFlowCancel();

	EXPECT_EQ(2,baseFlowAvgIndex);
	EXPECT_FLOAT_EQ(11.5,AnalyzeData.baseFlow);
}

TEST_F(BaseFlowTest, BaseFlowGet)
{
	baseFlow = 12.5;

	EXPECT_FLOAT_EQ(12.5,BaseFlowGet());
}

TEST_F(BaseFlowTest, BaseFlowGetAvg)
{
	baseFlowAvg = 15.5;

	EXPECT_FLOAT_EQ(15.5,BaseFlowGetAvg());
}

}


