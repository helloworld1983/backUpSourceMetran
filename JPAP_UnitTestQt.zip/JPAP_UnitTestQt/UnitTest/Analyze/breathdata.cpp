/*
 * breathdata.cpp
 *
 *  Created on: May 4, 2018
 *      Author: Quoc Viet
 */

//#include "FreeRTOS.h"
//#include "task.h"
//#include "debuguart.h"
#include "breathdata.h"
//#include "event.h"
//#include "volume.h"
#include "phase.h"
#include "baseflow.h"
#include "queue.h"
#include "VolumeMocks.h"

//declare breath information instance
BrthDataDetail currentBreath;
//declare average breath data
AvgBrthStruct avgBreath;
//time at start a new breath
unsigned long breathStartTime = 0;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: BreathDataReset()
//
//    Processing:
//		This operation all breath data in breath data buffer
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void BreathDataReset()
{
	currentBreath.amplitude = 70; 		//70 lpm is normal amplitude for adult
	currentBreath.exhTime = 500;		//500 ms
	currentBreath.inhTime = 500;		//500ms
	currentBreath.peakExhFlow = -20; 	//-20 lpm
	currentBreath.peakInhFlow = 50;		//50 lpm
	currentBreath.totalTime = 1000;		//1s for 1 breath
	currentBreath.volume = 300;			//300ml

	avgBreath.index = 0;
	avgBreath.full = false;
	for(int i = 0; i < EVENT_AVG_BUFF_SIZE; i++)
	{
		avgBreath.data[i].volume = 0;
		avgBreath.data[i].amplitude = 0;
		avgBreath.data[i].startTime = 0;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: BreathDataAdd()
//
//    Processing:
//		This operation add new data to breath buffer
//
//    Input Parameters:
//      BrthDataShorten item: new data to add to buffer
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void BreathDataAdd(BrthDataShorten item)
{
	//add new item to buffer
	avgBreath.data[avgBreath.index++] = item;
	//re-calculate index
	avgBreath.index %= EVENT_AVG_BUFF_SIZE;
	//check data to set buffer full
	if((avgBreath.index == 0)&&(!avgBreath.full))	//buffer full and now loop back
	{
		avgBreath.full = true;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: BreathDataCalc()
//
//    Processing:
//		This operation calculate average volume and amplitude from breath data buffer
//
//    Input Parameters:
//      avgBreath.data[]: breath data buffer
//
//    Output Parameters:
//      avgBreath.avgAmplitude: average amplitude
//		avgBreath.avgVolume:	average volume
//
//    Return Values:
//      none
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void BreathDataCalc()
{
	float sumAmplitude = 0;
	float sumVolume = 0;
	int num = (avgBreath.full)?EVENT_AVG_BUFF_SIZE:avgBreath.index;
	if(num > 0)
	{
		for(int i = 0; i < num; i++)
		{
			//add amplitude data to sum
			sumAmplitude += avgBreath.data[i].amplitude;
			//add volume data to sum
			sumVolume += avgBreath.data[i].volume;
		}
		//get average amplitude
		avgBreath.avgAmplitude = sumAmplitude/(float)num;
		//get average volume
		avgBreath.avgVolume = sumVolume/(float)num;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: BreathDataEnd()
//
//    Processing:
//		This operation process data of latest breath when finish a breath,
//		include amplitude, volume, total time,...
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void BreathDataEnd()
{
	unsigned long currentTime = xTaskGetTickCount();

	//finish volume of previous breath
	VolumeEndMocks();
	//start new volume for current breath
	VolumeBeginMocks(startInhFlow);
	//get current tidal volume
	currentBreath.volume = VolumeGetMocks();
	//get current amplitude
	currentBreath.amplitude = (currentBreath.peakInhFlow - currentBreath.peakExhFlow);
	//get breath time
	currentBreath.totalTime = (currentTime- breathStartTime);	//in seconds
	//get exhalation time
	currentBreath.exhTime = currentBreath.totalTime - currentBreath.inhTime;
	//reset max flow
	currentBreath.peakInhFlow = MAX_FLOW_RST;
	//reset start time of breath
	breathStartTime = currentTime;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: BreathHandleData()
//
//    Processing:
//		This operation use flow value from sensor to calculate amplitude and volume
//		of a breath
//
//    Input Parameters:
//      float flow: flow value from sensor
//
//    Output Parameters:
//      currentBreath: current breath data
//
//    Return Values:
//      bool: 	- true if a breath is finished
//				- false if breath still remain
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
bool BreathHandleData(float flow)
{
	bool rtn = false;
	static E_BreathPhase prevPhase = ePhaseExhMaintain;

	//monitor breath phase and reset max flow and min flow
	E_BreathPhase currentPhase = breathPhase;
	if(prevPhase != currentPhase)
	{
		if(currentPhase == ePhaseInhTrigger)
		{
			//do data processing of a breath has just done
			BreathDataEnd();
			rtn = true;
		}
		else if(currentPhase == ePhaseExhTrigger)
		{
			//reset peak exhalation flow
			currentBreath.peakExhFlow = MIN_FLOW_RST;
			//calculate inhalation time
			currentBreath.inhTime = (xTaskGetTickCount() - breathStartTime);
		}
		//update previous phase
		prevPhase = currentPhase;
	}

	//detect max flow and min flow
	currentBreath.peakInhFlow = (flow >= currentBreath.peakInhFlow)?flow:currentBreath.peakInhFlow;
	currentBreath.peakExhFlow = (flow <= currentBreath.peakExhFlow)?flow:currentBreath.peakExhFlow;

	//add flow to calculate tidal volume
	VolumeAddMocks(flow);

	return rtn;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: BreathDataCheckForAdd()
//
//    Processing:
//		This operation check current breath data to add to average buffer
//		Condition to add is: current data in range 80% -> 120%
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      bool: 	- true if data in range and ok to add
//				- false if data out of range
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
bool BreathDataCheckForAdd()
{
#define BREATH_DATA_LOWLMT		0.7	//under than 70%, do not add to average buffer
#define BREATH_DATA_HIGHLMT		1.7	//over than 130%, do not add to average buffer

	bool rtn = false;

	//calculate ratio
	float ampRatio = (currentBreath.amplitude/avgBreath.avgAmplitude);
	float volumeRatio = (currentBreath.volume/avgBreath.avgVolume);

	if((ampRatio >= BREATH_DATA_LOWLMT)&&(volumeRatio >= BREATH_DATA_LOWLMT)
			&&(ampRatio <= BREATH_DATA_HIGHLMT)&&(volumeRatio <= BREATH_DATA_HIGHLMT))
	{
		// add new data to average buffer
		BrthDataShorten cData;
		cData.amplitude = currentBreath.amplitude;
		cData.volume = currentBreath.volume;
		cData.startTime = breathStartTime;

		BreathDataAdd(cData);
		rtn = true;
	}

	//check for leak to cancel base flow
	if((ampRatio >= BREATH_DATA_HIGHLMT)||(volumeRatio >= BREATH_DATA_HIGHLMT))
	{
		//cancel latest base flow value on base flow average buffer
		BaseFlowCancel();
	}

	return rtn;
}



#if defined(__cplusplus)
}
#endif
