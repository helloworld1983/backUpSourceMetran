/*
 * breathdata.h
 *
 *  Created on: May 4, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_ANALYZE_BREATHDATA_H_
#define UNITTEST_ANALYZE_BREATHDATA_H_

#include <stdbool.h>

#define MAX_FLOW_RST	-1000		//max flow at reset
#define MIN_FLOW_RST	1000		//min flow at reset

#define EVENT_AVG_BUFF_SIZE		40		// maximum 40 item on the buffer
//#define EVENT_AVG_MIN_ITEM		20		// at least 20 item on the buffer

//time at start a new breath
extern unsigned long breathStartTime;

typedef struct
{
	unsigned long inhTime;		// inhalation time
	unsigned long exhTime;		// exhlalation time
//	float plateauTime;	// plateau time
	unsigned long totalTime;	// total breath time
//	float frequency;	// breath per minute
	float peakInhFlow;	// peak inhalation flow
	float peakExhFlow;	// peak exhalation flow
	float amplitude;		// amplitude flow
	float volume;		// tidal volume
} BrthDataDetail;

//define structure for average breath item
typedef struct
{
	float volume;		// volume of breath
	float amplitude;	// amplitude of breath
	unsigned long startTime;		// start time of breath
} BrthDataShorten;

typedef struct
{
	BrthDataShorten data[EVENT_AVG_BUFF_SIZE];		//maximum 40 items
	int index;
	bool full;
//	int head;				//current index
//	int tail;
	float avgAmplitude;
	float avgVolume;
} AvgBrthStruct;

extern BrthDataDetail currentBreath;
extern AvgBrthStruct avgBreath;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//function to reset breath data include current breath data and average breath data
void BreathDataReset();

//function to add new item to breath data buffer
void BreathDataAdd(BrthDataShorten item);

//function to get size of buffer of breath data
int BreathDataGetSize();

//function to calculate average data from breath data buffer
void BreathDataCalc();

//function to process breath data at the end of a breath
void BreathDataEnd();

//function to handle raw pressure and flow data
//return true if a breath is done
//return false if breath is still remain
bool BreathHandleData(float flow);

//function to check new breath data in range. if ok, add to average buffer
//return true if breath data is ok to add
//return false if breath data is out of range
bool BreathDataCheckForAdd();

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_ANALYZE_BREATHDATA_H_ */
