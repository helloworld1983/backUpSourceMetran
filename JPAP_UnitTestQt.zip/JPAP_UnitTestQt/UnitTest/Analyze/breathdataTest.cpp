/*
 * breathdataTest.cpp
 *
 *  Created on: May 4, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "breathdata.h"
#include "phase.h"
#include "analyzeinterface.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern float baseFlowAvg;
extern int baseFlowAvgIndex;
extern bool isAvgBufferFull;

namespace EmbeddedCUnitTest {


class BreathDataTest : public TestFixture
{
public:
	BreathDataTest() : TestFixture(new ModuleMock) {}
};

TEST_F(BreathDataTest, BreathDataReset)
{
	BreathDataReset();

	EXPECT_EQ(70,currentBreath.amplitude);
	EXPECT_EQ((unsigned long)500,currentBreath.exhTime);
	EXPECT_EQ((unsigned long)500,currentBreath.inhTime);
	EXPECT_EQ(-20,currentBreath.peakExhFlow);
	EXPECT_EQ(50,currentBreath.peakInhFlow);
	EXPECT_EQ((unsigned long)1000,currentBreath.totalTime);
	EXPECT_EQ(300,currentBreath.volume);

	EXPECT_EQ(0,avgBreath.index);
	EXPECT_EQ(false,avgBreath.full);
	for(int i = 0; i < EVENT_AVG_BUFF_SIZE; i++)
	{
		EXPECT_EQ(0,avgBreath.data[i].volume);
		EXPECT_EQ(0,avgBreath.data[i].amplitude);
		EXPECT_EQ((unsigned long)0,avgBreath.data[i].startTime);
	}
}

TEST_F(BreathDataTest, BreathDataAdd)
{
	avgBreath.index = 39;
	avgBreath.full = false;
	BrthDataShorten item;
	item.amplitude = 2.5;
	item.startTime = 10;
	item.volume = 5.5;
	BreathDataAdd(item);

	EXPECT_FLOAT_EQ(2.5,avgBreath.data[39].amplitude);
	EXPECT_EQ((unsigned long)10,avgBreath.data[39].startTime);
	EXPECT_FLOAT_EQ(5.5,avgBreath.data[39].volume);
	EXPECT_EQ(true,avgBreath.full);
}

TEST_F(BreathDataTest, BreathDataCalc)
{
	avgBreath.index = 2;
	avgBreath.full = false;
	avgBreath.data[0].amplitude = 1.5;
	avgBreath.data[1].amplitude = 2.5;
	avgBreath.data[0].volume = 0.5;
	avgBreath.data[1].volume = 4.5;
	BreathDataCalc();

	EXPECT_FLOAT_EQ(2.0,avgBreath.avgAmplitude);
	EXPECT_FLOAT_EQ(2.5,avgBreath.avgVolume);
}

TEST_F(BreathDataTest, BreathDataEnd)
{
	EXPECT_CALL(*_queueLib,xTaskGetTickCount()).Times(1).WillOnce(Return(10));
	EXPECT_CALL(*_VolumeLib,VolumeEndMocks()).Times(1);
	EXPECT_CALL(*_VolumeLib,VolumeBeginMocks(_)).Times(1);
	EXPECT_CALL(*_VolumeLib,VolumeGetMocks()).Times(1).WillOnce(Return(5));

	currentBreath.peakInhFlow = 6.0;
	currentBreath.peakExhFlow = 2.0;
	breathStartTime = 1;
	currentBreath.inhTime = 3;
	BreathDataEnd();

	EXPECT_EQ(5,currentBreath.volume);
	EXPECT_FLOAT_EQ(4.0,currentBreath.amplitude);
	EXPECT_EQ((unsigned long)9,currentBreath.totalTime);
	EXPECT_EQ((unsigned long)6,currentBreath.exhTime);
	EXPECT_FLOAT_EQ(MAX_FLOW_RST,currentBreath.peakInhFlow);
	EXPECT_EQ((unsigned long)10,breathStartTime);
}

TEST_F(BreathDataTest, BreathHandleData1)
{
	EXPECT_CALL(*_queueLib,xTaskGetTickCount()).Times(1).WillOnce(Return(10));
	EXPECT_CALL(*_VolumeLib,VolumeEndMocks()).Times(1);
	EXPECT_CALL(*_VolumeLib,VolumeBeginMocks(_)).Times(1);
	EXPECT_CALL(*_VolumeLib,VolumeGetMocks()).Times(1).WillOnce(Return(5));
	EXPECT_CALL(*_VolumeLib,VolumeAddMocks(_)).Times(1);

	currentBreath.peakInhFlow = 6.0;
	currentBreath.peakExhFlow = 2.0;
	breathStartTime = 1;
	currentBreath.inhTime = 3;
	breathPhase = ePhaseInhTrigger;

	EXPECT_EQ(true,BreathHandleData(1.5));
	EXPECT_EQ(5,currentBreath.volume);
	EXPECT_FLOAT_EQ(4.0,currentBreath.amplitude);
	EXPECT_EQ((unsigned long)9,currentBreath.totalTime);
	EXPECT_EQ((unsigned long)6,currentBreath.exhTime);
	EXPECT_FLOAT_EQ(1.5,currentBreath.peakInhFlow);
	EXPECT_EQ((unsigned long)10,breathStartTime);
	EXPECT_FLOAT_EQ(1.5,currentBreath.peakExhFlow);
}

TEST_F(BreathDataTest, BreathHandleData2)
{
	EXPECT_CALL(*_queueLib,xTaskGetTickCount()).Times(1).WillOnce(Return(10));
	EXPECT_CALL(*_VolumeLib,VolumeAddMocks(_)).Times(1);

	breathStartTime = 5;
	breathPhase = ePhaseExhTrigger;
	EXPECT_EQ(false,BreathHandleData(5.0));

	EXPECT_FLOAT_EQ(5.0,currentBreath.peakExhFlow);
	EXPECT_EQ((unsigned long)5,currentBreath.inhTime);
	EXPECT_FLOAT_EQ(5.0,currentBreath.peakInhFlow);
}

TEST_F(BreathDataTest, BreathDataCheckForAdd1)
{
	EXPECT_CALL(*_ArmMathLib,arm_mean_f32(_,4,_)).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	avgBreath.index = 39;
	avgBreath.full = false;

	currentBreath.amplitude = 17.0;
	avgBreath.avgAmplitude = 10.0;
	currentBreath.volume = 1.0;
	avgBreath.avgVolume = 1.0;
	breathStartTime = 1;
	baseFlowAvgIndex = 2;
	isAvgBufferFull = true;
	baseFlowAvg = 10.5;

	EXPECT_EQ(false,BreathDataCheckForAdd());
	EXPECT_FLOAT_EQ(2.5,avgBreath.data[39].amplitude);
	EXPECT_EQ((unsigned long)10,avgBreath.data[39].startTime);
	EXPECT_FLOAT_EQ(5.5,avgBreath.data[39].volume);
	EXPECT_EQ(false,avgBreath.full);
	EXPECT_EQ(1,baseFlowAvgIndex);
	EXPECT_FLOAT_EQ(10.5,AnalyzeData.baseFlow);
}

TEST_F(BreathDataTest, BreathDataCheckForAdd2)
{
	EXPECT_CALL(*_ArmMathLib,arm_mean_f32(_,4,_)).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	currentBreath.amplitude = 2.0;
	avgBreath.avgAmplitude = 1.0;
	currentBreath.volume = 20.0;
	avgBreath.avgVolume = 1.0;
	baseFlowAvgIndex = 2;
	isAvgBufferFull = true;
	baseFlowAvg = 10.5;

	EXPECT_EQ(false,BreathDataCheckForAdd());
	EXPECT_EQ(1,baseFlowAvgIndex);
	EXPECT_FLOAT_EQ(10.5,AnalyzeData.baseFlow);
}

}



