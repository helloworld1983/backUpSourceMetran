/*
 * event.cpp
 *
 *  Created on: May 7, 2018
 *      Author: Quoc Viet
 */

#include <setting.h>
#include "event.h"
//#include "FreeRTOS.h"
//#include "task.h"
//#include "debuguart.h"
//#include "arm_math.h"
#include "systeminterface.h"
//#include "systemconfig.h"
#include "breathdata.h"
#include "analyzeinterface.h"
#include "motorctrlinterface.h"
#include "phase.h"
//#include "volume.h"
#include "baseflow.h"
//#include "eventcheynestoke.h"
#include "EventMocks.h"
#include "ArmMath.h"
#include "SettingMocks.h"

#if 1//SUPPORT_EVENT_DISPLAY
#include "guiinterface.h"
//current breathing event
unsigned char eventBreath;
#endif

//define percentage to cancel event
//#define EVENT_CANCEL_LMT			((float)0.7)
//#define EVENT_FL_UPPER_LMT			((float)0.6)
//#define EVENT_FL_LOWER_LMT			((float)0.4)
//#define EVENT_H_UPPER_LMT			EVENT_FL_LOWER_LMT
//#define EVENT_H_LOWER_LMT			((float)0.0)
//#define EVENT_APNEA_UPPER_LMT		EVENT_H_LOWER_LMT
//#define EVENT_APNEA_LOWER_LMT		((float)0.0)
//#define EVENT_CS_DETECT_LMT			((float)0.2)
//#define EVENT_CS_CANCEL_LMT			((float)0.5)
//
////define vibration time for 1 cycle
//#define EVENT_VIBRATION_CYCLE		(1000/MOTOR_VIBRATION_FREQ)
////define vibration time for 1 section (12s)
//#define EVENT_VIBRATION_SECTION		(12*1000)
////flow amplitude limit to determine obstructive apnea
//#define EVENT_VIBRATION_LMT			5		// 6 LPM
////flow amplitude limit to exit vibration
//#define EVENT_VIBRATION_EXIT_LMT	7	//5LPM
//
////define number of cycle per section
//#define EVENT_CYCLE_PER_SECTION		(EVENT_VIBRATION_SECTION/EVENT_VIBRATION_CYCLE)
////define number of sample per cycle
//#define EVENT_SAMPLE_PER_CYCLE		(EVENT_VIBRATION_CYCLE/MOTOR_TASK_PRIODIC)
//
////define for snoring detection
//#define SNORE_FREQ_LMT			20		//snore is counted from 10Hz
//#define SNORE_INDEX_LMT			((int)((SNORE_FREQ_LMT*FFT_SAMPLE)/100))	//100 sampling rate
//#define SNORE_FFT_DETECT_LMT	((float)1.2)
//#define SNORE_COUNT_DETECT_LMT	7
//#define SNORE_MAX_PRESSURE		12 		//12 cmH2O maximum for snoring
//
//#define EVENT_CONFIRM_S			3	// 3 times of event Snore to make sure that event actually occur
//#define EVENT_CONFIRM_FL_H		5	// number of breath that an FL or H occur to make sure that FL or H is actually occur
//
////define max pressure increase when event happen continuously
//#define EVENT_PRESS_INC_MAX		(2)		//2 cmH2O
//
////number of sample for FFT calculation
//#define FFT_SAMPLE	64//128

bool eventIsFLEnable = true;
E_EventDetectionProcess eventDetectionState = eEventDetectionIdle;
E_OperationMode ventilationType = eAutoMode;
portTickType eventStartTime = 0;
portTickType eventHDetectTime = 0;
int countFL = 0;
int countH = 0;
int countNormal = 0;
int countSnore = 0;
int eventCycleCount = 0;
int eventSampleCount = 0;
int numCA = 0;		//Central apnea
int numOA = 0;		//Obstructive apnea
int numH = 0;		//Hypo Apnea
int numFL = 0;		//Flow limitation
int numS = 0;		//Snoring
bool isApneaOccurred = false;
bool isSnoreOccurred = false;
int eventCyclePerSection = 0;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//event start time, use to record tick to determine IDLE duration, COLLECT DATA duration,
//DETECT EVENT duration and DESCREASE PRESSURE duration
//static portTickType eventStartTime = 0;
//variable hold the tick time to detect Hypo-Apnea by time
//according to that, H event will be generated if 30s continuously without a normal breath
//static portTickType eventHDetectTime = 0;

//flag to enable FL detection
//static bool eventIsFLEnable = true;

//count number of breath that an event occurred
//static int countFL = 0;
//static int countH = 0;
//static int countApnea = 0;
//static int countSnore = 0;
//static int countNormal = 0;

//count number of event for a session
//static int numCA = 0;		//Central apnea
//static int numOA = 0;		//Obstructive apnea
//static int numH = 0;		//Hypo Apnea
//static int numFL = 0;		//Flow limitation
//static int numS = 0;		//Snoring

//variable indicate that an APNEA event is occur
//static bool isApneaOccurred = false;
//variable indicate that a snoring event is occur
//static bool isSnoreOccurred = false;
//count for number of cycle per section while doing vibration
//static int eventCycleCount = 0;
//count for number of sample per cycle while doing vibration
//static int eventSampleCount = 0;
//number of cycle per session in vibration mode
//static int eventCyclePerSection = 0;

//ventilation type
//static E_OperationMode ventilationType = eAutoMode;
//event process
//static E_EventDetectionProcess eventDetectionState = eEventDetectionIdle;
//pressure at the beginning of vibration
static float pressBeforeEvent = 0;

//buffer to store amplitude flow of vibration for each cycle
static float ampVibrationBuffer[EVENT_CYCLE_PER_SECTION] = {0};
//buffer to store mean flow of vibration for each cycle
static float meanVibrationBuffer[EVENT_CYCLE_PER_SECTION] = {0};
//buffer to store raw flow data in a cycle
static float flowVibrationBuffer[EVENT_SAMPLE_PER_CYCLE] = {0};

// ************ function declaration *******************
//function to handle FL event
void EventHandleFL();
//function to handle H event
void EventHandleH();
//function to handle Snore event
void EventHandleS();
//function to handle CA event
void EventHandleCA();
//function to handle OA event
void EventHandleOA();

//function to handle vibration flow to detect OA or CA
void EventHandleVibration(float flow);
//function to detect Snoring during breath
void EventDetectSnore();
//function to check whether snoring occurred after a breath
void EventCheckSnore();
//function to check whether FL and S has occurred
void EventCheckFLandH();
//function to detect Apnea by time
void EventCheckHypoApneaByTime();
//function to check breath data to detect event
void EventCheckBreathData();
//function to check Apnea (CA/OA)
void EventCheckApnea();
//function to check time and treatment pressure to decrease pressure if no event
void EventCheckDecPressure();

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventHandleVibration()
//
//    Processing:
//		This operation set enable/disable FL event detection.
//
//    Input Parameters:
//      bool isEnable:		-true: enable FL event detection
//							-false: disable FL event detection
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventSetFLEnable(bool isEnable)
{
	eventIsFLEnable = isEnable;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventReset()
//
//    Processing:
//		This operation to reset all event variables to begin a new cycle of detection.
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventReset()
{
//	DebugStr("+++ reset event");
	//set current event detection as idle
	eventDetectionState = eEventDetectionIdle;
	//get ventilation type
	ventilationType = (E_OperationMode)SettingGetMocks(eVentModeSettingId);
	//record current time
	eventStartTime = xTaskGetTickCount();
	//record time to detect Hypo-Apnea
	eventHDetectTime = eventStartTime;		//xTaskGetTickCount();
	//	eventDetectedTime = xTaskGetTickCount();
	//record start breath
	breathStartTime = eventStartTime;//xTaskGetTickCount();
	//clear count
	countFL = 0;
	countH = 0;
//	countApnea = 0;
	countNormal = 0;
	countSnore = 0;
	eventCycleCount = 0;
	eventSampleCount = 0;
	//reset number of event collected
	numCA = 0; numOA = 0; numH = 0; numFL = 0; numS = 0;
	//clear flag indicate that apnea occurred
	isApneaOccurred = false;
	//clear flag indicate that snore occurred
	isSnoreOccurred = false;
	//reset number of cycle per section in vibration
	eventCyclePerSection = EVENT_CYCLE_PER_SECTION/2;
	//clear Cheyne Stoke data buffer
	EventCSresetMocks();
	//do not allow snoring detection collect data
	//	isSnoreCollecData = false;
#if 1//SUPPORT_EVENT_DISPLAY
	//clear event
	eventBreath = 0;
	GuiTaskSendEventMocks(eGuiRealPressUpdateId, 0);
#endif
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventHandleData()
//
//    Processing:
//		This operation get flow data from buffer, then collect breath data to calculate events.
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventHandleData(float flow, float pressure)
{
	//define minimum time of a breath as 1s
#define EVENT_MIN_BREATH_TIME		(1.2*1000)
	//breath handle data
	bool aBreathDone = BreathHandleData(flow);

	//check event process state
	switch(eventDetectionState)
	{
	case eEventDetectionIdle:
		if((xTaskGetTickCount() - eventStartTime) >= EVENT_IDLE_TIME)
		{
//			DebugStr("\n start collect data ************");
			//change state
			eventDetectionState = eEventCollectData;		//enable detection
			//record current time
			eventStartTime = xTaskGetTickCount();
		}
		break;
	case eEventCollectData:
		if((aBreathDone == true)&&(currentBreath.totalTime >= EVENT_MIN_BREATH_TIME))	//total time must be greater than 1s
		{
			//make data to add to average buffer
			BrthDataShorten cData;
			cData.amplitude = currentBreath.amplitude;
			cData.volume = currentBreath.volume;
			cData.startTime = breathStartTime;
			//add data
			BreathDataAdd(cData);
		}

		//check condition to change state
		if((xTaskGetTickCount() - eventStartTime) >= EVENT_COLLECT_TIME)	//1 minutes
		{
			//change state
			eventDetectionState = eEventDoDetection;		//enable detection
			//record current time
			eventStartTime = xTaskGetTickCount();
			//record time to detect Hypo-Apnea by time
			eventHDetectTime = xTaskGetTickCount();
			//record current treatment pressure at normal condition (no event)
			AnalyzeDataGetTreatmentPressure(&pressBeforeEvent);
			//			DebugStr("\n EventHandleData *******");
			//			DebugStr("\n pressBeforeEvent: ");
			//			DebugNumber(pressBeforeEvent*10);
//			DebugStr("\n enable event detection *************");
		}
		break;
	case eEventDoDetection:
		if(aBreathDone == true)	//total time must be greater than 1s
		{
			//calculate latest average data
			BreathDataCalc();
			//check and update new data to average buffer
			BreathDataCheckForAdd();
			//check volume to detect event
			EventCheckBreathData();
		}
		//check time to detect apnea
		EventCheckApnea();
		//check time to detect Hypo-Apnea by time
		EventCheckHypoApneaByTime();
		//check to decrease pressure
		EventCheckDecPressure();
		//check snoring
		EventDetectSnore();
		break;
	case eEventHandleVibration:
		//detect breath from patient in case of doing pressure vibration 1Hz
		//method to detect is based on volume increase or amplitude increase
		EventHandleVibration(flow);
		break;
	default:
		eventDetectionState = eEventDetectionIdle;
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventDetectSnore()
//
//    Processing:
//		This operation do algorithm to detect snoring.
//		Snoring will be detected by doing FFT with input signal is pressure at user nose
//		Snoring will be run only 1 time in inhalation phase and 1 time in exhalation phase
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventDetectSnore()
{
	static bool findPositive = false;		// true = find positive pressure; false = find negative pressure
	static int snoreCount = 0;
	float nosePressure, controlPressure;

	//check breath phase to enable snoring collection data
	E_BreathPhase currentPhase = breathPhase;
	//do not detect snoring during inhalation trigger and exhalation trigger
	switch(currentPhase)
	{
	case ePhaseInhTrigger:
		//prepare for snoring detection
		findPositive = false;
		snoreCount = 0;
		break;
	case ePhaseInhMaintain:
		//get nose pressure
		if(AnalyzeDataGetRawNosePressure(&nosePressure) == false)
			break;
		//get phase pressure
		if(AnalyzeDataGetCtrlPressure(&controlPressure) == false)
			break;
		//do snoring detection
		if(findPositive == true)
		{
			//find the point that nose pressure greater than control pressure
			if(nosePressure > (controlPressure+0.2))
			{
				snoreCount++;
				findPositive = false;
			}
		}
		else
		{
			//find the point that nose pressure less than control pressure
			if(nosePressure < (controlPressure-0.2))
			{
				snoreCount++;
				findPositive = true;
			}
		}
		break;
	case ePhaseExhTrigger:
		if(snoreCount >= 9)
		{
			//set flag indicate that snore occurred
			isSnoreOccurred = true;
		}
		snoreCount = 0;
		break;
	default:
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventCheckHypoApneaByTime()
//
//    Processing:
//		This operation check time to do Hypo-Anpea detection
//		According to theory, if 30s continuously without normal breath,
//		generate H by default
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//		None
//
/******************************************************************************/
void EventCheckHypoApneaByTime()
{
#define EVENT_H_TIME_DETECTION		(30*1000)	//30 seconds
	//check Cheyne stock, if occurred, do nothing
//	if(EventCSgetCount())
//	{
//		//record time to detect Hypo-Apnea by time
//		eventHDetectTime = xTaskGetTickCount();
//		return;
//	}

	//check time to detect Hypo Apnea
	if((xTaskGetTickCount() - eventHDetectTime) >= EVENT_H_TIME_DETECTION)
	{
//		DebugStr("\n detect H by time ______________");
		//force to generate H event
		EventHandleH();
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventCheckBreathData()
//
//    Processing:
//		This operation check volume ratio, amplitude ratio to do event detection
//
//    Input Parameters:
//      currentBreath: 	current breath data
//		avgBreath:		average breath data
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventCheckBreathData()
{
	//check and refuse noise
	if(currentBreath.totalTime < EVENT_MIN_BREATH_TIME)
		return;

	//calculate volume ratio
	float volumeRatio = (currentBreath.volume/avgBreath.avgVolume);
	//calculate amplitude ratio
	float amplitudeRatio = (currentBreath.amplitude/avgBreath.avgAmplitude);

	//	DebugStr("\n avg volume: ");
	//	DebugNumber(avgBreath.avgVolume);
	//	DebugStr("; current volume: ");
	//	DebugNumber(currentBreath.volume);
//		DebugStr("\n ratio: ");
//		DebugNumber(volumeRatio*100);
//		DebugStr("; ");
//		DebugNumber(currentBreath.amplitude*100/avgBreath.avgAmplitude);
#if SUPPORT_EVENT_DISPLAY
	//send event to upgrade volume data on screen
	GuiTaskSendEvent(eGuiUpdateAvgVolumeEventId, (unsigned long)avgBreath.avgVolume);
	GuiTaskSendEvent(eGuiUpdateLastVolumeEventId, (unsigned long)currentBreath.volume);
	GuiTaskSendEvent(eGuiUpdatePercentageEventId, (unsigned long)(volumeRatio*100));
#endif

	//update data for cheyne stoke event detection
	EventCSaddDataMocks(currentBreath.amplitude);	//currentBreath.volume

	if(volumeRatio <= EVENT_H_UPPER_LMT)
	{
		countH++;			//hypo apnea occur
		countNormal = 0;	//reset normal breath counter
	}
	else if(volumeRatio <= EVENT_FL_UPPER_LMT)
	{
		if(eventIsFLEnable)
		{
			countFL++;			//flow limitation occur
		}
		countNormal = 0;	//reset normal breath counter
	}
	else if(volumeRatio >= EVENT_CANCEL_LMT)
	{
#if SUPPORT_EVENT_DISPLAY
		//clear event
		if(isSnoreOccurred == false)
			eventBreath = 0;
#endif
		//check if Apnea was happen and clear flag
		if(isApneaOccurred == true)
		{
			//clear flag indicate that apnea occurred
			isApneaOccurred = false;
			//record time
			eventStartTime = xTaskGetTickCount();
		}
		//check if are there any event is detected, then wait for 60s and write to SD card
//		short numCS = EventCSgetCount();
		if(/*numCS||*/numCA||numOA||numH||numFL||numS)
		{
			//increase normal breath count
			countNormal++;
			//check if 3 normal breath continuously happen
			if(countNormal >= 3)
			{
				//clear event number
				numCA = 0; numOA = 0; numH = 0; numFL = 0; numS = 0;
				//clear number of normal breath
				countNormal = 0;
				//reset Cheyne Stoke buffer
//				EventCSreset();
			}
		}
		//clear count
		countH = 0;
		countFL = 0;
		//record time to detect Hypo-Apnea by time
		eventHDetectTime = xTaskGetTickCount();
	}

	//2. check number of times that event H and FL occur
	EventCheckFLandH();
	//3. Check whether snoring occurred
	EventCheckSnore();
	//4. Cheyne Stokes detection
	if((volumeRatio <= EVENT_CS_DETECT_LMT)||(amplitudeRatio <= EVENT_CS_DETECT_LMT))
		EventCScheckBreathMocks();
	else if((volumeRatio >= EVENT_CS_CANCEL_LMT)&&(amplitudeRatio >= EVENT_CS_CANCEL_LMT))
		EventCScheckCancelMocks();
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventCheckSnore()
//
//    Processing:
//		This operation check amplitude of vibration on each phase to determine
//		Snoring event
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventCheckSnore()
{
	//check snoring data
	if((isSnoreOccurred == true)/*&&(isEventEnable == true)*/)
	{
		//increase snore count
		countSnore++;
		//reset flag
		isSnoreOccurred = false;
	}
	else
		countSnore = 0;		//clear count

	//check snoring count result
	if(countSnore >= EVENT_CONFIRM_S)
	{
		//handle Snore event
		EventHandleS();
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventCheckFLandH()
//
//    Processing:
//		This operation check counter of FL and H for each breath, then determine
//		the event FL or H depend on which number is greater
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventCheckFLandH()
{
	//check if Cheyne Stoke occurred, do nothing
//	if(EventCSgetCount())
//	{
//		//reset  count
//		countH = 0;
//		countFL = 0;
//		return;
//	}

	if((countH + countFL) >= EVENT_CONFIRM_FL_H)
	{
		//check if any hypo apnea event is occur
		//hypo apnea is higher priority compare with flow limitation
		if(countH >= countFL)
		{
			//call function to handle H event
			EventHandleH();
		}
		else
		{
			//call function to handle FL event
			EventHandleFL();
		}
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventCheckApnea()
//
//    Processing:
//		This operation check time from previous breath to detect apnea.
//		Apnea is defined as more than 8s without a breath
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventCheckApnea()
{
	//define time need to wait to detect apnea problem. An apnea (CA or OA) is defined
	//as 8s no breath
#define APNEA_DETECTION_MS		(8*1000)
	//check time from previous breath. if during 8 seconds without a breath, Apnea is activated
	if((xTaskGetTickCount() - breathStartTime) >= APNEA_DETECTION_MS)		//8s
	{
		//clear all count
		/*countApnea = 0;*/	countH = 0;	countFL = 0; countSnore = 0; countNormal = 0;
		//send event to motor task to support vibrate pressure
		MotorTaskSendEvent(eMotorEnterVibrateEventId);
		//send event to stop phase detection
		AnalyzeTaskSendEvent(eAnalyzeDisablePhaseId);
		//change state to monitor vibration signal
		eventDetectionState = eEventHandleVibration;
		//set number of sample per cycle is a half of normal (6s)
		eventCyclePerSection = EVENT_CYCLE_PER_SECTION/2;
		//record current time
		eventStartTime = xTaskGetTickCount();
		//update time
		breathStartTime = eventStartTime;//xTaskGetTickCount();
//		//record current treatment pressure as start vibration pressure
//		AnalyzeDataGetTreatmentPressure(&pressBeforeEvent);
		//		DebugStr("\n EventCheckApnea *******");
		//		DebugStr("\n pressBeforeEvent: ");
		//		DebugNumber(pressBeforeEvent*10);

		//reset count prepare for analyze signal vibration
		eventCycleCount = 0;
		eventSampleCount = 0;
		//check for Cheyne-Stoke
		EventCScheckApneaMocks(eventStartTime - APNEA_DETECTION_MS);
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventCheckDecPressure()
//
//    Processing:
//		This operation check time to decrease pressure
//		pressure decrease 0.5 cmH2O every 1 minutes with treatment pressure greater than 15cmH2O
//		pressure decrease 0.5 cmH2O every 2 minutes with treatment pressure in range 10cmH2O -> 15cmH2O
//		pressure decrease 0.5 cmH2O every 3 minutes with treatment pressure in range 8cmH2O -> 10cmH2O
//		pressure decrease 0.5 cmH2O every 5 minutes with treatment pressure in range 6cmH2O -> 8cmH2O
//		pressure decrease 0.5 cmH2O every 7 minutes with treatment pressure in range 4cmH2O -> 6cmH2O
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventCheckDecPressure()
{
#define MIN_TO_MS		(60*1000)		//convert minute to ms

	if(ventilationType != eAutoMode)
		return;

	//check if Cheyne stoke occurred, then do no decrease pressure
	if(EventCSgetCountMocks())
	{
		//remask start time
		eventStartTime = xTaskGetTickCount();
		return;
	}

	//check if any apnea event occur
	if(isApneaOccurred == true)
		return;

	//get treatment pressure to determine wait time
	float treatmentPressure = 0;
	if(AnalyzeDataGetTreatmentPressure(&treatmentPressure) == false)
		return;		//can not get treatment pressure

	//determine wait time depend on pressure
	unsigned long waitTime;
	if(treatmentPressure >= 15)
		waitTime = 1*MIN_TO_MS;		//1 minutes
	else if(treatmentPressure >= 10)
		waitTime = 2*MIN_TO_MS;		//2 minutes
	else if(treatmentPressure >= 8)
		waitTime = 3*MIN_TO_MS;		//3 minutes
	else if(treatmentPressure >= 6)
		waitTime = 4*MIN_TO_MS;		//5 minutes
	else
		waitTime = 5*MIN_TO_MS;		//7 minutes

	//if no Apnea occurred, check time to decrease pressure
	if((xTaskGetTickCount() - eventStartTime) >= waitTime)
	{
		//send event to decrease 0.5 cmH2O
		MotorTaskSendEvent(eMotorDesPress05EventId);
		//remask start time
		eventStartTime = xTaskGetTickCount();
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventHandleVibration()
//
//    Processing:
//		This operation calculate the flow vibration amplitude then determine CA or OA.
//		Function will be exited when vibration time is reach to EVENT_CYCLE_PER_SECTION, normally set to 6
//		Amplitude vibration will be store in ampVibrationBuffer buffer.
//
//    Input Parameters:
//      float flow:		flow value
//
//    Output Parameters:
//      float ampVibrationBuffer[]:  flow vibration amplitude buffer
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventHandleVibration(float flow)
{
	//add data to flow vibration buffer
	flowVibrationBuffer[eventSampleCount++] = flow;

	//check if 1 cycle is done
	if(eventSampleCount >= EVENT_SAMPLE_PER_CYCLE)
	{
		float mean, min, max;
		unsigned int index;
		//get mean value of flow buffer
		arm_mean_f32(&flowVibrationBuffer[0], EVENT_SAMPLE_PER_CYCLE, &mean);
		//set value to mean buffer
		meanVibrationBuffer[eventCycleCount] = mean;
		//get variance value of flow buffer
		arm_min_f32(&flowVibrationBuffer[0], EVENT_SAMPLE_PER_CYCLE, &min, &index);
		arm_max_f32(&flowVibrationBuffer[0], EVENT_SAMPLE_PER_CYCLE, &max, &index);
		//set value to amplitude buffer
		ampVibrationBuffer[eventCycleCount] = (max - min);
		//clear count
		eventSampleCount = 0;
		//increase cycle count
		eventCycleCount++;

		//check condition to exit vibration
		//get min max of mean buffer
		arm_min_f32(&meanVibrationBuffer[0], eventCycleCount, &min, &index);
		arm_max_f32(&meanVibrationBuffer[0], eventCycleCount, &max, &index);

		//check variance of mean buffer
		if((max - min) >= EVENT_VIBRATION_EXIT_LMT)	//5lpm
		{
//			DebugStr("\n +++ handle vibration");
			//user come back to breath
			//change state to normal detection
			eventDetectionState = eEventDoDetection;
			//send event to motor task to exit vibration
			MotorTaskSendEvent(eMotorExitVibrateEventId);
			//update time
			breathStartTime = xTaskGetTickCount();
			//send event to enable phase detection
			AnalyzeTaskSendEvent(eAnalyzeEnablePhaseId);
			//reset count
			eventCycleCount = 0;
			//annouce to CS detection that an apnea has been terminated
			EventCSexitApneaMocks(breathStartTime);
		}
		//check result to detect CA or OA
		else if(eventCycleCount >= eventCyclePerSection)	//enough a section
		{
			//check whether CS event is occurred, then do nothing
//			if(EventCSgetCount() == 0)
			{
				//get mean of amplitude buffer
				arm_mean_f32(&ampVibrationBuffer[0], eventCyclePerSection, &mean);
				//determine CA or OA by checking the amplitude
				if(mean < EVENT_VIBRATION_LMT)	//OA occurred
				{
					//handle event OA
					EventHandleOA();
				}
				else	//CA occurred
				{
					//handle event CA
					EventHandleCA();
				}
			}
//			else
//				DebugStr("\n do not detect CA/OA due to CS occurred");
		}
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventHandleFL()
//
//    Processing:
//		This operation handle FL event when it has occurred.
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventHandleFL()
{
//	DebugStr("\n FL ************");
	//check and write event
	if((!numFL)/*&&(!numH)&&(!numS)*/)
	{
		//record current treatment pressure as start vibration pressure
		AnalyzeDataGetTreatmentPressure(&pressBeforeEvent);
		//send event to system log to write log as CA
		SystemTaskSendEvent(eSystemLogApneaEventId, EVENT_FL_ID);
//		DebugStr("\n Write FL ************");
	}
	//record time to detect Hypo-Apnea by time
	eventHDetectTime = xTaskGetTickCount();

#if SUPPORT_EVENT_DISPLAY
	//set Flow limitation
	eventBreath = EVENT_FL_ID;
#endif
	//increase number of flow limitation detected
	numFL++;
	if(EventCSgetCountMocks() == 0)
	{
		//get current treatment pressure
		float treatmentPress = 0;
		AnalyzeDataGetTreatmentPressure(&treatmentPress);
		//send event to motor task to increase 0.5 cmH2O
		if((ventilationType == eAutoMode)&&(eventIsFLEnable)&&((treatmentPress - pressBeforeEvent) < EVENT_PRESS_INC_MAX))
			MotorTaskSendEvent(eMotorIncPress05EventId);
	}
	//set flag indicate that system having apnea
	isApneaOccurred = true;
	//clear count
	countH = 0;
	countFL = 0;
	//clear CA, OA for next time use
	numCA = 0; numOA = 0;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventHandleH()
//
//    Processing:
//		This operation handle H event when it has occurred.
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventHandleH()
{
//	DebugStr("\n H ************");
	//check and write event
	if(/*(!numFL)&&*/(!numH)/*&&(!numS)*/)
	{
		//record current treatment pressure as start vibration pressure
		AnalyzeDataGetTreatmentPressure(&pressBeforeEvent);
		//send event to system log to write log as CA
		SystemTaskSendEvent(eSystemLogApneaEventId, EVENT_H_ID);
//		DebugStr("\n Write H ************");
	}
	//record time to detect Hypo-Apnea by time
	eventHDetectTime = xTaskGetTickCount();

#if SUPPORT_EVENT_DISPLAY
	//set Hypo Apnea
	eventBreath = EVENT_H_ID;
#endif
	//increase number of hypo apnea detected
	numH++;

	if(EventCSgetCountMocks() == 0)
	{
		//get current treatment pressure
		float treatmentPress = 0;
		AnalyzeDataGetTreatmentPressure(&treatmentPress);
		//send event to motor task to increase 0.5 cmH2O
		if((ventilationType == eAutoMode)&&((treatmentPress - pressBeforeEvent) < EVENT_PRESS_INC_MAX))
		{
			MotorTaskSendEvent(eMotorIncPress05EventId);
			//		DebugStr("\n increase pressure");
		}
	}

	//set flag indicate that system having apnea
	isApneaOccurred = true;
	//clear count
	countH = 0;
	countFL = 0;
	//clear CA, OA for next time use
	numCA = 0; numOA = 0;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventHandleS()
//
//    Processing:
//		This operation handle Snore event when it has occurred.
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventHandleS()
{
//	DebugStr("\n Snore *************");
	//check and write event
	if(/*(!numFL)&&(!numH)&&*/(!numS))
	{
		//record current treatment pressure as start vibration pressure
		AnalyzeDataGetTreatmentPressure(&pressBeforeEvent);
		//send event to system log to write log as CA
		SystemTaskSendEvent(eSystemLogApneaEventId, EVENT_S_ID);
//		DebugStr("\n Write Snore *************");
	}
	//record time to detect Hypo-Apnea by time
	eventHDetectTime = xTaskGetTickCount();
	//increase number of snoring detected
	numS++;
	//record time of an event detected
	//		eventDetectedTime = xTaskGetTickCount();
#if SUPPORT_EVENT_DISPLAY
	//set Hypo Apnea
	eventBreath = EVENT_S_ID;
#endif
	//set flag indicate that system having apnea
	isApneaOccurred = true;
	//check operation mode to increase pressure
	if(ventilationType == eAutoMode)
	{
		if(EventCSgetCountMocks() == 0)
		{
			//get current treatment pressure
			float treatmentPress = 0;
			AnalyzeDataGetTreatmentPressure(&treatmentPress);
			//check treatment pressure to send event to motor task
			if((treatmentPress < SNORE_MAX_PRESSURE)&&((treatmentPress - pressBeforeEvent) < EVENT_PRESS_INC_MAX))
			{
				//send event to motor task to increase 0.5 cmH2O
				MotorTaskSendEvent(eMotorIncPress05EventId);
			}
		}
	}
	//clear count
	countSnore = 0;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventHandleCA()
//
//    Processing:
//		This operation handle Central Apnea event when it has occurred.
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventHandleCA()
{
//	DebugStr("\n ************ CA ");
	if((!numCA)/* && (!numOA)*/)
	{
		//record current treatment pressure as start vibration pressure
		AnalyzeDataGetTreatmentPressure(&pressBeforeEvent);
		//send event to system log to write log as CA
		SystemTaskSendEvent(eSystemLogApneaEventId, EVENT_CA_ID);
//		DebugStr("\n Write CA *********** ");
	}
	//record time to detect Hypo-Apnea by time
	eventHDetectTime = xTaskGetTickCount();
#if SUPPORT_EVENT_DISPLAY
	//set OA
	eventBreath = EVENT_CA_ID;
#endif
	//increase number of CA detected
	numCA++;
	//clear OA
	numOA = 0;
	//set flag indicate that system having apnea
	isApneaOccurred = true;
	//reset count
	eventCycleCount = 0;
	//reset FL, H, S
	numFL = 0; numS = 0; numH = 0;
	//reset number of cycle per section as 12s
	eventCyclePerSection = EVENT_CYCLE_PER_SECTION;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: EventHandleOA()
//
//    Processing:
//		This operation handle Obstructive Apnea event when it has occurred.
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void EventHandleOA()
{
//	DebugStr("\n ************ OA ");
	if(/*(!numCA) && */(!numOA))
	{
		//record current treatment pressure as start vibration pressure
		AnalyzeDataGetTreatmentPressure(&pressBeforeEvent);
//		DebugStr("\n pressBeforeEvent: ");
//		DebugNumber(pressBeforeEvent*10);
		//send event to system log to write log as OA
		SystemTaskSendEvent(eSystemLogApneaEventId, EVENT_OA_ID);
//		DebugStr("\n Write OA *********** ");
	}
	//record time to detect Hypo-Apnea by time
	eventHDetectTime = xTaskGetTickCount();
#if SUPPORT_EVENT_DISPLAY
	//set OA
	eventBreath = EVENT_OA_ID;
#endif
	//increase number of OA detected
	numOA++;
	//clear CA
	numCA = 0;
	//send event to motor task to increase 0.5 cmH2O
	//check mode,  if not AUTO CPAP, do nothing
	if(ventilationType == eAutoMode)
	{
		//check whether CS event occurr
		if(EventCSgetCountMocks() == 0)
		{
			//get current treatment pressure
			float treatmentPress;
			AnalyzeDataGetTreatmentPressure(&treatmentPress);

	//		DebugStr("\n treatmentPress: ");
	//		DebugNumber(treatmentPress*10);
	//		DebugStr("\n pressBeforeEvent: ");
	//		DebugNumber(pressBeforeEvent*10);

			//check current pressure compare with pressure at start vibration
			//OA only allow to increase pressure max 2 cmH2O
			if((treatmentPress - pressBeforeEvent) < EVENT_PRESS_INC_MAX)
			{
	//			DebugStr("\n eMotorIncPress05EventId");
				MotorTaskSendEvent(eMotorIncPress05EventId);
			}
		}
	}

	//set flag indicate that system having apnea
	isApneaOccurred = true;
	//reset count
	eventCycleCount = 0;
	//reset FL, H, S
	numFL = 0; numS = 0; numH = 0;
	//reset number of cycle per section as 12s
	eventCyclePerSection = EVENT_CYCLE_PER_SECTION;
}


#if defined(__cplusplus)
}
#endif

