/*
 * eventTest.cpp
 *
 *  Created on: May 7, 2018
 *      Author: Quoc Viet
 */
#include "stdafx.h"
#include "Fixture.h"
#include "event.h"
#include "setting.h"
#include "breathdata.h"
#include "guiinterface.h"
#include "phase.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern bool eventIsFLEnable;
extern E_EventDetectionProcess eventDetectionState;
extern E_OperationMode ventilationType;
extern portTickType eventStartTime;
extern int countFL;
extern int countH;
extern int countNormal;
extern int countSnore;
extern int eventCycleCount;
extern int eventSampleCount;
extern int numCA;
extern int numOA;
extern int numH;
extern int numFL;
extern int numS;
extern bool isApneaOccurred;
extern bool isSnoreOccurred;
extern int eventCyclePerSection;
extern portTickType eventHDetectTime;

namespace EmbeddedCUnitTest {


class EventTest : public TestFixture
{
public:
	EventTest() : TestFixture(new ModuleMock) {}
};

TEST_F(EventTest, EventSetFLEnable1)
{
	EventSetFLEnable(false);

	EXPECT_EQ(false,eventIsFLEnable);
}

TEST_F(EventTest, EventSetFLEnable2)
{
	EventSetFLEnable(true);

	EXPECT_EQ(true,eventIsFLEnable);
}

TEST_F(EventTest, EventReset)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eVentModeSettingId)).Times(1).WillOnce(Return(eAutoMode));
	EXPECT_CALL(*_queueLib,xTaskGetTickCount()).Times(1).WillOnce(Return(50));
	EXPECT_CALL(*_EventLib,EventCSresetMocks()).Times(1);
	EXPECT_CALL(*_queueLib,GuiTaskSendEventMocks(eGuiRealPressUpdateId, 0)).Times(1);

	EventReset();

	EXPECT_EQ(eEventDetectionIdle,eventDetectionState);
	EXPECT_EQ(eAutoMode,ventilationType);
	EXPECT_EQ((unsigned long)50,eventStartTime);
	EXPECT_EQ((unsigned long)50,eventHDetectTime);
	EXPECT_EQ((unsigned long)50,breathStartTime);
	EXPECT_EQ(0,countFL);
	EXPECT_EQ(0,countH);
	EXPECT_EQ(0,countNormal);
	EXPECT_EQ(0,countSnore);
	EXPECT_EQ(0,eventCycleCount);
	EXPECT_EQ(0,eventSampleCount);
	EXPECT_EQ(0,numCA);
	EXPECT_EQ(0,numOA);
	EXPECT_EQ(0,numH);
	EXPECT_EQ(0,numFL);
	EXPECT_EQ(0,numS);
	EXPECT_EQ(false,isApneaOccurred);
	EXPECT_EQ(false,isSnoreOccurred);
	EXPECT_EQ(EVENT_CYCLE_PER_SECTION/2,eventCyclePerSection);
	EXPECT_EQ(0,eventBreath);
}

TEST_F(EventTest, EventHandleData)
{
	EXPECT_CALL(*_queueLib,xTaskGetTickCount()).Times(3).WillOnce(Return(10)).WillOnce(Return(180000)).WillOnce(Return(180000));
	EXPECT_CALL(*_VolumeLib,VolumeAddMocks(_)).Times(1);

	breathStartTime = 5;
	breathPhase = ePhaseExhTrigger;
	eventDetectionState = eEventDetectionIdle;
	eventStartTime = 0;
	EventHandleData(5.0,1.0);

	EXPECT_FLOAT_EQ(5.0,currentBreath.peakExhFlow);
	EXPECT_EQ((unsigned long)5,currentBreath.inhTime);
	EXPECT_FLOAT_EQ(5.0,currentBreath.peakInhFlow);
	EXPECT_EQ(eEventCollectData,eventDetectionState);
	EXPECT_EQ((unsigned long)180000,eventStartTime);
}

//TEST_F(EventTest, EventHandleData3)
//{
//	eventDetectionState = eEventCollectData;
//	breathPhase = ePhaseInhTrigger;
//	currentBreath.totalTime = 1.2*1000;
//	EventHandleData(5.0,1.0);
//
//	avgBreath.index = 39;
//	avgBreath.full = false;
//	currentBreath.amplitude = 2.5;
//	currentBreath.volume = 5.5;
//
//	EXPECT_FLOAT_EQ(2.5,avgBreath.data[39].amplitude);
//	EXPECT_FLOAT_EQ(5.5,avgBreath.data[39].volume);
//	EXPECT_EQ(true,avgBreath.full);
//}

}




