/*
 * phase.cpp
 *
 *  Created on: May 4, 2018
 *      Author: Quoc Viet
 */
#include <stdbool.h>
#include "phase.h"
//#include "FreeRTOS.h"
//#include "task.h"
#include "queue.h"
//#include "debuguart.h"
//#include "setting.h"
//#include "circuitcalibrate.h"
//#include "arm_math.h"
//#include "motorcmd.h"
#include "breathdata.h"
#include "analyzeinterface.h"
#include "motorctrlinterface.h"
#include "baseflow.h"

//declare current breath phase
E_BreathPhase breathPhase = ePhaseExhMaintain;

#define PHASE_BUFFER_SIZE		16
//static float phaseFlowBuffer[PHASE_BUFFER_SIZE] = {0};
//static float phasePressureBuffer[PHASE_BUFFER_SIZE] = {0};
//static int phaseBufferIndex = 0;

//static unsigned long phaseStartTime = 0;
//static float currentFlow = 0;
//static float currentPressure = 0;
//static E_NsType nsType = eEType;
float startInhFlow = 0;

//static int countPressure = 0;
//static int countFlow = 0;
//static float phaseMinInhMaintainPressure = 0;		//variable for minimum inhalation maintain pressure
//static float phaseMaxInhTriggerPressure = 0;
//static float phaseMinExhTriggerPressure = 0;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif



#if defined(__cplusplus)
}
#endif
