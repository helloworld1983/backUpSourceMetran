/*
 * phase.h
 *
 *  Created on: May 4, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_ANALYZE_PHASE_H_
#define UNITTEST_ANALYZE_PHASE_H_

//define breath phases
typedef enum
{
	ePhaseInhTrigger = 0,
	ePhaseInhMaintain,
	ePhaseExhTrigger,
	ePhaseExhMaintain
} E_BreathPhase;


//declare current breath phase
extern E_BreathPhase breathPhase;
//start inhalation flow
extern float startInhFlow;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

////function handle data to detect breath phase change
//void PhaseHandleData(float flow, float pressure);
////function reset parameters in breath phase detection
//void PhaseReset();

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_ANALYZE_PHASE_H_ */
