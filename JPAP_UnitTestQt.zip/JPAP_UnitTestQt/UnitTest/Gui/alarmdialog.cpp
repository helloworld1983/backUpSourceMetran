/*
 * alarmdialog.cpp
 *
 *  Created on: Apr 10, 2018
 *      Author: QUOCVIET
 */

//#include "motorctrlinterface.h"
#include "alarmdialog.h"

#include <guiinterface.h>
#include <setting.h>

#include "strings.h"
//#include "mode.h"
//#include "rtc.h"
//#include "systeminterface.h"
//#include "pwm.h"
//#include "systemconfig.h"
#include "guiglobal.h"
#include "stdio.h"

int testAlarmScreenCallback = 0;
char* alarmInforStrTest = "";

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//1. define parameters of alarm screen
#define ALARM_SCREEN_X_START			20
#define ALARM_SCREEN_Y_START			20
#define ALARM_SCREEN_LENGTH				280
#define ALARM_SCREEN_HEIGHT				100
//2. alarm title
#define ALARM_TITLE_X					0
#define ALARM_TITLE_Y					5
#define ALARM_TITLE_LENGTH				275
#define ALARM_TITLE_HEIGHT				25
//3. the first row
#define ALARM_INFOR_FIRST_ROW_X			0
#define ALARM_INFOR_FIRST_ROW_Y			40
#define ALARM_INFOR_FIRST_ROW_LENGTH	ALARM_SCREEN_LENGTH
#define ALARM_INFOR_FIRST_ROW_HEIGHT	25
//4. the second rows
#define ALARM_INFOR_SECOND_ROW_X		0
#define ALARM_INFOR_SECOND_ROW_Y		70
#define ALARM_INFOR_SECOND_ROW_LENGTH	ALARM_SCREEN_LENGTH
#define ALARM_INFOR_SECOND_ROW_HEIGHT	25
//5. OK button
#define OK_BUTTON_X						80
#define OK_BUTTON_Y						65
#define OK_BUTTON_LENGTH				60
#define OK_BUTTON_HEIGHT				30
//6. image
#define IMAGE_X_START					5
#define IMAGE_Y_START					0
#define IMAGE_LENGTH					25
#define IMAGE_HEIGHT					30
//7. define color
#define ALARM_BK_COLOR					GUI_WHITE
#define ALARM_TITLE_BK_COLOR			COLOR_ULTRA_LIGHT_BLUE
#define ALARM_BORDER_COLOR				COLOR_ULTRA_LIGHT_BLUE
//#define ALARM_TEXT_COLOR				COLOR_ULTRA_LIGHT_BLUE
#define ALARM_ERR_TITLE_COLOR			0x241CED
#define ALARM_WARN_TITLE_COLOR			0x00DDFF

//WM_HWIN alarmDialog;

//extern IMAGE_Handle statusBar;
//static TEXT_Handle alarmTitle;
//static TEXT_Handle alarmInforSecondRow;
//static TEXT_Handle alarmInforFirstRow;
//static IMAGE_Handle alarmImage;
// main window instance
//extern WM_HWIN operationScreen;
//void AlarmScreenCallback(WM_MESSAGE * pMsg);
//void AlarmScreenHandleKeyEvent();
//void AlarmScrEnterKeyHandle();
//void AlarmScrShowContent(E_AlarmId id);

//static const GUI_FONT* guiFont16[] = { &GUI_FontMeiryo16B_2bpp, &GUI_FontJPAPJPFont16B };
//static const GUI_FONT* guiFont14[] = { &GUI_FontAlarmJapanesFont14, &GUI_FontJPAPJPFont14B };

static E_AlarmId alarmGuiId;
static xQueueHandle alarmQueue;
static xQueueHandle guiQueue;
static unsigned char language = 1;

typedef enum
{
	eAlarmTitleId,
	eAlarmInforId,
	eAlarmImageId,
	eAlarmTitleBarId,
	eAlarmContactId
} AlarmScreenItemId;

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: AlarmScreenCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		This is callback function of alarm screen
//
//    Input Parameters:
//
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void AlarmScreenCallback(WM_MESSAGE * pMsg) {
	//	GUI_RECT Rect;
	switch (pMsg->MsgId) {
	case WM_PAINT:
		//		WM_GetClientRect(&Rect);
		//		GUI_SetBkColor(GUI_WHITE);
		//		GUI_ClearRectEx(&Rect);
		//		GUI_SetColor(ALARM_CONTENT_COLOR);
		//		GUI_SetPenSize(2);
		//		GUI_AA_DrawRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1, 2);
		//		GUI_FillRect(Rect.x0, Rect.y0 , Rect.x1, Rect.y0 + 30);

		//		WM_GetClientRect(&Rect);
		//		GUI_SetPenShape(GUI_PS_ROUND);
		//		GUI_SetTextMode(GUI_TM_TRANS);
		//		//draw background
		//		GUI_SetColor(ALARM_BK_COLOR);
		//		GUI_AA_FillRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1, 10);
		//
		//		//draw title background
		//		GUI_SetColor(ALARM_TITLE_BK_COLOR);
		//		GUI_AA_FillRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y0+32, 10);
		//		GUI_FillRect(Rect.x0, Rect.y0+15, Rect.x1, Rect.y0+32);
		//
		//
		//		GUI_SetColor(ALARM_BORDER_COLOR);
		//		GUI_SetPenSize(2);
		//		GUI_AA_DrawRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1, 10);
		testAlarmScreenCallback = WM_PAINT;
		break;
	default:
		//		WM_DefaultProc(pMsg);
		testAlarmScreenCallback = 100;
		break;
	}
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: AlarmScrEnterKeyHandle()
//
//    Processing:
//		This operation handles ENTER key event
//
//    Input Parameters:
//
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
/*
void AlarmScrEnterKeyHandle()
{
	if(alarmGuiId == eLeakGuiId)
		return;
	//send event to deactivate alarm
	E_AlarmEventId alarmEvent = 0;

	switch (alarmGuiId) {
	case eBlowerErrorGuiId:
		alarmEvent = eBlowerErrorDeActivatedId;
		break;
	case ePressSensorErrorGuiId:
		alarmEvent = ePressSensorErrorDeActivatedId;
		break;
	case eFlowSensorErrorGuiId:
		alarmEvent = eFlowSensorErrorDeActivatedId;
		break;
	case ePowerFailureGuiId:
		alarmEvent = ePowerFailedDeActivatedId;
		break;
	case eSdCardErrorGuiId:
		alarmEvent = eSdCardErrorDeActivatedId;
		break;
	default:
		break;
	}

	//send event to alarm task to cancel alarm
	if(alarmEvent != 0)
		ALarmTaskSendEvent(alarmEvent);
}
 */
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: AlarmDialogInit(void)
//
//    Processing:
//		The operation initialize the alarm screen
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void AlarmDialogInit(void)
{
	testAlarmScreenCallback = 0;
	//create reset pop up
	//	alarmDialog = WM_CreateWindowAsChild(ALARM_SCREEN_X_START, ALARM_SCREEN_Y_START, ALARM_SCREEN_LENGTH, ALARM_SCREEN_HEIGHT, operationScreen, WM_CF_HIDE | WM_CF_HASTRANS, AlarmScreenCallback, 0);
	//
	//	//init question text
	//	alarmTitle = TEXT_CreateEx(ALARM_TITLE_X, ALARM_TITLE_Y, ALARM_TITLE_LENGTH, ALARM_TITLE_HEIGHT, alarmDialog, WM_CF_SHOW, TEXT_CF_HCENTER/*WM_CF_MEMDEV*/, eAlarmTitleId, strError[language]);
	//	TEXT_SetFont(alarmTitle, guiFont16[language]);
	//	//	TEXT_SetTextAlign(alarmTitle, GUI_TA_CENTER);
	//	TEXT_SetTextColor(alarmTitle, GUI_RED);
	//	//init error code
	//	alarmInforFirstRow = TEXT_CreateEx(ALARM_INFOR_FIRST_ROW_X, ALARM_INFOR_FIRST_ROW_Y, ALARM_INFOR_FIRST_ROW_LENGTH, ALARM_INFOR_FIRST_ROW_HEIGHT, alarmDialog, WM_CF_SHOW, TEXT_CF_HCENTER/*WM_CF_MEMDEV*/, eAlarmContactId, "");
	//	TEXT_SetFont(alarmInforFirstRow, guiFont14[language]);
	//	//	TEXT_SetTextAlign(alarmInforFirstRow, GUI_TA_CENTER);
	//	TEXT_SetTextColor(alarmInforFirstRow, ALARM_TEXT_COLOR);
	//	//init error code
	//	alarmInforSecondRow = TEXT_CreateEx(ALARM_INFOR_SECOND_ROW_X, ALARM_INFOR_SECOND_ROW_Y, ALARM_INFOR_SECOND_ROW_LENGTH, ALARM_INFOR_SECOND_ROW_HEIGHT, alarmDialog, WM_CF_SHOW, TEXT_CF_HCENTER/*WM_CF_MEMDEV*/, eAlarmInforId, "");
	//	TEXT_SetFont(alarmInforSecondRow, guiFont14[language]);
	//	//	TEXT_SetTextAlign(alarmInforSecondRow, GUI_TA_CENTER);
	//	TEXT_SetTextColor(alarmInforSecondRow, ALARM_TEXT_COLOR);
	//	//create alarm image
	//	alarmImage = IMAGE_CreateEx(IMAGE_X_START, IMAGE_Y_START, IMAGE_LENGTH, IMAGE_HEIGHT, alarmDialog, WM_CF_SHOW, WM_CF_MEMDEV, eAlarmImageId);
	//	IMAGE_SetBitmap(alarmImage, &warningImageInfor);
}

//function to confirm the alarm showing
void AlarmDialogConfirm()
{
	//	DebugStr("\n alarm confirm ***********");
	//	if(alarmGuiId == eLeakGuiId)
	//		return;
	//send event to deactivate alarm
	E_AlarmEventId alarmEvent = eAlarmTaskNoEventId;

	switch (alarmGuiId)
	{
	case eBlowerErrorId:
		alarmEvent = eBlowerErrorDeActivatedId;
		//		ALarmTaskSendEvent(alarmEvent, 0);
		break;
	case ePressSensorErrorId:
		alarmEvent = ePressSensorErrorDeActivatedId;
		//		ALarmTaskSendEvent(alarmEvent, 0);
		break;
	case eFlowSensorErrorId:
		alarmEvent = eFlowSensorErrorDeActivatedId;
		//		ALarmTaskSendEvent(alarmEvent, 0);
		break;
	case ePowerFailureId:
		alarmEvent = ePowerFailedDeActivatedId;
		//		ALarmTaskSendEvent(alarmEvent, 0);
		break;
	case eSdCardErrorId:
		alarmEvent = eSdCardErrorDeActivatedId;
		//		ALarmTaskSendEvent(alarmEvent, 0);
		break;
	default:
		break;
	}

	//send event to alarm task
	if(alarmEvent != eAlarmTaskNoEventId)
	{
		AlarmEventStruct event;
		event.id = alarmEvent;
		event.data = 0;
		if(xQueueSendToBack(alarmQueue, &event, 2) != pdPASS)
		{

		}
		//		ALarmTaskSendEvent(alarmEvent, 0);
	}
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: AlarmDialogHide()
//
//    Processing:
//		The operation changes to operation screen
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
//void AlarmDialogHide()
//{
//	//hide alarm screen
//	WM_HideWindow(alarmDialog);
//	//set mode to operation screen
////	if(OperScreenIsActivated() == true)
////		OperScreenBackToRunning();
////	else
////		GuiTaskSendEvent(eGuiChangeToOperScreenId, 0);
//}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: AlarmDialogMakeStr(unsigned char alarmId)
//
//    Processing:
//		The operation sets alarmGui Id and shows alarm screen
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void AlarmDialogMakeStr(unsigned char alarmId)
{
	//	bool showErrorIcon = false;
	//	bool showSDErrorIcon = false;

	//store current activated alarm
	alarmGuiId = (E_AlarmId)alarmId;
	//set content to show
	AlarmScrShowContent(alarmGuiId);
	//	//show alarm screen
	//	WM_ShowWindow(alarmDialog);
	//bring to top
	//	WM_BringToTop(alarmDialog);
	//focus alarm screen
	//	WM_SetFocus(alarmDialog);
	//check alarm Id to show error icon on status bar
	switch (alarmId) {
	case eBlowerErrorId:
	case ePressSensorErrorId:
	case eFlowSensorErrorId:
	{
		GuiEventStruct event;
		event.id = eGuiShowErrIconId;
		event.data = 0;
		//send event
		if(xQueueSendToBack(guiQueue, &event, 2) != pdPASS)
		{
			xQueueReset(guiQueue);
		}
		//				GuiTaskSendEvent(eGuiShowErrIconId, 0);
		//		showErrorIcon = true;
		break;
	}
	case eSdCardErrorId:
	{
		GuiEventStruct event;
		event.id = eGuiShowSdErrIconId;
		event.data = 0;
		//send event
		if(xQueueSendToBack(guiQueue, &event, 2) != pdPASS)
		{
			xQueueReset(guiQueue);
		}
		//				GuiTaskSendEvent(eGuiShowSdErrIconId, 0);
		//		showSDErrorIcon = true;
		break;
	}
	default:	break;
	}

	//	//check to show error icon
	//	if(showErrorIcon == true)
	//	{
	//		GuiTaskSendEvent(eGuiShowErrIconId, 0);
	//	}
	//
	//	//check to show SD error icon
	//	if(showSDErrorIcon == true)
	//		GuiTaskSendEvent(eGuiShowSdErrIconId, 0);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: AlarmScrShowContent(E_AlarmId id)
//
//    Processing:
//		The operation shows alarm
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void AlarmScrShowContent(E_AlarmId id)
{
		char* alarmInforStr = "";
//		GUI_COLOR alarmTitleColor = ALARM_ERR_TITLE_COLOR;
//		GUI_BITMAP* alarmImageBmp = (GUI_BITMAP*)&errorImageInfor;

//		TEXT_SetFont(alarmTitle, guiFont16[language]);
//		TEXT_SetFont(alarmInforFirstRow, guiFont14[language]);
//		TEXT_SetText(alarmInforFirstRow, strPleaseContactTheManufacturer[language]);
//		TEXT_SetFont(alarmInforSecondRow, guiFont14[language]);
//		TEXT_SetText(alarmInforSecondRow, strPressEnterToConfirm[language]);	//set text for alarm infor
//		WM_ShowWindow(alarmInforFirstRow);
//		WM_ShowWindow(alarmImage);
		switch (id) {
		case eBlowerErrorId:
			alarmInforStr = (char*)strBlowerAlarm[language];
			alarmInforStrTest = alarmInforStr;
			break;
		case ePressSensorErrorId:
			alarmInforStr = (char*)strPressSensorAlarm[language];
			alarmInforStrTest = alarmInforStr;
			break;
		case eFlowSensorErrorId:
			alarmInforStr = (char*)strFlowSensorAlarm[language];
			alarmInforStrTest = alarmInforStr;
			break;
		case ePowerFailureId:
			alarmInforStr = (char*)strPowerSupplyAlarm[language];
			alarmInforStrTest = alarmInforStr;
//			alarmTitleColor = ALARM_WARN_TITLE_COLOR;
//			alarmImageBmp = (GUI_BITMAP*)&warningImageInfor;
//			TEXT_SetText(alarmInforFirstRow, strPowerSuddenlyOffLastTime[language]);//set text for alarm infor
			break;
		case eSdCardErrorId:
			alarmInforStr = (char*)strMediaAlarm[language];
			alarmInforStrTest = alarmInforStr;
//			alarmTitleColor = ALARM_WARN_TITLE_COLOR;
//			alarmImageBmp = (GUI_BITMAP*)&warningImageInfor;
//			TEXT_SetText(alarmInforFirstRow, (const char*)strCannotDetectSdCard[language]);	//set text for alarm infor
			break;
		case eLeakErrorId:
//			WM_HideWindow(alarmImage);
			alarmInforStr = (char*)strInspection[language];
			alarmInforStrTest = alarmInforStr;
//			alarmTitleColor = GUI_WHITE;
//			alarmImageBmp = (GUI_BITMAP*)&warningImageInfor;
			if(language == eJapanese)
			{
//				TEXT_SetFont(alarmTitle, &GUI_FontJapanese16Add2);
//				TEXT_SetFont(alarmInforFirstRow, &GUI_FontJapanes14Add2);
//				TEXT_SetFont(alarmInforSecondRow, &GUI_FontJapanes14Add2);
			}
			else
			{
//				TEXT_SetFont(alarmInforFirstRow, &GUI_FontEnglish14Add3);
//				TEXT_SetFont(alarmInforSecondRow, &GUI_FontEnglish14Add3);
			}
//			TEXT_SetText(alarmInforFirstRow, (const char*)strAirIsLeaking[language]);	//set text for alarm infor
//			TEXT_SetText(alarmInforSecondRow, (const char*)strPressOnOffToStandby[language]);//set text for alarm infor
			break;
		default:
			alarmInforStrTest ="default";
			break;
		}

//		TEXT_SetText(alarmTitle, (const char*)alarmInforStr);	//set text for alarm title
//		TEXT_SetTextColor(alarmTitle, alarmTitleColor);			//set color for alarm title
//		IMAGE_SetBitmap(alarmImage, alarmImageBmp);				//set image for alarm icon
}


#if defined(__cplusplus)
}
#endif


