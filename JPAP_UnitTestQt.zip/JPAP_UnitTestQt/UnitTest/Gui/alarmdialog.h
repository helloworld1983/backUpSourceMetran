/*
 * alarmdialog.h
 *
 *  Created on: Apr 10, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_GUI_ALARMDIALOG_H_
#define UNITTEST_GUI_ALARMDIALOG_H_

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

#include "WM.h"
#include "alarminterface.h"
//#include "IMAGE.h"
//#include "guiinterface.h"

//extern WM_HWIN alarmDialog;

/*
typedef enum
{
	eFirsAlarmGuiId = 0,
	eBlowerErrorGuiId = eFirsAlarmGuiId,
	ePressSensorErrorGuiId,
	eFlowSensorErrorGuiId,
	ePowerFailureGuiId,
	eSdCardErrorGuiId,
	eLeakGuiId,
	eLastAlarmGuiId = eLeakGuiId
} E_AlarmGuiId;
*/
void AlarmScreenCallback(WM_MESSAGE * pMsg);
void AlarmScrShowContent(E_AlarmId id);
//function to initialize alarm dialog and its child objects
void AlarmDialogInit();
//function to confirm the alarm showing
void AlarmDialogConfirm();
//function to hide current showed alarm
//void AlarmDialogHide();
//function to show a alarm with content
void AlarmDialogMakeStr(unsigned char alarmId);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_GUI_ALARMDIALOG_H_ */
