/*
 * alarmdialogTest.cpp
 *
 *  Created on: Apr 10, 2018
 *      Author: QUOCVIET
 */


#include "stdafx.h"
#include "Fixture.h"
#include "alarmdialog.h"
#include "WM.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern int testAlarmScreenCallback;
extern char* alarmInforStrTest;

namespace EmbeddedCUnitTest {


class AlarmDialogTest : public TestFixture
{
public:
	AlarmDialogTest() : TestFixture(new ModuleMock) {}
};



TEST_F(AlarmDialogTest, AlarmScreenCallback)
{
	WM_MESSAGE pMsg;// = NULL;
	pMsg.MsgId = WM_PAINT;
	AlarmScreenCallback(&pMsg); // @suppress("Invalid arguments")

	EXPECT_EQ(testAlarmScreenCallback, WM_PAINT);

	pMsg.MsgId = WM_PAINT + 1;
	AlarmScreenCallback(&pMsg); // @suppress("Invalid arguments")

	EXPECT_EQ(testAlarmScreenCallback, 100);

}

TEST_F(AlarmDialogTest, AlarmDialogInit)
{
	AlarmDialogInit();
	EXPECT_EQ(testAlarmScreenCallback, 0);

}

TEST_F(AlarmDialogTest, AlarmDialogConfirm)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1).WillOnce(Return(pdPASS));
	AlarmDialogConfirm();
}

TEST_F(AlarmDialogTest, AlarmDialogMakeStr)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1).WillOnce(Return(pdPASS));
	AlarmDialogMakeStr(eBlowerErrorId);

	EXPECT_EQ(std::string(alarmInforStrTest), "Blower error");

	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1).WillOnce(Return(pdFAIL));
	EXPECT_CALL(*_queueLib,xQueueReset(_)).Times(1);
	AlarmDialogMakeStr(eBlowerErrorId);

	/*******************************************/
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1).WillOnce(Return(pdPASS));
	AlarmDialogMakeStr(eSdCardErrorId);

	EXPECT_EQ(std::string(alarmInforStrTest), "SD card error");

	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1).WillOnce(Return(pdFAIL));
	EXPECT_CALL(*_queueLib,xQueueReset(_)).Times(1);
	AlarmDialogMakeStr(eSdCardErrorId);
}

TEST_F(AlarmDialogTest, AlarmScrShowContent)
{
	AlarmDialogMakeStr(eBlowerErrorId);
	EXPECT_EQ(std::string(alarmInforStrTest), "Blower error");

	AlarmDialogMakeStr(ePressSensorErrorId);
	EXPECT_EQ(std::string(alarmInforStrTest), "P-sensor error");

	AlarmDialogMakeStr(eFlowSensorErrorId);
	EXPECT_EQ(std::string(alarmInforStrTest), "F-sensor error");

	AlarmDialogMakeStr(ePowerFailureId);
	EXPECT_EQ(std::string(alarmInforStrTest), "Power supply lost");

	AlarmDialogMakeStr(eSdCardErrorId);
	EXPECT_EQ(std::string(alarmInforStrTest), "SD card error");

	AlarmDialogMakeStr(eLeakErrorId);
	EXPECT_EQ(std::string(alarmInforStrTest), "Inspection");

	AlarmDialogMakeStr(eLastAlarmId);
	EXPECT_EQ(std::string(alarmInforStrTest), "default");
}

}
