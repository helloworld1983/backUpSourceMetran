/*
 * clinicscreen.cpp
 *
 *  Created on: Apr 10, 2018
 *      Author: QUOCVIET
 */

#include "guidefine.h"
#include "clinicscreen.h"

#include <setting.h>
#include "queue.h"
//#include "systeminterface.h"
//#include "debuguart.h"
//#include "usersettingdialog.h"
#include "stdlib.h"
//#include "popupdialog.h"
#include "strings.h"
//#include "systemconfig.h"
//#include "guiinterface.h"
//#include "guiglobal.h"
#include "SettingMocks.h"
#include "SettingBtnMocks.h"
#include "stdio.h"

/*static*/ short currentId = 0;
int testUpdateSlider = 0;
int testClinicRelayout = 0;
int testSliderSetMaxClinic = 0;
short currentItem;
int testClinicScreenCallback = 0;
E_SettingScreenState clinicState = eDialogState;
short prevSecondItem = 0;
short secondItem = 0;
short clinicNumOfButton = HCW_NUM_BTN_AUTO_MODE;//9
short endItem = HCW_NUM_SCREEN_BTN - 1;//4
bool isLogSetting = false;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//#define HTR_BACKGROUND_COLOR		COLOR_DARK_BLUE

//void ClinicScreenCallback(WM_MESSAGE * pMsg);
//void ClinicHandleEnterKey();
//void ClinicHandleLeftKey();
//void ClinicHandleRightKey();
//void ClinicSetButtonStatus();
//void ClinicRelayout();
//void ClinicSetItemList();

//WM_HWIN clinicScreen;
//// main window instance
//extern WM_HWIN mainWindow;
//
//static SLIDER_Handle clinicSlider;
//static BUTTON_Handle hcwTitleBar;
//
//static BUTTON_Handle ventilationTypeBtn;
//static BUTTON_Handle rampTimeBtn;
//static BUTTON_Handle settingPressBtn;
//static BUTTON_Handle upperLimitBtn;
//static BUTTON_Handle lowerLimitBtn;
//static BUTTON_Handle bluetoothBtn;
//static BUTTON_Handle initialPressBtn;
//static BUTTON_Handle nsTypeBtn;
//static BUTTON_Handle circuitCalibrateBtn;
//static BUTTON_Handle autoOffBtn;
//static BUTTON_Handle flBtn;

//static WM_HWIN buttonList[HCW_NUM_BTN_CPAP_MODE];			//create button list
//static E_SettingScreenState clinicState = eDialogState;

///*static*/ short currentId = 0;
//static short clinicNumOfButton = HCW_NUM_BTN_AUTO_MODE;
//static short currentItem;
//static short secondItem = 0;
//static short endItem = HCW_NUM_SCREEN_BTN - 1;
//static short prevSecondItem = 0;
//static bool isLogSetting = false;

static xQueueHandle guiQueue;

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: ClinicScreenInit(void)
//
//    Processing:
//		The operation creates healthcare workers screen
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void ClinicScreenInit(void)
{
	//create health care worker screen
	//	clinicScreen = WM_CreateWindowAsChild(SETTING_SCREEN_X, SETTING_SCREEN_Y, SETTING_SCREEN_LENGTH, SETTING_SCREEN_HEIGHT, mainWindow, WM_CF_HIDE | WM_CF_MEMDEV | WM_CF_LATE_CLIP, ClinicScreenCallback, 0);
	//	clinicState = eTitleBarState;
	currentItem = 0;
	//init home button
	//	hcwTitleBar = BUTTON_CreateEx(TITLE_BAR_X, TITLE_BAR_Y, TITLE_BAR_LENGTH, TITLE_BAR_HEIGHT, clinicScreen, WM_CF_SHOW, 0, eHcwTitleBarId);
	//	WM_SetCallback(hcwTitleBar, TitleBarCallback);
	//	//init VENTILATION TYPE button
	//	ventilationTypeBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y, BUTTON_LENGTH, BUTTON_HEIGHT, clinicScreen, WM_CF_SHOW, WM_CF_MEMDEV, eVentilationTypeBtnId);
	//	WM_SetCallback(ventilationTypeBtn, SettingBtnCallback);
	//	//init NS type button
	//	nsTypeBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y, BUTTON_LENGTH, BUTTON_HEIGHT, clinicScreen, WM_CF_SHOW, WM_CF_MEMDEV, eNaturalSupportTypeBtnId);
	//	WM_SetCallback(nsTypeBtn, SettingBtnCallback);
	//	//init exhalation trigger button
	//	settingPressBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*2, BUTTON_LENGTH, BUTTON_HEIGHT, clinicScreen, WM_CF_HIDE, WM_CF_MEMDEV, eSettingPressBtnId);
	//	WM_SetCallback(settingPressBtn, SettingBtnCallback);
	//	//init upper limit button
	//	upperLimitBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*3, BUTTON_LENGTH, BUTTON_HEIGHT, clinicScreen, WM_CF_HIDE, WM_CF_MEMDEV, eUpperPressBtnId);
	//	WM_SetCallback(upperLimitBtn, SettingBtnCallback);
	//	//init lower limit adjust button
	//	lowerLimitBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*4, BUTTON_LENGTH, BUTTON_HEIGHT, clinicScreen, WM_CF_HIDE, WM_CF_MEMDEV, eLowerPressBtnId);
	//	WM_SetCallback(lowerLimitBtn, SettingBtnCallback);
	//	//init delay initial button
	//	initialPressBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*3, BUTTON_LENGTH, BUTTON_HEIGHT, clinicScreen, WM_CF_SHOW, WM_CF_MEMDEV, eInitialPressBtnId);
	//	WM_SetCallback(initialPressBtn, SettingBtnCallback);
	//	//init ramp time button
	//	rampTimeBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*4, BUTTON_LENGTH, BUTTON_HEIGHT, clinicScreen, WM_CF_HIDE, WM_CF_MEMDEV, eRampTimeBtnId);
	//	WM_SetCallback(rampTimeBtn, SettingBtnCallback);
	//	//init bluetooth button
	//	bluetoothBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*7, BUTTON_LENGTH, BUTTON_HEIGHT, clinicScreen, WM_CF_SHOW, WM_CF_MEMDEV, eBluetoothSettingBtnId);
	//	WM_SetCallback(bluetoothBtn, SettingBtnCallback);
	//	//init auto OFF button
	//	autoOffBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*7, BUTTON_LENGTH, BUTTON_HEIGHT, clinicScreen, WM_CF_SHOW, WM_CF_MEMDEV, eAutoOffBtnId);
	//	WM_SetCallback(autoOffBtn, SettingBtnCallback);
	//	//init FL button
	//	flBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*7, BUTTON_LENGTH, BUTTON_HEIGHT, clinicScreen, WM_CF_SHOW, WM_CF_MEMDEV, eFLBtnId);
	//	WM_SetCallback(flBtn, SettingBtnCallback);
	//	//init circuit calibration button
	//	circuitCalibrateBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*8, BUTTON_LENGTH, BUTTON_HEIGHT, clinicScreen, WM_CF_SHOW, WM_CF_MEMDEV, eCircuitCalibrationBtnId);
	//	WM_SetCallback(circuitCalibrateBtn, ConfirmBtnCallback);
	//	//init vertical slider
	//	clinicSlider = SLIDER_CreateEx(SLIDER_BAR_X, SLIDER_BAR_Y, SLIDER_BAR_LENGTH, SLIDER_BAR_HEIGHT, clinicScreen, WM_CF_SHOW, SLIDER_CF_VERTICAL/*WM_CF_MEMDEV*/, eHcwVertSliderId);
	//	WM_SetCallback(clinicSlider, VerSliderCallback);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: ClinicScreenCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		The callback function of healthcare worker setting dialog
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void ClinicScreenCallback(WM_MESSAGE * pMsg)
{
	//	GUI_RECT Rect;
	switch (pMsg->MsgId) {
	case WM_PAINT:
		//		WM_GetInsideRect(&Rect);
		//		GUI_SetBkColor(HTR_BACKGROUND_COLOR);
		//		GUI_ClearRectEx(&Rect);
		testClinicScreenCallback = WM_PAINT;
		break;
	case WM_KEY:
	{
		switch (((WM_KEY_INFO*)(pMsg->Data.p))->Key) {
		case GUI_KEY_RIGHT:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
				ClinicHandleRightKey();
			break;
		case GUI_KEY_LEFT:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
				ClinicHandleLeftKey();
			break;
		case GUI_KEY_HOME:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
				ClinicHandleEnterKey();
			break;
		}
	}
	break;
	default:
		//		WM_DefaultProc(pMsg);
		testClinicScreenCallback = 5;
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: ClinicHandleEnterKey()
//
//    Processing:
//		The function operates when a enter key is received
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void ClinicHandleEnterKey()
{
	testClinicScreenCallback = 3;
	//get current ID
	//	currentId = eHcwTitleBarId;//WM_GetId(buttonList[currentItem]);
	switch (clinicState)
	{
	case eDialogState:
	{
		if(currentId == eHcwTitleBarId)
		{
			//save to EEPROM
			SettingSaveMocks();//SettingSave();
			//change to operation screen
			GuiEventStruct event;
			event.id = eGuiChangeToOperScreenId;
			event.data = 0;
			//send event
			if(xQueueSendToBack(guiQueue, &event, 2) != pdPASS)
			{
				xQueueReset(guiQueue);
			}
			//GuiTaskSendEvent(eGuiChangeToOperScreenId, 0);
			//WM_HideWindow(clinicScreen);
		}
		else if((currentId >= eFirstSettingBtnId)&&(currentId <= eLastSettingBtnId))
		{
			//			if(currentId == eBluetoothSettingBtnId)
			//			{
			//				if(SettingGet(eBluetoothSettingId) == eOn)
			//					//send event to show blue bluetooth searching dialog
			//					GuiTaskSendEvent(eGuiBleDialogShowId, 0);
			//			}
			//set previous second item
			prevSecondItem = secondItem;
			//change state
			clinicState = eSettingBarState;
			//enter current item
			//			WM_SetYSize(buttonList[currentItem], EXPAND_BUTTON_HEIGHT);
			//			SettingBtnSetStatus(buttonList[currentItem], eEnter);
			//			WM_Paint(buttonList[currentItem]);
			//if current is end item, decrease the second
			if(currentItem == endItem)
				secondItem++;
			//relayout the screen
			ClinicRelayout();
		}
		else if(currentId == eCircuitCalibrationBtnId)
		{
			//send event to show start calibration
			GuiEventStruct event;
			event.id = eGuiPopupCircuitCalibrateShowId;
			event.data = 0;
			//send event
			if(xQueueSendToBack(guiQueue, &event, 2) != pdPASS)
			{
				xQueueReset(guiQueue);
			}
			//			GuiTaskSendEvent(eGuiPopupCircuitCalibrateShowId, 0);
		}
	}
	break;
	case eSettingBarState:
	{
		//focus clinician screen
		//		WM_SetFocus(clinicScreen);
		//point current item
		//		SettingBtnSetStatus(buttonList[currentItem], ePoint);
		//		WM_SetYSize(buttonList[currentItem], BUTTON_HEIGHT);
		//		WM_Paint(buttonList[currentItem]);
		//change state
		clinicState = eDialogState;
		//set second item
		secondItem = prevSecondItem;
		//relayout the screen
		ClinicRelayout();
		//check to log
		if(isLogSetting == true)
		{
			//			SettingbtnLog(buttonList[currentItem]);
			isLogSetting = false;
		}
	}
	break;
	default:
		break;
	}
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: ClinicHandleLeftKey()
//
//    Processing:
//		The function operates when a right key is received
//
//    Input Parameters:
//		WM_HWIN hWin
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void ClinicHandleLeftKey()
{
	testClinicScreenCallback = 2;
	//get current ID
	currentId = eCircuitCalibrationBtnId;//WM_GetId(buttonList[currentItem]);
	switch(clinicState)
	{
	case eDialogState:
	{
		//increase current item
		//		currentItem++;
		if(currentItem >= clinicNumOfButton)
		{
			currentItem = 0;
			secondItem = 1;
			endItem = secondItem + 4;
		}
		else if(currentItem > endItem)
		{
			endItem = currentItem;
			secondItem = endItem - 4;
		}
		//relayout screen
		ClinicRelayout();
		//set item status
		ClinicSetButtonStatus();
		//update slider
		if(currentItem > 0)
		{
			testUpdateSlider = 1;
			//			SliderUpdate(clinicSlider, currentItem-1);
		}
		else
		{
			testUpdateSlider = 2;
			//			SliderUpdate(clinicSlider, 0);
		}
	}
	break;
	case eSettingBarState:
		//decrease the thump position of setting bar
		//		SettingBtnDecThumpPos(buttonList[currentItem]);
		isLogSetting = true;
		break;
	default:
		break;
	}

}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: ClinicHandleRightKey()
//
//    Processing:
//		The function operates when a left key is received
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void ClinicHandleRightKey()
{
	testClinicScreenCallback = 1;
	//get current ID
	currentId = eCircuitCalibrationBtnId;//WM_GetId(buttonList[currentItem]);
	switch(clinicState)
	{
	case eDialogState:
	{
		//increase current item
		//		currentItem--;
		if(currentItem < 0)
		{
			currentItem = clinicNumOfButton - 1;
			endItem = currentItem;
			secondItem = endItem - 4;
		}
		else if(currentItem == 0)
		{
			secondItem = 1;
			endItem = secondItem + 4;
		}
		else if(currentItem < secondItem)
		{
			secondItem = currentItem;
			endItem = secondItem + 4;
		}
		//change item status
		ClinicSetButtonStatus();
		//relayout
		ClinicRelayout();
		//update slider
		if(currentItem > 0)
		{
			testUpdateSlider = 3;
			//			SliderUpdate(clinicSlider, currentItem-1);
		}
		else
		{
			testUpdateSlider = 5;
			//			SliderUpdate(clinicSlider, 0);
		}
	}
	break;
	case eSettingBarState:
		//increase thump position of setting bar
		//		SettingBtnIncThumpPos(buttonList[currentItem]);
		isLogSetting = true;
		break;
	default:
		break;
	}
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: ClinicRelayout()
//
//    Processing:
//		The function layouts when front or end setting changes
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void ClinicRelayout()
{
	//show item from second to end and hide the rest
	for(int i = 1; i < clinicNumOfButton; i++)
	{
		if((i >= secondItem) && (i <= endItem))
		{
			//			WM_ShowWindow(buttonList[i]);
			testClinicRelayout = 1;
		}
		else
		{
			//			WM_HideWindow(buttonList[i]);
			testClinicRelayout = 2;
		}
	}
	//bring front button to top
	//	WM_MoveChildTo(buttonList[secondItem], 0 , BUTTON_HEIGHT);
	//layout others
	for(int i = secondItem; i < endItem; i++)
	{
		testClinicRelayout = testClinicRelayout + 1;
		//		WM_MoveChildTo(buttonList[i+1], 0, WM_GetYSize(buttonList[i])+WM_GetWinOrgY(buttonList[i]) - SETTING_SCREEN_Y);
	}
}

void SliderSetMaxClinic()
{
	testSliderSetMaxClinic = 100;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: ClinicSetItemList()
//
//    Processing:
//		The function is to set list of button
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void ClinicSetItemList()
{
	//get current ventilation mode
	unsigned char currentMode = SettingGetMocks(eVentModeSettingId);//SettingGet(eVentModeSettingId);
	if(currentMode == eAutoMode)
	{
		clinicNumOfButton = HCW_NUM_BTN_AUTO_MODE;	//set num buttons of hcw screen
		//create button list
		//		buttonList[0] = hcwTitleBar;
		//		buttonList[1] = ventilationTypeBtn;
		//		buttonList[2] = nsTypeBtn;
		//		buttonList[3] = upperLimitBtn;
		//		buttonList[4] = lowerLimitBtn;
		//		buttonList[5] = autoOffBtn;
		//		buttonList[6] = flBtn;
		//		buttonList[7] = bluetoothBtn;
		//		buttonList[8] = circuitCalibrateBtn;

		//show upper and lower limit buttons, and hide initial press., treatment press and ramp time buttons
		//		WM_HideWindow(settingPressBtn);
		//		WM_HideWindow(initialPressBtn);
		//		WM_HideWindow(rampTimeBtn);
		//		WM_ShowWindow(upperLimitBtn);
		//		WM_ShowWindow(lowerLimitBtn);
		//		WM_ShowWindow(flBtn);
	}
	else
	{
		clinicNumOfButton = HCW_NUM_BTN_CPAP_MODE;	//set num buttons of hcw screen
		//create button list
		//		buttonList[0] = hcwTitleBar;
		//		buttonList[1] = ventilationTypeBtn;
		//		buttonList[2] = nsTypeBtn;
		//		buttonList[3] = settingPressBtn;
		//		buttonList[4] = initialPressBtn;
		//		buttonList[5] = rampTimeBtn;
		//		buttonList[6] = autoOffBtn;
		//		buttonList[7] = bluetoothBtn;
		//		buttonList[8] = circuitCalibrateBtn;
		//hide item
		//		WM_HideWindow(upperLimitBtn);
		//		WM_HideWindow(lowerLimitBtn);
		//		WM_HideWindow(flBtn);
		//show item
		//		WM_ShowWindow(settingPressBtn);
		//		WM_ShowWindow(initialPressBtn);
		//		WM_ShowWindow(rampTimeBtn);
	}
	//set max value for slider bar
	SliderSetMaxClinic();//	SliderSetMax(clinicSlider, clinicNumOfButton - 2);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: ClinicSetButtonStatus()
//
//    Processing:
//		The function is to set status for all button
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void ClinicSetButtonStatus()
{
	int id;
	//get current ID
	currentId = eCircuitCalibrationBtnId;//WM_GetId(buttonList[currentItem]);

	for(int i = 0; i <= endItem; i++)
	{
		//get id of setting [i] in button list
		id = eCircuitCalibrationBtnId;//WM_GetId(buttonList[i]);

		if((id >= eFirstSettingBtnId)&&(id <= eLastSettingBtnId))
		{
			//			if(id == currentId)
			//			{
			//				SettingBtnSetStatus(buttonList[currentItem], ePoint);
			//			}
			//			else
			//			{
			//				SettingBtnSetStatus(buttonList[i], eRelease);
			//			}
		}
		else if((id >= eFirstConfirmBtnId)&&(id <= eLastConfirmBtnId))
		{
			//			if(id == currentId)
			//			{
			//				ConfirmBtnSetStatus(buttonList[currentItem], ePoint);
			//			}
			//			else
			//			{
			//				ConfirmBtnSetStatus(buttonList[i], eRelease);
			//			}
		}
		else if(id == eHcwTitleBarId)
		{
			//			if(id == WM_GetId(buttonList[currentItem]))
			//				TitleBarSetStatus(hcwTitleBar, ePoint);
			//			else
			//				TitleBarSetStatus(hcwTitleBar, eRelease);
		}
		//		WM_Paint(buttonList[i]);
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: ClinicScreenReload()
//
//    Processing:
//		The function prepares before showing clinician screen
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void ClinicScreenReload()
{
	//	SettingBtnSetValue(ventilationTypeBtn, SettingGet(eVentModeSettingId));	//get default ventilation mode
	//	SettingBtnSetValue(settingPressBtn, SettingGet(eOperPressSettingId)*2/PRESSURE_SCALE - PRESSURE_SETTING_MIN*2);		//get default treatment pressure
	//	SettingBtnSetValue(upperLimitBtn, SettingGet(eAutoUpperPressSettingId)*2/PRESSURE_SCALE - PRESSURE_SETTING_MIN*2);	//get default upper limit pressure
	//	SettingBtnSetValue(lowerLimitBtn, SettingGet(eAutoLowerPressSettingId)*2/PRESSURE_SCALE - PRESSURE_SETTING_MIN*2);	//get default lower limit pressure
	//	SettingBtnSetValue(initialPressBtn, SettingGet(eDelayPressSettingId)/(PRESSURE_SCALE*PRESSURE_INIT_MIN) - 1);		//get default initial pressure
	//	SettingBtnSetValue(rampTimeBtn, SettingGet(eRampTimeSettingId)/RAMP_TIME_SETTING_STEP);
	//	SettingBtnSetValue(nsTypeBtn, SettingGet(eNsTypeSettingId));
	//	SettingBtnSetValue(bluetoothBtn, SettingGet(eBluetoothSettingId));
	//	SettingBtnSetValue(autoOffBtn, SettingGet(eAutoOFFSettingId));
	//	SettingBtnSetValue(flBtn, SettingGet(eFLSettingId));
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(eVentModeSettingId));	//get default ventilation mode
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(eOperPressSettingId)*2/PRESSURE_SCALE - PRESSURE_SETTING_MIN*2);		//get default treatment pressure
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(eAutoUpperPressSettingId)*2/PRESSURE_SCALE - PRESSURE_SETTING_MIN*2);	//get default upper limit pressure
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(eAutoLowerPressSettingId)*2/PRESSURE_SCALE - PRESSURE_SETTING_MIN*2);	//get default lower limit pressure
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(eDelayPressSettingId)/(PRESSURE_SCALE*PRESSURE_INIT_MIN) - 1);		//get default initial pressure
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(eRampTimeSettingId)/RAMP_TIME_SETTING_STEP);
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(eNsTypeSettingId));
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(eBluetoothSettingId));
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(eAutoOFFSettingId));
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(eFLSettingId));

	clinicState = eDialogState;	//set state of hcw
	//	TitleBarSetStatus(hcwTitleBar, ePoint);
	//	WM_Paint(hcwTitleBar);
	ClinicSetItemList();		//reset new list
	currentItem = 0;
	secondItem = 1;
	endItem= secondItem + 4;
	ClinicRelayout();				//relayout
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: ClinicScreenHandleChangeVentMode()
//
//    Processing:
//		The function redraws screen when detect mode change
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void ClinicianScrHandleEvent(GuiEventStruct guiEvent)
{
	switch(guiEvent.id)
	{
	case eGuiClinicChangeVentModeId:
		ClinicSetItemList();			//reset button list
		ClinicRelayout();				//relayout
		break;
	default:
		break;
	}
}


#if defined(__cplusplus)
}
#endif


