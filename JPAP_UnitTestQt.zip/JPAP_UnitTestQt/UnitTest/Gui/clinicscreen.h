/*
 * clinicscreen.h
 *
 *  Created on: Apr 10, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_GUI_CLINICSCREEN_H_
#define UNITTEST_GUI_CLINICSCREEN_H_

#include <guiinterface.h>

#include "WM.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void ClinicScreenCallback(WM_MESSAGE * pMsg);
void ClinicHandleEnterKey();
void ClinicHandleLeftKey();
void ClinicHandleRightKey();
void ClinicRelayout();
void ClinicSetItemList();
void ClinicSetButtonStatus();
void ClinicScreenInit(void);
void ClinicScreenReload();
void ClinicianScrHandleEvent(GuiEventStruct guiEvent);
#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_CLINICSCREEN_H_ */
