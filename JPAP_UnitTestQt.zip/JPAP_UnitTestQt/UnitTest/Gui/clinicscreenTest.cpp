/*
 * clinicscreenTest.cpp
 *
 *  Created on: Apr 10, 2018
 *      Author: QUOCVIET
 */


#include "stdafx.h"
#include "Fixture.h"
#include "clinicscreen.h"

#include <guiinterface.h>
#include <setting.h>

#include "guidefine.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern short currentItem;
extern int testClinicScreenCallback;
extern short currentId;
extern E_SettingScreenState clinicState;
extern short prevSecondItem;
extern short secondItem;
extern int testClinicRelayout;
extern short clinicNumOfButton;
extern short endItem;
extern int testUpdateSlider;
extern bool isLogSetting;

namespace EmbeddedCUnitTest {


class ClinicScreenTest : public TestFixture
{
public:
	ClinicScreenTest() : TestFixture(new ModuleMock) {}
};



TEST_F(ClinicScreenTest, ClinicScreenInit)
{
	ClinicScreenInit();

	EXPECT_EQ(currentItem, 0);

}

TEST_F(ClinicScreenTest, ClinicScreenCallback)
{
	WM_MESSAGE *pMsg = new WM_MESSAGE;
	pMsg->MsgId = WM_PAINT;
	ClinicScreenCallback(pMsg);

	EXPECT_EQ(testClinicScreenCallback, WM_PAINT);

	/************************************************/
	WM_KEY_INFO *keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_RIGHT;
	keyData->PressedCnt = 1;
	pMsg->MsgId = WM_KEY;
	pMsg->Data.p = keyData;
	ClinicScreenCallback(pMsg);

	EXPECT_EQ(testClinicScreenCallback, 1);

	/************************************************/
	pMsg->MsgId = WM_KEY;
	keyData->Key = GUI_KEY_LEFT;
	pMsg->Data.p = keyData;
	ClinicScreenCallback(pMsg);

	EXPECT_EQ(testClinicScreenCallback, 2);

	/************************************************/
	pMsg->MsgId = WM_KEY;
	keyData->Key = GUI_KEY_HOME;
	pMsg->Data.p = keyData;
	ClinicScreenCallback(pMsg);

	EXPECT_EQ(testClinicScreenCallback, 3);

	/************************************************/
	pMsg->MsgId = WM_PAINT + WM_KEY;
	ClinicScreenCallback(pMsg);

	EXPECT_EQ(testClinicScreenCallback, 5);
}


TEST_F(ClinicScreenTest, ClinicHandleEnterKey)
{
	EXPECT_CALL(*_settingLib,SettingSaveMocks()).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(2).WillOnce(Return(pdPASS)).WillOnce(Return(pdFAIL));
	EXPECT_CALL(*_queueLib,xQueueReset(_)).Times(1);

	clinicState = eDialogState;
	currentId = eHcwTitleBarId;
	ClinicHandleEnterKey();

	EXPECT_EQ(testClinicScreenCallback, 3);

	for(int i = eFirstSettingBtnId; i <= eLastSettingBtnId; i++)
	{
		currentId = i;
		ClinicHandleEnterKey();
		EXPECT_EQ(prevSecondItem, 1);
		if(i%2 == 0)
		{
			EXPECT_EQ(testClinicRelayout,6);
			EXPECT_EQ(clinicState, eSettingBarState);
		}
		else
		{
			EXPECT_EQ(testClinicRelayout,6);
			EXPECT_EQ(clinicState, eDialogState);
		}

	}

	clinicState = eDialogState;
	currentId = eCircuitCalibrationBtnId;
	ClinicHandleEnterKey();

	clinicState = eSettingBarState;
	isLogSetting = true;
	ClinicHandleEnterKey();
	EXPECT_EQ(clinicState, eDialogState);
	EXPECT_EQ(secondItem, 1);
	EXPECT_EQ(testClinicRelayout,6);
	EXPECT_EQ(isLogSetting,false);
}

TEST_F(ClinicScreenTest, ClinicHandleLeftKey)
{
	currentItem = clinicNumOfButton;
	clinicState = eDialogState;

	ClinicHandleLeftKey();

	EXPECT_EQ(currentId, eCircuitCalibrationBtnId);

	EXPECT_EQ(currentItem, 0);
	EXPECT_EQ(secondItem, 1);
	EXPECT_EQ(endItem,secondItem + 4);

	EXPECT_EQ(testClinicRelayout,6);
	EXPECT_EQ(currentId,eCircuitCalibrationBtnId);
	EXPECT_EQ(testUpdateSlider,2);


	currentItem = 5;
	clinicState = eDialogState;

	ClinicHandleLeftKey();

	EXPECT_EQ(currentId, eCircuitCalibrationBtnId);

	EXPECT_EQ(endItem,currentItem);
	EXPECT_EQ(secondItem,endItem - 4);

	EXPECT_EQ(testClinicRelayout,6);
	EXPECT_EQ(currentId,eCircuitCalibrationBtnId);
	EXPECT_EQ(testUpdateSlider,1);

	clinicState = eSettingBarState;
	ClinicHandleLeftKey();
	EXPECT_EQ(isLogSetting,true);
}

TEST_F(ClinicScreenTest, ClinicHandleRightKey)
{
	currentItem = -1;
	clinicState = eDialogState;

	ClinicHandleRightKey();

	EXPECT_EQ(currentId, eCircuitCalibrationBtnId);

	EXPECT_EQ(currentItem, clinicNumOfButton - 1);
	EXPECT_EQ(endItem, currentItem);
	EXPECT_EQ(secondItem,endItem - 4);

	EXPECT_EQ(testClinicRelayout,5);
	EXPECT_EQ(currentId,eCircuitCalibrationBtnId);
	EXPECT_EQ(testUpdateSlider,3);


	currentItem = 0;
	clinicState = eDialogState;

	ClinicHandleRightKey();

	EXPECT_EQ(currentId, eCircuitCalibrationBtnId);

	EXPECT_EQ(secondItem, 1);
	EXPECT_EQ(endItem,secondItem + 4);

	EXPECT_EQ(testClinicRelayout,6);
	EXPECT_EQ(currentId,eCircuitCalibrationBtnId);
	EXPECT_EQ(testUpdateSlider,5);


	currentItem = 2;
	clinicState = eDialogState;

	ClinicHandleRightKey();

	EXPECT_EQ(currentId, eCircuitCalibrationBtnId);

	EXPECT_EQ(secondItem, 1);
	EXPECT_EQ(endItem,secondItem + 4);

	EXPECT_EQ(testClinicRelayout,6);
	EXPECT_EQ(currentId,eCircuitCalibrationBtnId);
	EXPECT_EQ(testUpdateSlider,3);

	clinicState = eSettingBarState;
	ClinicHandleRightKey();
	EXPECT_EQ(isLogSetting,true);
}

TEST_F(ClinicScreenTest, ClinicRelayout)
{
	ClinicRelayout();

	EXPECT_EQ(testClinicRelayout,6);
}

TEST_F(ClinicScreenTest, ClinicSetItemList)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eVentModeSettingId)).Times(1).WillOnce(Return(eAutoMode));
	ClinicSetItemList();

	EXPECT_EQ(clinicNumOfButton,HCW_NUM_BTN_AUTO_MODE);

	EXPECT_CALL(*_settingLib,SettingGetMocks(eVentModeSettingId)).Times(1).WillOnce(Return(eCpapMode));
	ClinicSetItemList();

	EXPECT_EQ(clinicNumOfButton,HCW_NUM_BTN_CPAP_MODE);
}

TEST_F(ClinicScreenTest, ClinicSetButtonStatus)
{
	ClinicSetButtonStatus();
	EXPECT_EQ(currentId,eCircuitCalibrationBtnId);
}

TEST_F(ClinicScreenTest, ClinicScreenReload)
{
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetValueMocks(_,_)).Times(10);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eVentModeSettingId)).Times(2).WillOnce(Return(eAutoMode)).WillOnce(Return(eAutoMode));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eOperPressSettingId)).Times(1).WillOnce(Return(eAutoMode));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eAutoUpperPressSettingId)).Times(1).WillOnce(Return(eAutoMode));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eAutoLowerPressSettingId)).Times(1).WillOnce(Return(eAutoMode));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eDelayPressSettingId)).Times(1).WillOnce(Return(eAutoMode));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eRampTimeSettingId)).Times(1).WillOnce(Return(eAutoMode));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eNsTypeSettingId)).Times(1).WillOnce(Return(eAutoMode));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eBluetoothSettingId)).Times(1).WillOnce(Return(eAutoMode));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eAutoOFFSettingId)).Times(1).WillOnce(Return(eAutoMode));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eFLSettingId)).Times(1).WillOnce(Return(eAutoMode));

	ClinicScreenReload();
	EXPECT_EQ(clinicState,eDialogState);
	EXPECT_EQ(clinicNumOfButton,HCW_NUM_BTN_AUTO_MODE);

	EXPECT_EQ(currentItem,0);
	EXPECT_EQ(secondItem,1);
	EXPECT_EQ(endItem,secondItem + 4);
	EXPECT_EQ(testClinicRelayout,6);
}

TEST_F(ClinicScreenTest, ClinicianScrHandleEvent)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eVentModeSettingId)).Times(1).WillOnce(Return(eAutoMode));

	GuiEventStruct guiEvent;
	guiEvent.id = eGuiClinicChangeVentModeId;
	ClinicianScrHandleEvent(guiEvent); // @suppress("Invalid arguments")

	EXPECT_EQ(testClinicRelayout,6);

	EXPECT_CALL(*_settingLib,SettingGetMocks(eVentModeSettingId)).Times(1).WillOnce(Return(eCpapMode));

	guiEvent.id = eGuiFirstClinicScreenId;
	ClinicianScrHandleEvent(guiEvent);// // @suppress("Invalid arguments")

	EXPECT_EQ(testClinicRelayout,6);
}

}

