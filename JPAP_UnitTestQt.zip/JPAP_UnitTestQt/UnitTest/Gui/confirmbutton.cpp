/*
 * confirmbutton.cpp
 *
 *  Created on: Apr 11, 2018
 *      Author: QUOCVIET
 */

#include "confirmbutton.h"

#include <setting.h>

#include "strings.h"
//#include "guiglobal.h"

int testConfirmBtnSetStatus = 0;
int testConfirmBtnCallback = 0;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

#define NUM_OF_CONFIRM_BUTTON			7
#define CONFIRM_BUTTON_HEIGHT			32

#define CONFIRM_BTN_NAME_X_START		10
#define CONFIRM_BTN_NAME_Y_START		5
//define color
#define CONFIRM_BTN_SELECTED_COLOR		COLOR_LIGHT_ORANGE
#define CONFIRM_BTN_UNSELECTED_COLOR	GUI_WHITE
#define CONFIRM_BTN_TOP_COLOR			SETTING_BAR_TOP_COLOR
#define CONFIRM_BTN_BOTTOM_COLOR		SETTING_BAR_BOTTOM_COLOR
#define CONFIRM_BTN_DRYING_RELEASE_COLOR	COLOR_ULTRA_LIGHT_BLUE


ConfirmBtnStruct confirmBtnContent[NUM_OF_CONFIRM_BUTTON] =
{
		{ strReset, eRelease },
		{ strCircuitCalibration, eRelease },
		{ strResetTimeUsing, eRelease },
		{ strMainUnitUpgrade, eRelease },
		{ strBlowerUpgrade, eRelease },
		{ strExportToCSVFile, eRelease },
		//		{ strCircuitCalibrationWOMask, eRelease },
		{ strBLEUnitUpgrade, eRelease }
};

void ConfirmBtnSetStatus(void* hObj, E_ButtonStatus status)
{
	//	confirmBtnContent[WM_GetId(hObj) - eFirstConfirmBtnId].status = status;
	testConfirmBtnSetStatus = status;
}

void ConfirmBtnCallback(WM_MESSAGE * pMsg)
{
//	GUI_RECT Rect;
//	const char* nameStr;
//	int status;

	switch (pMsg->MsgId) {
	case WM_PAINT:
//		WM_GetClientRect(&Rect);
//		nameStr = confirmBtnContent[WM_GetId(pMsg->hWin) - eFirstConfirmBtnId].nameStr[language]; //get name string
//		status = confirmBtnContent[WM_GetId(pMsg->hWin) - eFirstConfirmBtnId].status;	//get status

//		GUI_AA_SetFactor(6);
//		GUI_SetPenShape(GUI_PS_ROUND);
//		GUI_SetTextMode(GUI_TM_TRANS);

//		GUI_DrawGradientV(Rect.x0, Rect.y0, Rect.x1, Rect.y0 + CONFIRM_BUTTON_HEIGHT, CONFIRM_BTN_TOP_COLOR, CONFIRM_BTN_BOTTOM_COLOR);	//draw background
		//set color
//		if(status == eRelease)
//		{
//			if(WM_GetId(pMsg->hWin) == eDryingModeBtnId)
//				GUI_SetColor(CONFIRM_BTN_DRYING_RELEASE_COLOR);														//set color
//			else
//				GUI_SetColor(CONFIRM_BTN_UNSELECTED_COLOR);
//		}
//		else
//		{
//			GUI_SetColor(CONFIRM_BTN_SELECTED_COLOR);
//		}
//		GUI_SetFont(guiFont16[language]);	//set font
		//		if((WM_GetId(pMsg->hWin) == eDryingModeBtnId)&&(language == eJapanese))
		//			GUI_SetFont(&GUI_FontJapanese16Add2);	//set font
//		GUI_DispStringAt(nameStr, CONFIRM_BTN_NAME_X_START, CONFIRM_BTN_NAME_Y_START);	//display name

		testConfirmBtnCallback = WM_PAINT;
		break;
	default:
//		BUTTON_Callback(pMsg); //The original callback
		testConfirmBtnCallback = 1000;
		break;
	}
}

#if defined(__cplusplus)
}
#endif

