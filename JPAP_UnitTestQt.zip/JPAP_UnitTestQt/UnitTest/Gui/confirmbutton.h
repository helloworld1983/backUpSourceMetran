/*
 * confirmbutton.h
 *
 *  Created on: Apr 11, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_GUI_CONFIRMBUTTON_H_
#define UNITTEST_GUI_CONFIRMBUTTON_H_

#include "WM.h"
//#include "BUTTON.h"
#include "guidefine.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void ConfirmBtnCallback(WM_MESSAGE * pMsg);
void ConfirmBtnSetStatus(void* hObj, E_ButtonStatus status);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_GUI_CONFIRMBUTTON_H_ */
