/*
 * confirmbuttonTest.cpp
 *
 *  Created on: Apr 11, 2018
 *      Author: QUOCVIET
 */

#include "stdafx.h"
#include "Fixture.h"
#include "confirmbutton.h"
#include "WM.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern int testConfirmBtnSetStatus;
extern int testConfirmBtnCallback;

namespace EmbeddedCUnitTest {


class ConfirmButtonTest : public TestFixture
{
public:
	ConfirmButtonTest() : TestFixture(new ModuleMock) {}
};



TEST_F(ConfirmButtonTest, ConfirmBtnSetStatus)
{
	for(int i = eRelease; i < eEnter + 1; i++)
	{
		ConfirmBtnSetStatus(nullptr,(E_ButtonStatus)i);
		EXPECT_EQ(testConfirmBtnSetStatus, i);
	}

}

TEST_F(ConfirmButtonTest, ConfirmBtnCallback)
{
	WM_MESSAGE  pMsg;
	pMsg.MsgId = WM_PAINT;

	ConfirmBtnCallback(&pMsg);

	EXPECT_EQ(testConfirmBtnCallback,WM_PAINT);

	pMsg.MsgId = WM_PAINT + 1;

	ConfirmBtnCallback(&pMsg);

	EXPECT_EQ(testConfirmBtnCallback,1000);
}

}



