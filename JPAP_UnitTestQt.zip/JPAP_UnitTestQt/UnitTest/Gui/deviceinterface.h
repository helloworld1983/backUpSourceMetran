/*
 * deviceinterface.h
 *
 *  Created on: Apr 20, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_GUI_DEVICEINTERFACE_H_
#define UNITTEST_GUI_DEVICEINTERFACE_H_

//#include "FreeRTOS.h"
#include "queue.h"
//#include "semphr.h"
//#include "debuguart.h"

//define device event ID
typedef enum
{
	eDeviceCircuitResId = 0,			//event id from system task to update resistance
	eDeviceBleStatusChangeId,			//event indicate BLE has changed status
	eDeviceBleIntervalTimeId			//event to update interval time
} E_DeviceEventId;

//define BLE status
typedef enum
{
	eDeviceBleBootUpId = 0,		//this ID indicate that BLE has just boot up
	eDeviceBleConnectId,		//this ID indicate that BLE has just connected
	eDeviceBleDisconnectId,		//this ID indicate that BLE has just disconnected

	eDeviceBleEnableId,			//command to enable BLE module
	eDeviceBleDisableId,		//command to disable BLE module
	eDeviceBleResetId,			//command to reset BLE module

	eDeviceBleExportLogSuccessId,	//event indicate export system log success from System Task
	eDeviceBleExportLogFailedId,	//event indicate export system log failed from System Task
	eDeviceBleExportLogNoDataId		//event indicate export system log failed due to no data

} E_DeviceBleEventId;

//define structure for device event communication
typedef struct
{
	E_DeviceEventId id;
	long data;
} DeviceEventStruct;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

////declare UART0 mutex
//extern xSemaphoreHandle uart0Mutex;
//
////declare RTC mutex
//extern xSemaphoreHandle rtcMutex;
//
////declare device queue
//extern xQueueHandle deviceQueue;
//
////function to send event to system task
////return true if event was sent successful
////return false is event was sent failed
//inline bool DeviceTaskSendEvent(E_DeviceEventId id, long data)
//{
//	//return value
//	bool rtn = true;
//	//create a event to send
//	DeviceEventStruct event;
//	event.id = id;
//	event.data = data;
//	//send event to queue
//	if(xQueueSendToBack(deviceQueue, &event, 2) != pdPASS)
//	{
//		//reset device queue
//		xQueueReset(deviceQueue);
//		DebugStr("\n send failed: event to device task");
//		rtn = false;
//	}
//	return rtn;
//}

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_GUI_DEVICEINTERFACE_H_ */
