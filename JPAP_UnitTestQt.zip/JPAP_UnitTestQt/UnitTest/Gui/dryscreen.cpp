/*
 * dryscreen.cpp
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#include "dryscreen.h"

#include <setting.h>

#include "guidefine.h"
//#include "guiglobal.h"
//#include "fonts.h"
#include "strings.h"
//#include "debuguart.h"
//#include "stringtools.h"
#include "WString.h"

int testDryScreen = 0;
int testlengthOfMinute = 0;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

#define DRY_SETTING_SCREEN_X			40
#define DRY_SETTING_SCREEN_Y			25
#define DRY_SETTING_SCREEN_LENGTH		240
#define DRY_SETTING_SCREEN_HEIGHT		110

#define DRY_PROGRESS_BAR_X				0
#define DRY_PROGRESS_BAR_Y				70
#define DRY_PROGRESS_BAR_LENGTH			240
#define DRY_PROGRESS_BAR_HEIGHT			30

//2. alarm title
#define DRY_TITLE_X						0
#define DRY_TITLE_Y						5
#define DRY_TITLE_LENGTH				240
#define DRY_TITLE_HEIGHT				25

#define REAMIANING_LABEL_X				0
#define REMAINING_LABEL_Y				40
#define REMAINING_LABEL_LENGTH			240
#define REMAINING_LABLE_HEIGHT			25

#define DRY_BK_COLOR					GUI_WHITE
#define DRY_TITLE_BK_COLOR				COLOR_LIGHT_BLUE
#define DRY_BORDER_COLOR				COLOR_ULTRA_LIGHT_BLUE
#define DRY_TEXT_COLOR					COLOR_ULTRA_LIGHT_BLUE

static unsigned char language = 0;

//void DryScrCallback(WM_MESSAGE * pMsg);
//void DryProgressBarCallback(WM_MESSAGE * pMsg);

//WM_HWIN dryScreen;					//declare patient setting screen
//extern WM_HWIN operationScreen;
//
//static TEXT_Handle dryLabel;
////static PROGBAR_Handle dryProgressBar;	//real time pressure indicator
//static TEXT_Handle remainingTimeLabel;
//static TEXT_Handle inforLabel;
//
//static const GUI_FONT* guiFont16[] = { &GUI_FontJapanese16Add, &GUI_FontJPAPJPFont16B };
//static const GUI_FONT* guiFont14[] = { &GUI_FontJapanes14Add, &GUI_FontJPAPJPFont14B };

typedef enum
{
	eDryLabelId,
	eRemainTimeLabelId,
	eInforLabelId
	//	eProgressBarId
} E_DryScreenItemId;
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: UserSettingDialogInit(void)
//
//    Processing:
//		The function creates patient screen
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void DryScreenInit(void)
{
	testDryScreen = 1;
	//init patient setting screen
	//	dryScreen = WM_CreateWindowAsChild(DRY_SETTING_SCREEN_X, DRY_SETTING_SCREEN_Y, DRY_SETTING_SCREEN_LENGTH, DRY_SETTING_SCREEN_HEIGHT, operationScreen, WM_CF_HIDE /*| WM_CF_MEMDEV*/ | WM_CF_LATE_CLIP  | WM_CF_HASTRANS , DryScrCallback, 0);
	//init dry label
	//	dryLabel = TEXT_CreateEx(DRY_TITLE_X, DRY_TITLE_Y, DRY_TITLE_LENGTH, DRY_TITLE_HEIGHT, dryScreen, WM_CF_SHOW, TEXT_CF_HCENTER, eDryLabelId, strDrying[language]);
	//	TEXT_SetFont(dryLabel, guiFont16[language]);
	//	TEXT_SetTextColor(dryLabel, GUI_WHITE);
	//init patient setting screen
	//	dryProgressBar = PROGBAR_CreateEx(DRY_PROGRESS_BAR_X, DRY_PROGRESS_BAR_Y, DRY_PROGRESS_BAR_LENGTH, DRY_PROGRESS_BAR_HEIGHT, dryScreen, WM_CF_SHOW | WM_CF_HASTRANS, PROGBAR_CF_HORIZONTAL, eProgressBarId);
	//	WM_SetCallback(dryProgressBar, DryProgressBarCallback);
	//	PROGBAR_SetMinMax(dryProgressBar, 0, TOTAL_MINUTES);
	//create text for date and time
	//	remainingTimeLabel = TEXT_CreateEx(REAMIANING_LABEL_X, REMAINING_LABEL_Y, REMAINING_LABEL_LENGTH, REMAINING_LABLE_HEIGHT,dryScreen,WM_CF_SHOW, TEXT_CF_HCENTER, eRemainTimeLabelId, "");
	//	TEXT_SetFont(remainingTimeLabel, guiFont14[language]);
	//	TEXT_SetTextColor(remainingTimeLabel, DRY_TEXT_COLOR);

	//	inforLabel = TEXT_CreateEx(DRY_PROGRESS_BAR_X, DRY_PROGRESS_BAR_Y, DRY_PROGRESS_BAR_LENGTH, DRY_PROGRESS_BAR_HEIGHT, dryScreen,WM_CF_SHOW, TEXT_CF_HCENTER, eInforLabelId, "");
	//	TEXT_SetFont(inforLabel, guiFont14[language]);
	//	TEXT_SetTextColor(inforLabel, DRY_TEXT_COLOR);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: UserScrCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		The callback function of parent dialog (patient setting)
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void DryScrCallback(WM_MESSAGE * pMsg)
{
//	GUI_RECT Rect;
	switch (pMsg->MsgId) {
	case WM_PAINT:
		//get size: x0, x1, y0, y1
//		WM_GetClientRect(&Rect);
//		GUI_SetPenShape(GUI_PS_ROUND);
//		GUI_SetTextMode(GUI_TM_TRANS);
//		//draw background
//		GUI_SetColor(DRY_BK_COLOR);
//		GUI_AA_FillRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1, 10);
//
//		//draw title background
//		GUI_SetColor(DRY_TITLE_BK_COLOR);
//		GUI_AA_FillRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y0+31, 10);
//		GUI_FillRect(Rect.x0, Rect.y0+15, Rect.x1, Rect.y0+31);
//
//		//draw border
//		GUI_SetColor(DRY_BORDER_COLOR);
//		GUI_AA_DrawRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1, 10);

		testDryScreen = WM_PAINT;
		break;
	default:
//		PROGBAR_Callback(pMsg);
		testDryScreen = 1000;
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: DryScreenReload()
//
//    Processing:
//		The function reload all items before showing
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void DryScreenReload()
{
//	if(language == eJapanese)
//	{
//		TEXT_SetFont(inforLabel, &GUI_FontJapanes14Add2);
//	}
//	else
//	{
//		TEXT_SetFont(inforLabel, &GUI_FontEnglish14Add3);
//	}
	//set font and text for dry label
//	TEXT_SetFont(dryLabel, guiFont16[language]);
//	TEXT_SetText(dryLabel, strDrying[language]);
	//set font and text
	//	TEXT_SetFont(inforLabel, guiFont14[language]);
//	TEXT_SetText(inforLabel, strPressToTurnOff[language]);
	//reset progress bar
	DryScreenUpdate(DRY_TOTAL_MINUTES);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: cbGuiOperRealTimePressureIndicator(WM_MESSAGE * pMsg)
//
//    Processing:
//		Call back function for pressure indicator bar
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
//void DryProgressBarCallback(WM_MESSAGE * pMsg)
//{
//	GUI_RECT Rect;
//	switch (pMsg->MsgId) {
//	case WM_PAINT:
//		//get size: x0, x1, y0, y1
//		WM_GetClientRect(&Rect);
//		GUI_SetPenShape(GUI_PS_ROUND);
//		GUI_SetTextMode(GUI_TM_TRANS);
//
//		GUI_SetColor(COLOR_DARK_BLUE);
//		GUI_AA_FillRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1, 3);
//
//		GUI_SetColor(COLOR_LIGHT_ORANGE);
//		if (PROGBAR_GetValue(pMsg->hWin) >= 7)
//			GUI_AA_FillRoundedRect(Rect.x0, Rect.y0, Rect.x0 + PROGBAR_GetValue(pMsg->hWin)*(Rect.x1 - Rect.x0)/TOTAL_MINUTES, Rect.y1, 3);
//		else
//			GUI_FillRect(Rect.x0, Rect.y0, Rect.x0 + PROGBAR_GetValue(pMsg->hWin)*(Rect.x1 - Rect.x0)/TOTAL_MINUTES, Rect.y1);
//
//		GUI_SetColor(COLOR_ULTRA_LIGHT_BLUE);
//		GUI_AA_DrawRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1, 3);
//		break;
//	default:
//		PROGBAR_Callback(pMsg);
//	}
//}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: DryScreenUpdate(int percent)
//
//    Processing:
//		This operation updates the progress bar
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void DryScreenUpdate(int minute)
{
	testDryScreen = minute;
	char temp[50] = {'\0'};			//maximum 6 characters
	int index = strlen(strAutoOffAfter[language]);
	StrAppend(temp, strAutoOffAfter[language], 50);

	unsigned char lengthOfMinute;

	if(minute >= 100)
	{
		lengthOfMinute = 3;
	}
	else if(minute >= 10)
	{
		lengthOfMinute = 2;
	}
	else
	{
		lengthOfMinute = 1;
	}
	StrToolItoA(minute, &temp[index], lengthOfMinute);
	index += lengthOfMinute;
	testlengthOfMinute = index;
	StrAppend(temp, strMinutes[language], 50);
//	TEXT_SetFont(remainingTimeLabel, guiFont14[language]);
//	TEXT_SetText(remainingTimeLabel, &temp[0]);
}


#if defined(__cplusplus)
}
#endif


