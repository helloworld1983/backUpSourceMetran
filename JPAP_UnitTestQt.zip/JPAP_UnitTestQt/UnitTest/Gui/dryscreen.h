/*
 * dryscreen.h
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_GUI_DRYSCREEN_H_
#define UNITTEST_GUI_DRYSCREEN_H_

#include "WM.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

#define DRY_TOTAL_MINUTES					180

//extern WM_HWIN dryScreen;

void DryScrCallback(WM_MESSAGE * pMsg);
//function to initialize user option screen
void DryScreenInit(void);
//function to load setting before display
void DryScreenReload();
void DryScreenUpdate(int minute);


#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_DRYSCREEN_H_ */
