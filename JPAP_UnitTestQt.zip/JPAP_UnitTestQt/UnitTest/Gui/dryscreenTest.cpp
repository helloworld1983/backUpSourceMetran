/*
 * dryscreenTest.cpp
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#include "stdafx.h"
#include "Fixture.h"
#include "dryscreen.h"
#include "WM.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern int testDryScreen;
extern int testlengthOfMinute;

namespace EmbeddedCUnitTest {


class DryScreenTest : public TestFixture
{
public:
	DryScreenTest() : TestFixture(new ModuleMock) {}
};



TEST_F(DryScreenTest, DryScreenInit)
{
	DryScreenInit();

	EXPECT_EQ(testDryScreen,1);
}

TEST_F(DryScreenTest, DryScrCallback)
{
	WM_MESSAGE  pMsg;
	pMsg.MsgId = WM_PAINT;

	DryScrCallback(&pMsg);

	EXPECT_EQ(testDryScreen,WM_PAINT);

	pMsg.MsgId = WM_PAINT + 1;

	DryScrCallback(&pMsg);

	EXPECT_EQ(testDryScreen,1000);
}

TEST_F(DryScreenTest, DryScreenReload)
{
	DryScreenReload();

	EXPECT_EQ(testDryScreen,DRY_TOTAL_MINUTES);
}

TEST_F(DryScreenTest, DryScreenUpdate)
{
	EXPECT_CALL(*_wstring,strlen(_)).Times(1).WillOnce(Return(5));
	EXPECT_CALL(*_wstring,StrAppend(_,_,50)).Times(2);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);

	DryScreenUpdate(100);

	EXPECT_EQ(testDryScreen,100);
	EXPECT_EQ(testlengthOfMinute,8);

	/******************/
	EXPECT_CALL(*_wstring,strlen(_)).Times(1).WillOnce(Return(5));
	EXPECT_CALL(*_wstring,StrAppend(_,_,50)).Times(2);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);

	DryScreenUpdate(10);

	EXPECT_EQ(testDryScreen,10);
	EXPECT_EQ(testlengthOfMinute,7);

	/******************/
	EXPECT_CALL(*_wstring,strlen(_)).Times(1).WillOnce(Return(5));
	EXPECT_CALL(*_wstring,StrAppend(_,_,50)).Times(2);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);

	DryScreenUpdate(9);

	EXPECT_EQ(testDryScreen,9);
	EXPECT_EQ(testlengthOfMinute,6);
}

}



