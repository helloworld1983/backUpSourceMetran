/*
 * guidefine.h
 *
 *  Created on: Apr 10, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_GUI_GUIDEFINE_H_
#define UNITTEST_GUI_GUIDEFINE_H_

//#if defined(__cplusplus)
//namespace EmbeddedC {
//#endif

//0. define signals
//#define WM_UPDATE_TIME 					(WM_USER + 0)			//signal to update pressure
//#define WM_SHOW_SDICON					(WM_USER + 1)			//show SD card icon signal
//#define WM_HIDE_SDICON					(WM_USER + 2)			//hide SD card icon signal
//#define WM_SHOW_BLEICON					(WM_USER + 3)			//show BLE icon signal
//#define WM_HIDE_BLEICON					(WM_USER + 4)			//hide BLE icon signal
//#define WM_UPDATE_PRESSURE 				(WM_USER + 5)			//update real time pressure
//#define WM_UPDATE_COUNTER				(WM_USER + 6)			//change value on delay and ramp counter
//#define WM_OPERATION_ACTIVATE			(WM_USER + 7)			//start operation GUI
//#define WM_STANDBY_ACTIVATE				(WM_USER + 8)			//stop operation
//#define WM_OPERATION_UPDATE_SETTING		(WM_USER + 9)			//update setting value
//#define WM_UPGRADE_ERROR				(WM_USER + 10)			//upgrade error
//#define WM_UPGRADE_RUN					(WM_USER + 11)			//run upgrade
//#define WM_UPGRADE_SUCCESS				(WM_USER + 12)			//upgrade successfully
#define WM_APPLY_TIME					(WM_USER + 13)			//set time
//#define WM_END_CIRCUIT_CALIBRATION		(WM_USER + 14)			//circuit calibration
//#define WM_RELOAD_SETTING				(WM_USER + 15)			//reset settings
//#define WM_SLEEP_SCREEN_UPDATE_TIME		(WM_USER + 16)			//update time on Display-Off screen
//#define WM_UPDATE_TREATMENT_PRESSURE	(WM_USER + 17)			//update real time treatment pressure on operation screen
//#define WM_HCW_CHANGE_VENT_MODE			(WM_USER + 18)			//change hcw screen when mode is changed
//#define WM_SHOW_ERRICON					(WM_USER + 19)
//#define WM_SHOW_SD_ERROR_ICON			(WM_USER + 20)
//1. define parameters of setting screen
#define NUM_OF_SCREEN 				4
#define	SETTING_SCREEN_X			0
#define SETTING_SCREEN_Y			40
#define SETTING_SCREEN_LENGTH		320
#define SETTING_SCREEN_HEIGHT		200

//2. define parameters of title bar
#define TITLE_BAR_X					0
#define TITLE_BAR_Y					0
#define TITLE_BAR_LENGTH			320
#define TITLE_BAR_HEIGHT			32

//3. define parameters of slider bar
#define SLIDER_BAR_X				300
#define SLIDER_BAR_Y				32
#define SLIDER_BAR_LENGTH			20
#define SLIDER_BAR_HEIGHT			160

//4. define parameters of button
#define BUTTON_X					0
#define BUTTON_Y					32
#define BUTTON_LENGTH				300
#define BUTTON_HEIGHT				32

//5. define parameters of pop up
#define POPUP_NUM_YES_NO_BTN		2
#define POPUP_SCREEN_X				50
#define POPUP_SCREEN_Y				70
#define POPUP_SCREEN_LENGTH			220
#define POPUP_SCREEN_HEIGHT			100

//6. define parameters of YES button
#define POPUP_YES_BUTTON_X			30
#define POPUP_YES_BUTTON_Y			50
#define POPUP_YES_BUTTON_LENGTH		65
#define POPUP_YES_BUTTON_HEIGHT		30

//7. define parameters of NO button
#define POPUP_NO_BUTTON_X			125
#define POPUP_NO_BUTTON_Y			50
#define POPUP_NO_BUTTON_LENGTH		65
#define POPUP_NO_BUTTON_HEIGHT		30

//8. define parameters of OK button 80, 70, 60, 30
#define POPUP_OK_BUTTON_X			80
#define POPUP_OK_BUTTON_Y			50
#define POPUP_OK_BUTTON_LENGTH		60
#define POPUP_OK_BUTTON_HEIGHT		30

//9. define parameters of Title Label 0, 25, 220, 30
#define POPUP_TITLE_LABEL_X			0
#define POPUP_TITLE_LABEL_Y			5
#define POPUP_TITLE_LABEL_LENGTH	220
#define POPUP_TITLE_LABEL_HEIGHT	30

//10. define parameters of LOADING text 0, 70, 220, 30
#define POUP_LOADING_TEXT_X			0
#define POUP_LOADING_TEXT_Y			50
#define POUP_LOADING_TEXT_LENGTH	220
#define POUP_LOADING_TEXT_HEIGHT	30

//11. define size of setting button
#define NORMAL_BUTTON_HEIGHT		32
#define EXPAND_BUTTON_HEIGHT		64
#define EXPAND_TIME_BTN_HEIGHT	 	96
#define INFORMATION_BTN_HEIGHT	 	128

//12. define parameters of arrow sign
#define ARROW_NUM_OF_POINTS			6
#define RIGHT_ARROW_X				280
#define RIGHT_ARROW_Y				7
#define DOWN_ARROW_X				275
#define DOWN_ARROW_Y				10

//13. define  color
#define COLOR_DARK_BLUE					0x503008
#define COLOR_LIGHT_BLUE				0x835D00
#define COLOR_ULTRA_LIGHT_BLUE			0xEFAE00
#define COLOR_LIGHT_ORANGE 				0x24D3FF//0x1E94F7
#define COLOR_H_SLIDER					0xF6CF6D
#define COLOR_GRAY						0xE0E0E0

//14. define color for setting bar
#define SETTING_BAR_TOP_COLOR			0x513600
#define SETTING_BAR_BOTTOM_COLOR		0x967100
#define SETTING_EXPAND_BK_COLOR			0x967100

//15. define color for text


//16. define num buttons
#define MTN_NUM_BUTTON					13
#define MTN_NUM_SCREEN_BTN				5
#define USERSCREEN_WDRYING_NUM_BUTTON	4
#define USERSCREEN_WODRYING_NUM_BUTTON	3
#define HCW_NUM_BTN_CPAP_MODE			9
#define HCW_NUM_BTN_AUTO_MODE			9
#define HCW_NUM_SCREEN_BTN				5

//18. define timer period
#define BUZZER_TIMER_PERIOD				50
#define PRESS_TIMER_PERIOD				100
#define FIRST_TIME_TIMER_PERIOD			700
//#define ENTER_SCREEN_TIMER_PERIOD		5000

#define PRESSURE_SCALE					10
#define PRESSURE_SETTING_MIN			4
#define PRESSURE_INIT_MIN				2
#define PRESSURE_SETTING_STEP		5

//define for arrow icon
//#define ARROW_NUM_OF_POINT				6
//define right arrow sign
//static const GUI_POINT rightArrow[] = {
//		{0, 0},	{10, 10}, {0, 20}, {0, 16},	{6, 10}, {0, 4},
//};
////define down arrow sign
//static const GUI_POINT downArrow[] = {
//		{0, 0},	{10, 10}, {20, 0},	{16, 0}, {10, 6}, {4, 0},
//};

//define Button Status
typedef enum
{
	eRelease,
	ePoint,
	eEnter
} E_ButtonStatus;
//state of setting screen
typedef enum
{
	eDialogState,
	eSettingBarState
} E_SettingScreenState;

//pop up state
typedef enum{
	eNoState,
	eYesState,
	eDoneState
} E_PopUpState;

//define button event
typedef enum
{
	eKeyNoEventId = 0,
	eLeftKeyPressedId,
	eLeftKeyReleasedId,
	eRightKeyPressedId,
	eRightKeyReleasedId,
	eEnterKeyPressedId,
	eEnterKeyReleasedId,
	eOperKeyPressedId,
	eOperKeyReleasedId
} E_KeyEventId;

//define structure for buttons of POP UP
typedef struct{
	const char** nameStr;
	E_ButtonStatus status;
} PopUpButtonContent;

//define structure for slider bar
typedef struct{
	const char** stringArrayPtr;
	int numOfValue;
	int position;
} SliderContent;

typedef enum
{
	eFirstSettingBtnId = 0,
	eInhSupBtnId = eFirstSettingBtnId,
	eExhSupBtnId,
	eRampTimeBtnId,
	eBrightnessAdjustBtnId,
	eLanguageSettingBtnId,
	eVentilationTypeBtnId,
	eSettingPressBtnId,
	eUpperPressBtnId,
	eLowerPressBtnId,
	eBluetoothSettingBtnId,
	eInitialPressBtnId,
	eChangeUnitBtnId,
	eDisplayOffTimerBtnId,
	eNaturalSupportTypeBtnId,
	eAutoOffBtnId,
	eFLBtnId,
	eDryingModeBtnId,
	eLastSettingBtnId = eDryingModeBtnId,

	eFirstConfirmBtnId,
	eResetBtnId =  eFirstConfirmBtnId,
	eCircuitCalibrationBtnId,
	eResetTimeUsingBtnId,
	eMainUnitUpgradeBtnId,
	eBlowerUpgradeBtnId,
	eExportLogBtnId,
	eBLEUnitUpgradeBtnId,
	eLastConfirmBtnId = eBLEUnitUpgradeBtnId,

	eTimeSettingBtnId,
	eInformationDlgId,
	//define title bar ID
	eFirstTitleBarId,
	ePtTitleBarId = eFirstTitleBarId,
	eHcwTitleBarId,
	eMtnTitleBarId,
	eHtrTitleBarId,
	eLastTitleBarId = eHtrTitleBarId,
} E_GuiSettingId;

typedef enum
{
	eGuiOperRunning = 0,
	eGuiOperDrying,
	eGuiOperMaskOff,
	eGuiOperIdle
} E_GuiOperState;

//define struct for setting button
typedef struct{
	const char** buttonArrayPtr;
	const char** nameStr;
	char* valueStr;
	E_ButtonStatus status;
} SettingBtnStruct;

//define struct for time widget
typedef struct{
	int value;
	E_ButtonStatus status;
} TimeWidgetContent;

//define struct for confirm button
typedef struct{
	const char** nameStr;
	E_ButtonStatus status;
} ConfirmBtnStruct;

//define struct for title bar
typedef struct{
	const char** nameStr;
	E_ButtonStatus status;
} TitleBarStruct;

//define struct for log table
typedef struct{
	unsigned char pageAddr;
	unsigned char byteAddr;
} DataAddressStruct;


//#if defined(__cplusplus)
//}
//#endif



#endif /* UNITTEST_GUI_GUIDEFINE_H_ */
