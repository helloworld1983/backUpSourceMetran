/*
 * guiglobal.cpp
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#include "guiglobal.h"
//#include "debuguart.h"
//#include "string.h"
#include "WString.h"


unsigned char language = 0;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

unsigned char StrAppend1(char* des, const char* source, unsigned char bufferOfDes)
{
	//	DebugStr("\n *** length of des: ");
	//	DebugNumber(strlen(des));
	//	DebugStr(",... length of source: ");
	//	DebugNumber(strlen(source));

	unsigned char usageSize = strlen(des) + strlen(source);
	if(usageSize <= bufferOfDes)
		strcat(des, source);
	else
		strncat(des, source, (bufferOfDes - usageSize));

	return strlen(des);
}

#if defined(__cplusplus)
}
#endif

