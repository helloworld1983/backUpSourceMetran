/*
 * guiglobal.h
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_GUI_GUIGLOBAL_H_
#define UNITTEST_GUI_GUIGLOBAL_H_

extern unsigned char language;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

unsigned char StrAppend1(char* des, const char* source, unsigned char bufferOfDes);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_GUIGLOBAL_H_ */
