/*
 * guiglobalTest.cpp
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#include "stdafx.h"
#include "Fixture.h"
#include "guiglobal.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

namespace EmbeddedCUnitTest {


class GuiGlobalTest : public TestFixture
{
public:
	GuiGlobalTest() : TestFixture(new ModuleMock) {}
};



TEST_F(GuiGlobalTest, StrAppend1)
{
	EXPECT_CALL(*_wstring,strlen(_)).Times(3).WillOnce(Return(5)).WillOnce(Return(5)).WillOnce(Return(10));

	EXPECT_CALL(*_wstring,strcat(_,_)).Times(1);

	unsigned char size = StrAppend1(nullptr,nullptr,10);

	EXPECT_EQ(size,10);

	EXPECT_CALL(*_wstring,strlen(_)).Times(3).WillOnce(Return(5)).WillOnce(Return(6)).WillOnce(Return(11));

	EXPECT_CALL(*_wstring,strncat(_,_,_)).Times(1);

	size = StrAppend1(nullptr,nullptr,10);

	EXPECT_EQ(size,11);
}

}


