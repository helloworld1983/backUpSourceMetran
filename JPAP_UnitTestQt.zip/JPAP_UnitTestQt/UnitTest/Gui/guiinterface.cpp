/*
 * guiinterface.cpp
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#include <guiinterface.h>
#include "queue.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

static xQueueHandle guiQueue;

bool GuiTaskSendEvent(unsigned char id, long data)
{
	//return value
	bool rtn = true;
	//event to send
	GuiEventStruct event;
	event.id = (E_GuiEventId)id;
	event.data = data;
	//send event
	if(xQueueSendToBack(guiQueue, &event, 2) != pdPASS)
	{
//		DebugStr("\n send failed: event to GUI task");
		xQueueReset(guiQueue);
		rtn = false;
	}
	return rtn;
}

#if defined(__cplusplus)
}
#endif


