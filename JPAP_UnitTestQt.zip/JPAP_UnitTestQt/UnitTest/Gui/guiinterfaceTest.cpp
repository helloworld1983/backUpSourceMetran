/*
 * guiinterfaceTest.cpp
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#include <guiinterface.h>
#include "stdafx.h"
#include "Fixture.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

namespace EmbeddedCUnitTest {


class GuiInterfaceTest : public TestFixture
{
public:
	GuiInterfaceTest() : TestFixture(new ModuleMock) {}
};



TEST_F(GuiInterfaceTest, GuiTaskSendEvent)
{
	for(int i = eGuiFirstEventId; i <= eGuiUpdateMotorVersion; i++)
	{
		EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1).WillOnce(Return(pdPASS));

		EXPECT_EQ(GuiTaskSendEvent(i,0),true);
	}
	/*******************************/
	for(int i = eGuiFirstEventId; i <= eGuiUpdateMotorVersion; i++)
	{
		EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1).WillOnce(Return(pdFAIL));
		EXPECT_CALL(*_queueLib,xQueueReset(_)).Times(1);

		EXPECT_EQ(GuiTaskSendEvent(i,0),false);
	}
}

}



