/*
 * guitask.cpp
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */
#include <stdbool.h>
#include "guitask.h"

#include <guiinterface.h>
#include <setting.h>
#include "queue.h"
#include "guiglobal.h"
#include "MainScreenMocks.h"
#include "PWMLib.h"
#include "SettingMocks.h"
#include "WDTLib.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

static xQueueHandle guiQueue;

//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: GuiProcessEvent()
//
//    Processing:		This operation check Gui event from Gui queue and process them
//
//    Input Parameters: None
//
//    Output Parameters:None
//
//    Return Values:    None
//
//    Pre-Conditions:   None
//
//    Miscellaneous:    None
//
//    Requirements:
//
//******************************************************************************
void GuiProcessEvent()
{
#define MAX__GUI_EVENT_HANDLE	4
	GuiEventStruct guiEvent;
	//handle maximum 8 event for a time
	for(int i = 0; i < MAX__GUI_EVENT_HANDLE; i++)
	{
		//wait for queue event
		if(xQueueReceive(guiQueue, &guiEvent, 0) == pdPASS)		//wait 0 tick (do not wait)
		{
			MainScreenHandleEventMocks(&guiEvent);//MainScreenHandleEvent(guiEvent);
		}
		else
		{
			vTaskDelay(10);
			break;
		}
	}
}

void FuncGuiTask(void *pvParameters)
{
	//show start up screen
	StartupScreenShowMocks();//	StartupScreenShow();
	//restore LCD brightness
	PWMSetDutyMocks((uint8_t)ePWMLCDBLId, (unsigned int)SettingGetMocks(eBrightnessSettingId));//PWMSetDuty(ePWMLCDBLId, SettingGet(eBrightnessSettingId));
	//start watch dog
	WWDT_CmdMocks(1);//	WWDT_Cmd(ENABLE);

//	while(1)
	{
		//process event on GUi queue
		GuiProcessEvent();
		//run Window manager
		//		WM_Exec();
		//feed Watch dog
		WatchDogFeedMocks();//		WatchDogFeed();
	}
}

#if defined(__cplusplus)
}
#endif


