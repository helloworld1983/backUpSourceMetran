/*
 * guitask.h
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_GUI_GUITASK_H_
#define UNITTEST_GUI_GUITASK_H_



#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//function to process GUI event
void GuiProcessEvent();
void FuncGuiTask(void *pvParameters);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_GUITASK_H_ */
