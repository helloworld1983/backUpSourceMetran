/*
 * guitaskTest.cpp
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */


#include "stdafx.h"
#include "Fixture.h"
#include "guitask.h"

#include <setting.h>

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

namespace EmbeddedCUnitTest {


class GuiTaskTest : public TestFixture
{
public:
	GuiTaskTest() : TestFixture(new ModuleMock) {}
};



TEST_F(GuiTaskTest, GuiProcessEvent)
{
	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,_)).Times(4).WillOnce(Return(pdPASS)).WillOnce(Return(pdPASS))
							.WillOnce(Return(pdPASS)).WillOnce(Return(pdPASS));
	EXPECT_CALL(*_MainScreenLib,MainScreenHandleEventMocks(_)).Times(4);

	GuiProcessEvent();

	/********************/

	EXPECT_CALL(*_queueLib,xQueueReceive(_,_,_)).Times(1).WillOnce(Return(pdFAIL));
	EXPECT_CALL(*_queueLib,vTaskDelay(10)).Times(1);

	GuiProcessEvent();
}

TEST_F(GuiTaskTest, FuncGuiTask)
{
	for(int  i = 0; i < 1000; i++)
	{
		EXPECT_CALL(*_MainScreenLib,StartupScreenShowMocks()).Times(1);
		EXPECT_CALL(*_PWMLib,PWMSetDutyMocks(_,_)).Times(1);
		EXPECT_CALL(*_settingLib,SettingGetMocks(eBrightnessSettingId)).Times(1).WillOnce(Return(100));
		EXPECT_CALL(*_WWDTLib,WWDT_CmdMocks(1)).Times(1);

		EXPECT_CALL(*_queueLib,xQueueReceive(_,_,_)).Times(4).WillOnce(Return(pdPASS)).WillOnce(Return(pdPASS))
								.WillOnce(Return(pdPASS)).WillOnce(Return(pdPASS));
		EXPECT_CALL(*_MainScreenLib,MainScreenHandleEventMocks(_)).Times(4);

		EXPECT_CALL(*_WWDTLib,WatchDogFeedMocks()).Times(1);

		FuncGuiTask(nullptr);
	}
	/*********************************/
	for(int  i = 0; i < 1000; i++)
	{
		EXPECT_CALL(*_MainScreenLib,StartupScreenShowMocks()).Times(1);
		EXPECT_CALL(*_PWMLib,PWMSetDutyMocks(_,_)).Times(1);
		EXPECT_CALL(*_settingLib,SettingGetMocks(eBrightnessSettingId)).Times(1).WillOnce(Return(100));
		EXPECT_CALL(*_WWDTLib,WWDT_CmdMocks(1)).Times(1);

		EXPECT_CALL(*_queueLib,xQueueReceive(_,_,_)).Times(1).WillOnce(Return(pdFAIL));
		EXPECT_CALL(*_queueLib,vTaskDelay(10)).Times(1);

		EXPECT_CALL(*_WWDTLib,WatchDogFeedMocks()).Times(1);

		FuncGuiTask(nullptr);
	}
}

}


