/*
 * historyscreen.cpp
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */
#include "historyscreen.h"

#include <guiinterface.h>
#include <setting.h>
#include "stdbool.h"
//#include "titlebar.h"
//#include "mode.h"
//#include "operationscreen.h"
//#include "systemlog.h"
//#include "fonts.h"
#include "string.h"
//#include "debuguart.h"
//#include "stringtools.h"
#include "guidefine.h"
//#include "logtable.h"
//#include "verticalslider.h"
#include "guiglobal.h"
#include "LogTableMocks.h"
#include "SliderMocks.h"
#include "TitleBarMock.h"
#include "stdio.h"

#define TABLE_NUM_ROWS			6
#define BUFFER_DATA_LENGTH		16
#define HTR_BK_COLOR			COLOR_DARK_BLUE			//GUI_WHITE
#define NUMRECORD_MAX			244

#define EEPROM_NUM_PAGE					63
#define EEPROM_PAGE_SIZE				64

int numRecords;
unsigned char currentRow = 0;
unsigned char numOrder = 1;
unsigned char currentPage;
unsigned char currentByte;
unsigned char nextPage;
unsigned char prevPage;
E_HtrSettingState currentState;
int testHtrDialogCallback = 0;
unsigned char isPrevKey;
unsigned char testisPrevKey;
unsigned char data[BUFFER_DATA_LENGTH];
char currentPageData[EEPROM_PAGE_SIZE];
char prevPageData[EEPROM_PAGE_SIZE];
char nextPageData[EEPROM_PAGE_SIZE];

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//typedef enum
//{
//	eLeftKey,
//	eRightKey,
//	eEnterKey
//}E_PrevKey;

//void HtrDialogCallback(WM_MESSAGE * pMsg);
//void HtrEnterKeyHandle();
//void HtrKeyEventHandle();
//void HtrLeftKeyEventHandle();
//void HtrRightKeyEventHandle();
//void HtrGetNextPocket();
//void HtrGetPrevPocket();
//void HtrIncCurrentPage();
//void HtrDecCurrentPage();

//history screen
//WM_HWIN historyScreen;
//main window instance
//extern WM_HWIN mainWindow;
//title bar
//static BUTTON_Handle htrTitleBar;
//slider
//static SLIDER_Handle htrVerticalSlider;
//current state
//static E_HtrSettingState currentState;
//define timer
//static WM_HTIMER pressTimer;
//define current row
//static unsigned char currentRow = 0;
//define page to read
//static unsigned char currentPage;
//static unsigned char readPage;
//static unsigned char nextPage;
//static unsigned char prevPage;
//define byte to read
//static unsigned char currentByte;
//static int numRecords;

//unsigned char data[BUFFER_DATA_LENGTH];

//static unsigned char numOrder = 1;
//static unsigned char isPrevKey;

//static char currentPageData[EEPROM_PAGE_SIZE];
//static char prevPageData[EEPROM_PAGE_SIZE];
//static char nextPageData[EEPROM_PAGE_SIZE];
//static unsigned char testPage[64];

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: HistoryScrInit(void)
//
//    Processing:
//		The function creates history screen and initializes its items
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void HistoryScrInit(void)
{
	//initialize patient setting screen
	//	historyScreen = WM_CreateWindowAsChild(SETTING_SCREEN_X, SETTING_SCREEN_Y, SETTING_SCREEN_LENGTH, SETTING_SCREEN_HEIGHT, mainWindow, WM_CF_HIDE | WM_CF_MEMDEV | WM_CF_LATE_CLIP, HtrDialogCallback, 0);
	//	//initialize TITLE button
	//	htrTitleBar = BUTTON_CreateEx(TITLE_BAR_X, TITLE_BAR_Y, TITLE_BAR_LENGTH, TITLE_BAR_HEIGHT, historyScreen, WM_CF_SHOW, 0, eHtrTitleBarId);
	//	WM_SetCallback(htrTitleBar, TitleBarCallback);
	TitleBarSetStatusMocks(nullptr, ePoint);//TitleBarSetStatus(htrTitleBar, ePoint);
	//	WM_Paint(htrTitleBar);
	//	//init vertical slider
	//	htrVerticalSlider = SLIDER_CreateEx(SLIDER_BAR_X, SLIDER_BAR_Y, SLIDER_BAR_LENGTH, SLIDER_BAR_HEIGHT, historyScreen, WM_CF_SHOW, SLIDER_CF_VERTICAL/*WM_CF_MEMDEV*/, eHtrVertSliderId);
	SliderSetMaxMocks(nullptr, SysLogGetNumRecordsMocks() + 1);//SliderSetMax(htrVerticalSlider, SysLogGetNumRecords() + 1);
	//	WM_SetCallback(htrVerticalSlider, VerSliderCallback);
	//initialize timer
	//	pressTimer = WM_CreateTimer(historyScreen, 1, PRESS_TIMER_PERIOD, 0);
	//initialize list view
	LogTableInitMocks();//LogTableInit();
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: HtrSetFocus()
//
//    Processing:
//		The function focus the history screen
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void HistoryScrReload()
{
	//clear table
	for(int i = 0; i < TABLE_NUM_ROWS; i++)
	{
		LogTableDeleteLastRowMocks();//LogTableDeleteLastRow();
	}

	LogTableReloadMocks();//LogTableReload();

	numRecords = SysLogGetNumRecordsMocks();//SysLogGetNumRecords();	//get num records
	if(numRecords == 0)
		return;

	currentRow = 0;

	//refill the table
	numOrder = 1;						//set No. = 1
	currentByte = SysLogGetEndByteMocks();//SysLogGetEndByte();	//get page offset
	currentPage = SysLogGetEndPageMocks();//SysLogGetEndPage();	//get page
	prevPage = currentPage-1;			//set previous page

	if((prevPage < 2)&&(numRecords >= NUMRECORD_MAX))
		prevPage = EEPROM_NUM_PAGE - 1;

	nextPage = currentPage+1;			//set next page
	currentState = eHtrFirstRowState;	//set current state
	SysLogReadMocks(currentPage, &currentPageData[0]);//SysLogRead(currentPage, &currentPageData[0]);	//read data of current page
	SysLogReadMocks(prevPage, &prevPageData[0]);//SysLogRead(prevPage, &prevPageData[0]);			//read data of previous page
	isPrevKey = eRightKey;				//the previous key is left key

	//display all rows of table
	if(numRecords < TABLE_NUM_ROWS)
	{
		for(int i = numRecords - 1; i >= 0; i--)
		{
			HtrGetPrevPocket();	//get previous data
			LogTableAddRowMocks(numOrder, data, currentRow++);//LogTableAddRow(numOrder, data, currentRow++);	//display on table
			numOrder++;	//increase No.
		}
	}
	else
	{
		for(int i = TABLE_NUM_ROWS - 1; i >= 0; i--)
		{
			HtrGetPrevPocket();	//get previous data
			LogTableAddRowMocks(numOrder, data, currentRow++);//LogTableAddRow(numOrder, data, currentRow++);	//add row
			numOrder++;	//increase No.
		}
	}

	currentByte = SysLogGetEndByteMocks();//SysLogGetEndByte();	//get page offset
	currentPage = SysLogGetEndPageMocks();//SysLogGetEndPage();	//get page
	prevPage = currentPage-1;			//set previous page
	nextPage = currentPage+1;			//set next page
	if((prevPage < 2)&&(numRecords >= NUMRECORD_MAX))
		prevPage = EEPROM_NUM_PAGE - 1;
	currentState = eHtrFirstRowState;	//set current state
	SysLogReadMocks(currentPage, &currentPageData[0]);//SysLogRead(currentPage, &currentPageData[0]);	//get data of current page
	SysLogReadMocks(prevPage, &prevPageData[0]);//SysLogRead(prevPage, &prevPageData[0]);			//get data of previous page
	numOrder = 1;		//reset No.
	LogTableSetSelMocks(0);//LogTableSetSel(0);	//select the first row
	//set parameters for slider
	SliderSetMaxMocks(nullptr,numRecords - 1);//SliderSetMax(htrVerticalSlider, numRecords - 1);
	SliderUpdateMocks(nullptr, numOrder - 1);//SliderUpdate(htrVerticalSlider, numOrder - 1);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: HtrDialogCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		The callback function of parent dialog (patient setting)
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void HtrDialogCallback(WM_MESSAGE * pMsg)
{
	//	GUI_RECT Rect;
	switch (pMsg->MsgId) {
	case WM_PAINT:
		//		WM_GetInsideRect(&Rect);
		//		GUI_SetBkColor(HTR_BK_COLOR);
		//		GUI_ClearRectEx(&Rect);
		testHtrDialogCallback = WM_PAINT;
		break;
	case WM_KEY:
	{
		switch (((WM_KEY_INFO*)(pMsg->Data.p))->Key) {
		case GUI_KEY_RIGHT:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
			{
				testHtrDialogCallback = 1;
				HtrRightKeyEventHandle();			//right key event handle
			}
			break;
		case GUI_KEY_LEFT:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
			{
				testHtrDialogCallback = 2;
				HtrLeftKeyEventHandle();			//left key event handle
			}
			break;
		case GUI_KEY_HOME:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
			{
				testHtrDialogCallback = 3;
				HtrEnterKeyHandle();
			}
			break;
		}
	}
	break;
	default:
		//		WM_DefaultProc(pMsg);
		testHtrDialogCallback = 5;
		break;
	}
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: HtrEnterKeyHandle()
//
//    Processing:
//		The function operates when a enter key is received
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void HtrEnterKeyHandle()
{
	//send event to change to operation screen
	GuiTaskSendEvent(eGuiChangeToOperScreenId, 0);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: HtrLeftKeyEventHandle()
//
//    Processing:
//		The function operates when a right key is received
//
//    Input Parameters:
//		WM_HWIN hWin
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void HtrLeftKeyEventHandle()
{
	numOrder++;	//increase No.
	//return if No. > number records
	if(numOrder > numRecords)
	{
		numOrder = numRecords;
		return;
	}
	if(isPrevKey == eRightKey)
	{
		testisPrevKey = eRightKey;
		HtrGetPrevPocket();	//get previous data
	}
	isPrevKey = eLeftKey;	//set the previous key be left key

	HtrGetPrevPocket();	//get previous pocket data

	switch (currentState) {
	case eHtrFirstRowState:
		currentState = eHtrDialogState;	//change state
		LogTableSetSelMocks(1);//LogTableSetSel(1);
		break;
	case eHtrDialogState:
		LogTableIncSelMocks();//LogTableIncSel();				//increase selected row
		if(LogTableGetSelMoc() == TABLE_NUM_ROWS - 1)//if(LogTableGetSel() == TABLE_NUM_ROWS - 1)	//in case the selected is the last row of table
			currentState = eHtrLastRowState;		//change state
		break;
	case eHtrLastRowState:
		LogTableAddRowMocks(numOrder, data, currentRow++);//LogTableAddRow(numOrder, data, currentRow++);	//add row at the last row of table
		LogTableDeleteFirstRowMocks();//LogTableDeleteFirstRow();						//delete the first row
		LogTableSetSelMocks(TABLE_NUM_ROWS - 1);//LogTableSetSel(TABLE_NUM_ROWS - 1);				//select the last row
		break;
	default:
		break;
	}
	SliderUpdateMocks(nullptr, numOrder - 1);//SliderUpdate(htrVerticalSlider, numOrder - 1);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: HtrRightKeyEventHandle()
//
//    Processing:
//		The function operates when a left key is received
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void HtrRightKeyEventHandle()
{
	if(numOrder <= 1)
	{
		numOrder = 1;
		return;
	}
	numOrder--;	//decrease No.

	if(isPrevKey == eLeftKey)			//detect changing the key press
	{
		testisPrevKey = eLeftKey;
		HtrGetNextPocket();	//get next pocket data
	}

	HtrGetNextPocket();	//get next pocket data

	isPrevKey = eRightKey;			//set the previous key is right key

	switch (currentState) {
	case eHtrFirstRowState:
		LogTableAddRowMocks(numOrder, data, 0);//LogTableAddRow(numOrder, data, 0);	//add the first row
		LogTableDeleteLastRowMocks();//LogTableDeleteLastRow();			//delete the last row
		LogTableSetSelMocks(0);//LogTableSetSel(0);					//select the first row
		break;
	case eHtrDialogState:
		LogTableDecSelMocks();//LogTableDecSel();			//decrease the selected
		if(LogTableGetSelMoc() == 0)//if(LogTableGetSel() == 0)	//if the first row is selected, change current state
			currentState = eHtrFirstRowState;
		break;
	case eHtrLastRowState:
		currentState = eHtrDialogState;	//change current state
		LogTableDecSelMocks();//LogTableDecSel();				//decrease the selected
		break;
	default:
		break;
	}
	SliderUpdateMocks(nullptr, numOrder - 1);//SliderUpdate(htrVerticalSlider, numOrder - 1);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: HtrGetNextPocket(u)
//
//    Processing:
//		This operation get next data with address
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void HtrGetNextPocket()
{
	int dataLength;
	int startLoop = currentByte;
	//detect header and handle
	for(int i = startLoop; i <= EEPROM_PAGE_SIZE-1; i++)
	{
		if((currentPageData[i] == (char)0xAA)&&(i <= EEPROM_PAGE_SIZE-BUFFER_DATA_LENGTH))//detect header
		{
			data[0] = currentPageData[i+1];			//get id
			dataLength = currentPageData[i+2];		//get data length

			if(dataLength >= BUFFER_DATA_LENGTH)	//get wrong data length
				break;
			for(int j = 0; j < dataLength; j++)
			{
				if((i+3+j) < EEPROM_PAGE_SIZE)
					data[j+1] = currentPageData[i+3+j];
			}
			currentByte = i + 3 + dataLength;	//set new current byte
			if(currentByte == EEPROM_PAGE_SIZE)
			{
				HtrIncCurrentPage();
				currentByte = 0;
			}
			break;
		}
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: HtrGetPrevPocket()
//
//    Processing:
//		This operation get previous data with address
//
//    Input Parameters:
//		unsigned char byte: page offset of data
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void HtrGetPrevPocket()
{
	unsigned char dataLength;

	if(currentByte == 0)
	{
		currentByte = EEPROM_PAGE_SIZE;
		HtrDecCurrentPage();
	}
	int startLoop = currentByte - 1;

	for(int i = startLoop; i >= 0; i--)
	{
		if((currentPageData[i] == 0xAA)&&(i <= EEPROM_PAGE_SIZE-BUFFER_DATA_LENGTH))//detect header
		{
			currentByte = i;					//set new current byte
			data[0] = currentPageData[i+1];		//get id
			dataLength = currentPageData[i+2];	//get data length
			if(dataLength >= BUFFER_DATA_LENGTH)	//get wrong data length
				break;
			//get data
			for(int j = i; j < i + dataLength; j++)
				data[j-i+1] = currentPageData[j+3];
			break;
		}
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: HtrIncCurrentPage()
//
//    Processing:
//		This operation increase current page
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void HtrIncCurrentPage()
{
	prevPage++;
	if(prevPage > (EEPROM_NUM_PAGE-1))
		prevPage = 2;

	currentPage++;
	if(currentPage > (EEPROM_NUM_PAGE-1))
		currentPage = 2;

	nextPage++;
	if(nextPage > (EEPROM_NUM_PAGE-1))
		nextPage = 2;

	for(int i = 0; i < EEPROM_PAGE_SIZE; i++)
	{
		prevPageData[i] = currentPageData[i];
		currentPageData[i] = nextPageData[i];
	}
	//read data of next page
	SysLogReadMocks(nextPage, &nextPageData[0]);//SysLogRead(nextPage, &nextPageData[0]);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: HtrDecCurrentPage()
//
//    Processing:
//		This operation decrease current page
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void HtrDecCurrentPage()
{
	nextPage--;		//decrease next page
	if((nextPage < 2)&&(numRecords >= NUMRECORD_MAX))
		nextPage = EEPROM_NUM_PAGE -1;

	currentPage--;	//decrease current page
	if((currentPage < 2)&&(numRecords >= NUMRECORD_MAX))
		currentPage = EEPROM_NUM_PAGE - 1;

	prevPage--;		//decrease previous page
	if((prevPage < 2)&&(numRecords >= NUMRECORD_MAX))
		prevPage = EEPROM_NUM_PAGE - 1;

	for(int i = 0; i < EEPROM_PAGE_SIZE; i++)
	{
		nextPageData[i] = currentPageData[i];
		currentPageData[i] = prevPageData[i];
	}
	//read data of next page
	SysLogReadMocks(prevPage, &prevPageData[0]);//SysLogRead(prevPage, &prevPageData[0]);
}

#if defined(__cplusplus)
}
#endif
