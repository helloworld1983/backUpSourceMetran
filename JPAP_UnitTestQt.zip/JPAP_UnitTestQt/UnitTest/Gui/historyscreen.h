/*
 * historyscreen.h
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_GUI_HISTORYSCREEN_H_
#define UNITTEST_GUI_HISTORYSCREEN_H_

#include "WM.h"

typedef enum
{
	eHtrTitleState,
	eHtrFirstRowState,
	eHtrDialogState,
	eHtrLastRowState
} E_HtrSettingState;

typedef enum
{
	eLeftKey,
	eRightKey,
	eEnterKey
}E_PrevKey;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//extern WM_HWIN historyScreen;

void HistoryScrInit(void);
void HistoryScrReload();
void HtrDialogCallback(WM_MESSAGE * pMsg);
void HtrEnterKeyHandle();
void HtrKeyEventHandle();
void HtrLeftKeyEventHandle();
void HtrRightKeyEventHandle();
void HtrGetNextPocket();
void HtrGetPrevPocket();
void HtrIncCurrentPage();
void HtrDecCurrentPage();

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_HISTORYSCREEN_H_ */
