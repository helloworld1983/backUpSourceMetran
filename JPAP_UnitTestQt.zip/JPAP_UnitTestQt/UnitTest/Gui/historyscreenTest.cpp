/*
 * historyscreenTest.cpp
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */
#include "stdafx.h"
#include "Fixture.h"
#include "historyscreen.h"
#include "WM.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern int numRecords;
extern unsigned char currentRow;
extern unsigned char numOrder;
extern unsigned char currentPage;
extern unsigned char currentByte;
extern unsigned char nextPage;
extern unsigned char prevPage;
extern E_HtrSettingState currentState;
extern int testHtrDialogCallback;
extern unsigned char isPrevKey;
extern unsigned char testisPrevKey;
//extern unsigned char data[];
extern char currentPageData[];
//extern char prevPageData[];
//extern char nextPageData[];

namespace EmbeddedCUnitTest {


class HistoryScreenTest : public TestFixture
{
public:
	HistoryScreenTest() : TestFixture(new ModuleMock) {}
};

TEST_F(HistoryScreenTest, HistoryScrInit)
{
	EXPECT_CALL(*_TitleBarLib,TitleBarSetStatusMocks(_,_)).Times(1);
	EXPECT_CALL(*_SliderLib,SliderSetMaxMocks(_,_)).Times(1);
	EXPECT_CALL(*_LogTableLib,LogTableInitMocks()).Times(1);
	HistoryScrInit();

}

TEST_F(HistoryScreenTest, HistoryScrReload)
{
	EXPECT_CALL(*_LogTableLib,LogTableDeleteLastRowMocks()).Times(6);
	EXPECT_CALL(*_LogTableLib,LogTableReloadMocks()).Times(1);
	EXPECT_CALL(*_LogTableLib,SysLogGetNumRecordsMocks()).Times(1).WillOnce(Return(0));

	HistoryScrReload();

	EXPECT_EQ(numRecords, 0);

	/****************************************************************************/
	EXPECT_CALL(*_LogTableLib,LogTableDeleteLastRowMocks()).Times(6);
	EXPECT_CALL(*_LogTableLib,LogTableReloadMocks()).Times(1);
	EXPECT_CALL(*_LogTableLib,SysLogGetNumRecordsMocks()).Times(1).WillOnce(Return(1));
	EXPECT_CALL(*_LogTableLib,SysLogGetEndByteMocks()).Times(2).WillOnce(Return(1)).WillOnce(Return(1));
	EXPECT_CALL(*_LogTableLib,SysLogGetEndPageMocks()).Times(2).WillOnce(Return(1)).WillOnce(Return(1));
	EXPECT_CALL(*_LogTableLib,LogTableAddRowMocks(_,_,_)).Times(1);
	EXPECT_CALL(*_LogTableLib,SysLogReadMocks(_,_)).Times(4);
	EXPECT_CALL(*_LogTableLib,LogTableSetSelMocks(0)).Times(1);
	EXPECT_CALL(*_SliderLib,SliderSetMaxMocks(_,_)).Times(1);
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,0)).Times(1);

	HistoryScrReload();

	EXPECT_EQ(currentRow, 1);
	EXPECT_EQ(numOrder, 1);
	EXPECT_EQ(currentByte, 1);
	EXPECT_EQ(currentPage, 1);
	EXPECT_EQ(prevPage, 0);
	EXPECT_EQ(nextPage, 2);
	EXPECT_EQ(currentState, eHtrFirstRowState);
}

TEST_F(HistoryScreenTest, HtrDialogCallback)
{
	WM_MESSAGE *pMsg = new WM_MESSAGE;
	pMsg->MsgId = WM_PAINT;
	HtrDialogCallback(pMsg);

	EXPECT_EQ(testHtrDialogCallback, WM_PAINT);

	/************************************************/
	WM_KEY_INFO *keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_RIGHT;
	keyData->PressedCnt = 1;

	pMsg->MsgId = WM_KEY;
	pMsg->Data.p = keyData;

	HtrDialogCallback(pMsg);
	EXPECT_EQ(testHtrDialogCallback, 1);

	/************************************************/
	keyData->Key = GUI_KEY_LEFT;
	HtrDialogCallback(pMsg);
	EXPECT_EQ(testHtrDialogCallback, 2);

	/************************************************/
	keyData->Key = GUI_KEY_HOME;
	HtrDialogCallback(pMsg);
	EXPECT_EQ(testHtrDialogCallback, 3);


	/************************************************/
	pMsg->MsgId = WM_KEY + WM_PAINT;
	HtrDialogCallback(pMsg);
	EXPECT_EQ(testHtrDialogCallback, 5);
}

TEST_F(HistoryScreenTest, HtrEnterKeyHandle)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(2).WillOnce(Return(pdPASS)).WillOnce(Return(pdFAIL));
	EXPECT_CALL(*_queueLib,xQueueReset(_)).Times(1);

	HtrEnterKeyHandle();
	HtrEnterKeyHandle();
}

TEST_F(HistoryScreenTest, HtrLeftKeyEventHandle)
{
	HtrLeftKeyEventHandle();
	EXPECT_EQ(numOrder,numRecords);

	/***********************************/
	numRecords = 10;
	isPrevKey = eRightKey;
	currentState = eHtrFirstRowState;

	EXPECT_CALL(*_LogTableLib,LogTableSetSelMocks(_)).Times(1);
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,_)).Times(1);

	HtrLeftKeyEventHandle();

	EXPECT_EQ(testisPrevKey,eRightKey);
	EXPECT_EQ(isPrevKey,eLeftKey);

	/***********************************/
	numRecords = 10;
	isPrevKey = eRightKey;
	currentState = eHtrDialogState;

	EXPECT_CALL(*_LogTableLib,LogTableIncSelMocks()).Times(1);
	EXPECT_CALL(*_LogTableLib,LogTableGetSelMoc()).Times(1).WillOnce(Return(8));
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,_)).Times(1);

	HtrLeftKeyEventHandle();

	EXPECT_EQ(testisPrevKey,eRightKey);
	EXPECT_EQ(isPrevKey,eLeftKey);
	EXPECT_EQ(currentState,eHtrDialogState);

	/***********************************/
	numRecords = 10;
	isPrevKey = eRightKey;
	currentState = eHtrDialogState;

	EXPECT_CALL(*_LogTableLib,LogTableIncSelMocks()).Times(1);
	EXPECT_CALL(*_LogTableLib,LogTableGetSelMoc()).Times(1).WillOnce(Return(5));
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,_)).Times(1);

	HtrLeftKeyEventHandle();

	EXPECT_EQ(testisPrevKey,eRightKey);
	EXPECT_EQ(isPrevKey,eLeftKey);
	EXPECT_EQ(currentState,eHtrLastRowState);

	/***********************************/
	numRecords = 10;
	isPrevKey = eRightKey;
	currentState = eHtrLastRowState;

	EXPECT_CALL(*_LogTableLib,LogTableAddRowMocks(_,_,_)).Times(1);
	EXPECT_CALL(*_LogTableLib,LogTableDeleteFirstRowMocks()).Times(1);
	EXPECT_CALL(*_LogTableLib,LogTableSetSelMocks(5)).Times(1);
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,_)).Times(1);

	HtrLeftKeyEventHandle();

	EXPECT_EQ(testisPrevKey,eRightKey);
	EXPECT_EQ(isPrevKey,eLeftKey);
	EXPECT_EQ(currentState,eHtrLastRowState);
}

TEST_F(HistoryScreenTest, HtrRightKeyEventHandle)
{
	numOrder = 0;
	HtrRightKeyEventHandle();
	EXPECT_EQ(numOrder,1);

	/***********************************/
	numOrder = 5;
	isPrevKey = eLeftKey;
	currentState = eHtrFirstRowState;

	EXPECT_CALL(*_LogTableLib,LogTableAddRowMocks(_,_,0)).Times(1);
	EXPECT_CALL(*_LogTableLib,LogTableDeleteLastRowMocks()).Times(1);
	EXPECT_CALL(*_LogTableLib,LogTableSetSelMocks(0)).Times(1);
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,_)).Times(1);

	HtrRightKeyEventHandle();

	EXPECT_EQ(numOrder,4);
	EXPECT_EQ(testisPrevKey,eLeftKey);
	EXPECT_EQ(isPrevKey,eRightKey);

	/***********************************/
	numOrder = 6;
	isPrevKey = eLeftKey;
	currentState = eHtrDialogState;

	EXPECT_CALL(*_LogTableLib,LogTableDecSelMocks()).Times(1);
	EXPECT_CALL(*_LogTableLib,LogTableGetSelMoc()).Times(1).WillOnce(Return(1));
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,_)).Times(1);

	HtrRightKeyEventHandle();

	EXPECT_EQ(numOrder,5);
	EXPECT_EQ(testisPrevKey,eLeftKey);
	EXPECT_EQ(isPrevKey,eRightKey);

	/***********************************/
	numOrder = 7;
	isPrevKey = eLeftKey;
	currentState = eHtrDialogState;

	EXPECT_CALL(*_LogTableLib,LogTableDecSelMocks()).Times(1);
	EXPECT_CALL(*_LogTableLib,LogTableGetSelMoc()).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,_)).Times(1);

	HtrRightKeyEventHandle();

	EXPECT_EQ(numOrder,6);
	EXPECT_EQ(testisPrevKey,eLeftKey);
	EXPECT_EQ(isPrevKey,eRightKey);
	EXPECT_EQ(currentState,eHtrFirstRowState);

	/***********************************/
	numOrder = 8;
	isPrevKey = eLeftKey;
	currentState = eHtrLastRowState;

	EXPECT_CALL(*_LogTableLib,LogTableDecSelMocks()).Times(1);
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,_)).Times(1);

	HtrRightKeyEventHandle();

	EXPECT_EQ(numOrder,7);
	EXPECT_EQ(testisPrevKey,eLeftKey);
	EXPECT_EQ(isPrevKey,eRightKey);
	EXPECT_EQ(currentState,eHtrDialogState);
}

TEST_F(HistoryScreenTest, HtrGetNextPocket)
{
	for(int i = 0; i < 64; i++)//EEPROM_PAGE_SIZE = 64
	{
		currentPageData[i] = 0xAA;
	}
	HtrGetNextPocket();

	EXPECT_EQ(currentByte,174);
}


TEST_F(HistoryScreenTest, HtrGetPrevPocket)
{
	currentByte = 0;

	HtrGetPrevPocket();

	EXPECT_EQ(currentByte,64);//EEPROM_PAGE_SIZE = 64
}

TEST_F(HistoryScreenTest, HtrIncCurrentPage)
{
	EXPECT_CALL(*_LogTableLib,SysLogReadMocks(_,_)).Times(1);

	prevPage = 63;
	currentPage = 63;
	nextPage = 63;
	HtrIncCurrentPage();

	EXPECT_EQ(prevPage,2);
	EXPECT_EQ(currentPage,2);
	EXPECT_EQ(nextPage,2);
}

TEST_F(HistoryScreenTest, HtrDecCurrentPage)
{
	EXPECT_CALL(*_LogTableLib,SysLogReadMocks(_,_)).Times(1);

	prevPage = 2;
	currentPage = 2;
	nextPage = 2;
	numRecords = 244;
	HtrDecCurrentPage();

	EXPECT_EQ(prevPage,62);
	EXPECT_EQ(currentPage,62);
	EXPECT_EQ(nextPage,62);
}
}



