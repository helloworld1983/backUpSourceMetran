/*
 * loadingscreen.cpp
 *
 *  Created on: Apr 16, 2018
 *      Author: QUOCVIET
 */

#include "loadingscreen.h"

#include <setting.h>

#include "guidefine.h"
#include "guiglobal.h"
#include "strings.h"
#include "SettingMocks.h"

int testLoadingScreenReload = 0;
int testLoadingScreenCallback = 0;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//define parameters of dialog
#define LOADING_SCR_X			100
#define LOADING_SCR_Y			50
#define LOADING_SCR_LENGTH		120
#define LOADING_SCR_HEIGHT		35

//define color
#define LOADING_SCR_BK_COLOR		COLOR_DARK_BLUE
#define LOADING_SCR_BORDER_COLOR	COLOR_ULTRA_LIGHT_BLUE
//#define LOADING_TEXT_COLOR			GUI_ORANGE

//WM_HWIN loadingScreen;
// main window instance
//extern WM_HWIN operationScreen;

//void LoadingScreenCallback(WM_MESSAGE * pMsg);
//loading text
//static TEXT_Handle loadingText;

//static const GUI_FONT* guiFont16[] = { &GUI_FontMeiryo16B_2bpp, &GUI_FontJPAPJPFont16B };


void LoadingScreenReload()
{
//	TEXT_SetFont(loadingText, guiFont16[language]);
//	TEXT_SetText(loadingText, strStarting[language]);
	testLoadingScreenReload = 10;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: LoadingScreenCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		This is callback function of alarm screen
//
//    Input Parameters:
//
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void LoadingScreenCallback(WM_MESSAGE * pMsg) {
//	GUI_RECT Rect;
	switch (pMsg->MsgId) {
	case WM_PAINT:
		//get size: x0, x1, y0, y1
//		WM_GetClientRect(&Rect);
//		GUI_SetPenShape(GUI_PS_ROUND);
//		GUI_SetTextMode(GUI_TM_TRANS);
//
//		//draw background of dialog
//		GUI_SetColor(LOADING_SCR_BK_COLOR);
//		GUI_AA_FillRoundedRect(Rect.x0, Rect.y0 + 10, Rect.x1, Rect.y1, 10);
//
//		//draw border
//		GUI_SetColor(LOADING_SCR_BORDER_COLOR);
//		GUI_AA_DrawRoundedRect(Rect.x0, Rect.y0 + 10, Rect.x1, Rect.y1, 10);
		testLoadingScreenCallback = WM_PAINT;
		break;
	default:
//		WM_DefaultProc(pMsg);
		testLoadingScreenCallback = 100;
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: LoadingPopUpInit(void)
//
//    Processing:
//		The operation initialize the loading popup
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void LoadingScreenInit(void)
{
	language = SettingGetMocks(eLanguageSettingId);//SettingGet(eLanguageSettingId);
	//create reset pop up
//	loadingScreen = WM_CreateWindowAsChild(LOADING_SCR_X, LOADING_SCR_Y, LOADING_SCR_LENGTH, LOADING_SCR_HEIGHT, operationScreen, WM_CF_HASTRANS | WM_CF_HIDE, LoadingScreenCallback, 0);
	//init text
//	loadingText = TEXT_CreateEx(0, 10, LOADING_SCR_LENGTH, LOADING_SCR_HEIGHT, loadingScreen, WM_CF_SHOW, TEXT_CF_HCENTER/*WM_CF_MEMDEV*/, GUI_ID_TEXT0, "");
//	TEXT_SetFont(loadingText, guiFont16[language]);
//	TEXT_SetTextColor(loadingText, LOADING_TEXT_COLOR);
}


#if defined(__cplusplus)
}
#endif

