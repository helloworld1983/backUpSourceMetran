/*
 * loadingscreen.h
 *
 *  Created on: Apr 16, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_GUI_LOADINGSCREEN_H_
#define UNITTEST_GUI_LOADINGSCREEN_H_

#include "WM.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void LoadingScreenCallback(WM_MESSAGE * pMsg);
void LoadingScreenInit();
void LoadingScreenReload();

//extern WM_HWIN loadingScreen;

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_LOADINGSCREEN_H_ */
