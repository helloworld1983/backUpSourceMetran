/*
 * loadingscreenTest.cpp
 *
 *  Created on: Apr 16, 2018
 *      Author: QUOCVIET
 */

#include "stdafx.h"
#include "Fixture.h"
#include "loadingscreen.h"

#include <setting.h>

#include "WM.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern int testLoadingScreenReload;
extern int testLoadingScreenCallback;

namespace EmbeddedCUnitTest {

class LoadingScreenTest : public TestFixture
{
public:
	LoadingScreenTest() : TestFixture(new ModuleMock) {}
};



TEST_F(LoadingScreenTest, LoadingScreenReload)
{
	LoadingScreenReload();

	EXPECT_EQ(testLoadingScreenReload, 10);

}

TEST_F(LoadingScreenTest, LoadingScreenCallback)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	LoadingScreenCallback(&pMsg); // @suppress("Invalid arguments")
	EXPECT_EQ(testLoadingScreenCallback, WM_PAINT);

	/*********************************************************/
	pMsg.MsgId = WM_PAINT + 100;
	LoadingScreenCallback(&pMsg); // @suppress("Invalid arguments")
	EXPECT_EQ(testLoadingScreenCallback, 100);

}

TEST_F(LoadingScreenTest, LoadingScreenInit)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eLanguageSettingId)).Times(1).WillOnce(Return(eEnglish));
	LoadingScreenInit();
}

}



