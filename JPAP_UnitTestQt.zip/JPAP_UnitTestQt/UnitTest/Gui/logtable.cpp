/*
 * logtable.cpp
 *
 *  Created on: Apr 16, 2018
 *      Author: QUOCVIET
 */

#include "logtable.h"

#include <event.h>
#include <setting.h>
#include <systeminterface.h>
#include "string.h"
//#include "fonts.h"
#include "guidefine.h"
#include "strings.h"
#include "alarminterface.h"
#include "guiglobal.h"
#include "WString.h"

int testLogTableInit = 0;
unsigned char id = 0;
unsigned char valBeforeDot = 0;
unsigned char valAfterDot = 0;
int testLogTableIncSel = 0;
int testLogTableDeleteFirstRow = 0;
int testLogTableDeleteLastRow = 0;
int testLogTableDecSel = 0;
int testcbHeaderView = 0;
int testLogTableSetSel = 0;
int testLogTableReload = 0;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif
#define LOGTABLE_X 						0
#define LOGTABLE_Y						32
#define LOGTABLE_LENGTH					300
#define LOGTABLE_HEIGHT					160
#define LOGTABLE_FIRST_COLUMN_LENGTH	30
#define LOGTABLE_SECOND_COLUMN_LENGTH	120
#define LOGTABLE_THIRST_COLUMN_LENGTH	150
#define LOGTABLE_HEADER_HEIGHT			25
#define LOGTABLE_ROW_HEIGHT				21

#define LOGTABLE_SELECTED_COLOR			COLOR_LIGHT_ORANGE
//#define LOGTABLE_UNSELECTED_COLOR		GUI_WHITE		//COLOR_ULTRA_LIGHT_BLUE
#define LOGTABLE_BK_SELECTED_COLOR		COLOR_DARK_BLUE		//GUI_WHITE
#define LOGTABLE_BK_UNSELECTED_COLOR	COLOR_DARK_BLUE		//GUI_WHITE
#define LOGTABLE_HEADER_NAME_COLOR		GUI_WHITE
#define LOGTABLE_HEADER_BK_COLOR		SETTING_EXPAND_BK_COLOR
#define LOGNAME_LENGTH					40

//void cbHeaderView(WM_MESSAGE *pMsg);

//extern WM_HWIN historyScreen;
//LISTVIEW_Handle logTable;
//static HEADER_Handle headerView;

//static const GUI_FONT* guiFont12[] = { &GUI_FontLogFont12, &GUI_FontJPAPJPFont12B };	//font 12
//static const GUI_FONT* guiFont14[] = { &GUI_FontLogFont14, &GUI_FontJPAPJPFont14B };	//font 14
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: LogTableInit(void)
//
//    Processing:
//		The function creates log table and initializes its item
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void LogTableInit(void)
{
	//	logTable = LISTVIEW_Create(LOGTABLE_X, LOGTABLE_Y, LOGTABLE_LENGTH, LOGTABLE_HEIGHT, historyScreen, GUI_ID_LISTVIEW0, WM_CF_SHOW, /*WM_CF_MEMDEV*/0);
	//add No. column
	//	LISTVIEW_AddColumn(logTable, LOGTABLE_FIRST_COLUMN_LENGTH, strNumOrder, GUI_TA_CENTER);
	//add date time column
	//	LISTVIEW_AddColumn(logTable, LOGTABLE_SECOND_COLUMN_LENGTH, strTime[language], GUI_TA_CENTER);
	//add log name column
	//	LISTVIEW_AddColumn(logTable, LOGTABLE_THIRST_COLUMN_LENGTH, strEvent[language], GUI_TA_LEFT);
	//set font
	//	LISTVIEW_SetFont(logTable, guiFont12[language]);
	//	LISTVIEW_SetTextColor(logTable, LISTVIEW_CI_UNSEL, LOGTABLE_UNSELECTED_COLOR);
	//	LISTVIEW_SetTextColor(logTable, LISTVIEW_CI_SEL, LOGTABLE_SELECTED_COLOR);
	//	LISTVIEW_SetBkColor(logTable, LISTVIEW_CI_UNSEL, LOGTABLE_BK_UNSELECTED_COLOR);
	//	LISTVIEW_SetBkColor(logTable, LISTVIEW_CI_SEL, LOGTABLE_BK_SELECTED_COLOR);
	//	LISTVIEW_SetGridVis(logTable, 1);
	//	LISTVIEW_SetRowHeight(logTable, LOGTABLE_ROW_HEIGHT);
	//	headerView = LISTVIEW_GetHeader(logTable);
	//	LISTVIEW_SetHeaderHeight(logTable, LOGTABLE_HEADER_HEIGHT);
	//	WM_SetCallback(headerView, cbHeaderView);

	testLogTableInit = 1000;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: LogTableAddRow(int numericalOrder, unsigned char* data, unsigned char rowIndex)
//
//    Processing:
//		The operation adds 1 row to table
//
//    Input Parameters:
//		int numricalOrder: the No. of table
//
//		unsigned char* data: data to log
//
//		unsigned char rowIndex: the position of new row
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void LogTableAddRow(int numericalOrder, unsigned char* data, unsigned char rowIndex)
{
	char time[20] = {'\0'};		//maximum 20 characters
	char name[LOGNAME_LENGTH] = {'\0'};
	char no[5] = {'\0'};
//	unsigned char valBeforeDot = 0;
//	unsigned char valAfterDot = 0;
	unsigned char length = 0;
	//	unsigned char id = data[0];	//get log id

	//add No.
	if(numericalOrder < 10)
		StrToolItoA(numericalOrder, &no[0], 1);
	else if(numericalOrder < 100)
		StrToolItoA(numericalOrder, &no[0], 2);
	else
		StrToolItoA(numericalOrder, &no[0], 3);

	int timeIndex = 0;

	if(id != eTimeSettingLogId)
	{
		StrToolItoA(data[1], &time[timeIndex], 2);	//add date
		timeIndex += 2;
		time[timeIndex++] = '/';					//insert '/'
		StrToolItoA(data[2], &time[timeIndex], 2);	//add month
		timeIndex += 2;
		time[timeIndex++] = '/';					//insert '/'
		StrToolItoA(data[3], &time[timeIndex], 2);
		timeIndex += 2;
		time[timeIndex++] = ' ';
		StrToolItoA(data[4], &time[timeIndex], 2);	//add hour
		timeIndex += 2;								//ship 2 characters
		time[timeIndex++] = ':';					//insert '/'
		StrToolItoA(data[5], &time[timeIndex], 2);	//add minute
		timeIndex += 2;								//ship 2 characters
		time[timeIndex++] = ':';					//insert '/'
		StrToolItoA(data[6], &time[timeIndex], 2);	//add second
	}
	switch (id) {
	case eSystemLogSettingChangedId:
	{
		switch (data[7]) {
		case eSleepTimerSettingId:
		{
			length = StrAppend(name, strTimeoutLog[language], LOGNAME_LENGTH);
			name[length++] = ':';
			name[length++] = ' ';
			length += StrToolItoA(data[8]+1, &name[length], 1);

			StrAppend(name, strMin[language], LOGNAME_LENGTH);	//add min
		}
		break;
		case ePressUnitSettingId:
		{
			length = StrAppend(name, strChangeUnit[language], LOGNAME_LENGTH);
			name[length++] = ':';
			if(data[8] > 1)
				data[8] = 1;
			StrAppend(name, unitStr[data[8]], LOGNAME_LENGTH);
		}
		break;
		case eFLSettingId:
		{
			length = StrAppend(name, strFL[language], LOGNAME_LENGTH);
			name[length++] = ':';
			if(data[8] > 1)
				data[8] = 1;
			StrAppend(name, strOnOff[data[8]], LOGNAME_LENGTH);
		}
		break;
		case eAutoOFFSettingId:
		{
			length = StrAppend(name, strAutoOff[language], LOGNAME_LENGTH);
			name[length++] = ':';
			if(data[8] > 1)
				data[8] = 1;
			StrAppend(name, strOnOff[data[8]], LOGNAME_LENGTH);
		}
		break;
		case eLanguageSettingId:
		{
			length = StrAppend(name, strLanguge[language], LOGNAME_LENGTH);
			name[length++] = ':';
			if(data[8] == 0)
				StrAppend(name, strJapanese[language], LOGNAME_LENGTH);
			else
				StrAppend(name, strEnglish[language], LOGNAME_LENGTH);
		}
		break;
		case eNsTypeSettingId:
		{
			length = StrAppend(name, strNsType[language], LOGNAME_LENGTH);
			name[length++] = ':';
			if(data[8] == 0)
				StrAppend(name, strType1[language], LOGNAME_LENGTH);
			else
				StrAppend(name, strType2[language], LOGNAME_LENGTH);
		}
		break;
		case eBrightnessSettingId:
		{
			length = StrAppend(name, strBrightness[language], LOGNAME_LENGTH);
			name[length++] = ':';
			length += StrToolItoA(data[8], &name[length], 2);
			name[length++] = '%';
		}
		break;
		case eVentModeSettingId:
		{
			StrAppend(name, strMode[language], LOGNAME_LENGTH);
			if(data[8] > 1)
				data[8] = 1;
			StrAppend(name, strCpapAutoCpap[data[8]], LOGNAME_LENGTH);
		}
		break;
		case eOperPressSettingId:
		{
			length = StrAppend(name, strTreatmenPress[language], LOGNAME_LENGTH);	//add name
			valBeforeDot = (data[8]*5)/10;	//get the value before dot
			valAfterDot = (data[8]*5)%10;		//get the value after dot
			if(valBeforeDot < 10)
				length += StrToolItoA(valBeforeDot, &name[length], 1);	//add value before dot
			else
				length += StrToolItoA(valBeforeDot, &name[length], 2);	//add value before dot
			name[length++] = '.';							//insert '.'
			StrToolItoA(valAfterDot, &name[length++], 1);
			StrAppend(name, unitStr[data[9]], LOGNAME_LENGTH);	//add unit
		}
		break;
		case eDelayPressSettingId:
		{
			length = StrAppend(name, strInitPress[language], LOGNAME_LENGTH);
			valBeforeDot = data[8]/10;
			length += StrToolItoA(valBeforeDot, &name[length], 1);	//add value before dot
			if(data[9] > 1)
				data[9] = 1;
			StrAppend(name, unitStr[data[9]], LOGNAME_LENGTH);	//add unit
		}
		break;
		case eRampTimeSettingId:
		{
			length = StrAppend(name, strRampTime[language], LOGNAME_LENGTH);
			name[length++] = ':';
			name[length++] = ' ';
			if(data[8] < 10)
				length += StrToolItoA(data[8], &name[length], 1);
			else
				length += StrToolItoA(data[8], &name[length], 2);
			StrAppend(name, strMin[language], LOGNAME_LENGTH);	//add min
		}
		break;
		case eExhPressSupportSettingId:
		{
			length = StrAppend(name, strExhSupport[language], LOGNAME_LENGTH);
			StrToolItoA(data[8], &name[length], 1);
		}
		break;
		case eInhPressSupportSettingId:
		{
			length = StrAppend(name, strInhSupport[language], LOGNAME_LENGTH);
			StrToolItoA(data[8], &name[length], 1);
		}
		break;
		case eAutoUpperPressSettingId:
		{
			length = StrAppend(name, strHighPressLimit[language], LOGNAME_LENGTH);	//add name
			valBeforeDot = (data[8]*5)/10;	//get value before dot
			valAfterDot = (data[8]*5)%10;		//get value after dot
			if(valBeforeDot < 10)
				length += StrToolItoA(valBeforeDot, &name[length], 1);	//add value before dot
			else
				length += StrToolItoA(valBeforeDot, &name[length], 2);	//add value before dot
			name[length++] = '.'; //insert '.'
			StrToolItoA(valAfterDot, &name[length++], 1);	//add value after dot
			if(data[9] > 1)
				data[9] = 1;
			StrAppend(name, unitStr[data[9]], LOGNAME_LENGTH);		//add unit
		}
		break;
		case eAutoLowerPressSettingId:
		{
			length = StrAppend(name, strLowPressLimit[language], LOGNAME_LENGTH);
			valBeforeDot = (data[8]*5)/10;
			valAfterDot = (data[8]*5)%10;
			if(valBeforeDot < 10)
				length += StrToolItoA(valBeforeDot, &name[length], 1);	//add value before dot
			else
				length += StrToolItoA(valBeforeDot, &name[length], 2);	//add value before dot
			name[length++] = '.'; //insert '.'
			StrToolItoA(valAfterDot, &name[length++], 1);
			if(data[9] > 1)
				data[9] = 1;
			StrAppend(name, unitStr[data[9]], LOGNAME_LENGTH);	//add unit
		}
		break;
		default:
			break;
		}
	}
	break;
	case eSystemStateLogId:
	{
		switch (data[7]) {
		case eSystemPowerOn:				StrAppend(name, strPowerOn[language], LOGNAME_LENGTH);		break;
		case eSystemPowerOff:				StrAppend(name, strPowerOff[language], LOGNAME_LENGTH);		break;
		case eSystemAutoStart:				StrAppend(name, strAutoStart[language], LOGNAME_LENGTH);	break;
		case eSystemManualStart:			StrAppend(name, strManualStart[language], LOGNAME_LENGTH);	break;
		case eSystemAutoOFF: 				StrAppend(name, strAutoOFF[language], LOGNAME_LENGTH);		break;
		case eSystemStrongDrying: 			StrAppend(name, strStrongDrying[language], LOGNAME_LENGTH);	break;
		case eSystemWeakDrying: 			StrAppend(name, strWeakDrying[language], LOGNAME_LENGTH);	break;
		case eSystemAutoStop:				StrAppend(name, strAutoStop[language], LOGNAME_LENGTH);		break;
		case eSystemCompleteDrying:			StrAppend(name, strCompleteDrying[language], LOGNAME_LENGTH);		break;
		case eSystemManualStop: 			StrAppend(name, strManualStop[language], LOGNAME_LENGTH);	break;
		case eSystemInterruptionDrying:		StrAppend(name, strInterruptionDrying[language], LOGNAME_LENGTH);	break;
		case eSystemReturnOperate:			StrAppend(name, strMaskOnAfterAirLeak[language], LOGNAME_LENGTH);	break;
		//		case eSystemMaskLeak:				StrAppend(name, strMaskLeak[language], LOGNAME_LENGTH);	break;
		default: break;
		}
	}
	break;
	case eSDCardLogId:
	{
		switch (data[7]) {
		case eInsert:	StrAppend(name, strInsertSDCard[language], LOGNAME_LENGTH);	break;
		case eRemove: StrAppend(name, strRemoveSDCard[language], LOGNAME_LENGTH);	break;
		default:	break;
		}
	}
	break;
	case eSettingResetLogId:
		StrAppend(name, strReset[language], LOGNAME_LENGTH);
		break;
	case eClearUsedHoursLogId:
		StrAppend(name, strResetTimeUsing[language], LOGNAME_LENGTH);
		break;
	case eSystemLogExportLogDataEventId:
		StrAppend(name, strExportToCSVFile[language], LOGNAME_LENGTH);
		break;
	case eCalibrateSuccessLogId:
		StrAppend(name, strCircuitCalibration[language], LOGNAME_LENGTH);
		break;
	case eCalibrateFailLogId:
		StrAppend(name, strCalibrationError[language], LOGNAME_LENGTH);
		break;
	case eSystemLogApneaEventId:
	{
		switch (data[7]) {
		case EVENT_MSK_OFF_ID:	StrAppend(name, strMaskOff[language], LOGNAME_LENGTH);			break;
		case EVENT_MSK_ON_ID:	StrAppend(name, strMaskOn[language], LOGNAME_LENGTH);			break;
		case EVENT_S_ID:		StrAppend(name, strSnore[language], LOGNAME_LENGTH);			break;
		case EVENT_H_ID:		StrAppend(name, strHyponea[language], LOGNAME_LENGTH);			break;
		case EVENT_FL_ID:		StrAppend(name, strFl[language], LOGNAME_LENGTH);				break;
		case EVENT_OA_ID:		StrAppend(name, strOa[language], LOGNAME_LENGTH);				break;
		case EVENT_CA_ID:		StrAppend(name, strCa[language], LOGNAME_LENGTH);				break;
		case EVENT_CS_ID: 		StrAppend(name, strCsr[language], LOGNAME_LENGTH);				break;
		case EVENT_NOMAL_ID:	StrAppend(name, strNormalBreath[language], LOGNAME_LENGTH);	break;
		default: break;
		}
	}
	break;
	case eMainUnitUpgradeLogId:
	{
		length = StrAppend(name, strControlVer[language], LOGNAME_LENGTH);
		name[length++] = data[7];
		name[length++] = data[8];
		name[length++] = data[9];
		name[length++] = data[10];
		name[length++] = data[11];

		break;							//main unit upgrade
	}
	case eBlowerUnitUpgradeLogId:
	{
		length = StrAppend(name, strBlowerVer[language], LOGNAME_LENGTH);
		name[length++] = data[7];
		name[length++] = data[8];
		name[length++] = data[9];
		name[length++] = data[10];
		name[length++] = data[11];
		name[length++] = data[12];
		name[length++] = data[13];
		break;
	}
	case eBLEUnitUpgradeLogId:
	{
		StrAppend(name, strBLEUnitUpgrade[language], LOGNAME_LENGTH);
	}
	break;
	case eSystemLogErrorEventId:
	{
		switch (data[7]) {
		case eBlowerErrorId:
			length = StrAppend(name, strBlowerAlarm[language], LOGNAME_LENGTH);
			name[length++] = ' ';
			StrToolItoHexS(data[8], &name[length], 2);
			break;
		case ePressSensorErrorId:
			length = StrAppend(name, strPressSensorAlarm[language], LOGNAME_LENGTH);
			name[length++] = ' ';
			StrToolItoHexS(data[8], &name[length], 2);
			break;
		case eFlowSensorErrorId:
			length = StrAppend(name, strFlowSensorAlarm[language], LOGNAME_LENGTH);
			name[length++] = ' ';
			StrToolItoHexS(data[8], &name[length], 2);
			break;
		case ePowerFailureId:		StrAppend(name, strPowerSupplyAlarm[language], LOGNAME_LENGTH);	break;
		case eSdCardErrorId:		StrAppend(name, strMediaAlarm[language], LOGNAME_LENGTH);			break;
		case eLeakErrorId:			StrAppend(name, strLeak[language], LOGNAME_LENGTH);				break;
		default: break;
		}
		break;
	}
	case eTimeSettingLogId:
	{
		StrToolItoA(data[7], &time[timeIndex], 2);	//add date
		timeIndex += 2;
		time[timeIndex++] = '/';					//insert '/'
		StrToolItoA(data[8], &time[timeIndex], 2);	//add month
		timeIndex += 2;
		time[timeIndex++] = '/';					//insert '/'
		StrToolItoA(data[9], &time[timeIndex], 2);
		timeIndex += 2;
		time[timeIndex++] = ' ';
		StrToolItoA(data[10], &time[timeIndex], 2);	//add hour
		timeIndex += 2;								//ship 2 characters
		time[timeIndex++] = ':';					//insert '/'
		StrToolItoA(data[11], &time[timeIndex], 2);	//add minute
		timeIndex += 2;								//ship 2 characters
		time[timeIndex++] = ':';					//insert '/'
		StrToolItoA(data[12], &time[timeIndex], 2);	//add second
		StrAppend(name, strChangeDateTime[language], LOGNAME_LENGTH);
		break;						//time setting change
	}
	default:
		break;
	}

	//char* logData[5] = {no, time, name};
	//add data into table
	//	LISTVIEW_InsertRow(logTable, rowIndex, (const GUI_ConstString *)logData);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: LogTableIncSel()
//
//    Processing:
//		The operation increases the selected row
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void LogTableIncSel()
{
	//	LISTVIEW_IncSel(logTable);
	testLogTableIncSel = 100;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: LogTableDeleteFirstRow()
//
//    Processing:
//		The operation deletes the first row of table
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void LogTableDeleteFirstRow()
{
	//	LISTVIEW_DeleteRow(logTable, 0);
	testLogTableDeleteFirstRow = 101;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: LogTableDeleteLastRow()
//
//    Processing:
//		The operation deletes the last row of table
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void LogTableDeleteLastRow()
{
	//	LISTVIEW_DeleteRow(logTable, LISTVIEW_GetNumRows(logTable) - 1);
	testLogTableDeleteLastRow = 102;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: LogTableDecSel()
//
//    Processing:
//		The operation decreases the selected row
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void LogTableDecSel()
{
	//	LISTVIEW_DecSel(logTable);
	testLogTableDecSel = 103;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: cbHeaderView(WM_MESSAGE *pMsg)
//
//    Processing:
//		The callback function of header
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void cbHeaderView(WM_MESSAGE *pMsg)
{
	//	GUI_RECT Rect;
	switch (pMsg->MsgId) {
	case WM_PAINT:
		testcbHeaderView = WM_PAINT;
		//		WM_GetClientRect(&Rect);
		//		GUI_SetBkColor(LOGTABLE_HEADER_BK_COLOR);
		//		GUI_ClearRectEx(&Rect);
		//
		//		GUI_SetColor(LOGTABLE_HEADER_NAME_COLOR);
		//		//set font for header
		//		GUI_SetFont(guiFont14[language]);
		//		//draw line
		//		GUI_DrawLine(Rect.x0 + LOGTABLE_FIRST_COLUMN_LENGTH, Rect.y0, Rect.x0 + LOGTABLE_FIRST_COLUMN_LENGTH, Rect.y0 + LOGTABLE_HEADER_HEIGHT);
		//		GUI_DrawLine(Rect.x0 + LOGTABLE_FIRST_COLUMN_LENGTH+LOGTABLE_SECOND_COLUMN_LENGTH, Rect.y0, Rect.x0 + LOGTABLE_FIRST_COLUMN_LENGTH+LOGTABLE_SECOND_COLUMN_LENGTH, Rect.y0 + LOGTABLE_HEADER_HEIGHT);
		//		//display No.
		//		GUI_SetFont(guiFont14[eEnglish]);
		//		GUI_DispStringHCenterAt(strNumOrder, Rect.x0 + LOGTABLE_FIRST_COLUMN_LENGTH/2, Rect.y0);
		//		//set font for header
		//		GUI_SetFont(guiFont14[language]);
		//		//display Date Time
		//		GUI_DispStringHCenterAt(strTime[language], Rect.x0 + (LOGTABLE_FIRST_COLUMN_LENGTH+(LOGTABLE_FIRST_COLUMN_LENGTH+LOGTABLE_SECOND_COLUMN_LENGTH))/2, Rect.y0);
		//		//display log name
		//		GUI_DispStringHCenterAt(strEvent[language], Rect.x0 + (LOGTABLE_FIRST_COLUMN_LENGTH+LOGTABLE_SECOND_COLUMN_LENGTH+(LOGTABLE_FIRST_COLUMN_LENGTH+LOGTABLE_SECOND_COLUMN_LENGTH+LOGTABLE_THIRST_COLUMN_LENGTH))/2, Rect.y0);
		break;
	default:
		testcbHeaderView = 1009;
		//		HEADER_Callback(pMsg);
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: LogTableGetSel()
//
//    Processing:
//		This operation gets the position of the selected row
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      int: the position of the selected row
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
int LogTableGetSel()
{
	return 100;//LISTVIEW_GetSel(logTable);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: LogTableSetSel(int row)
//
//    Processing:
//		The operation sets the position of the selected row
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      int: the position of new selected row
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void LogTableSetSel(int row)
{
	//	LISTVIEW_SetSel(logTable, row);
	testLogTableSetSel = row;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: LogTableSetSel(int row)
//
//    Processing:
//		The operation sets the position of the selected row
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      int: the position of new selected row
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void LogTableReload()
{
	//	LISTVIEW_SetFont(logTable, guiFont12[language]);
	testLogTableReload = 105;
}


#if defined(__cplusplus)
}
#endif
