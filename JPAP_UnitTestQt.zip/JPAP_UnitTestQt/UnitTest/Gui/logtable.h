/*
 * logtable.h
 *
 *  Created on: Apr 16, 2018
 *      Author: QUOCVIET
 */

//#include "LISTVIEW.h"
//#include "systemlog.h"
#include "stdbool.h"
#include "WM.h"

#ifndef UNITTEST_GUI_LOGTABLE_H_
#define UNITTEST_GUI_LOGTABLE_H_

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//extern WM_HWIN logTable;

void cbHeaderView(WM_MESSAGE *pMsg);
void LogTableInit(void);
void LogTableAddRow(int numericalOrder,unsigned char* data, unsigned char rowIndex);
void LogTableIncSel();
void LogTableDecSel();
int LogTableGetSel();
void LogTableSetSel(int row);
void LogTableDeleteFirstRow();
void LogTableDeleteLastRow();
void LogTableReload();

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_GUI_LOGTABLE_H_ */
