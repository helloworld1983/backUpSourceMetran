/*
 * logtableTest.cpp
 *
 *  Created on: Apr 16, 2018
 *      Author: QUOCVIET
 */


#include "stdafx.h"
#include "Fixture.h"
#include "logtable.h"

#include <event.h>
#include <setting.h>
#include <systeminterface.h>

#include "WM.h"
#include "guiglobal.h"
#include "strings.h"
#include "alarminterface.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern int testLogTableInit;
extern unsigned char id;
extern unsigned char valBeforeDot;
extern unsigned char valAfterDot;
extern int testLogTableIncSel;
extern int testLogTableDeleteFirstRow;
extern int testLogTableDeleteLastRow;
extern int testLogTableDecSel;
extern int testcbHeaderView;
extern int testLogTableSetSel;
extern int testLogTableReload;

namespace EmbeddedCUnitTest {

class LogTableTest : public TestFixture
{
public:
	LogTableTest() : TestFixture(new ModuleMock) {}
};



TEST_F(LogTableTest, LogTableInit)
{
	LogTableInit();

	EXPECT_EQ(testLogTableInit, 1000);
}

TEST_F(LogTableTest, LogTableAddRow1)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	unsigned char data[100];
	id = 0;
	LogTableAddRow(8,data,0);
}

TEST_F(LogTableTest, LogTableAddRow2)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);

	unsigned char data[100];
	id = 0;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow3)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,3)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6).WillOnce(Return(0));

	unsigned char data[100];
	id = 0;
	LogTableAddRow(101,data,0);
}

TEST_F(LogTableTest, LogTableAddRow4)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(2).WillOnce(Return(0)).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,_,40)).Times(2);

	unsigned char data[100];
	id = eSystemLogSettingChangedId;
	data[7] = eSleepTimerSettingId;
	LogTableAddRow(8,data,0);
}

TEST_F(LogTableTest, LogTableAddRow5)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,_,40)).Times(2);

	unsigned char data[100];
	id = eSystemLogSettingChangedId;
	data[7] = ePressUnitSettingId;
	data[8] = 2;
	LogTableAddRow(8,data,0);
	EXPECT_EQ(1, data[8]);
}

TEST_F(LogTableTest, LogTableAddRow6)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,_,40)).Times(2);

	unsigned char data[100];
	id = eSystemLogSettingChangedId;
	data[7] = eFLSettingId;
	data[8] = 2;
	LogTableAddRow(8,data,0);
	EXPECT_EQ(1, data[8]);
}

TEST_F(LogTableTest, LogTableAddRow7)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,_,40)).Times(2);

	unsigned char data[100];
	id = eSystemLogSettingChangedId;
	data[7] = eAutoOFFSettingId;
	data[8] = 2;
	LogTableAddRow(8,data,0);
	EXPECT_EQ(1, data[8]);
}

TEST_F(LogTableTest, LogTableAddRow8)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,strLanguge[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,strJapanese[language],40)).Times(1).WillOnce(Return(0));

	unsigned char data[100];
	id = eSystemLogSettingChangedId;
	data[7] = eLanguageSettingId;
	data[8] = 0;
	LogTableAddRow(8,data,0);
}

TEST_F(LogTableTest, LogTableAddRow9)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strLanguge[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,strEnglish[language],40)).Times(1).WillOnce(Return(0));

	unsigned char data[100];
	id = eSystemLogSettingChangedId;
	data[7] = eLanguageSettingId;
	data[8] = 1;
	LogTableAddRow(8,data,0);
}

TEST_F(LogTableTest, LogTableAddRow10)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strNsType[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,strType1[language],40)).Times(1).WillOnce(Return(0));

	unsigned char data[100];
	id = eSystemLogSettingChangedId;
	data[7] = eNsTypeSettingId;
	data[8] = 0;
	LogTableAddRow(8,data,0);
}

TEST_F(LogTableTest, LogTableAddRow11)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strNsType[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,strType2[language],40)).Times(1).WillOnce(Return(0));

	unsigned char data[100];
	id = eSystemLogSettingChangedId;
	data[7] = eNsTypeSettingId;
	data[8] = 1;
	LogTableAddRow(8,data,0);
}

TEST_F(LogTableTest, LogTableAddRow12)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strBrightness[language],40)).Times(1).WillOnce(Return(0));

	unsigned char data[100];
	id = eSystemLogSettingChangedId;
	data[7] = eBrightnessSettingId;
	LogTableAddRow(8,data,0);
}

TEST_F(LogTableTest, LogTableAddRow13)
{
	unsigned char data[100];
	data[8] = 1;

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strMode[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,strCpapAutoCpap[data[8]],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogSettingChangedId;
	data[7] = eVentModeSettingId;
	data[8] = 2;
	LogTableAddRow(8,data,0);
	EXPECT_EQ(1, data[8]);
}

TEST_F(LogTableTest, LogTableAddRow14)
{
	unsigned char data[100];
	data[9] = 1;

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(3);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strTreatmenPress[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,unitStr[data[9]],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogSettingChangedId;
	data[7] = eOperPressSettingId;
	data[8] = 10;
	LogTableAddRow(8,data,0);
	EXPECT_EQ(5, valBeforeDot);
	EXPECT_EQ(0, valAfterDot);
}

TEST_F(LogTableTest, LogTableAddRow15)
{
	unsigned char data[100];
	data[9] = 1;

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(2);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strTreatmenPress[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,unitStr[data[9]],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogSettingChangedId;
	data[7] = eOperPressSettingId;
	data[8] = 40;
	LogTableAddRow(8,data,0);
	EXPECT_EQ(20, valBeforeDot);
	EXPECT_EQ(0, valAfterDot);
}

TEST_F(LogTableTest, LogTableAddRow16)
{
	unsigned char data[100];
	data[9] = 1;

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(2);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strInitPress[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,unitStr[data[9]],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogSettingChangedId;
	data[7] = eDelayPressSettingId;
	data[8] = 20;
	data[9] = 2;
	LogTableAddRow(8,data,0);
	EXPECT_EQ(2, valBeforeDot);
	EXPECT_EQ(1, data[9]);
}

TEST_F(LogTableTest, LogTableAddRow17)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(2);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strRampTime[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,strMin[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogSettingChangedId;
	data[7] = eRampTimeSettingId;
	data[8] = 5;
	LogTableAddRow(8,data,0);
}

TEST_F(LogTableTest, LogTableAddRow18)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strRampTime[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,strMin[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogSettingChangedId;
	data[7] = eRampTimeSettingId;
	data[8] = 11;
	LogTableAddRow(8,data,0);
}

TEST_F(LogTableTest, LogTableAddRow19)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(2);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strExhSupport[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogSettingChangedId;
	data[7] = eExhPressSupportSettingId;
	LogTableAddRow(8,data,0);
}

TEST_F(LogTableTest, LogTableAddRow20)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(2);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strInhSupport[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogSettingChangedId;
	data[7] = eInhPressSupportSettingId;
	LogTableAddRow(8,data,0);
}

TEST_F(LogTableTest, LogTableAddRow21)
{
	unsigned char data[100];
	data[9] = 1;

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(3);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strHighPressLimit[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,unitStr[data[9]],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogSettingChangedId;
	data[7] = eAutoUpperPressSettingId;
	data[8] = 10;
	data[9] = 2;
	LogTableAddRow(8,data,0);
	EXPECT_EQ(1, data[9]);
	EXPECT_EQ(5, valBeforeDot);
	EXPECT_EQ(0, valAfterDot);
}

TEST_F(LogTableTest, LogTableAddRow22)
{
	unsigned char data[100];
	data[9] = 1;

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(2);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strHighPressLimit[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,unitStr[data[9]],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogSettingChangedId;
	data[7] = eAutoUpperPressSettingId;
	data[8] = 100;
	data[9] = 2;
	LogTableAddRow(8,data,0);
	EXPECT_EQ(1, data[9]);
	EXPECT_EQ(50, valBeforeDot);
	EXPECT_EQ(0, valAfterDot);
}

TEST_F(LogTableTest, LogTableAddRow23)
{
	unsigned char data[100];
	data[9] = 1;

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(3);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strLowPressLimit[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,unitStr[data[9]],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogSettingChangedId;
	data[7] = eAutoLowerPressSettingId;
	data[8] = 10;
	data[9] = 2;
	LogTableAddRow(8,data,0);
	EXPECT_EQ(1, data[9]);
	EXPECT_EQ(5, valBeforeDot);
	EXPECT_EQ(0, valAfterDot);
}

TEST_F(LogTableTest, LogTableAddRow24)
{
	unsigned char data[100];
	data[9] = 1;

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,1)).Times(2);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strLowPressLimit[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrAppend(_,unitStr[data[9]],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogSettingChangedId;
	data[7] = eAutoLowerPressSettingId;
	data[8] = 100;
	data[9] = 2;
	LogTableAddRow(8,data,0);
	EXPECT_EQ(1, data[9]);
	EXPECT_EQ(50, valBeforeDot);
	EXPECT_EQ(0, valAfterDot);
}

TEST_F(LogTableTest, LogTableAddRow25)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strPowerOn[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemStateLogId;
	data[7] = eSystemPowerOn;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow26)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strPowerOff[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemStateLogId;
	data[7] = eSystemPowerOff;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow27)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strAutoStart[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemStateLogId;
	data[7] = eSystemAutoStart;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow28)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strManualStart[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemStateLogId;
	data[7] = eSystemManualStart;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow29)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strAutoOFF[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemStateLogId;
	data[7] = eSystemAutoOFF;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow30)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strStrongDrying[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemStateLogId;
	data[7] = eSystemStrongDrying;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow31)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strWeakDrying[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemStateLogId;
	data[7] = eSystemWeakDrying;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow32)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strAutoStop[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemStateLogId;
	data[7] = eSystemAutoStop;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow33)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strCompleteDrying[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemStateLogId;
	data[7] = eSystemCompleteDrying;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow34)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strManualStop[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemStateLogId;
	data[7] = eSystemManualStop;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow35)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strInterruptionDrying[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemStateLogId;
	data[7] = eSystemInterruptionDrying;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow36)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strMaskOnAfterAirLeak[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemStateLogId;
	data[7] = eSystemReturnOperate;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow37)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strInsertSDCard[language],40)).Times(1).WillOnce(Return(0));

	id = eSDCardLogId;
	data[7] = eInsert;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow38)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strRemoveSDCard[language],40)).Times(1).WillOnce(Return(0));

	id = eSDCardLogId;
	data[7] = eRemove;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow39)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,3)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strReset[language],40)).Times(1).WillOnce(Return(0));

	id = eSettingResetLogId;
	LogTableAddRow(101,data,0);
}

TEST_F(LogTableTest, LogTableAddRow40)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,3)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strResetTimeUsing[language],40)).Times(1).WillOnce(Return(0));

	id = eClearUsedHoursLogId;
	LogTableAddRow(101,data,0);
}

TEST_F(LogTableTest, LogTableAddRow41)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,3)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strExportToCSVFile[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogExportLogDataEventId;
	LogTableAddRow(101,data,0);
}

TEST_F(LogTableTest, LogTableAddRow42)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,3)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strCircuitCalibration[language],40)).Times(1).WillOnce(Return(0));

	id = eCalibrateSuccessLogId;
	LogTableAddRow(101,data,0);
}

TEST_F(LogTableTest, LogTableAddRow43)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,3)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strCalibrationError[language],40)).Times(1).WillOnce(Return(0));

	id = eCalibrateFailLogId;
	LogTableAddRow(101,data,0);
}

TEST_F(LogTableTest, LogTableAddRow44)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strMaskOff[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogApneaEventId;
	data[7] = EVENT_MSK_OFF_ID;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow45)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strMaskOn[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogApneaEventId;
	data[7] = EVENT_MSK_ON_ID;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow46)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strSnore[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogApneaEventId;
	data[7] = EVENT_S_ID;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow47)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strHyponea[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogApneaEventId;
	data[7] = EVENT_H_ID;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow48)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strFl[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogApneaEventId;
	data[7] = EVENT_FL_ID;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow49)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strOa[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogApneaEventId;
	data[7] = EVENT_OA_ID;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow50)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strCa[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogApneaEventId;
	data[7] = EVENT_CA_ID;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow51)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strCsr[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogApneaEventId;
	data[7] = EVENT_CS_ID;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow52)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strNormalBreath[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogApneaEventId;
	data[7] = EVENT_NOMAL_ID;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow53)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strControlVer[language],40)).Times(1).WillOnce(Return(0));

	id = eMainUnitUpgradeLogId;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow54)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strBlowerVer[language],40)).Times(1).WillOnce(Return(0));

	id = eBlowerUnitUpgradeLogId;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow55)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strBLEUnitUpgrade[language],40)).Times(1).WillOnce(Return(0));

	id = eBLEUnitUpgradeLogId;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow56)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strBlowerAlarm[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrToolItoHexS(_,_,2)).Times(1);

	id = eSystemLogErrorEventId;
	data[7] = eBlowerErrorId;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow57)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strPressSensorAlarm[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrToolItoHexS(_,_,2)).Times(1);

	id = eSystemLogErrorEventId;
	data[7] = ePressSensorErrorId;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow58)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strFlowSensorAlarm[language],40)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,StrToolItoHexS(_,_,2)).Times(1);

	id = eSystemLogErrorEventId;
	data[7] = eFlowSensorErrorId;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow59)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strPowerSupplyAlarm[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogErrorEventId;
	data[7] = ePowerFailureId;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow60)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strMediaAlarm[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogErrorEventId;
	data[7] = eSdCardErrorId;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow61)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(7);
	EXPECT_CALL(*_wstring,StrAppend(_,strLeak[language],40)).Times(1).WillOnce(Return(0));

	id = eSystemLogErrorEventId;
	data[7] = eLeakErrorId;
	LogTableAddRow(99,data,0);
}

TEST_F(LogTableTest, LogTableAddRow62)
{
	unsigned char data[100];

	EXPECT_CALL(*_wstring,StrToolItoA(_,_,3)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(6);
	EXPECT_CALL(*_wstring,StrAppend(_,strChangeDateTime[language],40)).Times(1).WillOnce(Return(0));

	id = eTimeSettingLogId;
	LogTableAddRow(101,data,0);
}

TEST_F(LogTableTest, LogTableIncSel)
{
	LogTableIncSel();

	EXPECT_EQ(100, testLogTableIncSel);
}

TEST_F(LogTableTest, LogTableDeleteFirstRow)
{
	LogTableDeleteFirstRow();

	EXPECT_EQ(101, testLogTableDeleteFirstRow);
}

TEST_F(LogTableTest, LogTableDeleteLastRow)
{
	LogTableDeleteLastRow();

	EXPECT_EQ(102, testLogTableDeleteLastRow);
}

TEST_F(LogTableTest, LogTableDecSel)
{
	LogTableDecSel();

	EXPECT_EQ(103, testLogTableDecSel);
}

TEST_F(LogTableTest, cbHeaderView)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	cbHeaderView(&pMsg); // @suppress("Invalid arguments")
	EXPECT_EQ(WM_PAINT, testcbHeaderView);

	/*******************************************/
	pMsg.MsgId = WM_PAINT + 1000;
	cbHeaderView(&pMsg); // @suppress("Invalid arguments")
	EXPECT_EQ(1009, testcbHeaderView);
}

TEST_F(LogTableTest, LogTableGetSel)
{
	EXPECT_EQ(100, LogTableGetSel());
}

TEST_F(LogTableTest, LogTableSetSel)
{
	LogTableSetSel(104);

	EXPECT_EQ(104, testLogTableSetSel);
}

TEST_F(LogTableTest, LogTableReload)
{
	LogTableReload();

	EXPECT_EQ(105, testLogTableReload);
}

}

