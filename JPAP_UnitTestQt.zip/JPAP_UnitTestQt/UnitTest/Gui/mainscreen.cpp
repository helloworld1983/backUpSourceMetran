/*
 * mainscreen.cpp
 *
 *  Created on: Apr 17, 2018
 *      Author: QUOCVIET
 */

#include "stdio.h"
//#include "sleepscreen.h"
//#include "systeminfortable.h"
//#include "operationscreen.h"
#include "mainscreen.h"

#include <motorctrlinterface.h>
#include <setting.h>

#include "clinicscreen.h"
#include "historyscreen.h"
#include "alarmdialog.h"
//#include "startupscreen.h"
//#include "debuguart.h"
#include "WM.h"
//#include "systemconfig.h"
//#include "powermonitor.h"
//#include "mode.h"
//#include "softtimer.h"
#include "alarminterface.h"
#include "guiglobal.h"
//#include "usersettingdialog.h"
#include "SettingMocks.h"
#include "queue.h"

E_GuiEventId testMainScreenHandleEvent = eGuiFirstEventId;
E_ScreenId currentScr = eStartUpScrId;
int testcbMainWindow = 0;
E_ScreenId testcurrentScr = eStartUpScrId;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

#define MAIN_WINDOW_X		0
#define MAIN_WINDOW_Y		0
#define MAIN_WINDOW_SIZE_X	320
#define MAIN_WINDOW_SIZE_Y	240

//define background color for main window
#define MAIN_SCR_BKCOLOR	0x503008


//declare variable to manage current screen display
//static E_ScreenId currentScr = eStartUpScrId;

//declare table screen to get correctly screen from table id
//static const WM_HWIN* ScreenTable[] =
//{
//		&startupScreen,
//		&operationScreen,
//		&clinicScreen,
//		&historyScreen,
//		&maintenanceScreen,
//};

// main window
//WM_HWIN mainWindow;
static xQueueHandle alarmQueue;
static xQueueHandle motorQueue;

//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: cbMainWindow()
//
//    Processing:		This operation is a function callback for main screen.
//						it check event come to main window and re-draw main screen
//
//    Input Parameters: None
//
//    Output Parameters:None
//
//    Return Values:    None
//
//    Pre-Conditions:   None
//
//    Miscellaneous:    None
//
//    Requirements:
//
//******************************************************************************
void cbMainWindow(WM_MESSAGE * pMsg)
{
	//	GUI_RECT Rect;
	switch (pMsg->MsgId) {
	case WM_PAINT:
		testcbMainWindow = WM_PAINT;
		//		WM_GetInsideRect(&Rect);
		//		GUI_SetBkColor(MAIN_SCR_BKCOLOR);
		//		GUI_ClearRectEx(&Rect);
		break;
	default:
		//		WM_DefaultProc(pMsg);
		testcbMainWindow = 108;
		break;
	}
}

//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: MainScreenInit()
//
//    Processing:		This operation create main window object and its child.
//
//    Input Parameters: None
//
//    Output Parameters:None
//
//    Return Values:    None
//
//    Pre-Conditions:   None
//
//    Miscellaneous:    None
//
//    Requirements:
//
//******************************************************************************
void MainScreenInit()
{
	//create a window as basic
	//	mainWindow = WM_CreateWindow(MAIN_WINDOW_X, MAIN_WINDOW_Y, MAIN_WINDOW_SIZE_X, MAIN_WINDOW_SIZE_Y, WM_CF_SHOW | WM_CF_MEMDEV | WM_CF_LATE_CLIP, cbMainWindow, 0);
	//	//init operation screen
	//	OperScreenInit();
	//	//init status bar
	//	StatBarInit();
	//	//init health care worker screen
	//	ClinicScreenInit();
	//	//init maintenance screen
	//	MaintenanceScrInit();
	//	//init history screen
	//	HistoryScrInit();
	//	//init startup screen
	//	StartupScreenInit();
	//	//init display off screen
	//	SleepScrInit();
	//	//init pop up
	//	PopupInit();
	//	//set default font as UTF8
	//	GUI_UC_SetEncodeUTF8();
	//set first screen as start up screen
	currentScr = eStartUpScrId;
}

//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: MainScreenHandleEvent()
//
//    Processing:		This operation handle GUI event. Event come to main window
//						can be forward to its child to process them
//
//    Input Parameters:
//						GuiEventStruct guiEvent: event need to process
//
//    Output Parameters:None
//
//    Return Values:    None
//
//    Pre-Conditions:   None
//
//    Miscellaneous:    None
//
//    Requirements:
//
//******************************************************************************
void MainScreenHandleEvent(GuiEventStruct guiEvent)
{
	E_GuiEventId eventId = guiEvent.id;
	if((eventId >= eGuiFirstTitleBarId)&&(eventId <= eGuiLastTitleBarId))
	{
		//these event belong to status bar object
		//		StatusBarHandeEvent(guiEvent.id);
		if(eventId == eGuiUpdateRtcId)
		{
#if SUPPORT_SLEEP_MODE
			//update time for sleep screen
			SleepScrUpdateTime();
#endif
		}

		testMainScreenHandleEvent = eventId;
	}
	else if((eventId >= eGuiFirstPopUpDialogId)&&(eventId <= eGuiLastPopUpDialogId))
	{
		testMainScreenHandleEvent = eventId;
		//		PopupHandleEvent(guiEvent);
	}
	else if((eventId >= eGuiFirstOperScreenId)&&(eventId <= eGuiLastOperScreenId))
	{
		if((currentScr == eOperationScrId)||(currentScr == eStartUpScrId))
		{
			testcurrentScr = currentScr;
			//			OperScreenHandleEvent(guiEvent);
		}
		testMainScreenHandleEvent = eventId;
	}
	else if((eventId >= eGuiFirstFactoryScreenId)&&(eventId <= eGuiLastFactoryScreenId))
	{
		//		MaintenanceScrHandleEvent(guiEvent);
		testMainScreenHandleEvent = eventId;
	}
	else if((eventId >= eGuiFirstClinicScreenId)&&(eventId <= eGuiLastClinicScreenId))
	{
		//		ClinicianScrHandleEvent(guiEvent);
		testMainScreenHandleEvent = eventId;
	}
	else if(eventId == eGuiChangeToOperScreenId)
	{
		//check to read setting from SD card
		//		if(SettingGetRequestReadSd() == true)
		//			SettingReadFromSd();
		//send event to enable alarm task
		AlarmEventStruct event;
		event.id = eAlarmTaskEnableId;
		event.data = 0;
		if(xQueueSendToBack(alarmQueue, &event, 2) != pdPASS)
		{

		}
		//		ALarmTaskSendEvent(eAlarmTaskEnableId, 0);
		//hide current screen
		//		WM_HideWindow(*ScreenTable[currentScr]);
		//set screen id
		currentScr = eOperationScrId;
		//reload setting and display on operation screen
		//		OperScreenUpdateSetting();
		//select operation screen at focus
		//		WM_ShowWindow(*ScreenTable[currentScr]);	//show operation screen
		//		WM_SetFocus(*ScreenTable[currentScr]);	//focus operation screen
		//set system to idle mode
		//		OperScreenEnterIdle();
		//resume motor to work
		//		MotorTaskSendEvent(eMotorResumeEventId);
		//update value for timer1 as sleep screen entrance timer
		//		SoftTimerSetInterval(eSoftTimer1Id, (SettingGet(eSleepTimerSettingId)+1)*60*1000);
		//start timer to enter sleep screen
		//		SoftTimerStart(eSoftTimer1Id);
		testMainScreenHandleEvent = eventId;
	}
	else if(eventId == eGuiChangeToClinicScreenId)
	{
		//send event to disable alarm task
		AlarmEventStruct event;
		event.id = eAlarmTaskDisableId;
		event.data = 0;
		if(xQueueSendToBack(alarmQueue, &event, 2) != pdPASS)
		{

		}
		//		ALarmTaskSendEvent(eAlarmTaskDisableId, 0);
		//hide current screen
		//		WM_HideWindow(*ScreenTable[currentScr]);
		//set screen id
		currentScr = eClinicScrId;
		//load setting before showing clinic screen
		//		ClinicScreenReload();
		//change to current activate screen
		//		WM_SetFocus(*ScreenTable[currentScr]);			//focus hcw
		//		WM_ShowWindow(*ScreenTable[currentScr]);		//show hcw
		//suspend motor
		//		MotorTaskSendEvent(eMotorSuspendEventId);
		//stop timer to enter sleep screen
		//		SoftTimerStop(eSoftTimer1Id);
		testMainScreenHandleEvent = eventId;
	}
	else if(eventId == eGuiChangeToMaintenaceScreenId)
	{
		//send event to disable alarm task
		AlarmEventStruct event;
		event.id = eAlarmTaskDisableId;
		event.data = 0;
		if(xQueueSendToBack(alarmQueue, &event, 2) != pdPASS)
		{

		}
		//		ALarmTaskSendEvent(eAlarmTaskDisableId, 0);
		//hide current screen
		//		WM_HideWindow(*ScreenTable[currentScr]);
		//set screen id
		currentScr = eMaintenanceScrId;
		//update setting before showing maintenance screen
		//		MaintenanceScrReload();
		//show current activate screen
		//		WM_SetFocus(*ScreenTable[currentScr]);		//focus maintenance
		//		WM_ShowWindow(*ScreenTable[currentScr]);	//show maintenance
		//suspend motor
		unsigned char sendEvent = eMotorSuspendEventId;
		if(xQueueSendToBack(motorQueue, &sendEvent, 2) != pdPASS)
		{

		}
		//		MotorTaskSendEvent(eMotorSuspendEventId);
		//stop timer to enter sleep screen
		//		SoftTimerStop(eSoftTimer1Id);
		testMainScreenHandleEvent = eventId;
	}
	else if(eventId == eGuiChangeToHistoryScreenId)
	{
		//send event to disable alarm task
		AlarmEventStruct event;
		event.id = eAlarmTaskDisableId;
		event.data = 0;
		if(xQueueSendToBack(alarmQueue, &event, 2) != pdPASS)
		{

		}
		//		ALarmTaskSendEvent(eAlarmTaskDisableId, 0);
		//hide current screen
		//		WM_HideWindow(*ScreenTable[currentScr]);
		//change screen id
		currentScr = eHistoryScrId;
		//load history data before showing
		//		HistoryScrReload();
		//show current activate screen
		//		WM_SetFocus(*ScreenTable[currentScr]);		//focus history
		//		WM_ShowWindow(*ScreenTable[currentScr]);	//show history
		//suspend motor
		unsigned char sendEvent = eMotorSuspendEventId;
		if(xQueueSendToBack(motorQueue, &sendEvent, 2) != pdPASS)
		{

		}
//		MotorTaskSendEvent(eMotorSuspendEventId);
		//stop timer to enter sleep screen
		//		SoftTimerStop(eSoftTimer1Id);
		testMainScreenHandleEvent = eventId;
	}
	else if(eventId == eGuiChangeSettingFromCloudId)
	{
		//save setting
		SettingSaveMocks();//SettingSave();
		//update setting
		GuiTaskSendEvent(eGuiOperUpdateSettingId, 0);
		testMainScreenHandleEvent = eventId;
	}
#if SUPPORT_EVENT_DISPLAY
	else if(eventId == eGuiUpdateAvgVolumeEventId)
		OperscreenSetAverageVolume(guiEvent.data);
	else if(eventId == eGuiUpdateLastVolumeEventId)
		OperscreenSetCurrentVolume(guiEvent.data);
	else if(eventId == eGuiUpdatePercentageEventId)
		OperscreenSetPercentage(guiEvent.data);
#endif
}

#if defined(__cplusplus)
}
#endif

