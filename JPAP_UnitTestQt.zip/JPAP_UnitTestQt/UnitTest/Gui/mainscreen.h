/*
 * mainscreen.h
 *
 *  Created on: Apr 17, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_GUI_MAINSCREEN_H_
#define UNITTEST_GUI_MAINSCREEN_H_

#include <guiinterface.h>

#include "WM.h"
//#include "GUI.h"

//define screen id for main window to manage its children
typedef enum
{
	eStartUpScrId = 0,
	eOperationScrId,
	eClinicScrId,
	eHistoryScrId,
	eMaintenanceScrId,
} E_ScreenId;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//main window
//extern WM_HWIN mainWindow;
void cbMainWindow(WM_MESSAGE * pMsg);

//function to create main window and its child's window
void MainScreenInit();

//function to handle event on GUI
void MainScreenHandleEvent(GuiEventStruct guiEvent);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_GUI_MAINSCREEN_H_ */
