/*
 * mainscreenTest.cpp
 *
 *  Created on: Apr 17, 2018
 *      Author: QUOCVIET
 */

#include "stdafx.h"
#include "Fixture.h"
#include "mainscreen.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern E_GuiEventId testMainScreenHandleEvent;
extern int testcbMainWindow;
extern E_ScreenId currentScr;
extern E_ScreenId testcurrentScr;

namespace EmbeddedCUnitTest {


class MainScreenTest : public TestFixture
{
public:
	MainScreenTest() : TestFixture(new ModuleMock) {}
};



TEST_F(MainScreenTest, cbMainWindow)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;

	cbMainWindow(&pMsg); // @suppress("Invalid arguments")

	EXPECT_EQ(WM_PAINT,testcbMainWindow);

	/*****************************************************/
	pMsg.MsgId = WM_PAINT + 100;

	cbMainWindow(&pMsg); // @suppress("Invalid arguments")
	EXPECT_EQ(108,testcbMainWindow);
}

TEST_F(MainScreenTest, MainScreenInit)
{
	MainScreenInit();
	EXPECT_EQ(eStartUpScrId,currentScr);
}

TEST_F(MainScreenTest, MainScreenHandleEvent1)
{
	GuiEventStruct guiEvent;

	for(int i = 0; i < 7; i++)
	{
		guiEvent.id = (E_GuiEventId)i;
		MainScreenHandleEvent(guiEvent);
		EXPECT_EQ((E_GuiEventId)i,testMainScreenHandleEvent);
	}
}

TEST_F(MainScreenTest, MainScreenHandleEvent2)
{
	GuiEventStruct guiEvent;

	for(int i = 7; i < 31; i++)
	{
		guiEvent.id = (E_GuiEventId)i;
		MainScreenHandleEvent(guiEvent);
		EXPECT_EQ((E_GuiEventId)i,testMainScreenHandleEvent);
	}
}

TEST_F(MainScreenTest, MainScreenHandleEvent3)
{
	GuiEventStruct guiEvent;

	currentScr = eOperationScrId;

	for(int i = 31; i < 50; i++)
	{
		guiEvent.id = (E_GuiEventId)i;
		MainScreenHandleEvent(guiEvent);
		EXPECT_EQ((E_GuiEventId)i,testMainScreenHandleEvent);
		EXPECT_EQ(eOperationScrId,testcurrentScr);
	}
}

TEST_F(MainScreenTest, MainScreenHandleEvent4)
{
	GuiEventStruct guiEvent;

	currentScr = eStartUpScrId;

	for(int i = 31; i < 50; i++)
	{
		guiEvent.id = (E_GuiEventId)i;
		MainScreenHandleEvent(guiEvent);
		EXPECT_EQ((E_GuiEventId)i,testMainScreenHandleEvent);
		EXPECT_EQ(eStartUpScrId,testcurrentScr);
	}
}

TEST_F(MainScreenTest, MainScreenHandleEvent5)
{
	GuiEventStruct guiEvent;

	for(int i = 50; i < 55; i++)
	{
		guiEvent.id = (E_GuiEventId)i;
		MainScreenHandleEvent(guiEvent);
		EXPECT_EQ((E_GuiEventId)i,testMainScreenHandleEvent);
	}
}

TEST_F(MainScreenTest, MainScreenHandleEvent6)
{
	GuiEventStruct guiEvent;

	guiEvent.id = eGuiFirstClinicScreenId;
	MainScreenHandleEvent(guiEvent);
	EXPECT_EQ(eGuiFirstClinicScreenId,testMainScreenHandleEvent);
}

TEST_F(MainScreenTest, MainScreenHandleEvent7)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1).WillOnce(Return(pdPASS));

	GuiEventStruct guiEvent;

	guiEvent.id = eGuiChangeToOperScreenId;
	MainScreenHandleEvent(guiEvent);
	EXPECT_EQ(eOperationScrId,currentScr);
	EXPECT_EQ(eGuiChangeToOperScreenId,testMainScreenHandleEvent);
}

TEST_F(MainScreenTest, MainScreenHandleEvent8)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1).WillOnce(Return(pdPASS));

	GuiEventStruct guiEvent;

	guiEvent.id = eGuiChangeToClinicScreenId;
	MainScreenHandleEvent(guiEvent);
	EXPECT_EQ(eClinicScrId,currentScr);
	EXPECT_EQ(eGuiChangeToClinicScreenId,testMainScreenHandleEvent);
}

TEST_F(MainScreenTest, MainScreenHandleEvent9)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(2).WillOnce(Return(pdPASS)).WillOnce(Return(pdPASS));

	GuiEventStruct guiEvent;

	guiEvent.id = eGuiChangeToMaintenaceScreenId;
	MainScreenHandleEvent(guiEvent);
	EXPECT_EQ(eMaintenanceScrId,currentScr);
	EXPECT_EQ(eGuiChangeToMaintenaceScreenId,testMainScreenHandleEvent);
}

TEST_F(MainScreenTest, MainScreenHandleEvent10)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(2).WillOnce(Return(pdPASS));

	GuiEventStruct guiEvent;

	guiEvent.id = eGuiChangeToHistoryScreenId;
	MainScreenHandleEvent(guiEvent);
	EXPECT_EQ(eHistoryScrId,currentScr);
	EXPECT_EQ(eGuiChangeToHistoryScreenId,testMainScreenHandleEvent);
}

TEST_F(MainScreenTest, MainScreenHandleEvent11)
{
	EXPECT_CALL(*_settingLib,SettingSaveMocks()).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1).WillOnce(Return(pdPASS));

	GuiEventStruct guiEvent;

	guiEvent.id = eGuiChangeSettingFromCloudId;
	MainScreenHandleEvent(guiEvent);
	EXPECT_EQ(eGuiChangeSettingFromCloudId,testMainScreenHandleEvent);
}

}


