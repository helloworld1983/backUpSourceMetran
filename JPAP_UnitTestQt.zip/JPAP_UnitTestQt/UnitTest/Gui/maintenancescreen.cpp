/*
 * maintenancescreen.cpp
 *
 *  Created on: Apr 17, 2018
 *      Author: QUOCVIET
 */

#include "guidefine.h"
//#include "motorcmd.h"
#include "maintenancescreen.h"

#include <guiinterface.h>
#include <motorctrlinterface.h>
#include <setting.h>

#include "confirmbutton.h"
//#include "settingbutton.h"
//#include "systeminfortable.h"
//#include "popupdialog.h"
//#include "BUTTON.h"
//#include "SLIDER.h"
//#include "DIALOG.h"
//#include "IMAGE.h"
//#include "mode.h"
//#include "operationscreen.h"
//#include "debuguart.h"
#include "string.h"
//#include "motorupgrade.h"
#include "clinicscreen.h"
//#include "usersettingdialog.h"
#include "strings.h"
//#include "systemconfig.h"
#include "guiglobal.h"
//#include "timesettingdialog.h"
#include "SettingBtnMocks.h"
#include "SettingMocks.h"
#include "TimeDialogMocks.h"
#include "SliderMocks.h"
#include "WMMocks.h"
#include "InforDlgMocks.h"
#include "TitleBarMock.h"
#include "PWMLib.h"
#include "systeminfortableMocks.h"
#include "stdio.h"

int testMaintenanceScrInit = 0;
int testFactoryReLayout = 0;
int testFactoryScrCallback = 0;
bool isLogSetting1 = false;
E_SettingScreenState testState = eDialogState;
short endItem1 = MTN_NUM_SCREEN_BTN;
short currentItem1 = 0;
short preEndSetting1 = MTN_NUM_SCREEN_BTN - 1;
short secondItem1 = 1;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

#define MTN_BACKGROUND_COLOR		COLOR_DARK_BLUE
#define INVISIBLE_SPACE_HEIGHT		8

//void FactoryScrCallback(WM_MESSAGE * pMsg);
//void FactoryHandleEnterKey();
//void FactoryHandleLeftKey();
//void FactoryHandleRightKey();
//void FactorySetItemStatus();
//void FactoryReLayout();

//WM_HWIN maintenanceScreen;

//main window instance
//extern WM_HWIN mainWindow;
//static SLIDER_Handle mtnVerticalSlider;
//static BUTTON_Handle mtnTitleBar;
//static BUTTON_Handle resetTimeBtn;
//static BUTTON_Handle brightnessAdjBtn;
//static BUTTON_Handle displayOffTimerBtn;
//static BUTTON_Handle languageSettingBtn;
//static BUTTON_Handle changeUnitBtn;
//static BUTTON_Handle resetBtn;
//static BUTTON_Handle mainUnitUpgradeBtn;
//static BUTTON_Handle blowerUpgradeBtn;
//static BUTTON_Handle exportLogBtn;
//static BUTTON_Handle bleUnitUpgrade;

//static WM_HWIN buttonList[MTN_NUM_BUTTON];

static E_SettingScreenState currentState = eDialogState;
//static short currentItem = 0;
static short currentId = 0;
//static short secondItem = 1;
//static short endItem = MTN_NUM_SCREEN_BTN;
//static short preEndSetting = MTN_NUM_SCREEN_BTN - 1;
//static bool isLogSetting = false;

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: maintenanceScreen(void)
//
//    Processing:
//		The operation creates maintenance screen
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void MaintenanceScrInit(void)
{
	//init maintenance screen
	//	maintenanceScreen = WM_CreateWindowAsChild(SETTING_SCREEN_X, SETTING_SCREEN_Y, SETTING_SCREEN_LENGTH, SETTING_SCREEN_HEIGHT, mainWindow, WM_CF_HIDE | WM_CF_MEMDEV | WM_CF_LATE_CLIP, FactoryScrCallback, 0);
	//	//init vertical slider
	//	mtnVerticalSlider = SLIDER_CreateEx(SLIDER_BAR_X, SLIDER_BAR_Y, SLIDER_BAR_LENGTH, SLIDER_BAR_HEIGHT, maintenanceScreen, WM_CF_SHOW, SLIDER_CF_VERTICAL/*WM_CF_MEMDEV*/, eMtnVertSliderId);
	//	WM_SetCallback(mtnVerticalSlider, VerSliderCallback);
	//	//init home button
	//	mtnTitleBar = BUTTON_CreateEx(TITLE_BAR_X, TITLE_BAR_Y, TITLE_BAR_LENGTH, TITLE_BAR_HEIGHT, maintenanceScreen, WM_CF_SHOW, 0, eMtnTitleBarId);
	//	WM_SetCallback(mtnTitleBar, TitleBarCallback);
	//	//init information dialog
	//	InforDlgInit();
	//	//init reset time button
	//	resetTimeBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*5, BUTTON_LENGTH, BUTTON_HEIGHT, maintenanceScreen, WM_CF_SHOW, WM_CF_MEMDEV, eResetTimeUsingBtnId);
	//	WM_SetCallback(resetTimeBtn, ConfirmBtnCallback);
	//	//init time setting button
	//	TimeDialogInit();
	//	//init language setting
	//	languageSettingBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*6, BUTTON_LENGTH, BUTTON_HEIGHT, maintenanceScreen, WM_CF_SHOW, WM_CF_MEMDEV, eLanguageSettingBtnId);
	//	WM_SetCallback(languageSettingBtn, SettingBtnCallback);
	//	//init brightness adjust button
	//	brightnessAdjBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*7, BUTTON_LENGTH, BUTTON_HEIGHT, maintenanceScreen, WM_CF_SHOW, WM_CF_MEMDEV, eBrightnessAdjustBtnId);
	//	WM_SetCallback(brightnessAdjBtn, SettingBtnCallback);
	//	//init display off timer button
	//	displayOffTimerBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*7, BUTTON_LENGTH, BUTTON_HEIGHT, maintenanceScreen, WM_CF_SHOW, WM_CF_MEMDEV, eDisplayOffTimerBtnId);
	//	WM_SetCallback(displayOffTimerBtn, SettingBtnCallback);
	//	//init change unit button
	//	changeUnitBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*8, BUTTON_LENGTH, BUTTON_HEIGHT, maintenanceScreen, WM_CF_SHOW, WM_CF_MEMDEV, eChangeUnitBtnId);
	//	WM_SetCallback(changeUnitBtn, SettingBtnCallback);
	//	//init reset button
	//	resetBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*9, BUTTON_LENGTH, BUTTON_HEIGHT, maintenanceScreen, WM_CF_SHOW, WM_CF_MEMDEV, eResetBtnId);
	//	WM_SetCallback(resetBtn, ConfirmBtnCallback);
	//	//init main unit upgrade button
	//	mainUnitUpgradeBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*9, BUTTON_LENGTH, BUTTON_HEIGHT, maintenanceScreen, WM_CF_SHOW, WM_CF_MEMDEV, eMainUnitUpgradeBtnId);
	//	WM_SetCallback(mainUnitUpgradeBtn, ConfirmBtnCallback);
	//	//init blower upgrade button
	//	blowerUpgradeBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*10, BUTTON_LENGTH, BUTTON_HEIGHT, maintenanceScreen, WM_CF_SHOW, WM_CF_MEMDEV, eBlowerUpgradeBtnId);
	//	WM_SetCallback(blowerUpgradeBtn, ConfirmBtnCallback);
	//	//init ble Unit Upgrade
	//	bleUnitUpgrade = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*10, BUTTON_LENGTH, BUTTON_HEIGHT, maintenanceScreen, WM_CF_SHOW, WM_CF_MEMDEV, eBLEUnitUpgradeBtnId);
	//	WM_SetCallback(bleUnitUpgrade, ConfirmBtnCallback);
	//	//init button exporting log data
	//	exportLogBtn = BUTTON_CreateEx(BUTTON_X, BUTTON_Y*11, BUTTON_LENGTH, BUTTON_HEIGHT, maintenanceScreen, WM_CF_SHOW, WM_CF_MEMDEV, eExportLogBtnId);
	//	WM_SetCallback(exportLogBtn, ConfirmBtnCallback);
	//
	//	//create button list
	//	buttonList[0] = mtnTitleBar;
	//	buttonList[1] = informationDialog;
	//	buttonList[2] = resetTimeBtn;
	//	buttonList[3] = timeSettingDialog;
	//	buttonList[4] = brightnessAdjBtn;
	//	buttonList[5] = displayOffTimerBtn;
	//	buttonList[6] = languageSettingBtn;
	//	buttonList[7] = changeUnitBtn;
	//	buttonList[8] = resetBtn;
	//	buttonList[9] = mainUnitUpgradeBtn;
	//	buttonList[10] = blowerUpgradeBtn;
	//	buttonList[11] = bleUnitUpgrade;
	//	buttonList[12] = exportLogBtn;

	testMaintenanceScrInit = 1000;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: MTNScrCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		The callback function of health care worker setting dialog
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void FactoryScrCallback(WM_MESSAGE * pMsg)
{
	//	GUI_RECT Rect;
	switch (pMsg->MsgId) {
	case WM_PAINT:
		//		WM_GetInsideRect(&Rect);
		//		GUI_SetBkColor(MTN_BACKGROUND_COLOR);
		//		GUI_ClearRectEx(&Rect);
		testFactoryScrCallback = WM_PAINT;
		break;
	case WM_KEY:
	{
		switch (((WM_KEY_INFO*)(pMsg->Data.p))->Key) {
		case GUI_KEY_RIGHT:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
			{
				testFactoryScrCallback = GUI_KEY_RIGHT;
				FactoryHandleRightKey(eFirstSettingBtnId,eDialogState);
			}
			break;
		case GUI_KEY_LEFT:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
			{
				testFactoryScrCallback = GUI_KEY_LEFT;
				FactoryHandleLeftKey(eDialogState);
			}
			break;
		case GUI_KEY_HOME:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
			{
				testFactoryScrCallback = GUI_KEY_HOME;
				FactoryHandleEnterKey(eDialogState);
			}
			break;
		}
	}
	break;
	//	case WM_TIMER:
	//		if(WM_GetTimerId(pMsg->Data.v) == 0)
	//		{
	//			//pull the reset pin to zero
	//			DigitalOutputSetState(OUTPUT_PORT, RESET_PIN, 0);
	//			//delete timer
	//			WM_DeleteTimer(pMsg->Data.v);
	//		}
	//		break;
	default:
		//		WM_DefaultProc(pMsg);
		testFactoryScrCallback = 1007;
		break;
	}
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: FactoryHandleEnterKey()
//
//    Processing:
//		The function operates when a enter key is received
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void FactoryHandleEnterKey(E_SettingScreenState state)
{
	currentState = state;
	//get current ID
	currentId = WM_GetId(nullptr);
	switch (currentState)
	{
	case eSettingBarState:
	{
		if((currentId >= eFirstSettingBtnId)&&(currentId <= eLastSettingBtnId))
		{
			//			WM_SetFocus(maintenanceScreen);							//focus mtn
			SettingBtnSetStatusMocks(nullptr, ePoint);//SettingBtnSetStatus(buttonList[currentItem1], ePoint);	//point to current setting
			//			WM_Paint(buttonList[currentItem1]);
			currentState = eDialogState;							//change state of mtn
			testState = currentState;
			//			WM_SetYSize(buttonList[currentItem1], BUTTON_HEIGHT);	//resize current setting
			if(isLogSetting1 == true)
			{
				SettingbtnLogMocks(nullptr);//SettingbtnLog(buttonList[currentItem1]);
				isLogSetting1 = false;
			}
			//set end item
			endItem1 = preEndSetting1;
			//relayout
			FactoryReLayout();
		}
	}
	break;
	case eDialogState:
	{
		if(currentId == eMtnTitleBarId)
		{
			SettingSaveMocks();//SettingSave();					//save setting to EEPROM
			GuiTaskSendEvent(eGuiChangeToOperScreenId, 0);
		}
		else if((currentId >= eFirstSettingBtnId)&&(currentId <= eLastSettingBtnId))
		{
			//change state
			currentState = eSettingBarState;
			testState = currentState;
			//repaint current item
			//			WM_SetYSize(buttonList[currentItem1], EXPAND_BUTTON_HEIGHT);
			SettingBtnSetStatusMocks(nullptr, eEnter);//SettingBtnSetStatus(buttonList[currentItem1], eEnter);
			//			WM_Paint(buttonList[currentItem1]);
			//set previous end setting
			preEndSetting1 = endItem1;
			if(currentItem1 < endItem1)
				endItem1 = endItem1 - 1;
			//relayout screen
			FactoryReLayout();
		}
		else if(currentId == eTimeSettingBtnId)
		{
			//change state
			currentState = eSettingBarState;
			testState = currentState;
			//enter time setting
			//			WM_SetFocus(timeSettingDialog);
			TimeDialogReloadMocks();//TimeDialogReload();
			TimeDialogSetStatusMocks(eEnter);//TimeDialogSetStatus(eEnter);
			//			WM_Paint(timeSettingDialog);
			//set previous end setting
			preEndSetting1 = endItem1;
			//handle end item
			if(currentItem1 == endItem1 - 1)
			{
				endItem1 = endItem1 - 1;
			}
			else if(currentItem1 < endItem1 - 1)
			{
				endItem1 = endItem1 - 2;
			}
			//relayout
			FactoryReLayout();
		}
		else if(currentId == eResetBtnId)
			GuiTaskSendEvent(eGuiPopupRestoreDefaultsShowId, 0);
		else if(currentId == eResetTimeUsingBtnId)
			GuiTaskSendEvent(eGuiPopupClearUsedHoursShowId, 0);
		else if(currentId == eMainUnitUpgradeBtnId)
			GuiTaskSendEvent(eGuiPopupControlUpgradeShowId, 0);
		else if(currentId == eBlowerUpgradeBtnId)
			GuiTaskSendEvent(eGuiPopupMotorUpgradeShowId, 0);
		else if(currentId == eBLEUnitUpgradeBtnId)
			GuiTaskSendEvent(eGuiBLEUpgradeShowId, 0);
		else if(currentId == eExportLogBtnId)
			GuiTaskSendEvent(eGuiPopupExportLogShowId, 0);
	}
	break;
	default:
		break;
	}
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: MTNRightKeyHandle()
//
//    Processing:
//		The function operates when a right key is received
//
//    Input Parameters:
//		WM_HWIN hWin
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void FactoryHandleLeftKey(E_SettingScreenState state)
{
	//get current ID
	currentId = eLastSettingBtnId;//WM_GetId(buttonList[currentItem1]);
	currentState = state;
	switch(currentState)
	{
	case eDialogState:
		//increase current item
		currentItem1++;
		if(currentItem1 >= MTN_NUM_BUTTON)
		{
			currentItem1 = 0;
			secondItem1 = 1;	//front item is information dialog
			endItem1 = 2;
		}
		else if(currentItem1 > endItem1)
		{
			endItem1 = currentItem1;
			if((endItem1 == 3) || (endItem1 == 4))
				secondItem1 = 1;	//front setting is information dialog
			else
				secondItem1 = endItem1 - 4;
		}
		//change status for all items
		FactorySetItemStatus();
		//relayout
		FactoryReLayout();
		//update slider
		if(currentItem1 > 0)
			SliderUpdateMocks(nullptr, currentItem1 - 1);//SliderUpdate(mtnVerticalSlider, currentItem1 - 1);
		else
			SliderUpdateMocks(nullptr, 0);//SliderUpdate(mtnVerticalSlider, 0);
		break;
	case eSettingBarState:
		if((currentId >= eFirstSettingBtnId)&&(currentId <= eLastSettingBtnId))
		{
			isLogSetting1 = true;
			//decrease setting value
			SettingBtnDecThumpPosMocks(nullptr);//SettingBtnDecThumpPos(buttonList[currentItem1]);
		}
		break;
	default:
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: FactoryHandleRightKey()
//
//    Processing:
//		The function operates when a left key is received
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void FactoryHandleRightKey(short id, E_SettingScreenState state)
{
	//get current ID
	currentId = id;//eFirstSettingBtnId;//WM_GetId(buttonList[currentItem1]);
	currentState = state;
	switch(currentState)
	{
	case eDialogState:
		//increase current item
		currentItem1--;
		if(currentItem1 < 0)
		{
			currentItem1 = MTN_NUM_BUTTON - 1;
			endItem1 = currentItem1;
			secondItem1 = endItem1 - 4;
		}
		else if(currentItem1 == 0)
		{
			//front item is information dialog
			secondItem1 = 1;
			endItem1 = 2;
		}
		else if(currentItem1 < secondItem1)
		{
			secondItem1 = currentItem1;
			if(secondItem1 == 1)
				endItem1 = 2;
			else
				endItem1 = secondItem1 + 4;
		}
		//change item status
		FactorySetItemStatus();
		//relayout
		FactoryReLayout();
		//update slider
		//update slider
		if(currentItem1 > 0)
			SliderUpdateMocks(nullptr, currentItem1 - 1);//SliderUpdate(mtnVerticalSlider, currentItem1 - 1);
		else
			SliderUpdateMocks(nullptr, 0);//SliderUpdate(mtnVerticalSlider, 0);
		break;
	case eSettingBarState:
		if((currentId >= eFirstSettingBtnId)&&(currentId <= eLastSettingBtnId))
		{
			isLogSetting1 = true;
			SettingBtnIncThumpPosMocks(nullptr);//SettingBtnIncThumpPos(buttonList[currentItem1]);	//decrease thump position of setting bar
		}
		break;
	default:
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: MTNSetBtnStatus()
//
//    Processing:
//		The function is to set status for all button
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void FactorySetItemStatus()
{
	int id;
	for(int i = 0; i <= endItem1; i++)
	{
		//get id
		id = WM_GetId(nullptr);//(buttonList[i]);

		if((id >= eFirstSettingBtnId)&&(id <= eLastSettingBtnId))
		{
			if(id == WM_GetId(nullptr))//WM_GetId(buttonList[currentItem1]))
				SettingBtnSetStatusMocks(nullptr, ePoint);//SettingBtnSetStatus(buttonList[currentItem1], ePoint);
			else
				SettingBtnSetStatusMocks(nullptr, eRelease);//SettingBtnSetStatus(buttonList[i], eRelease);
		}
		else if((id >= eFirstConfirmBtnId)&&(id <= eLastConfirmBtnId))
		{
			//focus current confirm button and release others
			if(id == WM_GetId(nullptr))//WM_GetId(buttonList[currentItem1]))
				ConfirmBtnSetStatus(nullptr,ePoint);//(buttonList[currentItem1], ePoint);
			else
				ConfirmBtnSetStatus(nullptr,eRelease);//(buttonList[i], eRelease);
		}
		else if(id == eInformationDlgId)
		{
			if(id == WM_GetId(nullptr))//WM_GetId(buttonList[currentItem1]))
				InforDlgSetStatus(ePoint);
			else
				InforDlgSetStatus(eRelease);
		}
		else if(id == eTimeSettingBtnId)
		{
			if(id == WM_GetId(nullptr))//WM_GetId(buttonList[currentItem1]))
				TimeDialogSetStatusMocks(ePoint);//TimeDialogSetStatus(ePoint);
			else
				TimeDialogSetStatusMocks(eRelease);//TimeDialogSetStatus(eRelease);
		}
		else if(id == eMtnTitleBarId)
		{
			if(id == WM_GetId(nullptr))//WM_GetId(buttonList[currentItem1]))
				TitleBarSetStatusMocks(nullptr, ePoint);//TitleBarSetStatus(mtnTitleBar, ePoint);
			else
				TitleBarSetStatusMocks(nullptr, eRelease);//TitleBarSetStatus(mtnTitleBar, eRelease);
		}
		//repaint item
		//		WM_Paint(buttonList[i]);
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: FactoryReLayout()
//
//    Processing:
//		The function layouts all items of factory screen
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void FactoryReLayout()
{
	//show items from front to end and hide the rest
	for(int i = 1; i < MTN_NUM_BUTTON; i++)
	{
		if((i >= secondItem1) && (i <= endItem1))
		{
			//			WM_ShowWindow(buttonList[i]);
			testFactoryReLayout--;
		}
		else
		{
			//			WM_HideWindow(buttonList[i]);
			testFactoryReLayout++;
		}
	}
	//set new position for the end setting
	//	WM_MoveChildTo(buttonList[endItem1], 0 , SETTING_SCREEN_HEIGHT - WM_GetYSize(buttonList[endItem1]) - INVISIBLE_SPACE_HEIGHT);
	//layout others
	for(int i = endItem1; i > secondItem1; i--)
	{
		//		WM_MoveChildTo(buttonList[i-1], 0, WM_GetWinOrgY(buttonList[i]) - WM_GetYSize(buttonList[i-1]) - SETTING_SCREEN_Y);
		testFactoryReLayout++;
	}
	//bring title bar to top
	//	WM_BringToTop(mtnTitleBar);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: MtnSetFocus()
//
//    Processing:
//		This operation restarts the maintenance screen
//
//    Input Parameters:
//		WM_HWIN hDlg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void MaintenanceScrReload()
{
	//reload system information dialog
	SystemInfortableReloadMocks();//SystemInfortableReload();
	//set language button
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(eLanguageSettingId));//SettingBtnSetValue(languageSettingBtn, SettingGet(eLanguageSettingId));
	//set brightness button
	SettingBtnSetValueMocks(nullptr, (SettingGetMocks(eBrightnessSettingId)-PWM_LCDBL_MIN)/PWM_LCDBL_STEP);//SettingBtnSetValue(brightnessAdjBtn, (SettingGet(eBrightnessSettingId)-PWM_LCDBL_MIN)/PWM_LCDBL_STEP);
	//set screen timout button
	SettingBtnSetValueMocks(nullptr, (SettingGetMocks(eSleepTimerSettingId)));//SettingBtnSetValue(displayOffTimerBtn, (SettingGet(eSleepTimerSettingId)));
	//set unit option button
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(ePressUnitSettingId));//SettingBtnSetValue(changeUnitBtn, SettingGet(ePressUnitSettingId));
	//set max for slider
	SliderSetMaxMocks(nullptr, MTN_NUM_BUTTON - 2);//SliderSetMax(mtnVerticalSlider, MTN_NUM_BUTTON - 2);
	//set current state
	currentState = eDialogState;
	testState = currentState;
	//set front setting
	secondItem1 = 1;
	//set end setting
	endItem1 = 2;
	//set current setting
	currentItem1 = 0;
	//relayout factory screen
	FactoryReLayout();
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: MaintenanceScrHandleEvent(GuiEventStruct guiEvent)
//
//    Processing:
//		This operation handles all events sent to maintanance screen
//
//    Input Parameters:
//		GuiEventStruct guiEvent
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void MaintenanceScrHandleEvent(GuiEventStruct guiEvent)
{
	switch(guiEvent.id)
	{
	case eGuiFactoryRestoreDefaultsId:
		//reload system information dialog
		SystemInfortableReloadMocks();//SystemInfortableReload();
		//set brightness
		SettingBtnSetValueMocks(nullptr, (SettingGetMocks(eBrightnessSettingId)-PWM_LCDBL_MIN)/PWM_LCDBL_STEP);//SettingBtnSetValue(brightnessAdjBtn, (SettingGet(eBrightnessSettingId)-PWM_LCDBL_MIN)/PWM_LCDBL_STEP);
		PWMSetDutyMocks(ePWMLCDBLId, SettingGetMocks(eBrightnessSettingId));//PWMSetDuty(ePWMLCDBLId, SettingGet(eBrightnessSettingId));
		//get sleep timeout
		SettingBtnSetValueMocks(nullptr, SettingGetMocks(eSleepTimerSettingId));//SettingBtnSetValue(displayOffTimerBtn, SettingGet(eSleepTimerSettingId));
		//get language
		SettingBtnSetValueMocks(nullptr, SettingGetMocks(eLanguageSettingId));//SettingBtnSetValue(languageSettingBtn, SettingGet(eLanguageSettingId));
		//get unit
		SettingBtnSetValueMocks(nullptr, (SettingGetMocks(ePressUnitSettingId)));//SettingBtnSetValue(changeUnitBtn, (SettingGet(ePressUnitSettingId)));
		//repaint factory screen
		//		WM_Paint(maintenanceScreen);
		break;
	case eGuiFactoryClearUsedHoursId:
		//reload system information dialog
		SystemInfortableReloadMocks();//SystemInfortableReload();
		break;
	case eGuiFactoryRepaint:
		//reload system information dialog
		SystemInfortableReloadMocks();//SystemInfortableReload();
		//repaint factory screen
		//		WM_Paint(maintenanceScreen);
		break;
	case eGuiFactoryReleaseTimeSettingId:
		//set new state
		currentState = eDialogState;
		testState = currentState;
		//focus time dialog
		TimeDialogSetStatusMocks(ePoint);//TimeDialogSetStatus(ePoint);
		//set end setting
		endItem1 = preEndSetting1;
		//relayout user screen
		FactoryReLayout();
		break;
	default:
		break;
	}
}

#if defined(__cplusplus)
}
#endif

