/*
 * maintenancescreen.h
 *
 *  Created on: Apr 17, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_GUI_MAINTENANCESCREEN_H_
#define UNITTEST_GUI_MAINTENANCESCREEN_H_

#include <guiinterface.h>

#include "WM.h"
//#include "GUI.h"
#include "guidefine.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//extern WM_HWIN maintenanceScreen;

void FactoryScrCallback(WM_MESSAGE * pMsg);
void FactoryHandleEnterKey(E_SettingScreenState state);
void FactoryHandleLeftKey(E_SettingScreenState state);
void FactoryHandleRightKey(short id, E_SettingScreenState state);
void FactorySetItemStatus();
void FactoryReLayout();
void MaintenanceScrInit(void);
void MaintenanceScrHandleEvent(GuiEventStruct guiEvent);
void MaintenanceScrReload();


#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_MAINTENANCESCREEN_H_ */
