/*
 * maintenancescreenTest.cpp
 *
 *  Created on: Apr 17, 2018
 *      Author: QUOCVIET
 */

#include "stdafx.h"
#include "Fixture.h"
#include "maintenancescreen.h"

#include <setting.h>

#include "WM.h"
#include "PWMLib.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern int testMaintenanceScrInit;
extern int testFactoryReLayout;
extern int testFactoryScrCallback;
extern bool isLogSetting1;
extern E_SettingScreenState testState;
extern short endItem1;
extern short currentItem1;
//extern short preEndSetting1;
extern short secondItem1;
extern int testConfirmBtnSetStatus;

namespace EmbeddedCUnitTest {


class MaintenanceScreenTest : public TestFixture
{
public:
	MaintenanceScreenTest() : TestFixture(new ModuleMock) {}
};



TEST_F(MaintenanceScreenTest, MaintenanceScrInit)
{
	MaintenanceScrInit();
	EXPECT_EQ(1000,testMaintenanceScrInit);
}

TEST_F(MaintenanceScreenTest, FactoryScrCallback1)
{
	WM_MESSAGE *pMsg = new WM_MESSAGE;
	pMsg->MsgId = WM_PAINT;
	FactoryScrCallback(pMsg); // @suppress("Invalid arguments")
	EXPECT_EQ(WM_PAINT,testFactoryScrCallback);
}

TEST_F(MaintenanceScreenTest, FactoryScrCallback2)
{
	WM_MESSAGE *pMsg = new WM_MESSAGE;
	WM_KEY_INFO *keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_RIGHT;
	keyData->PressedCnt = 1;
	pMsg->MsgId = WM_KEY;
	pMsg->Data.p = keyData;
	FactoryScrCallback(pMsg);// @suppress("Invalid arguments")
	EXPECT_EQ(GUI_KEY_RIGHT,testFactoryScrCallback);
}

TEST_F(MaintenanceScreenTest, FactoryScrCallback3)
{
	WM_MESSAGE *pMsg = new WM_MESSAGE;
	WM_KEY_INFO *keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_LEFT;
	keyData->PressedCnt = 1;
	pMsg->MsgId = WM_KEY;
	pMsg->Data.p = keyData;
	FactoryScrCallback(pMsg);// @suppress("Invalid arguments")
	EXPECT_EQ(GUI_KEY_LEFT,testFactoryScrCallback);
}

TEST_F(MaintenanceScreenTest, FactoryScrCallback4)
{
	WM_MESSAGE *pMsg = new WM_MESSAGE;
	WM_KEY_INFO *keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_HOME;
	keyData->PressedCnt = 1;
	pMsg->MsgId = WM_KEY;
	pMsg->Data.p = keyData;
	FactoryScrCallback(pMsg);// @suppress("Invalid arguments")
	EXPECT_EQ(GUI_KEY_HOME,testFactoryScrCallback);
}

TEST_F(MaintenanceScreenTest, FactoryScrCallback5)
{
	WM_MESSAGE *pMsg = new WM_MESSAGE;
	pMsg->MsgId = WM_KEY + WM_PAINT;
	FactoryScrCallback(pMsg);// @suppress("Invalid arguments")
	EXPECT_EQ(1007,testFactoryScrCallback);
}

TEST_F(MaintenanceScreenTest, FactoryHandleEnterKey1)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eFirstSettingBtnId));
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_,ePoint)).Times(1);

	isLogSetting1 = false;
	FactoryHandleEnterKey(eSettingBarState);
	EXPECT_EQ(eDialogState,testState);
}

TEST_F(MaintenanceScreenTest, FactoryHandleEnterKey2)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eFirstSettingBtnId));
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_,ePoint)).Times(1);
	EXPECT_CALL(*_settingBtnLib,SettingbtnLogMocks(_)).Times(1);

	isLogSetting1 = true;
	FactoryHandleEnterKey(eSettingBarState);
	EXPECT_EQ(false,isLogSetting1);
	EXPECT_EQ(eDialogState,testState);
}

TEST_F(MaintenanceScreenTest, FactoryHandleEnterKey3)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eMtnTitleBarId));
	EXPECT_CALL(*_settingLib,SettingSaveMocks()).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	FactoryHandleEnterKey(eDialogState);
}

TEST_F(MaintenanceScreenTest, FactoryHandleEnterKey4)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eLastSettingBtnId));
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_,eEnter)).Times(1);

	currentItem1 = 5;
	endItem1 = 6;
	FactoryHandleEnterKey(eDialogState);
	EXPECT_EQ(eSettingBarState,testState);
	EXPECT_EQ(5,endItem1);
}

TEST_F(MaintenanceScreenTest, FactoryHandleEnterKey5)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eTimeSettingBtnId));
	EXPECT_CALL(*_TimeDialogLib,TimeDialogReloadMocks()).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeDialogSetStatusMocks(eEnter)).Times(1);

	currentItem1 = 5;
	endItem1 = 8;
	FactoryHandleEnterKey(eDialogState);
	EXPECT_EQ(eSettingBarState,testState);
	EXPECT_EQ(6,endItem1);
}

TEST_F(MaintenanceScreenTest, FactoryHandleEnterKey6)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eResetBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	FactoryHandleEnterKey(eDialogState);
}

TEST_F(MaintenanceScreenTest, FactoryHandleEnterKey7)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eResetTimeUsingBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	FactoryHandleEnterKey(eDialogState);
}

TEST_F(MaintenanceScreenTest, FactoryHandleEnterKey8)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eMainUnitUpgradeBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	FactoryHandleEnterKey(eDialogState);
}

TEST_F(MaintenanceScreenTest, FactoryHandleEnterKey9)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eBlowerUpgradeBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	FactoryHandleEnterKey(eDialogState);
}

TEST_F(MaintenanceScreenTest, FactoryHandleEnterKey10)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eBLEUnitUpgradeBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	FactoryHandleEnterKey(eDialogState);
}

TEST_F(MaintenanceScreenTest, FactoryHandleEnterKey11)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eExportLogBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	FactoryHandleEnterKey(eDialogState);
}

TEST_F(MaintenanceScreenTest, FactoryHandleLeftKey1)
{
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,0)).Times(1);

	currentItem1 = 15;
	FactoryHandleLeftKey(eDialogState);
	EXPECT_EQ(0,currentItem1);
	EXPECT_EQ(1,secondItem1);
	EXPECT_EQ(2,endItem1);
}

TEST_F(MaintenanceScreenTest, FactoryHandleLeftKey2)
{
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,2)).Times(1);

	currentItem1 = 2;
	endItem1 = 1;
	FactoryHandleLeftKey(eDialogState);
	EXPECT_EQ(3,currentItem1);
	EXPECT_EQ(1,secondItem1);
	EXPECT_EQ(3,endItem1);
}

TEST_F(MaintenanceScreenTest, FactoryHandleLeftKey3)
{
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,3)).Times(1);

	currentItem1 = 3;
	endItem1 = 2;
	FactoryHandleLeftKey(eDialogState);
	EXPECT_EQ(4,currentItem1);
	EXPECT_EQ(1,secondItem1);
	EXPECT_EQ(4,endItem1);
}

TEST_F(MaintenanceScreenTest, FactoryHandleLeftKey4)
{
	EXPECT_CALL(*_settingBtnLib,SettingBtnDecThumpPosMocks(_)).Times(1);

	FactoryHandleLeftKey(eSettingBarState);
	EXPECT_EQ(true,isLogSetting1);
}

TEST_F(MaintenanceScreenTest, FactoryHandleRightKey1)
{
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,11)).Times(1);

	currentItem1 = 0;
	FactoryHandleRightKey(eFirstSettingBtnId,eDialogState);
	EXPECT_EQ(12,currentItem1);
	EXPECT_EQ(12,endItem1);
	EXPECT_EQ(8,secondItem1);

}

TEST_F(MaintenanceScreenTest, FactoryHandleRightKey2)
{
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,0)).Times(1);

	currentItem1 = 2;
	secondItem1 = 2;
	FactoryHandleRightKey(eFirstSettingBtnId,eDialogState);
	EXPECT_EQ(1,currentItem1);
	EXPECT_EQ(2,endItem1);
	EXPECT_EQ(1,secondItem1);
}

TEST_F(MaintenanceScreenTest, FactoryHandleRightKey3)
{
	EXPECT_CALL(*_SliderLib,SliderUpdateMocks(_,1)).Times(1);

	currentItem1 = 3;
	secondItem1 = 3;
	FactoryHandleRightKey(eFirstSettingBtnId,eDialogState);
	EXPECT_EQ(2,currentItem1);
	EXPECT_EQ(6,endItem1);
	EXPECT_EQ(2,secondItem1);
}

TEST_F(MaintenanceScreenTest, FactoryHandleRightKey4)
{
	EXPECT_CALL(*_settingBtnLib,SettingBtnIncThumpPosMocks(_)).Times(1);

	FactoryHandleRightKey(eExhSupBtnId,eSettingBarState);
	EXPECT_EQ(true,isLogSetting1);
}

TEST_F(MaintenanceScreenTest, FactorySetItemStatus1)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(eFirstSettingBtnId)).WillOnce(Return(eFirstSettingBtnId));
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_,ePoint)).Times(1);

	endItem1 = 0;
	FactorySetItemStatus();
}

TEST_F(MaintenanceScreenTest, FactorySetItemStatus2)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(eFirstSettingBtnId)).WillOnce(Return(eFirstSettingBtnId + 1));
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_,eRelease)).Times(1);

	endItem1 = 0;
	FactorySetItemStatus();
}

TEST_F(MaintenanceScreenTest, FactorySetItemStatus3)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(eFirstConfirmBtnId)).WillOnce(Return(eFirstConfirmBtnId));

	endItem1 = 0;
	FactorySetItemStatus();
	EXPECT_EQ(ePoint,testConfirmBtnSetStatus);
}

TEST_F(MaintenanceScreenTest, FactorySetItemStatus4)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(eFirstConfirmBtnId)).WillOnce(Return(eFirstConfirmBtnId + 1));

	endItem1 = 0;
	FactorySetItemStatus();
	EXPECT_EQ(eRelease,testConfirmBtnSetStatus);
}

TEST_F(MaintenanceScreenTest, FactorySetItemStatus5)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(eInformationDlgId)).WillOnce(Return(eInformationDlgId));
	EXPECT_CALL(*_InforDlgLib,InforDlgSetStatus(ePoint)).Times(1);

	endItem1 = 0;
	FactorySetItemStatus();
}

TEST_F(MaintenanceScreenTest, FactorySetItemStatus6)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(eInformationDlgId)).WillOnce(Return(eInformationDlgId + 1));
	EXPECT_CALL(*_InforDlgLib,InforDlgSetStatus(eRelease)).Times(1);

	endItem1 = 0;
	FactorySetItemStatus();
}

TEST_F(MaintenanceScreenTest, FactorySetItemStatus7)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(eTimeSettingBtnId)).WillOnce(Return(eTimeSettingBtnId));
	EXPECT_CALL(*_TimeDialogLib,TimeDialogSetStatusMocks(ePoint)).Times(1);

	endItem1 = 0;
	FactorySetItemStatus();
}

TEST_F(MaintenanceScreenTest, FactorySetItemStatus8)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(eTimeSettingBtnId)).WillOnce(Return(eTimeSettingBtnId + 1));
	EXPECT_CALL(*_TimeDialogLib,TimeDialogSetStatusMocks(eRelease)).Times(1);

	endItem1 = 0;
	FactorySetItemStatus();
}

TEST_F(MaintenanceScreenTest, FactorySetItemStatus9)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(eMtnTitleBarId)).WillOnce(Return(eMtnTitleBarId));
	EXPECT_CALL(*_TitleBarLib,TitleBarSetStatusMocks(_,ePoint)).Times(1);

	endItem1 = 0;
	FactorySetItemStatus();
}

TEST_F(MaintenanceScreenTest, FactorySetItemStatus10)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(eMtnTitleBarId)).WillOnce(Return(eMtnTitleBarId + 1));
	EXPECT_CALL(*_TitleBarLib,TitleBarSetStatusMocks(_,eRelease)).Times(1);

	endItem1 = 0;
	FactorySetItemStatus();
}

TEST_F(MaintenanceScreenTest, FactoryReLayout)
{
	FactoryReLayout();
	EXPECT_EQ(111,testFactoryReLayout);
}

TEST_F(MaintenanceScreenTest, MaintenanceScrReload)
{
	EXPECT_CALL(*_SysInforTableLib,SystemInfortableReloadMocks()).Times(1);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetValueMocks(_,_)).Times(4);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eLanguageSettingId)).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eBrightnessSettingId)).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eSleepTimerSettingId)).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(ePressUnitSettingId)).Times(1);
	EXPECT_CALL(*_SliderLib,SliderSetMaxMocks(_,_)).Times(1);

	MaintenanceScrReload();
	EXPECT_EQ(eDialogState,testState);
	EXPECT_EQ(1,secondItem1);
	EXPECT_EQ(2,endItem1);
	EXPECT_EQ(0,currentItem1);
	EXPECT_EQ(120,testFactoryReLayout);
}

TEST_F(MaintenanceScreenTest, MaintenanceScrHandleEvent1)
{
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiFactoryRestoreDefaultsId;

	EXPECT_CALL(*_SysInforTableLib,SystemInfortableReloadMocks()).Times(1);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetValueMocks(_,_)).Times(4);
	EXPECT_CALL(*_PWMLib,PWMSetDutyMocks(ePWMLCDBLId,_)).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eBrightnessSettingId)).Times(2);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eSleepTimerSettingId)).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eLanguageSettingId)).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(ePressUnitSettingId)).Times(1);

	MaintenanceScrHandleEvent(guiEvent);
}

TEST_F(MaintenanceScreenTest, MaintenanceScrHandleEvent2)
{
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiFactoryClearUsedHoursId;

	EXPECT_CALL(*_SysInforTableLib,SystemInfortableReloadMocks()).Times(1);

	MaintenanceScrHandleEvent(guiEvent);
}

TEST_F(MaintenanceScreenTest, MaintenanceScrHandleEvent3)
{
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiFactoryRepaint;

	EXPECT_CALL(*_SysInforTableLib,SystemInfortableReloadMocks()).Times(1);

	MaintenanceScrHandleEvent(guiEvent);
}

TEST_F(MaintenanceScreenTest, MaintenanceScrHandleEvent4)
{
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiFactoryReleaseTimeSettingId;

	EXPECT_CALL(*_TimeDialogLib,TimeDialogSetStatusMocks(ePoint)).Times(1);

	MaintenanceScrHandleEvent(guiEvent);
	EXPECT_EQ(eDialogState,testState);
	EXPECT_EQ(8,endItem1);
	EXPECT_EQ(123,testFactoryReLayout);
}

}



