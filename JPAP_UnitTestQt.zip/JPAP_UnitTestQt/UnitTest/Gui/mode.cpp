/*
 * mode.cpp
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#include "mode.h"

//declare current mode
E_ModeId currentMode;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//initialize mode as standby mode
void ModeInit()
{
	currentMode = eStandbyMode;
}

//update current mode
//void ModeSet(E_ModeId mode)
//{
//	currentMode = mode;
//}

//get current mode
E_ModeId ModeGet()
{
	return currentMode;
}

#if defined(__cplusplus)
}
#endif


