/*
 * mode.h
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_GUI_MODE_H_
#define UNITTEST_GUI_MODE_H_

//define all mode require for Swell
typedef enum
{
	eStandbyMode = 0,
	eOperationMode,
	ePtSettingMode,		//patient setting
	eHcwSettingMode,	//health care worker setting mode
	eHistoryMode,		//history mode screen
	eMaintenanceMode,	//maintenance mode screen
//	eAlarmMode,
} E_ModeId;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void ModeInit();
//void ModeSet(E_ModeId mode);
E_ModeId ModeGet();

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_GUI_MODE_H_ */
