/*
 * modeTest.cpp
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#include "stdafx.h"
#include "Fixture.h"
#include "mode.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern E_ModeId currentMode;

namespace EmbeddedCUnitTest {


class ModeTest : public TestFixture
{
public:
	ModeTest() : TestFixture(new ModuleMock) {}
};

TEST_F(ModeTest, ModeInit)
{
	ModeInit();
	EXPECT_EQ(eStandbyMode,currentMode);
}

TEST_F(ModeTest, ModeGet)
{
	EXPECT_EQ(eStandbyMode,ModeGet());
}

}


