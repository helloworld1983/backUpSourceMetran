/*
 * operationscreen.cpp
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#include <stdbool.h>
//#include "sleepscreen.h"
//#include "userdatalog.h"
#include "stdlib.h"
#include "operationscreen.h"

#include <guiinterface.h>
#include <motorctrlinterface.h>
#include <setting.h>
#include <systeminterface.h>

#include "mode.h"
//#include "usersettingdialog.h"
#include "clinicscreen.h"
#include "mainscreen.h"
#include "historyscreen.h"
#include "maintenancescreen.h"
#include "alarmdialog.h"
#include "WM.h"
//#include "IMAGE.h"
//#include "TEXT.h"
//#include "PROGBAR.h"
//#include "BUTTON.h"
#include "guidefine.h"
#include "strings.h"
#include "alarminterface.h"
//#include "systemconfig.h"
//#include "rtc.h"
//#include "systeminformation.h"
//#include "pwm.h"
//#include "softtimer.h"
#include "guiglobal.h"
#include "loadingscreen.h"
#include "dryscreen.h"
#include "AnalyzeDataMocks.h"
#include "WString.h"
#include "PROGBARMocks.h"
#include "UserSettingMocks.h"
#include "SettingMocks.h"
#include "SoftTimerMocks.h"
#include "SleepScrMocks.h"

#if SUPPORT_EVENT_DISPLAY
#include "phase.h"
#include "event.h"
#endif

//1. define ramp image parameters
#define RAMP_IMAGE_X		20
#define RAMP_IMAGE_Y		50
#define RAMP_IMAGE_SIZE_X	85
#define RAMP_IMAGE_SIZE_Y	85
//2. define ramp value label parameters
#define RAMP_VALUE_X		7
#define RAMP_VALUE_Y		45
#define RAMP_VALUE_SIZE_X	70
#define RAMP_VALUE_SIZE_Y	30
//3. define ramp label parameters
#define RAMP_LABEL_X		7
#define RAMP_LABEL_Y		13
#define RAMP_LABEL_SIZE_X 	70
#define RAMP_LABEL_SIZE_Y	30

//4. define natural support image parameters
#define NS_IMAGE_X			5
#define NS_IMAGE_Y			138
#define NS_IMAGE_SIZE_X		110
#define NS_IMAGE_SIZE_Y		60
//5. pressure image definition
#define PRESS_IMAGE_X			125
#define PRESS_IMAGE_Y			0
#define PRESS_IMAGE_SIZE_X		190
#define PRESS_IMAGE_SIZE_Y		190
//6. pressure label definition
#define PRESS_LABEL_X			80
#define PRESS_LABEL_Y			80
#define PRESS_LABEL_SIZE_X		90
#define PRESS_LABEL_SIZE_Y		40
//7. REAL TIME pressure indicator bar definition
#define PRESS_INDICATOR_X		0
#define PRESS_INDICATOR_Y		3
#define PRESS_INDICATOR_SIZE_X	190
#define PRESS_INDICATOR_SIZE_Y	190
//8. pressure indicator bar
#define VERT_PRESS_INDICATOR_X			150
#define VERT_PRESS_INDICATOR_Y			60
#define VERT_PRESS_INDICATOR_SIZE_X		20
#define VERT_PRESS_INDICATOR_SIZE_Y		90
//9. pressure setting definition
#define PRESS_SETTING_X			120
#define PRESS_SETTING_Y			55
#define PRESS_SETTING_SIZE_X	30
#define PRESS_SETTING_SIZE_Y	20
//10. current pressure definition
#define CURR_PRESS_X			80
#define CURR_PRESS_Y			80
#define CURR_PRESS_SIZE_X		75
#define CURR_PRESS_SIZE_Y		50
//11. pressure unit definition
#define PRESS_UNIT_X			110
#define PRESS_UNIT_Y			155
#define PRESS_UNIT_SIZE_X		60
#define PRESS_UNIT_SIZE_Y		25
//12. pressure inhalation setting definition
#define PRESS_INH_LEVEL_X		90
#define PRESS_INH_LEVEL_Y		0
#define PRESS_INH_LEVEL_SIZE_X	25
#define PRESS_INH_LEVEL_SIZE_Y	22
//13. inhalation label definition
#define PRESS_INH_LABEL_X		47
#define PRESS_INH_LABEL_Y		0
#define PRESS_INH_LABEL_SIZE_X	45
#define PRESS_INH_LABEL_SIZE_Y	20
//14. pressure exhalation setting definition
#define PRESS_EXH_LEVEL_X		90
#define PRESS_EXH_LEVEL_Y		32
#define PRESS_EXH_LEVEL_SIZE_X	25
#define PRESS_EXH_LEVEL_SIZE_Y	22
//15. exhalation label definition
#define PRESS_EXH_LABEL_X		47
#define PRESS_EXH_LABEL_Y		32
#define PRESS_EXH_LABEL_SIZE_X	45
#define PRESS_EXH_LABEL_SIZE_Y	20
//16. pressure value real time display
#define PRESS_VALUE_X			65 	//62
#define PRESS_VALUE_Y			145 //147
#define PRESS_VALUE_SIZE_X		50
#define PRESS_VALUE_SIZE_Y		25

//17. ventilation mode label display
#define VENTMODE_LABEL_X		20
#define VENTMODE_LABEL_Y		0
#define VENTMODE_LABEL_SIZE_X	90
#define VENTMODE_LABEL_SIZE_Y	90

#if SUPPORT_EVENT_DISPLAY
#define AVERAGE_VOLUME_X		100
#define AVERAGE_VOLUME_Y		20
#define AVERAGE_VOLUME_LENGTH	40
#define AVERAGE_VOLUME_HEIGHT	20

#define CURRENT_VOLUME_X		150
#define CURRENT_VOLUME_Y		20
#define CURRENT_VOLUME_LENGTH	40
#define CURRENT_VOLUME_HEIGHT	20

#define PERCENTAGE_X			130
#define PERCENTAGE_Y			50
#define PERCENTAGE_LENGTH		40
#define PERCENTAGE_HEIGHT		20

#endif

//18. define color
#define OPER_PRESS_REALTIME_OPERATION_COLOR			COLOR_LIGHT_ORANGE	//color code of real time pressure
//#define OPER_PRESS_REALTIME_STANDBY_COLOR			GUI_WHITE
//#define OPER_TREATMENT_PRESS_COLOR					GUI_WHITE
#define OPER_TREAT_REALPRESS_INDICATOR_COLOR		COLOR_ULTRA_LIGHT_BLUE
#define OPER_TREAT_INDICATOR_COLOR					GUI_WHITE
#define OPER_TRIANGLE_COLOR							GUI_WHITE
#define OPER_SCR_BK_COLOR							0x503008	//background color for main window
//#define OPER_PRESS_UNIT_COLOR						GUI_WHITE
//#define OPER_SETTING_PRESS_COLOR					GUI_WHITE
//#define OPER_INIT_PRESS_COLOR						GUI_WHITE
#define OPER_LOWER_PRESS_COLOR						GUI_WHITE
#define OPER_UPPER_PRESS_COLOR						GUI_WHITE
//#define OPER_RAMP_LABEL_COLOR						GUI_WHITE
#define OPER_RUNNING_RAMP_COLOR						COLOR_LIGHT_ORANGE
//#define OPER_STOP_RAMP_COLOR						GUI_WHITE
//#define OPER_INH_EXH_COLOR							GUI_WHITE
//#define OPER_MODE_COLOR								GUI_WHITE
#define OPER_PRESS_IMAGE_COLOR						GUI_WHITE


#define PRESS_MAX_VALUE						20			//20 cmH2O
#define PRESS_MAX_DEGREE					90			//90 degree at 20 cmH2O

#define GUI_VALUE_STR_LENGTH				10			//length of value string
#define NUM_OF_PRESS_SUPPORT				6			//num of press support
#define MINUTE_IN_MILISECOND				60000		//1 minute in milisecond

#define MOTOR_PRESS_SCALE		10		//pressure scale up 10
#define MOTOR_FLOW_SCALE		40		//flow scale up 60

int testcbGuiOperRealTimePressureIndicator = 0;
int testcbGuiOperTreatPressIndicator = 0;
E_KeyEventId testkeyEventcbOperationScreen = eKeyNoEventId;
E_GuiOperState guiOperState = eGuiOperIdle;
bool isSleepShowing = false;
float guiOperPressure = 0;		//real time pressure
float guiOperTreatPressure = 0;	//real time treatment pressure
float guiOperBottomPressure = 0;
float guiOperTopPressure = 0;
bool isRunningRampTime = false;
short guiOperRampValue = 0;		//ramp time in second
short guiOperRampTimeSetting = 0;
bool isDryShowing = false;
E_ChangeScrTimerId changeScreenTimerId = eChangeOperScrTimerId;
bool leftKeyPressed = false;
bool isUserOptionShowing = false;
bool isAlarmShowing = false;
bool rightKeyPressed = false;
bool enterKeyPressed = false;
unsigned char guiOperInhSupportSetting = 0;
unsigned char guiOperExhSupportSetting = 0;
char guiOperPressSettingStr[GUI_VALUE_STR_LENGTH] = {'\0'};

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//typedef enum
//{
//	eGuiOperRunning = 0,
//	eGuiOperDrying,
//	eGuiOperMaskOff,
//	eGuiOperIdle
//} E_GuiOperState;

//declare variable to indicate that an alarm is showing or user option is showing
//static bool isAlarmShowing = false;
//static bool isUserOptionShowing = false;
//static bool isSleepShowing = false;
//static bool isDryShowing = false;
//static bool isStartByManual = false;		//start blower by manually press ON/OFF button
static xQueueHandle motorQueue;
static xQueueHandle systemQueue;

//static const char* pressSupport[NUM_OF_PRESS_SUPPORT] = { "L0", "L1", "L2", "L3", "L4", "L5" };	//string array for NS support
//static const GUI_FONT* guiFont14[] = { &GUI_FontMeiryo14B_2bpp, &GUI_FontJPAPJPFont14B };

/*************** internal functions ******************/
//void OperScreenHandleKeyEvent(E_KeyEventId eventId);
//void cbGuiOperRealTimePressureIndicator(WM_MESSAGE * pMsg);
//void cbGuiOperTreatPressIndicator(WM_MESSAGE * pMsg);
//void cbOperationScreen(WM_MESSAGE * pMsg);
//void OperScreenTimeoutHandle();
//void OperScreenResetKey();

// ************* internal variables *****************
//extern WM_HWIN popUp;
//WM_HWIN operationScreen;						// operation window
//static IMAGE_Handle pressureMeter;				//pressure meter
//static TEXT_Handle pressureUnitLabel;			//pressure unit
//static TEXT_Handle pressureSettingLabel;		//pressure setting
//static TEXT_Handle initPressSettingLabel;		//initial pressure setting
//static TEXT_Handle pressureRealtimeLabel;		//pressure real time
//static TEXT_Handle treatRealtimePressLabel;		//current pressure
//static TEXT_Handle inhLevel;					//pressure inhalation label
//static TEXT_Handle exhLevel;					//pressure exhalation label
//static PROGBAR_Handle realtimePressIndicator;	//real time pressure indicator
//static PROGBAR_Handle treatPressIndicator;		//pressure indicator
//static IMAGE_Handle rampMeter;					//ramp time image
//static IMAGE_Handle naturalSupportImage;		//natural support image
//static TEXT_Handle rampLabel;					//ramp label
//static TEXT_Handle rampValue;					//ramp value
//static TEXT_Handle ventModeLabel;				//ventilation mode
//static TEXT_Handle inhLabel;					//inhalation label
//static TEXT_Handle exhLabel;					//exhalation label

#if SUPPORT_EVENT_DISPLAY
static TEXT_Handle averageVolume;			//pressure unit
static TEXT_Handle currentVolume;			//pressure unit
static TEXT_Handle percentageLabel;			//pressure unit
#endif

//static E_ChangeScrTimerId changeScreenTimerId = eChangeOperScrTimerId;

//variables for setting
//static short guiOperRampTimeSetting = 0;
//static unsigned char guiOperInhSupportSetting = 0;
//static unsigned char guiOperExhSupportSetting = 0;
//static float guiOperTopPressure = 0;
//static float guiOperBottomPressure = 0;
//static float guiOperPressure = 0;		//real time pressure
//static float guiOperTreatPressure = 0;	//real time treatment pressure
//static short guiOperRampValue = 0;		//ramp time in second

//static unsigned long operationGuiTickTime = 0;
//static bool isRunningRampTime = false;

//key input status
//static bool leftKeyPressed = false;
//static bool rightKeyPressed = false;
//static bool enterKeyPressed = false;
// system on operation flag
//static E_GuiOperState guiOperState = eGuiOperIdle;
//static bool isRecount = false;

// strings for delay time, ramp time and pressure display
static char guiOperRampStr[GUI_VALUE_STR_LENGTH] = {'\0'};
static char guiOPerPressStr[GUI_VALUE_STR_LENGTH] = {'\0'};
static char guiOperTreatPressStr[GUI_VALUE_STR_LENGTH] = {'\0'};
//static char guiOperPressSettingStr[GUI_VALUE_STR_LENGTH] = {'\0'};
static char guiOperInitPressSettingStr[GUI_VALUE_STR_LENGTH] = {'\0'};

//define TRIANGLE
//static GUI_POINT triangle[] = {
//		{0, 0},	{7, 5}, {0, 10},
//};

//font 16
//static const GUI_FONT* guiFont16[] = { &GUI_FontMeiryo16B_2bpp, &GUI_FontJPAPJPFont16B };

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: cbGuiOperRealTimePressureIndicator(WM_MESSAGE * pMsg)
//
//    Processing:
//		Call back function for pressure indicator bar
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void cbGuiOperRealTimePressureIndicator(WM_MESSAGE * pMsg)
{
	const float convertFactor = (float)90/(float)(PRESS_MAX_VALUE*MOTOR_PRESS_SCALE);
	int intTemp = 0;
	float floatTemp = 0;
	switch (pMsg->MsgId) {
	case WM_PAINT:
		//		GUI_SetPenSize(10);
		//		GUI_SetColor(OPER_PRESS_REALTIME_OPERATION_COLOR);
		intTemp = pMsg->Data.v;//PROGBAR_GetValue(pMsg->hWin);			//get value
		floatTemp = (float)intTemp*convertFactor;
		intTemp = 180 - (int)floatTemp;
		if(intTemp >= 180)
			intTemp = 180;
		if(intTemp <= 90)
			intTemp = 90;

		testcbGuiOperRealTimePressureIndicator = intTemp;
		//		GUI_DrawArc(177, 177, 138, 138, intTemp, 180);
		//		GUI_SetPenSize(1);
		//		GUI_SetColor(0x66A2F7);
		//		GUI_DrawArc(177, 177, 143, 143, intTemp, 180);
		//		GUI_SetColor(0x346BD7);
		//		GUI_DrawArc(177, 177, 133, 133, intTemp, 180);
		//		GUI_SetColor(0xA0510F);
		//		GUI_DrawArc(177, 177, 132, 132, intTemp, 180);
		break;
	default:
		//		PROGBAR_Callback(pMsg);
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: cbGuiOperTreatPressIndicator(WM_MESSAGE * pMsg)
//
//    Processing:
//		Call back function for pressure indicator bar
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void cbGuiOperTreatPressIndicator(WM_MESSAGE * pMsg, int max, int min)
{
	//	GUI_RECT Rect;
	int intTemp = 0;
	int pMin = min;//0;
	int pMax = max;//0;
	int value = 0;
	//get min max
	PROGBAR_GetMinMax(nullptr, &pMin, &pMax);//(pMsg->hWin, &pMin, &pMax);
	value = pMsg->Data.v;//PROGBAR_GetValue(pMsg->hWin);
	if(value <= pMin)
		value = pMin;
	else if(value >= pMax)
		value = pMax;

	testcbGuiOperTreatPressIndicator = value;

	switch (pMsg->MsgId) {
	case WM_PAINT:
		//get size: x0, x1, y0, y1
		//		WM_GetClientRect(&Rect);
		if(pMax != pMin)
		{
			intTemp = 10;//(int)((value - pMin)*(Rect.y1 - Rect.y0)/(pMax - pMin));
		}
		else
		{
			intTemp = 5;//Rect.y0;
		}
		testcbGuiOperTreatPressIndicator = testcbGuiOperTreatPressIndicator + intTemp;
		//		GUI_SetColor(OPER_TREAT_INDICATOR_COLOR);
		//		GUI_FillRoundedRect(Rect.x0 + 15, Rect.y0, Rect.x1, Rect.y1, 1);
		//draw indicator
		//		GUI_SetColor(OPER_TREAT_REALPRESS_INDICATOR_COLOR);
		//		GUI_FillRoundedRect(Rect.x0 + 15, Rect.y1 - intTemp, Rect.x1, Rect.y1, 1);
		//draw triagle
		//		GUI_SetColor(OPER_TRIANGLE_COLOR);
		//		GUI_AA_FillPolygon(&triangle[0], 3, Rect.x0 + 5, Rect.y0);
		//		GUI_AA_FillPolygon(&triangle[0], 3, Rect.x0 + 5, Rect.y1 - 10);
		break;
	default:
		//		PROGBAR_Callback(pMsg);
		break;
	}
}


/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: cbOperationScreen(WM_MESSAGE * pMsg)
//
//    Processing:
//		Callback function for operation screen
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void cbOperationScreen(WM_MESSAGE * pMsg)
{
	//	GUI_RECT Rect;
	E_KeyEventId keyEvent = eKeyNoEventId;

	switch (pMsg->MsgId) {
	case WM_PAINT:
		//		WM_GetInsideRect(&Rect);
		//		GUI_SetBkColor(OPER_SCR_BK_COLOR);
		//		GUI_ClearRectEx(&Rect);
		testkeyEventcbOperationScreen = keyEvent;
		break;
	case WM_KEY:
		switch (((WM_KEY_INFO*)(pMsg->Data.p))->Key)
		{
		case GUI_KEY_LEFT:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt != 0)
				keyEvent = eLeftKeyPressedId;
			else
				keyEvent = eLeftKeyReleasedId;
			break;
		case GUI_KEY_RIGHT:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt != 0)
				keyEvent = eRightKeyPressedId;
			else
				keyEvent = eRightKeyReleasedId;
			break;
		case GUI_KEY_HOME:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt != 0)
				keyEvent = eEnterKeyPressedId;
			else
				keyEvent = eEnterKeyReleasedId;
			break;
		case GUI_KEY_OPER:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt != 0)
				keyEvent = eOperKeyPressedId;
			else
				keyEvent = eOperKeyReleasedId;
			break;
		default:
			break;
		}
		//handle key event
		if(keyEvent != eKeyNoEventId)
		{
			testkeyEventcbOperationScreen = keyEvent;
			OperScreenHandleKeyEvent(keyEvent);
		}
		break;
		default:
			//			WM_DefaultProc(pMsg);
			break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OPerScreenUpdateRealPressure()
//
//    Processing:
//		This operation gets pressure and sends message to display on operation GUI
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void OPerScreenUpdateRealPressure()
{
	//check if current gui running is operation gui
	if(guiOperState != eGuiOperRunning)
	{
		guiOperState = eGuiOperRunning;//Add test Viet
		return;
	}

	//check if sleep screen is activated
	if(isSleepShowing == true)
	{
		isSleepShowing = false;//Add test Viet
		return;
	}

	//get nose pressure to display
	AnalyzeDataGetFilteredNosePressureMocks(&guiOperPressure);//AnalyzeDataGetFilteredNosePressure(&guiOperPressure);
	if(guiOperPressure <= 0)
		guiOperPressure = 0;
	else if(guiOperPressure >= 20)
		guiOperPressure = 20;

	//display pressure indicator
	PROGBAR_SetValue(nullptr, (long)(guiOperPressure*(float)MOTOR_PRESS_SCALE));//(realtimePressIndicator, (long)(guiOperPressure*(float)MOTOR_PRESS_SCALE));
	//	PROGBAR_SetText(realtimePressIndicator, "");
	//	PROGBAR_SetTextAlign(realtimePressIndicator, GUI_TA_RIGHT);
	StrToolFtoA(guiOperPressure, &guiOPerPressStr[0], 1);							//display pressure as text
	//	TEXT_SetTextColor(pressureRealtimeLabel, OPER_PRESS_REALTIME_OPERATION_COLOR);			//set color for real time pressure label
	//	TEXT_SetText(pressureRealtimeLabel, (const char*)&guiOPerPressStr[0]);	//set value text

	//update phase if enable update configured
#if SUPPORT_EVENT_DISPLAY
	//1. update phase status
	static E_BreathPhase previousPhase = ePhaseExhMaintain;
	if(previousPhase != breathPhase)
	{
		//check phase and display
		if((breathPhase == ePhaseInhTrigger) || (breathPhase == ePhaseInhMaintain))
			WM_SendMessageNoPara(statusBar, WM_SHOW_INH);
		else
			WM_SendMessageNoPara(statusBar, WM_SHOW_EXH);
		//update phase
		previousPhase = breathPhase;
	}
	//2. update event status
	if(eventBreath & EVENT_CA_ID)
		WM_SendMessageNoPara(statusBar, WM_CA_EVENT);
	else if(eventBreath & EVENT_OA_ID)
		WM_SendMessageNoPara(statusBar, WM_OA_EVENT);
	else if(eventBreath & EVENT_S_ID)
		WM_SendMessageNoPara(statusBar, WM_S_EVENT);
	else if(eventBreath & EVENT_H_ID)
		WM_SendMessageNoPara(statusBar, WM_H_EVENT);
	else if(eventBreath & EVENT_FL_ID)
		WM_SendMessageNoPara(statusBar, WM_FL_EVENT);
	else
		WM_SendMessageNoPara(statusBar, WM_NONE_EVENT);
#endif
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OperScreenUpdateTreatPressure()
//
//    Processing:
//		This operation gets real time treatment pressure and sends message to display on operation GUI
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void OperScreenUpdateTreatPressure()
{
	if(guiOperState != eGuiOperRunning)		//check if current gui running is operation gui
	{
		guiOperState = eGuiOperRunning;//Add test Viet
		return;
	}

	//get real time treatment pressure value
	AnalyzeDataGetTreatmentPressureMocks(&guiOperTreatPressure);//AnalyzeDataGetTreatmentPressure(&guiOperTreatPressure);
	if(guiOperTreatPressure <= guiOperBottomPressure)
		guiOperTreatPressure = guiOperBottomPressure;
	else if(guiOperTreatPressure >= guiOperTopPressure)
		guiOperTreatPressure = guiOperTopPressure;

	//display pressure indicator
	if(guiOperTopPressure > guiOperBottomPressure)
		PROGBAR_SetValue(nullptr,(long)(guiOperTreatPressure*(float)MOTOR_PRESS_SCALE));//PROGBAR_SetValue(treatPressIndicator,(long)(guiOperTreatPressure*(float)MOTOR_PRESS_SCALE));
	else
	{
		int pMin = 0;
		int pMax = 0;
		PROGBAR_GetMinMax(nullptr, &pMin, &pMax);//PROGBAR_GetMinMax(treatPressIndicator, &pMin, &pMax);
		PROGBAR_SetValue(nullptr, pMax);//PROGBAR_SetValue(treatPressIndicator, pMax);
		//		PROGBAR_SetValue(treatPressIndicator,(guiOperTopPressure*(float)MOTOR_PRESS_SCALE));
	}
	//	else if(SettingGet(eVentModeSettingId) == eAutoMode)
	//		PROGBAR_SetValue(treatPressIndicator,0);

	//	PROGBAR_SetText(treatPressIndicator, "");
	//	PROGBAR_SetTextAlign(treatPressIndicator, GUI_TA_RIGHT);

	//display pressure as text
	StrToolFtoA(guiOperTreatPressure, &guiOperTreatPressStr[0], 1);
	//set color for real time pressure label
	//	TEXT_SetTextColor(treatRealtimePressLabel, OPER_TREATMENT_PRESS_COLOR);
	//set value text
	//	TEXT_SetText(treatRealtimePressLabel, (const char*)&guiOperTreatPressStr[0]);
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OPerScreenUpdateRampTime()
//
//    Processing:
//		This operation updates ramp counter on Operation GUI and handles 1 second timer event and counts down
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void OPerScreenUpdateRampTime()
{
	//check if current gui running is operation gui
	if(guiOperState != eGuiOperRunning)
	{
		guiOperState = eGuiOperRunning;//Add test Viet
		return;
	}

	if(isRunningRampTime == true)
	{
		//decrease operation delay value to 1
		++guiOperRampValue;
		//update value by sending a message
		//		WM_SendMessageNoPara(rampMeter, WM_UPDATE_COUNTER);
		if(guiOperRampValue > guiOperRampTimeSetting)
		{
			//set flag to stop running RAMP counter
			isRunningRampTime = false;
			//load image with disable all
			//			TEXT_SetTextColor(rampValue, OPER_STOP_RAMP_COLOR);
			guiOperRampValue = guiOperRampTimeSetting;
		}
		//convert time to string
		StrToolTtoS(&guiOperRampStr[0], (guiOperRampTimeSetting - guiOperRampValue));
		//set text
		//		TEXT_SetText(rampValue, (const char*)&guiOperRampStr[0]);
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OperScreenEnterRunning()
//
//    Processing:
//		This operation activates operation GUI
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void OperScreenEnterRunning()
{
	//read used hours from EEPROM
	guiOperRampValue = 0;
	//set flag to activate operation GUI
	guiOperState = eGuiOperRunning;
	//do not run ramp time until blower start ok
	isRunningRampTime = false;
	//load full image of delay and ramp time
	if(guiOperRampTimeSetting != 0)
	{
		//convert time to string
		StrToolTtoS(&guiOperRampStr[0], guiOperRampTimeSetting);
		//set text
		//		TEXT_SetText(rampValue, (const char*)&guiOperRampStr[0]);
	}
	//	TEXT_SetTextColor(pressureRealtimeLabel, OPER_PRESS_REALTIME_OPERATION_COLOR);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OperScreenStartRamp()
//
//    Processing:
//		This operation starts ramp time
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void OperScreenStartRamp()
{
	guiOperRampValue = 0;								//reset counter value
	//	TEXT_SetTextColor(rampValue, OPER_RUNNING_RAMP_COLOR);		//set color for ramp value
	//set flag to start running ramp time
	isRunningRampTime = true;
	//convert time to string
	StrToolTtoS(&guiOperRampStr[0], (guiOperRampTimeSetting - guiOperRampValue));
	//set text
	//	TEXT_SetText(rampValue, (const char*)&guiOperRampStr[0]);
	//	WM_SendMessageNoPara(rampMeter, WM_UPDATE_COUNTER);	//update value by sending a message
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OperScreenEndRamp()
//
//    Processing:
//		This operation resets ramp value and updates value
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void OperScreenEndRamp()
{
	//check if system is on operation,
	if(guiOperState != eGuiOperRunning)
	{
		guiOperState = eGuiOperRunning;//Add test Viet
		return;
	}

	//if system is not on operation , do nothing
	int pMin = 0;
	int pMax = 0;
	PROGBAR_GetMinMax(nullptr, &pMin, &pMax);//(treatPressIndicator, &pMin, &pMax);
	PROGBAR_SetValue(nullptr, pMax);//(treatPressIndicator, pMax);

	//change color for ramp value
	//	TEXT_SetTextColor(rampValue, OPER_STOP_RAMP_COLOR);
	//clear flag to update ramp time
	isRunningRampTime = false;
	//reset ramp value
	guiOperRampValue = guiOperRampTimeSetting;
	//convert time to string
	StrToolTtoS(&guiOperRampStr[0], (guiOperRampTimeSetting - guiOperRampValue));
	//set text
	//	TEXT_SetText(rampValue, (const char*)&guiOperRampStr[0]);

	//	WM_SendMessageNoPara(rampMeter, WM_UPDATE_COUNTER);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OperScreenEnterIdle()
//
//    Processing:
//		This operation draws standby screen, loads and displays setting on standby screen
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void OperScreenEnterIdle()
{
	//set gui opeation state
	guiOperState = eGuiOperIdle;
	//hide starting dialog
	//	WM_HideWindow(loadingScreen);
	//hide dry screen
	//	WM_HideWindow(dryScreen);
	//hide drying dialog and clear flag
	isDryShowing = false;
	//clear flag indicate start method
	//	isStartByManual = false;
	//update setting on operation screen
	OperScreenUpdateSetting();
	//reload user screen
	UserSettingReloadMocks(guiOperState);//UserSettingReload(guiOperState);
	//reset key status
	//	OperScreenResetKey();
	//set flag to deactivate operation GUI
	//	if(guiOperState == eGuiOperRunning)
	//	{
	//		//reset flag
	//		guiOperState = eGuiOperDrying;
	//		//re-draw operation screen
	//		OperScreenUpdateSetting();
	//	}
	//check if ramp counter is running, then stop
	//	if(isRunningRampTime == true)
	//		OperScreenEndRamp();
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OperScreenEnterDrying()
//
//    Processing:
//		This operation draws standby screen, loads and displays setting on standby screen
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void OperScreenEnterDrying()
{
	//reset key status
	OperScreenResetKey();
	//show drying dialog
	DryScreenReload();
	//	WM_ShowWindow(dryScreen);
	isDryShowing = true;
	//set flag to deactivate operation GUI
	guiOperState = eGuiOperDrying;
	//check if user setting is showing, then hide it
	if(isUserOptionShowing == true)
		GuiTaskSendEvent(eGuiUserOptionHideId, 0);
	//re-draw operation screen
	OperScreenUpdateSetting();
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OperScreenEnterMaskOff()
//
//    Processing:
//		This operation put operation GUI to mask off state
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
//void OperScreenEnterMaskOff()
//{
//	//reset key status
//	OperScreenResetKey();
//	//show drying dialog
////	DryScreenReload();
////	WM_ShowWindow(dryScreen);
////	isDryShowing = true;
//	//set flag to deactivate operation GUI
//	guiOperState = eGuiOperMaskOff;
//	//check if user setting is showing, then hide it
//	if(isUserOptionShowing == true)
//		GuiTaskSendEvent(eGuiUserOptionHideId, 0);
//	//re-draw operation screen
//	OperScreenUpdateSetting();
//}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OperScreenInit()
//
//    Processing:
//		This operation initializes operation mode and its content
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void OperScreenInit()
{
	language = SettingGetMocks(eLanguageSettingId);//SettingGet(eLanguageSettingId);
	if(language > 1)
		language = 1;
	//create operation window
	//	operationScreen = WM_CreateWindowAsChild(SETTING_SCREEN_X, SETTING_SCREEN_Y, SETTING_SCREEN_LENGTH, SETTING_SCREEN_HEIGHT, mainWindow, WM_CF_SHOW/* | WM_CF_MEMDEV*/ | WM_CF_LATE_CLIP, cbOperationScreen, 0);

	/***********************************1. Initialize PRESSURE METER******************************************/
	//load pressure image
	//	pressureMeter = IMAGE_CreateEx(PRESS_IMAGE_X, PRESS_IMAGE_Y, PRESS_IMAGE_SIZE_X, PRESS_IMAGE_SIZE_Y, operationScreen, WM_CF_SHOW, 0/*IMAGE_CF_MEMDEV*/, GUI_ID_IMAGE0);
	//	IMAGE_SetBitmap(pressureMeter,&pressMeterImageInfor);	//load pressure image
	//	WM_SetCallback(pressureMeter,cbGuiOperPressureMeter);
	//add pressure unit
	//	pressureUnitLabel = TEXT_CreateEx(PRESS_UNIT_X, PRESS_UNIT_Y, PRESS_UNIT_SIZE_X, PRESS_UNIT_SIZE_Y,pressureMeter,WM_CF_SHOW, TEXT_CF_RIGHT, GUI_ID_TEXT1, "");
	//	TEXT_SetFont(pressureUnitLabel,&GUI_FontJPAPJPFont12B);
	//	TEXT_SetTextAlign(pressureUnitLabel, GUI_TA_RIGHT);
	//	TEXT_SetTextColor(pressureUnitLabel,OPER_PRESS_UNIT_COLOR);
	//add pressure setting
	//	pressureSettingLabel = TEXT_CreateEx(PRESS_SETTING_X, PRESS_SETTING_Y, PRESS_SETTING_SIZE_X, PRESS_SETTING_SIZE_Y,pressureMeter,WM_CF_SHOW, TEXT_CF_RIGHT, GUI_ID_TEXT2, "");
	//	TEXT_SetFont(pressureSettingLabel,&GUI_FontJPAPJPFont12B);
	////	TEXT_SetTextAlign(pressureSettingLabel, GUI_TA_RIGHT);
	//	TEXT_SetTextColor(pressureSettingLabel, OPER_SETTING_PRESS_COLOR);
	//add initial pressure setting
	//	initPressSettingLabel = TEXT_CreateEx(PRESS_SETTING_X, PRESS_SETTING_Y + 80, PRESS_SETTING_SIZE_X, PRESS_SETTING_SIZE_Y,pressureMeter,WM_CF_SHOW, TEXT_CF_RIGHT, GUI_ID_TEXT3, "");
	//	TEXT_SetFont(initPressSettingLabel,&GUI_FontJPAPJPFont12B);
	////	TEXT_SetTextAlign(initPressSettingLabel, GUI_TA_RIGHT);
	//	TEXT_SetTextColor(initPressSettingLabel, OPER_INIT_PRESS_COLOR);
	//add current pressure
	//	treatRealtimePressLabel = TEXT_CreateEx(CURR_PRESS_X, CURR_PRESS_Y, CURR_PRESS_SIZE_X, CURR_PRESS_SIZE_Y,pressureMeter,WM_CF_SHOW, TEXT_CF_RIGHT, GUI_ID_TEXT4, "");
	//	TEXT_SetFont(treatRealtimePressLabel,&GUI_FontJPAPJPFont32B);
	////	TEXT_SetTextAlign(treatRealtimePressLabel, GUI_TA_RIGHT);
	//	TEXT_SetTextColor(treatRealtimePressLabel, OPER_TREATMENT_PRESS_COLOR);
	//add pressure real time display
	//	pressureRealtimeLabel = TEXT_CreateEx(PRESS_VALUE_X, PRESS_VALUE_Y, PRESS_VALUE_SIZE_X, PRESS_VALUE_SIZE_Y,pressureMeter,WM_CF_SHOW, TEXT_CF_HCENTER, GUI_ID_TEXT5, "");
	//	TEXT_SetFont(pressureRealtimeLabel,&GUI_FontJPAPJPFont18B);
	////	TEXT_SetTextAlign(pressureRealtimeLabel, GUI_TA_CENTER);
	//	//	TEXT_SetTextColor(pressureRealtimeLabel, OPER_PRESS_REALTIME_OPERATION_COLOR);
	//	TEXT_SetText(pressureRealtimeLabel, "0.0");
	//add pressure indicator bar
	//	realtimePressIndicator = PROGBAR_CreateEx(PRESS_INDICATOR_X, PRESS_INDICATOR_Y, PRESS_INDICATOR_SIZE_X, PRESS_INDICATOR_SIZE_Y, pressureMeter, WM_CF_SHOW, PROGBAR_CF_HORIZONTAL, GUI_ID_PROGBAR0);
	//	PROGBAR_SetMinMax(realtimePressIndicator, 0, PRESS_MAX_VALUE*MOTOR_PRESS_SCALE);
	//	WM_SetHasTrans(realtimePressIndicator);
	//	WM_SetCallback(realtimePressIndicator, cbGuiOperRealTimePressureIndicator);
	//add pressure indicator bar
	//	treatPressIndicator = PROGBAR_CreateEx(VERT_PRESS_INDICATOR_X, VERT_PRESS_INDICATOR_Y, VERT_PRESS_INDICATOR_SIZE_X, VERT_PRESS_INDICATOR_SIZE_Y, pressureMeter, WM_CF_SHOW, PROGBAR_CF_VERTICAL, GUI_ID_PROGBAR1);
	//	WM_SetHasTrans(treatPressIndicator);
	//	WM_SetCallback(treatPressIndicator, cbGuiOperTreatPressIndicator);

	/***********************************2. Initialize RAMP IMAGE**********************************************/
	//create ramp image
	//	rampMeter = IMAGE_CreateEx(RAMP_IMAGE_X, RAMP_IMAGE_Y, RAMP_IMAGE_SIZE_X, RAMP_IMAGE_SIZE_Y, operationScreen, WM_CF_SHOW, /*IMAGE_CF_MEMDEV*/0, GUI_ID_IMAGE2);
	//	//	WM_SetCallback(rampMeter, cbGuiOperRampMeter);
	//	IMAGE_SetBitmap(rampMeter,&rampImageInfor);

	//create ramp label
	//	rampLabel = TEXT_CreateEx(RAMP_LABEL_X, RAMP_LABEL_Y, RAMP_LABEL_SIZE_X, RAMP_LABEL_SIZE_Y,rampMeter,WM_CF_SHOW, TEXT_CF_HCENTER, GUI_ID_TEXT8, "");
	//	TEXT_SetFont(rampLabel,&GUI_FontJPAPJPFont16B);
	//	TEXT_SetTextColor(rampLabel, OPER_RAMP_LABEL_COLOR);
	//	//create ramp label
	//	rampValue = TEXT_CreateEx(RAMP_VALUE_X, RAMP_VALUE_Y, RAMP_VALUE_SIZE_X, RAMP_VALUE_SIZE_Y,rampMeter,WM_CF_SHOW, TEXT_CF_HCENTER, GUI_ID_TEXT9, "");
	//	TEXT_SetFont(rampValue,&GUI_FontJPAPJPFont16B);
	//	TEXT_SetTextColor(rampValue, OPER_STOP_RAMP_COLOR);

	/***********************************3. Initialize NATURAL SUPPORT*****************************************/
	//create natural support
	//	naturalSupportImage = IMAGE_CreateEx(NS_IMAGE_X, NS_IMAGE_Y, NS_IMAGE_SIZE_X, NS_IMAGE_SIZE_Y, operationScreen, WM_CF_SHOW, /*IMAGE_CF_MEMDEV*/0, GUI_ID_IMAGE3);
	//	IMAGE_SetBitmap(naturalSupportImage,&nsImageInfor);
	//	//add inhalation label
	//	inhLabel = TEXT_CreateEx(PRESS_INH_LABEL_X, PRESS_INH_LABEL_Y, PRESS_INH_LABEL_SIZE_X, PRESS_INH_LABEL_SIZE_Y, naturalSupportImage, WM_CF_SHOW, TEXT_CF_HCENTER, GUI_ID_TEXT3, "Inh:");
	//	TEXT_SetFont(inhLabel, guiFont14[language]);
	//	TEXT_SetText(inhLabel, strInh[language]);
	////	TEXT_SetTextAlign(inhLabel, GUI_TA_CENTER);
	//	TEXT_SetTextColor(inhLabel, OPER_INH_EXH_COLOR);
	//	//add exhalation level
	//	exhLabel = TEXT_CreateEx(PRESS_EXH_LABEL_X, PRESS_EXH_LABEL_Y, PRESS_EXH_LABEL_SIZE_X, PRESS_EXH_LABEL_SIZE_Y, naturalSupportImage, WM_CF_SHOW, TEXT_CF_HCENTER, GUI_ID_TEXT4, "Exh:");
	//	TEXT_SetFont(exhLabel, guiFont14[language]);
	//	TEXT_SetText(exhLabel, strExh[language]);
	////	TEXT_SetTextAlign(exhLabel, GUI_TA_CENTER);
	//	TEXT_SetTextColor(exhLabel, OPER_INH_EXH_COLOR);
	//	//add inhalation level
	//	inhLevel = TEXT_CreateEx(PRESS_INH_LEVEL_X, PRESS_INH_LEVEL_Y, PRESS_INH_LEVEL_SIZE_X, PRESS_INH_LEVEL_SIZE_Y, naturalSupportImage, WM_CF_SHOW, TEXT_CF_LEFT, GUI_ID_TEXT5, "");
	//	TEXT_SetFont(inhLevel,&GUI_FontJPAPJPFont14B);
	////	TEXT_SetTextAlign(inhLevel, GUI_TA_CENTER);
	//	TEXT_SetTextColor(inhLevel, OPER_INH_EXH_COLOR);
	//	//add exhalation level
	//	exhLevel = TEXT_CreateEx(PRESS_EXH_LEVEL_X, PRESS_EXH_LEVEL_Y, PRESS_EXH_LEVEL_SIZE_X, PRESS_EXH_LEVEL_SIZE_Y, naturalSupportImage, WM_CF_SHOW, TEXT_CF_LEFT, GUI_ID_TEXT6, "");
	//	TEXT_SetFont(exhLevel,&GUI_FontJPAPJPFont14B);
	////	TEXT_SetTextAlign(exhLevel, GUI_TA_CENTER);
	//	TEXT_SetTextColor(exhLevel, OPER_INH_EXH_COLOR);

	/***********************************4. Initialize VENTIALTION LABEL***************************************/
	//	ventModeLabel = TEXT_CreateEx(VENTMODE_LABEL_X, VENTMODE_LABEL_Y, VENTMODE_LABEL_SIZE_X, VENTMODE_LABEL_SIZE_Y,operationScreen, WM_CF_SHOW, TEXT_CF_TOP|TEXT_CF_HCENTER, GUI_ID_TEXT10, "");
	//	TEXT_SetFont(ventModeLabel,&GUI_FontJPAPJPFont28B);
	//	TEXT_SetTextColor(ventModeLabel, OPER_MODE_COLOR);
	//	TEXT_SetTextAlign(ventModeLabel, GUI_TA_HCENTER | TEXT_CF_TOP);

#if SUPPORT_EVENT_DISPLAY
	//initialize AVERAGE VOLUME
	averageVolume = TEXT_CreateEx(AVERAGE_VOLUME_X, AVERAGE_VOLUME_Y, AVERAGE_VOLUME_LENGTH, AVERAGE_VOLUME_HEIGHT,operationScreen, WM_CF_SHOW, TEXT_CF_TOP, GUI_ID_TEXT11, "");
	WM_BringToTop(averageVolume);
	TEXT_SetFont(averageVolume,&GUI_FontJPAPJPFont14B);
	TEXT_SetTextColor(averageVolume, OPER_MODE_COLOR);
	TEXT_SetTextAlign(averageVolume, GUI_TA_LEFT);
	TEXT_SetText(averageVolume, "AV=0");
	//initialize CURRENT VOLUME
	currentVolume = TEXT_CreateEx(CURRENT_VOLUME_X, CURRENT_VOLUME_Y, CURRENT_VOLUME_LENGTH, CURRENT_VOLUME_HEIGHT,operationScreen, WM_CF_SHOW, TEXT_CF_TOP, GUI_ID_TEXT12, "");
	WM_BringToTop(currentVolume);
	TEXT_SetFont(currentVolume,&GUI_FontJPAPJPFont14B);
	TEXT_SetTextColor(currentVolume, OPER_MODE_COLOR);
	TEXT_SetTextAlign(currentVolume, GUI_TA_LEFT);
	TEXT_SetText(currentVolume, "CV=0");
	//initialize PERCENTAGE
	percentageLabel = TEXT_CreateEx(PERCENTAGE_X, PERCENTAGE_Y, PERCENTAGE_LENGTH, PERCENTAGE_HEIGHT,operationScreen, WM_CF_SHOW, TEXT_CF_TOP, GUI_ID_TEXT13, "");
	WM_BringToTop(percentageLabel);
	TEXT_SetFont(percentageLabel,&GUI_FontJPAPJPFont14B);
	TEXT_SetTextColor(percentageLabel, OPER_MODE_COLOR);
	TEXT_SetTextAlign(percentageLabel, GUI_TA_LEFT);
	TEXT_SetText(percentageLabel, "0%");
#endif

	/****************************************5. Init POP UP screen*******************************************/

	//init user setting dialog
	UserSettingDialogInitMocks();//UserSettingDialogInit();
	//init loading screen
	LoadingScreenInit();
	//init alarm dialog
	AlarmDialogInit();
	//init dry dialog
	DryScreenInit();
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OperScreenHandleKeyEvent()
//
//    Processing:
//		This operation handle key events
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void OperScreenHandleKeyEvent(E_KeyEventId eventId)
{
	//start timer 1 to enter sleep screen
	SoftTimerResetMocks(eSoftTimer1Id);//SoftTimerReset(eSoftTimer1Id);
	//	TimerReset(eTimer1Id);
	//stop timer 3 for changing screen
	SoftTimerStopMocks(eSoftTimer2Id);//SoftTimerStop(eSoftTimer2Id);
	//	TimerStop(eTimer3Id);
	//reset change screen timer id
	changeScreenTimerId = eChangeOperScrTimerId;

	//check event
	switch(eventId)
	{
	case eLeftKeyPressedId:
		//set state change
		leftKeyPressed = true;
		//check whether sleep screen is activated
		if(isSleepShowing == true)
			GuiTaskSendEvent(eGuiSleepScreenHideId, 0);
		break;
	case eLeftKeyReleasedId:
		leftKeyPressed = false;
		break;
	case eRightKeyPressedId:
		//set state change
		rightKeyPressed = true;
		//check whether sleep screen is activated
		if(isSleepShowing == true)
			GuiTaskSendEvent(eGuiSleepScreenHideId, 0);
		break;
	case eRightKeyReleasedId:
		rightKeyPressed = false;
		break;
	case eEnterKeyPressedId:
		//set state change
		enterKeyPressed = true;
		//check whether sleep screen is activated
		/*if(isDryShowing == true)
			break;
		else */if(isSleepShowing == true)
		{
			GuiTaskSendEvent(eGuiSleepScreenHideId, 0);
		}
		//check alarm is showing
		else if(isAlarmShowing == true)
		{
			AlarmDialogConfirm();
		}
		//handle changing to patient setting mode
		else if((leftKeyPressed == false)&&(rightKeyPressed == false))
		{
			GuiTaskSendEvent(eGuiUserOptionShowId, 0);	//show user option
		}
		break;
	case eEnterKeyReleasedId:
		enterKeyPressed = false;
		break;
	case eOperKeyPressedId:
		//check whether sleep screen is activated
		if(isSleepShowing == true)
			GuiTaskSendEvent(eGuiSleepScreenHideId, 0);

		//check condition to start/stop system
		if((guiOperState == eGuiOperRunning)||(guiOperState == eGuiOperMaskOff))	//system is operating
		{
			//send event to stop motor
			unsigned char sendEvent = eMotorStopEventId;
			if(xQueueSendToBack(motorQueue, &sendEvent, 2) != pdPASS)
			{
			}
			//MotorTaskSendEvent(eMotorStopEventId);	//eMotorEnterMaskOffEventId
			//log go to drying by user push ON/OFF button while operation
			SystemEventStruct event;
			event.Id = eSystemStateLogId;
			event.Data.type1 = eSystemManualStop;
			//send event to queue
			if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
			{

			}
			//SystemTaskSendEvent(eSystemStateLogId, eSystemManualStop);
			//			DebugStr("\n dry motor");
			//hide event label
#if SUPPORT_EVENT_DISPLAY
			WM_SendMessageNoPara(statusBar, WM_NONE_EVENT);
			//hide phase label
			WM_SendMessageNoPara(statusBar, WM_SHOW_EXH);
#endif
		}
		else if(guiOperState == eGuiOperDrying)
		{
			//send event to stop motor
			unsigned char sendEvent = eMotorStopEventId;
			if(xQueueSendToBack(motorQueue, &sendEvent, 2) != pdPASS)
			{
			}
			//			MotorTaskSendEvent(eMotorStopEventId);	//eMotorEnterMaskOffEventId
			//log event interrupt while drying
			SystemEventStruct event;
			event.Id = eSystemStateLogId;
			event.Data.type1 = eSystemInterruptionDrying;
			//send event to queue
			if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
			{

			}
			//			SystemTaskSendEvent(eSystemStateLogId, eSystemInterruptionDrying);
		}
		else	//system is on standby
		{
			//send event to start blower
			unsigned char sendEvent = eMotorStartEventId;
			if(xQueueSendToBack(motorQueue, &sendEvent, 2) != pdPASS)
			{
			}
			//			MotorTaskSendEvent(eMotorStartEventId);
			//send event to log as manual start
			SystemEventStruct event;
			event.Id = eSystemStateLogId;
			event.Data.type1 = eSystemManualStart;
			//send event to queue
			if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
			{

			}
			//			SystemTaskSendEvent(eSystemStateLogId, eSystemManualStart);
			//set flag to indicate that start by manually press ON/OFF button on blower unit
			//			isStartByManual = true;
			//show event label
#if SUPPORT_EVENT_DISPLAY
			WM_SendMessageNoPara(statusBar, WM_NONE_EVENT);
			//show phase label
			WM_SendMessageNoPara(statusBar, WM_SHOW_EXH);
#endif
		}
		break;
	case eOperKeyReleasedId:
		break;
	default:
		break;
	}

	//handle screen change
	if((guiOperState == eGuiOperIdle)&&(isAlarmShowing == false))
	{
		//handle changing to health care worker mode
		if((enterKeyPressed == true)&&(rightKeyPressed == true)&&(leftKeyPressed == false))
		{
			//set timer id is clinic screen change timer
			changeScreenTimerId = eChangeClinicScrTimerId;
			//start timer
			SoftTimerStartMocks(eSoftTimer2Id);//SoftTimerStart(eSoftTimer2Id);
			//			TimerStart(eTimer3Id);
		}
		//handle changing to maintenance mode
		if((leftKeyPressed == true)&&(enterKeyPressed == false)&&(rightKeyPressed == true))
		{
			//set timer id is clinic screen change timer
			changeScreenTimerId = eChangeMaintenanceScrTimerId;
			//start timer
			SoftTimerStartMocks(eSoftTimer2Id);//SoftTimerStart(eSoftTimer2Id);
			//			TimerStart(eTimer3Id);
		}
		//handle changing to history screen
		if((leftKeyPressed == true)&&(enterKeyPressed == true)&&(rightKeyPressed == true))
		{
			//set timer id is clinic screen change timer
			changeScreenTimerId = eChangeSystemLogScrTimerId;
			//start timer
			SoftTimerStartMocks(eSoftTimer2Id);//SoftTimerStart(eSoftTimer2Id);
			//			TimerStart(eTimer3Id);
		}
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OperScreenHandleTimeOut()
//
//    Processing:
//		This operation handles all events of timer
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void OperScreenHandleTimeOut()
{
	//check timer id
	switch (changeScreenTimerId)
	{
	case eChangeClinicScrTimerId:
		// check condition to change to health care worker setting
		//		if((guiOperState == false)&&(enterKeyPressed == true)&&(rightKeyPressed == true)&&(leftKeyPressed == false))
	{
		//change to clinic screen
		GuiTaskSendEvent(eGuiChangeToClinicScreenId, 0);
		//stop motor
		//			MotorTaskSendEvent(eMotorStopEventId);
	}
	//reset key status
	//	OperScreenResetKey();

	break;
	case eChangeMaintenanceScrTimerId:
		//check condition to change to maintenance screen
		//		if((guiOperState == false)&&(leftKeyPressed == true)&&(enterKeyPressed == false)&&(rightKeyPressed == true))
	{
		//change to maintenance screen
		GuiTaskSendEvent(eGuiChangeToMaintenaceScreenId, 0);
		//stop motor
		//			MotorTaskSendEvent(eMotorStopEventId);
	}
	//reset key status
	//	OperScreenResetKey();
	break;
	case eChangeSystemLogScrTimerId:
		//check condition to change to history screen
		//		if((guiOperState == false)&&(leftKeyPressed == true)&&(enterKeyPressed == false)&&(rightKeyPressed == false))
	{
		//send event to change to history screen
		GuiTaskSendEvent(eGuiChangeToHistoryScreenId, 0);
		//stop motor
		//			MotorTaskSendEvent(eMotorStopEventId);
	}
	//reset key status
	//	OperScreenResetKey();
	break;
	default:
		break;
	}
	//reset key status
	OperScreenResetKey();
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OperScreenUpdateSetting()
//
//    Processing:
//		This operation reload all settings on standby screen
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void OperScreenUpdateSetting()
{
	//1.display inhalation and exhalation setting
	guiOperInhSupportSetting = SettingGetMocks(eInhPressSupportSettingId);//SettingGet(eInhPressSupportSettingId);
	guiOperInhSupportSetting = (guiOperInhSupportSetting >= (NUM_OF_PRESS_SUPPORT-1))?(NUM_OF_PRESS_SUPPORT-1):guiOperInhSupportSetting;	//make setting in range
	//load exhalation setting level
	guiOperExhSupportSetting = SettingGetMocks(eExhPressSupportSettingId);//SettingGet(eExhPressSupportSettingId);
	guiOperExhSupportSetting = (guiOperExhSupportSetting >= (NUM_OF_PRESS_SUPPORT-1))?(NUM_OF_PRESS_SUPPORT-1):guiOperExhSupportSetting;	//make setting in range
	//reload inh label
	//	TEXT_SetFont(inhLabel, guiFont14[language]);
	//	TEXT_SetText(inhLabel, strInh[language]);
	//reload exh label
	//	TEXT_SetFont(exhLabel, guiFont14[language]);
	//	TEXT_SetText(exhLabel, strExh[language]);
	//display inhalation setting
	//	TEXT_SetText(inhLevel, pressSupport[guiOperInhSupportSetting]);
	//display exhalation setting
	//	TEXT_SetText(exhLevel, pressSupport[guiOperExhSupportSetting]);
	//check if system is in operation, then do not upgrade the following things
	if(guiOperState == eGuiOperRunning)
		return;

	if(SettingGetMocks(eVentModeSettingId) == eCpapMode)//(SettingGet(eVentModeSettingId) == eCpapMode)
	{
		//load operation pressure setting
		guiOperTopPressure = ((float)SettingGetMocks(eOperPressSettingId)/(float)MOTOR_PRESS_SCALE);//((float)SettingGet(eOperPressSettingId)/(float)MOTOR_PRESS_SCALE);
		//load initial pressure setting
		guiOperBottomPressure = ((float)SettingGetMocks(eDelayPressSettingId)/(float)MOTOR_PRESS_SCALE);//((float)SettingGet(eDelayPressSettingId)/(float)MOTOR_PRESS_SCALE);
		//load ramp time and convert to second
		guiOperRampTimeSetting = SettingGetMocks(eRampTimeSettingId)*60;//SettingGet(eRampTimeSettingId)*60;
		//show Ramp time
		//		WM_ShowWindow(rampMeter);

#if SUPPORT_EVENT_DISPLAY
		WM_ShowWindow(averageVolume);
		WM_ShowWindow(currentVolume);
		WM_ShowWindow(percentageLabel);
		//hide Ramp time
		//		WM_HideWindow(rampMeter);
#endif
		//set range for progress bar
		//		PROGBAR_SetMinMax(treatPressIndicator, SettingGet(eDelayPressSettingId), SettingGet(eOperPressSettingId));
		//reset real time treatment indicator
		//		PROGBAR_SetValue(treatPressIndicator, SettingGet(eDelayPressSettingId));
		//		DebugStr("\n set treat value: ");
		//		DebugNumber(SettingGet(eDelayPressSettingId));
	}
	else
	{
		//load operation pressure setting
		guiOperTopPressure = ((float)SettingGetMocks(eAutoUpperPressSettingId)/(float)MOTOR_PRESS_SCALE);//((float)SettingGet(eAutoUpperPressSettingId)/(float)MOTOR_PRESS_SCALE);
		//load initial pressure setting
		guiOperBottomPressure = ((float)SettingGetMocks(eAutoLowerPressSettingId)/(float)MOTOR_PRESS_SCALE);//((float)SettingGet(eAutoLowerPressSettingId)/(float)MOTOR_PRESS_SCALE);
		//hide Ramp time
		//		WM_HideWindow(rampMeter);

#if SUPPORT_EVENT_DISPLAY
		WM_ShowWindow(averageVolume);
		WM_ShowWindow(currentVolume);
		WM_ShowWindow(percentageLabel);
#endif
		//set range for progress bar
		//		PROGBAR_SetMinMax(treatPressIndicator, SettingGet(eAutoLowerPressSettingId), SettingGet(eAutoUpperPressSettingId));
		//reset real time treatment indicator
		//		PROGBAR_SetValue(treatPressIndicator, SettingGet(eAutoLowerPressSettingId));
	}
	//display ramp time
	//	TEXT_SetFont(rampLabel, guiFont16[language]);	//set font for RAMP label
	//	TEXT_SetText(rampLabel, strRamp[language]);		//set text for Ramp
	StrToolTtoS(&guiOperRampStr[0], guiOperRampTimeSetting);	//convert ramp time to string
	//	TEXT_SetTextColor(rampValue, OPER_STOP_RAMP_COLOR);			//set color for ramp value
	//	TEXT_SetText(rampValue, (const char*)&guiOperRampStr[0]);	//set value for ramp

	//************************ 3. display pressure meter ******************************
	//	IMAGE_SetBitmap(pressureMeter,&pressMeterImageInfor);	//load pressure image
	//	TEXT_SetText(pressureUnitLabel, unitStr[SettingGet(ePressUnitSettingId)]);
	//display pressure setting
	for(int i = 0; i < GUI_VALUE_STR_LENGTH; i++)
		guiOperPressSettingStr[i] = '\0';

	StrToolFtoA(guiOperTopPressure, &guiOperPressSettingStr[0], 1);
	//	TEXT_SetText(pressureSettingLabel, (const char*)&guiOperPressSettingStr[0]);

	//set text for initial pressure setting label
	StrToolFtoA(guiOperBottomPressure, &guiOperInitPressSettingStr[0], 1);
	//	TEXT_SetText(initPressSettingLabel, (const char*)&guiOperInitPressSettingStr[0]);
	//set text for current pressure label
	//	TEXT_SetText(treatRealtimePressLabel, (const char*)&guiOperInitPressSettingStr[0]);
	//reset real time treatment indicator
	PROGBAR_SetValue(nullptr, 0);//PROGBAR_SetValue(treatPressIndicator, 0);
	//init value for pressure indicator bar
	PROGBAR_SetValue(nullptr, 0);//PROGBAR_SetValue(realtimePressIndicator, 0);

	//********************* 4. display operation mode **********************************
	if(SettingGetMocks(eVentModeSettingId) == eCpapMode)//if(SettingGet(eVentModeSettingId) == eCpapMode)
	{
		//		TEXT_SetText(ventModeLabel, strCpap);
	}
	else
	{
		//		TEXT_SetText(ventModeLabel, autoCpapStr);
	}
	//set color of real time pressure label
	//	TEXT_SetTextColor(pressureRealtimeLabel, OPER_PRESS_REALTIME_STANDBY_COLOR);
	//display empty string at real time pressure
	//	TEXT_SetText(pressureRealtimeLabel, "0.0");
}

#if SUPPORT_EVENT_DISPLAY
void OperscreenSetAverageVolume(int value)
{
	char averStr[7] = {'\0'};
	unsigned char length;
	//set length
	if(value < 10)
		length = 1;
	else if(value < 100)
		length = 2;
	else if(value < 1000)
		length = 3;
	else
		length = 4;
	//convert value to string
	IntToAscii(value, &averStr[0], length);
	TEXT_SetText(averageVolume, (const char*)averStr);
}
void OperscreenSetCurrentVolume(int value)
{
	char currentStr[7] = {'\0'};
	unsigned char length;
	//set length
	if(value < 10)
		length = 1;
	else if(value < 100)
		length = 2;
	else if(value < 1000)
		length = 3;
	else
		length = 4;
	//convert value to string
	IntToAscii(value, &currentStr[0], length);
	TEXT_SetText(currentVolume, (const char*)&currentStr[0]);
}

void OperscreenSetPercentage(int percentage)
{
	if(percentage > 999)
		percentage = 999;

	char percentageStr[5] = {'\0'};
	unsigned char length;
	//set length
	if(percentage < 10)
		length = 1;
	else if(percentage < 100)
		length = 2;
	else
		length = 3;
	//convert value to string
	IntToAscii(percentage, &percentageStr[0], length);
	percentageStr[length] = '%';	//add '%'
	TEXT_SetText(percentageLabel, (const char*)&percentageStr[0]);
}
#endif

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OperScreenResetKey()
//
//    Processing:
//		This operation reset key status for all button to released status
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void OperScreenResetKey()
{
	leftKeyPressed = false;
	rightKeyPressed = false;
	enterKeyPressed = false;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: OperScreenHandleEvent()
//
//    Processing:
//		This operation handle event come to operation screen
//
//    Input Parameters:
//		GuiEventStruct guiEvent: event need to be handled
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void OperScreenHandleEvent(GuiEventStruct guiEvent)
{
	switch(guiEvent.id)
	{
	case eGuiOperationStopId:
		//clear parameters to stop
		OperScreenEnterIdle();
		break;
	case eGuiOperationStartId:
		//set flag to activate operation GUI
		guiOperState = eGuiOperRunning;
		//show starting dialog
		LoadingScreenReload();
		//		WM_ShowWindow(loadingScreen);
		//bring to top
		//		WM_BringToTop(loadingScreen);
		//check if sleep screen is showed, then hide sleep screen
		if(isSleepShowing == true)
			GuiTaskSendEvent(eGuiSleepScreenHideId, 0);
		//start timer 1 to enter sleep
		SoftTimerStartMocks(eSoftTimer1Id);//SoftTimerStart(eSoftTimer1Id);
		break;
	case eGuiOperationRunId:
		OperScreenEnterRunning();
		//hide starting dialog
		//		WM_HideWindow(loadingScreen);
		//check if sleep screen is showed, then hide sleep screen
		if(isSleepShowing == true)
			GuiTaskSendEvent(eGuiSleepScreenHideId, 0);
		if(isDryShowing == true)
		{
			//hide drying dialog
			//			WM_HideWindow(dryScreen);
			isDryShowing = false;
		}
		//reload user screen
		UserSettingReloadMocks(guiOperState);//UserSettingReload(guiOperState);
		//start timer 1 to enter sleep
		SoftTimerStartMocks(eSoftTimer1Id);//SoftTimerStart(eSoftTimer1Id);

		//send event to log start in system log
		//		if(isStartByManual == true)
		//		{
		//			//log motor started
		//			SystemTaskSendEvent(eSystemStateLogId, eSystemManualStart);
		//		}
		//		else
		//		{
		//			//log motor started
		//			SystemTaskSendEvent(eSystemStateLogId, eSystemAutoStart);
		//		}
		break;
	case eGuiOperationDryId:
		if(guiEvent.data == DRY_TOTAL_MINUTES)
		{
			//show drying process dialog
			OperScreenEnterDrying();
			//check if sleep screen is showed, then hide sleep screen
			if(isSleepShowing == true)
				GuiTaskSendEvent(eGuiSleepScreenHideId, 0);
			//start timer 1 to enter sleep
			SoftTimerStartMocks(eSoftTimer1Id);//SoftTimerStart(eSoftTimer1Id);
		}
		else if(guiEvent.data == 0)
		{
			//hide drying dialog
			//			WM_HideWindow(dryScreen);
			isDryShowing = false;
		}
		else
		{
			//update time to drying dialog
			DryScreenUpdate(guiEvent.data);
		}
		break;
	case eGuiOperationMaskOffId:
		//reset key status
		OperScreenResetKey();
		//set flag to deactivate operation GUI
		guiOperState = eGuiOperMaskOff;
		break;
	case eGuiOperUpdateSettingId:
		//update setting
		OperScreenUpdateSetting();
		break;
	case eGuiRampTimeStartId:
		OperScreenStartRamp();
		break;
	case eGuiRampTimeEndId:
		OperScreenEndRamp();
		break;
	case eGuiRampTimeCountId:
		OPerScreenUpdateRampTime();
		break;
	case eGuiRealPressUpdateId:
		OPerScreenUpdateRealPressure();
		break;
	case eGuiTreatPressUpdateId:
		//update treatment pressure on sleep screen
		SleepScrUpdatePressureMocks();//SleepScrUpdatePressure();
		//update treatment pressure on operation screen
		OperScreenUpdateTreatPressure();
		break;
	case eGuiUserOptionShowId:
		//do not enter if alarm is showing
		if(isAlarmShowing | isDryShowing)
			break;
		//bring to top
		//		WM_BringToTop(userOptionScreen);
		//set user option is showing now
		isUserOptionShowing = true;
		//set focus for user option dialog
		//		WM_SetFocus(userOptionScreen);
		//load setting to user setting dialog
		UserSettingReloadMocks(guiOperState);//UserSettingReload(guiOperState);
		//show user option dialog
		//		WM_ShowWindow(userOptionScreen);
		//reset key event
		OperScreenResetKey();
		break;
	case eGuiUserOptionHideId:
		//clear flag to show user option
		isUserOptionShowing = false;
		//hide user option
		//		WM_HideWindow(userOptionScreen);
		//show operation screen
		//		WM_ShowWindow(operationScreen);
		//set focus on operation screen
		//		WM_SetFocus(operationScreen);
		//reset key status
		OperScreenResetKey();
		break;
	case eGuiAlarmDialogShowId:
		//check data
		//if leak error and setting auto off is ON, just show nothing
		if((guiEvent.data == eLeakErrorId)&&(SettingGetMocks(eAutoOFFSettingId) == eOn))//(SettingGet(eAutoOFFSettingId) == eOn))
		{
			//send event to stop motor
			unsigned char sendEvent = eMotorStopEventId;
			if(xQueueSendToBack(motorQueue, &sendEvent, 2) != pdPASS)
			{
			}
			//MotorTaskSendEvent(eMotorStopEventId);
			//send event to log as auto OFF
			SystemEventStruct event;
			event.Id = eSystemStateLogId;
			event.Data.type1 = eSystemAutoOFF;
			//send event to queue
			if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
			{

			}
			//SystemTaskSendEvent(eSystemStateLogId, eSystemAutoOFF);
			//			DebugStr("Leak occurred, STOP MOTOR");
		}
		else		//otherwise, show alarm dialog
		{
			//			DebugStr("Leak occurred, Show alarm dialog");
			//set flag to show alarm dialog
			isAlarmShowing = true;
			//make string to show on alarm dialog
			AlarmDialogMakeStr(guiEvent.data);
			//show alarm screen
			//			WM_ShowWindow(alarmDialog);
			//bring alarm to top
			//			WM_BringToTop(alarmDialog);
			//set focus on operation screen
			//			WM_SetFocus(operationScreen);
			//			//check if sleep screen is showed, then hide sleep screen
			//			if(isSleepShowing == true)
			//				GuiTaskSendEvent(eGuiSleepScreenHideId, 0);
			//			//start timer 1 to enter sleep
			//			SoftTimerStart(eSoftTimer1Id);
		}
		//check if sleep screen is showed, then hide sleep screen
		if(isSleepShowing == true)
			GuiTaskSendEvent(eGuiSleepScreenHideId, 0);
		//start timer 1 to enter sleep
		SoftTimerStartMocks(eSoftTimer1Id);//SoftTimerStart(eSoftTimer1Id);
		break;
	case eGuiAlarmDialogHideId:
		if(isAlarmShowing == false)
			return;
		//clear flag to show alarm dialog
		isAlarmShowing = false;
		//hide alarm dialog
		//		WM_HideWindow(alarmDialog);
		//check if user setting is showing, then set focus on it
		if(isUserOptionShowing == true)
		{
			//			WM_SetFocus(userOptionScreen);
			//load setting to user setting dialog
			//			WM_ShowWindow(userOptionScreen);
		}
		else
		{
			//			WM_SetFocus(operationScreen);
			//			WM_ShowWindow(operationScreen);
		}
		//reset key status
		OperScreenResetKey();
		break;
	case eGuiSleepScreenShowId:
		//set flag to show sleep screen
		isSleepShowing = true;
		//set sleep screen display type
		if(guiOperState == eGuiOperRunning)
			SleepScrSetTypeMocks(eDispOperType);//SleepScrSetType(eDispOperType);
		else
			SleepScrSetTypeMocks(eDispIdleType);//SleepScrSetType(eDispIdleType);
		//show user option dialog
//		WM_ShowWindow(sleepScreen);
		//hide pop up
//		WM_HideWindow(popUp);
		//set focus to operation screen
//		WM_SetFocus(operationScreen);
		break;
	case eGuiSleepScreenHideId:
		//check if sleep screen is showed or not
		if(isSleepShowing == false)
			break;

		//clear flag to show sleep screen
		isSleepShowing = false;
		//hide sleep screen
//		WM_HideWindow(sleepScreen);
		//check user setting is showed and set focus on it
		if((isUserOptionShowing == true)&&(isAlarmShowing == false))
		{
//			WM_SetFocus(userOptionScreen);		//focus user dialog
//			WM_ShowWindow(userOptionScreen);	//show user dialog
		}
		else
		{
//			WM_SetFocus(operationScreen);
//			WM_ShowWindow(operationScreen);
		}
		//reset key status
		OperScreenResetKey();
		//start timer 1 to enter sleep
		SoftTimerStartMocks(eSoftTimer1Id);//SoftTimerStart(eSoftTimer1Id);
		break;
	case eGuiRequestReadSdId:
		if(guiOperState != eGuiOperRunning)
		{
			//if system is in idle, read setting from SD card and apply
			SettingReadFromSdMocks();//SettingReadFromSd();
		}
		else
		{
			//if system is operating, set flag to read from SD for next time go to idle
			SettingSetRequestReadSdMocks();//SettingSetRequestReadSd();
		}
		break;
	case eGuiChangeScreenTimerId:
		OperScreenHandleTimeOut();
		break;
	default:
		break;
	}
}

#if defined(__cplusplus)
}
#endif
