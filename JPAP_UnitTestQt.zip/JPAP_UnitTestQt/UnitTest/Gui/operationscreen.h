/*
 * operationscreen.h
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_GUI_OPERATIONSCREEN_H_
#define UNITTEST_GUI_OPERATIONSCREEN_H_

#include <guiinterface.h>
#include <stdbool.h>
#include "WM.h"
//#include "systemconfig.h"
#include "guidefine.h"

// operation window
//extern WM_HWIN operationScreen;

typedef enum
{
	eChangeOperScrTimerId = 0,
	eChangeClinicScrTimerId,
	eChangeMaintenanceScrTimerId,
	eChangeSystemLogScrTimerId
} E_ChangeScrTimerId;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void OperScreenHandleKeyEvent(E_KeyEventId eventId);
void cbGuiOperRealTimePressureIndicator(WM_MESSAGE * pMsg);
void cbGuiOperTreatPressIndicator(WM_MESSAGE * pMsg, int max, int min);
void cbOperationScreen(WM_MESSAGE * pMsg);
void OperScreenTimeoutHandle();
void OperScreenResetKey();
void OPerScreenUpdateRealPressure();
void OperScreenUpdateTreatPressure();
void OPerScreenUpdateRampTime();
void OperScreenStartRamp();
void OperScreenEndRamp();
void OperScreenHandleTimeOut();

//function to create operation screen and child's objects
void OperScreenInit();
//function to enter standby
void OperScreenEnterIdle();
//function to enter drying screen
void OperScreenEnterDrying();
//function to enter operation
void OperScreenEnterRunning();
//function to prepare operation screen before display
void OperScreenUpdateSetting();
//function to handle event
void OperScreenHandleEvent(GuiEventStruct guiEvent);

//void OperScreenBackToRunning();		//back to running
//bool OperScreenIsActivated();		//ask for system is running or not
//void OperScreenCheckToSleepScreen();
//void OperScreenShow();

/******************add function for AVERAGE/CURRENT VOLUME********************/
#if SUPPORT_EVENT_DISPLAY
void OperscreenSetAverageVolume(int value);
void OperscreenSetCurrentVolume(int value);
void OperscreenSetPercentage(int percentage);
#endif
/****************************************************************************/

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_OPERATIONSCREEN_H_ */
