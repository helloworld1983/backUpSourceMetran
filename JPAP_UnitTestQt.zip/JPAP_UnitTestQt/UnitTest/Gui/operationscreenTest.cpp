/*
 * operationscreenTest.cpp
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#include "stdafx.h"
#include "Fixture.h"
#include "operationscreen.h"

#include <setting.h>

#include "guiglobal.h"
#include "SoftTimerMocks.h"
#include "alarminterface.h"
#include "SleepScrMocks.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern int testcbGuiOperRealTimePressureIndicator;
extern int testcbGuiOperTreatPressIndicator;
extern E_KeyEventId testkeyEventcbOperationScreen;
extern E_GuiOperState guiOperState;
extern bool isSleepShowing;
extern float guiOperPressure;
extern float guiOperTreatPressure;
extern float guiOperBottomPressure;
extern float guiOperTopPressure;
extern bool isRunningRampTime;
extern short guiOperRampValue;
extern short guiOperRampTimeSetting;
extern bool isDryShowing;
extern bool isUserOptionShowing;
extern int testAlarmScreenCallback;
extern int testDryScreen;
extern E_ChangeScrTimerId changeScreenTimerId;
extern bool leftKeyPressed;
extern bool isAlarmShowing;
extern bool rightKeyPressed;
extern bool enterKeyPressed;
extern unsigned char guiOperInhSupportSetting;
extern unsigned char guiOperExhSupportSetting;
extern char guiOperPressSettingStr[];
extern int testLoadingScreenReload;
extern int testDryScreen;
extern int testlengthOfMinute;
extern char* alarmInforStrTest;

namespace EmbeddedCUnitTest {


class OperationScreenTest : public TestFixture
{
public:
	OperationScreenTest() : TestFixture(new ModuleMock) {}
};

TEST_F(OperationScreenTest, cbGuiOperRealTimePressureIndicator1)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	pMsg.Data.v = 10;
	cbGuiOperRealTimePressureIndicator(&pMsg);

	EXPECT_EQ(176,testcbGuiOperRealTimePressureIndicator);
}

TEST_F(OperationScreenTest, cbGuiOperRealTimePressureIndicator2)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	pMsg.Data.v = 2;
	cbGuiOperRealTimePressureIndicator(&pMsg);

	EXPECT_EQ(180,testcbGuiOperRealTimePressureIndicator);
}

TEST_F(OperationScreenTest, cbGuiOperRealTimePressureIndicator3)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	pMsg.Data.v = 1000;
	cbGuiOperRealTimePressureIndicator(&pMsg);

	EXPECT_EQ(90,testcbGuiOperRealTimePressureIndicator);
}

TEST_F(OperationScreenTest, cbGuiOperTreatPressIndicator1)
{
	EXPECT_CALL(*_ProgbarLib,PROGBAR_GetMinMax(_,_,_)).Times(1);

	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	pMsg.Data.v = 10;
	cbGuiOperTreatPressIndicator(&pMsg,20,15);
	EXPECT_EQ(25,testcbGuiOperTreatPressIndicator);
}

TEST_F(OperationScreenTest, cbGuiOperTreatPressIndicator2)
{
	EXPECT_CALL(*_ProgbarLib,PROGBAR_GetMinMax(_,_,_)).Times(1);

	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	pMsg.Data.v = 30;
	cbGuiOperTreatPressIndicator(&pMsg,20,20);
	EXPECT_EQ(25,testcbGuiOperTreatPressIndicator);
}

TEST_F(OperationScreenTest, cbOperationScreen1)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	cbOperationScreen(&pMsg);
	EXPECT_EQ(eKeyNoEventId,testkeyEventcbOperationScreen);
}

TEST_F(OperationScreenTest, cbOperationScreen2)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	WM_KEY_INFO* keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_LEFT;
	keyData->PressedCnt = 1;
	pMsg.Data.p = keyData;
	cbOperationScreen(&pMsg);
	EXPECT_EQ(eLeftKeyPressedId,testkeyEventcbOperationScreen);
}

TEST_F(OperationScreenTest, cbOperationScreen3)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	WM_KEY_INFO* keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_LEFT;
	keyData->PressedCnt = 0;
	pMsg.Data.p = keyData;
	cbOperationScreen(&pMsg);
	EXPECT_EQ(eLeftKeyReleasedId,testkeyEventcbOperationScreen);
}

TEST_F(OperationScreenTest, cbOperationScreen4)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	WM_KEY_INFO* keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_RIGHT;
	keyData->PressedCnt = 1;
	pMsg.Data.p = keyData;
	cbOperationScreen(&pMsg);
	EXPECT_EQ(eRightKeyPressedId,testkeyEventcbOperationScreen);
}

TEST_F(OperationScreenTest, cbOperationScreen5)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	WM_KEY_INFO* keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_RIGHT;
	keyData->PressedCnt = 0;
	pMsg.Data.p = keyData;
	cbOperationScreen(&pMsg);
	EXPECT_EQ(eRightKeyReleasedId,testkeyEventcbOperationScreen);
}

TEST_F(OperationScreenTest, cbOperationScreen6)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	WM_KEY_INFO* keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_HOME;
	keyData->PressedCnt = 1;
	pMsg.Data.p = keyData;
	cbOperationScreen(&pMsg);
	EXPECT_EQ(eEnterKeyPressedId,testkeyEventcbOperationScreen);
}

TEST_F(OperationScreenTest, cbOperationScreen7)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	WM_KEY_INFO* keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_HOME;
	keyData->PressedCnt = 0;
	pMsg.Data.p = keyData;
	cbOperationScreen(&pMsg);
	EXPECT_EQ(eEnterKeyReleasedId,testkeyEventcbOperationScreen);
}

TEST_F(OperationScreenTest, cbOperationScreen8)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	WM_KEY_INFO* keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_OPER;
	keyData->PressedCnt = 1;
	pMsg.Data.p = keyData;
	cbOperationScreen(&pMsg);
	EXPECT_EQ(eOperKeyPressedId,testkeyEventcbOperationScreen);
}

TEST_F(OperationScreenTest, cbOperationScreen9)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	WM_KEY_INFO* keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_OPER;
	keyData->PressedCnt = 0;
	pMsg.Data.p = keyData;
	cbOperationScreen(&pMsg);
	EXPECT_EQ(eOperKeyReleasedId,testkeyEventcbOperationScreen);
}

TEST_F(OperationScreenTest, OPerScreenUpdateRealPressure1)
{
	guiOperState = eGuiOperIdle;
	OPerScreenUpdateRealPressure();
	EXPECT_EQ(eGuiOperRunning,guiOperState);
}

TEST_F(OperationScreenTest, OPerScreenUpdateRealPressure2)
{
	isSleepShowing = true;
	OPerScreenUpdateRealPressure();
	EXPECT_EQ(false,isSleepShowing);
}

TEST_F(OperationScreenTest, OPerScreenUpdateRealPressure3)
{
	EXPECT_CALL(*_AnalyzeDataLib,AnalyzeDataGetFilteredNosePressureMocks(_)).Times(1);
	EXPECT_CALL(*_ProgbarLib,PROGBAR_SetValue(_,_)).Times(1);
	EXPECT_CALL(*_wstring,StrToolFtoA(_,_,_)).Times(1);

	guiOperState = eGuiOperRunning;
	isSleepShowing = false;
	guiOperPressure = -1.0f;
	OPerScreenUpdateRealPressure();
	EXPECT_EQ(0.0f,guiOperPressure);
}

TEST_F(OperationScreenTest, OPerScreenUpdateRealPressure4)
{
	EXPECT_CALL(*_AnalyzeDataLib,AnalyzeDataGetFilteredNosePressureMocks(_)).Times(1);
	EXPECT_CALL(*_ProgbarLib,PROGBAR_SetValue(_,_)).Times(1);
	EXPECT_CALL(*_wstring,StrToolFtoA(_,_,_)).Times(1);

	guiOperState = eGuiOperRunning;
	isSleepShowing = false;
	guiOperPressure = 21.0f;
	OPerScreenUpdateRealPressure();
	EXPECT_EQ(20.0f,guiOperPressure);
}

TEST_F(OperationScreenTest, OperScreenUpdateTreatPressure1)
{
	guiOperState = eGuiOperIdle;
	OperScreenUpdateTreatPressure();
	EXPECT_EQ(eGuiOperRunning,guiOperState);
}

TEST_F(OperationScreenTest, OperScreenUpdateTreatPressure2)
{
	EXPECT_CALL(*_AnalyzeDataLib,AnalyzeDataGetTreatmentPressureMocks(_)).Times(1);
	EXPECT_CALL(*_ProgbarLib,PROGBAR_SetValue(_,_)).Times(1);
	EXPECT_CALL(*_wstring,StrToolFtoA(_,_,_)).Times(1);

	guiOperState = eGuiOperRunning;
	guiOperTreatPressure = 10;
	guiOperBottomPressure = 20;
	guiOperTopPressure = 30;
	OperScreenUpdateTreatPressure();
	EXPECT_EQ(eGuiOperRunning,guiOperState);
	EXPECT_EQ(20,guiOperTreatPressure);
}

TEST_F(OperationScreenTest, OperScreenUpdateTreatPressure3)
{
	EXPECT_CALL(*_AnalyzeDataLib,AnalyzeDataGetTreatmentPressureMocks(_)).Times(1);
	EXPECT_CALL(*_ProgbarLib,PROGBAR_SetValue(_,_)).Times(1);
	EXPECT_CALL(*_wstring,StrToolFtoA(_,_,_)).Times(1);

	guiOperState = eGuiOperRunning;
	guiOperTreatPressure = 40;
	guiOperBottomPressure = 20;
	guiOperTopPressure = 30;
	OperScreenUpdateTreatPressure();
	EXPECT_EQ(eGuiOperRunning,guiOperState);
	EXPECT_EQ(30,guiOperTreatPressure);
}

TEST_F(OperationScreenTest, OperScreenUpdateTreatPressure4)
{
	EXPECT_CALL(*_AnalyzeDataLib,AnalyzeDataGetTreatmentPressureMocks(_)).Times(1);
	EXPECT_CALL(*_ProgbarLib,PROGBAR_GetMinMax(_,_,_)).Times(1);
	EXPECT_CALL(*_ProgbarLib,PROGBAR_SetValue(_,_)).Times(1);
	EXPECT_CALL(*_wstring,StrToolFtoA(_,_,_)).Times(1);

	guiOperState = eGuiOperRunning;
	guiOperTreatPressure = 40;
	guiOperBottomPressure = 20;
	guiOperTopPressure = 15;
	OperScreenUpdateTreatPressure();
	EXPECT_EQ(eGuiOperRunning,guiOperState);
	EXPECT_EQ(15,guiOperTreatPressure);
}

TEST_F(OperationScreenTest, OPerScreenUpdateRampTime1)
{
	guiOperState = eGuiOperIdle;
	OPerScreenUpdateRampTime();
	EXPECT_EQ(eGuiOperRunning,guiOperState);
}

TEST_F(OperationScreenTest, OPerScreenUpdateRampTime2)
{
	EXPECT_CALL(*_wstring,StrToolTtoS(_,_)).Times(1);

	guiOperState = eGuiOperRunning;
	isRunningRampTime = true;
	guiOperRampValue = 10;
	guiOperRampTimeSetting = 9;
	OPerScreenUpdateRampTime();
	EXPECT_EQ(false,isRunningRampTime);
	EXPECT_EQ(9,guiOperRampValue);
}

TEST_F(OperationScreenTest, OPerScreenUpdateRampTime3)
{
	EXPECT_CALL(*_wstring,StrToolTtoS(_,_)).Times(1);

	guiOperState = eGuiOperRunning;
	isRunningRampTime = true;
	guiOperRampValue = 9;
	guiOperRampTimeSetting = 10;
	OPerScreenUpdateRampTime();
	EXPECT_EQ(true,isRunningRampTime);
	EXPECT_EQ(10,guiOperRampValue);
}

TEST_F(OperationScreenTest, OperScreenEnterRunning1)
{
	EXPECT_CALL(*_wstring,StrToolTtoS(_,_)).Times(1);

	guiOperRampTimeSetting = 1;
	OperScreenEnterRunning();

	EXPECT_EQ(0,guiOperRampValue);
	EXPECT_EQ(eGuiOperRunning,guiOperState);
	EXPECT_EQ(false,isRunningRampTime);
}

TEST_F(OperationScreenTest, OperScreenEnterRunning2)
{
	guiOperRampTimeSetting = 0;
	OperScreenEnterRunning();

	EXPECT_EQ(0,guiOperRampValue);
	EXPECT_EQ(eGuiOperRunning,guiOperState);
	EXPECT_EQ(false,isRunningRampTime);
}

TEST_F(OperationScreenTest, OperScreenStartRamp)
{
	EXPECT_CALL(*_wstring,StrToolTtoS(_,_)).Times(1);

	OperScreenStartRamp();

	EXPECT_EQ(0,guiOperRampValue);
	EXPECT_EQ(true,isRunningRampTime);
}

TEST_F(OperationScreenTest, OperScreenEndRamp1)
{
	guiOperState = eGuiOperIdle;
	OperScreenEndRamp();

	EXPECT_EQ(eGuiOperRunning,guiOperState);
}

TEST_F(OperationScreenTest, OperScreenEndRamp2)
{
	EXPECT_CALL(*_ProgbarLib,PROGBAR_GetMinMax(_,_,_)).Times(1);
	EXPECT_CALL(*_ProgbarLib,PROGBAR_SetValue(_,_)).Times(1);
	EXPECT_CALL(*_wstring,StrToolTtoS(_,_)).Times(1);

	guiOperState = eGuiOperRunning;
	guiOperRampTimeSetting = 100;
	OperScreenEndRamp();
	EXPECT_EQ(false,isRunningRampTime);
	EXPECT_EQ(100,guiOperRampValue);
}

TEST_F(OperationScreenTest, OperScreenEnterIdle)
{
	EXPECT_CALL(*_UserSettingLib,UserSettingReloadMocks(_)).Times(1);

	OperScreenEnterIdle();
	EXPECT_EQ(eGuiOperIdle,guiOperState);
	EXPECT_EQ(false,isDryShowing);
}

TEST_F(OperationScreenTest, OperScreenEnterDrying)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	isUserOptionShowing = true;
	OperScreenEnterDrying();
	EXPECT_EQ(eGuiOperDrying,guiOperState);
	EXPECT_EQ(true,isDryShowing);
}

TEST_F(OperationScreenTest, OperScreenInit1)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eLanguageSettingId)).Times(2).WillOnce(Return(0)).WillOnce(Return(0));
	EXPECT_CALL(*_UserSettingLib,UserSettingDialogInitMocks()).Times(1);

	OperScreenInit();
	EXPECT_EQ(0,language);
	EXPECT_EQ(0,testAlarmScreenCallback);
	EXPECT_EQ(1,testDryScreen);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent1)
{
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	isSleepShowing = true;
	guiOperState = eGuiOperIdle;
	isAlarmShowing = true;
	enterKeyPressed = true;
	rightKeyPressed = true;
	leftKeyPressed = false;
	OperScreenHandleKeyEvent(eLeftKeyPressedId);
	EXPECT_EQ(true,leftKeyPressed);
	EXPECT_EQ(eChangeOperScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent2)
{
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStartMocks(eSoftTimer2Id)).Times(1);

	isSleepShowing = true;
	guiOperState = eGuiOperIdle;
	isAlarmShowing = false;
	enterKeyPressed = true;
	rightKeyPressed = true;
	leftKeyPressed = true;
	OperScreenHandleKeyEvent(eLeftKeyReleasedId);
	EXPECT_EQ(false,leftKeyPressed);
	EXPECT_EQ(eChangeClinicScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent3)
{
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStartMocks(eSoftTimer2Id)).Times(1);

	isSleepShowing = true;
	guiOperState = eGuiOperIdle;
	isAlarmShowing = false;
	enterKeyPressed = true;
	rightKeyPressed = false;
	leftKeyPressed = false;
	OperScreenHandleKeyEvent(eRightKeyPressedId);
	EXPECT_EQ(true,rightKeyPressed);
	EXPECT_EQ(eChangeClinicScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent4)
{
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStartMocks(eSoftTimer2Id)).Times(1);

	isSleepShowing = true;
	guiOperState = eGuiOperIdle;
	isAlarmShowing = false;
	enterKeyPressed = false;
	rightKeyPressed = false;
	leftKeyPressed = true;
	OperScreenHandleKeyEvent(eRightKeyPressedId);
	EXPECT_EQ(true,rightKeyPressed);
	EXPECT_EQ(eChangeMaintenanceScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent5)
{
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	isSleepShowing = true;
	guiOperState = eGuiOperIdle;
	isAlarmShowing = true;
	enterKeyPressed = false;
	rightKeyPressed = false;
	leftKeyPressed = true;
	OperScreenHandleKeyEvent(eRightKeyPressedId);
	EXPECT_EQ(true,rightKeyPressed);
	EXPECT_EQ(eChangeOperScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent6)
{
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);

	isSleepShowing = true;
	guiOperState = eGuiOperIdle;
	isAlarmShowing = true;
	enterKeyPressed = false;
	rightKeyPressed = true;
	leftKeyPressed = true;
	OperScreenHandleKeyEvent(eRightKeyReleasedId);
	EXPECT_EQ(false,rightKeyPressed);
	EXPECT_EQ(eChangeOperScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent7)
{
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStartMocks(eSoftTimer2Id)).Times(1);

	isSleepShowing = true;
	guiOperState = eGuiOperIdle;
	isAlarmShowing = false;
	enterKeyPressed = false;
	rightKeyPressed = true;
	leftKeyPressed = true;
	OperScreenHandleKeyEvent(eEnterKeyPressedId);
	EXPECT_EQ(true,enterKeyPressed);
	EXPECT_EQ(eChangeSystemLogScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent8)
{
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	isSleepShowing = false;
	guiOperState = eGuiOperIdle;
	isAlarmShowing = true;
	enterKeyPressed = false;
	rightKeyPressed = true;
	leftKeyPressed = true;
	OperScreenHandleKeyEvent(eEnterKeyPressedId);
	EXPECT_EQ(true,enterKeyPressed);
	EXPECT_EQ(eChangeOperScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent9)
{
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	isSleepShowing = false;
	guiOperState = eGuiOperIdle;
	isAlarmShowing = false;
	enterKeyPressed = false;
	rightKeyPressed = false;
	leftKeyPressed = false;
	OperScreenHandleKeyEvent(eEnterKeyPressedId);
	EXPECT_EQ(true,enterKeyPressed);
	EXPECT_EQ(eChangeOperScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent10)
{
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);

	isSleepShowing = false;
	guiOperState = eGuiOperIdle;
	isAlarmShowing = true;
	enterKeyPressed = true;
	rightKeyPressed = false;
	leftKeyPressed = false;
	OperScreenHandleKeyEvent(eEnterKeyReleasedId);
	EXPECT_EQ(false,enterKeyPressed);
	EXPECT_EQ(eChangeOperScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent11)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(3);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);

	guiOperState = eGuiOperRunning;
	isSleepShowing = true;
	isAlarmShowing = true;
	enterKeyPressed = true;
	rightKeyPressed = false;
	leftKeyPressed = false;
	OperScreenHandleKeyEvent(eOperKeyPressedId);
	EXPECT_EQ(eChangeOperScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent12)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(3);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);

	guiOperState = eGuiOperMaskOff;
	isSleepShowing = true;
	isAlarmShowing = true;
	enterKeyPressed = true;
	rightKeyPressed = false;
	leftKeyPressed = false;
	OperScreenHandleKeyEvent(eOperKeyPressedId);
	EXPECT_EQ(eChangeOperScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent13)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(3);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);

	guiOperState = eGuiOperDrying;
	isSleepShowing = true;
	isAlarmShowing = false;
	enterKeyPressed = true;
	rightKeyPressed = true;
	leftKeyPressed = false;
	OperScreenHandleKeyEvent(eOperKeyPressedId);
	EXPECT_EQ(eChangeOperScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent14)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(3);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStartMocks(eSoftTimer2Id)).Times(1);

	guiOperState = eGuiOperIdle;
	isSleepShowing = true;
	isAlarmShowing = false;
	enterKeyPressed = true;
	rightKeyPressed = true;
	leftKeyPressed = false;
	OperScreenHandleKeyEvent(eOperKeyPressedId);
	EXPECT_EQ(eChangeClinicScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleKeyEvent15)
{
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStopMocks(eSoftTimer2Id)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStartMocks(eSoftTimer2Id)).Times(1);

	guiOperState = eGuiOperIdle;
	isSleepShowing = true;
	isAlarmShowing = false;
	enterKeyPressed = false;
	rightKeyPressed = true;
	leftKeyPressed = true;
	OperScreenHandleKeyEvent(eOperKeyReleasedId);
	EXPECT_EQ(eChangeMaintenanceScrTimerId,changeScreenTimerId);
}

TEST_F(OperationScreenTest, OperScreenHandleTimeOut1)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	changeScreenTimerId = eChangeClinicScrTimerId;
	OperScreenHandleTimeOut();
	EXPECT_EQ(false,leftKeyPressed);
	EXPECT_EQ(false,rightKeyPressed);
	EXPECT_EQ(false,enterKeyPressed);
}

TEST_F(OperationScreenTest, OperScreenHandleTimeOut2)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	changeScreenTimerId = eChangeMaintenanceScrTimerId;
	OperScreenHandleTimeOut();
	EXPECT_EQ(false,leftKeyPressed);
	EXPECT_EQ(false,rightKeyPressed);
	EXPECT_EQ(false,enterKeyPressed);
}

TEST_F(OperationScreenTest, OperScreenHandleTimeOut3)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	changeScreenTimerId = eChangeSystemLogScrTimerId;
	OperScreenHandleTimeOut();
	EXPECT_EQ(false,leftKeyPressed);
	EXPECT_EQ(false,rightKeyPressed);
	EXPECT_EQ(false,enterKeyPressed);
}

TEST_F(OperationScreenTest, OperScreenUpdateSetting1)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eInhPressSupportSettingId)).Times(1).WillOnce(Return(10));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eExhPressSupportSettingId)).Times(1).WillOnce(Return(3));

	guiOperState = eGuiOperRunning;
	OperScreenUpdateSetting();
	EXPECT_EQ(5,guiOperInhSupportSetting);
	EXPECT_EQ(3,guiOperExhSupportSetting);
}

TEST_F(OperationScreenTest, OperScreenUpdateSetting2)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eInhPressSupportSettingId)).Times(1).WillOnce(Return(3));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eExhPressSupportSettingId)).Times(1).WillOnce(Return(10));

	guiOperState = eGuiOperRunning;
	OperScreenUpdateSetting();
	EXPECT_EQ(3, guiOperInhSupportSetting);
	EXPECT_EQ(5,guiOperExhSupportSetting);
}

TEST_F(OperationScreenTest, OperScreenUpdateSetting3)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eInhPressSupportSettingId)).Times(1).WillOnce(Return(3));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eExhPressSupportSettingId)).Times(1).WillOnce(Return(10));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eAutoUpperPressSettingId)).Times(1).WillOnce(Return(15));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eAutoLowerPressSettingId)).Times(1).WillOnce(Return(25));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eVentModeSettingId)).Times(2).WillOnce(Return(eAutoMode)).WillOnce(Return(eAutoMode));
	EXPECT_CALL(*_wstring,StrToolTtoS(_,_)).Times(1);
	EXPECT_CALL(*_wstring,StrToolFtoA(_,_,1)).Times(2);
	EXPECT_CALL(*_ProgbarLib,PROGBAR_SetValue(_,0)).Times(2);

	guiOperState = eGuiOperIdle;
	OperScreenUpdateSetting();
	EXPECT_EQ(3, guiOperInhSupportSetting);
	EXPECT_EQ(5,guiOperExhSupportSetting);

	EXPECT_EQ(1.5f,guiOperTopPressure);
	EXPECT_EQ(2.5f,guiOperBottomPressure);
	for(int i = 0; i < 10; i++)
		EXPECT_EQ('\0', guiOperPressSettingStr[i]);
}

TEST_F(OperationScreenTest, OperScreenUpdateSetting4)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eInhPressSupportSettingId)).Times(1).WillOnce(Return(3));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eExhPressSupportSettingId)).Times(1).WillOnce(Return(10));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eOperPressSettingId)).Times(1).WillOnce(Return(25));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eDelayPressSettingId)).Times(1).WillOnce(Return(55));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eRampTimeSettingId)).Times(1).WillOnce(Return(2));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eVentModeSettingId)).Times(2).WillOnce(Return(eCpapMode)).WillOnce(Return(eCpapMode));
	EXPECT_CALL(*_wstring,StrToolTtoS(_,_)).Times(1);
	EXPECT_CALL(*_wstring,StrToolFtoA(_,_,1)).Times(2);
	EXPECT_CALL(*_ProgbarLib,PROGBAR_SetValue(_,0)).Times(2);

	guiOperState = eGuiOperIdle;
	OperScreenUpdateSetting();
	EXPECT_EQ(3, guiOperInhSupportSetting);
	EXPECT_EQ(5,guiOperExhSupportSetting);

	EXPECT_EQ(2.5f,guiOperTopPressure);
	EXPECT_EQ(5.5f,guiOperBottomPressure);
	EXPECT_EQ(120,guiOperRampTimeSetting);
	for(int i = 0; i < 10; i++)
		EXPECT_EQ('\0', guiOperPressSettingStr[i]);
}

TEST_F(OperationScreenTest, OperScreenUpdateSetting5)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eInhPressSupportSettingId)).Times(1).WillOnce(Return(3));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eExhPressSupportSettingId)).Times(1).WillOnce(Return(10));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eOperPressSettingId)).Times(1).WillOnce(Return(25));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eDelayPressSettingId)).Times(1).WillOnce(Return(55));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eRampTimeSettingId)).Times(1).WillOnce(Return(2));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eVentModeSettingId)).Times(2).WillOnce(Return(eCpapMode)).WillOnce(Return(eAutoMode));
	EXPECT_CALL(*_wstring,StrToolTtoS(_,_)).Times(1);
	EXPECT_CALL(*_wstring,StrToolFtoA(_,_,1)).Times(2);
	EXPECT_CALL(*_ProgbarLib,PROGBAR_SetValue(_,0)).Times(2);

	guiOperState = eGuiOperIdle;
	OperScreenUpdateSetting();
	EXPECT_EQ(3, guiOperInhSupportSetting);
	EXPECT_EQ(5,guiOperExhSupportSetting);

	EXPECT_EQ(2.5f,guiOperTopPressure);
	EXPECT_EQ(5.5f,guiOperBottomPressure);
	EXPECT_EQ(120,guiOperRampTimeSetting);
	for(int i = 0; i < 10; i++)
		EXPECT_EQ('\0', guiOperPressSettingStr[i]);
}

TEST_F(OperationScreenTest, OperScreenResetKey)
{
	OperScreenResetKey();
	EXPECT_EQ(false,leftKeyPressed);
	EXPECT_EQ(false,rightKeyPressed);
	EXPECT_EQ(false,enterKeyPressed);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent1)
{
	EXPECT_CALL(*_UserSettingLib,UserSettingReloadMocks(_)).Times(1);

	GuiEventStruct guiEvent;
	guiEvent.id = eGuiOperationStopId;
	OperScreenHandleEvent(guiEvent);
	EXPECT_EQ(eGuiOperIdle,guiOperState);
	EXPECT_EQ(false,isDryShowing);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent2)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStartMocks(eSoftTimer1Id)).Times(1);

	GuiEventStruct guiEvent;
	guiEvent.id = eGuiOperationStartId;
	isSleepShowing = true;
	OperScreenHandleEvent(guiEvent);
	EXPECT_EQ(eGuiOperRunning,guiOperState);
	EXPECT_EQ(10,testLoadingScreenReload);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent3)
{
	EXPECT_CALL(*_wstring,StrToolTtoS(_,_)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);
	EXPECT_CALL(*_UserSettingLib,UserSettingReloadMocks(_)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStartMocks(eSoftTimer1Id)).Times(1);

	guiOperRampTimeSetting = 1;
	isSleepShowing = true;
	isDryShowing = true;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiOperationRunId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(0,guiOperRampValue);
	EXPECT_EQ(eGuiOperRunning,guiOperState);
	EXPECT_EQ(false,isRunningRampTime);
	EXPECT_EQ(false,isDryShowing);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent4)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(2);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStartMocks(eSoftTimer1Id)).Times(1);

	isUserOptionShowing = true;
	isSleepShowing = true;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiOperationDryId;
	guiEvent.data = 180;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(eGuiOperDrying,guiOperState);
	EXPECT_EQ(true,isDryShowing);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent5)
{
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiOperationDryId;
	guiEvent.data = 0;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(false,isDryShowing);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent6)
{
	EXPECT_CALL(*_wstring,strlen(_)).Times(1).WillOnce(Return(5));
	EXPECT_CALL(*_wstring,StrAppend(_,_,50)).Times(2);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);

	GuiEventStruct guiEvent;
	guiEvent.id = eGuiOperationDryId;
	guiEvent.data = 100;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(testDryScreen,100);
	EXPECT_EQ(testlengthOfMinute,8);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent7)
{
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiOperationMaskOffId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(eGuiOperMaskOff,guiOperState);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent8)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eInhPressSupportSettingId)).Times(1).WillOnce(Return(10));
	EXPECT_CALL(*_settingLib,SettingGetMocks(eExhPressSupportSettingId)).Times(1).WillOnce(Return(3));

	guiOperState = eGuiOperRunning;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiOperUpdateSettingId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(5,guiOperInhSupportSetting);
	EXPECT_EQ(3,guiOperExhSupportSetting);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent9)
{
	EXPECT_CALL(*_wstring,StrToolTtoS(_,_)).Times(1);

	GuiEventStruct guiEvent;
	guiEvent.id = eGuiRampTimeStartId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(0,guiOperRampValue);
	EXPECT_EQ(true,isRunningRampTime);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent10)
{
	guiOperState = eGuiOperIdle;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiRampTimeEndId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(eGuiOperRunning,guiOperState);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent11)
{
	guiOperState = eGuiOperIdle;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiRampTimeCountId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(eGuiOperRunning,guiOperState);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent12)
{
	guiOperState = eGuiOperIdle;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiRealPressUpdateId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(eGuiOperRunning,guiOperState);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent13)
{
	EXPECT_CALL(*_SleepScrLib,SleepScrUpdatePressureMocks()).Times(1);

	guiOperState = eGuiOperIdle;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiTreatPressUpdateId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(eGuiOperRunning,guiOperState);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent14)
{
	isUserOptionShowing = false;
	isAlarmShowing = true;
	isDryShowing = false;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiUserOptionShowId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(false,isUserOptionShowing);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent15)
{
	EXPECT_CALL(*_UserSettingLib,UserSettingReloadMocks(_)).Times(1);

	isUserOptionShowing = false;
	isAlarmShowing = false;
	isDryShowing = false;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiUserOptionShowId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(true,isUserOptionShowing);
	EXPECT_EQ(false,leftKeyPressed);
	EXPECT_EQ(false,rightKeyPressed);
	EXPECT_EQ(false,enterKeyPressed);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent16)
{
	isUserOptionShowing = true;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiUserOptionHideId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(false,isUserOptionShowing);
	EXPECT_EQ(false,leftKeyPressed);
	EXPECT_EQ(false,rightKeyPressed);
	EXPECT_EQ(false,enterKeyPressed);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent17)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eAutoOFFSettingId)).Times(1).WillOnce(Return(eOn));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(3);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStartMocks(eSoftTimer1Id)).Times(1);

	isSleepShowing = true;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiAlarmDialogShowId;
	guiEvent.data = eLeakErrorId;
	OperScreenHandleEvent(guiEvent);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent18)
{
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStartMocks(eSoftTimer1Id)).Times(1);

	isAlarmShowing = false;
	isSleepShowing = true;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiAlarmDialogShowId;
	guiEvent.data = eBlowerErrorId;
	OperScreenHandleEvent(guiEvent);
	EXPECT_EQ(true,isAlarmShowing);
	EXPECT_EQ(std::string(alarmInforStrTest), "Blower error");
}

TEST_F(OperationScreenTest, OperScreenHandleEvent19)
{
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiAlarmDialogHideId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(false,leftKeyPressed);
	EXPECT_EQ(false,rightKeyPressed);
	EXPECT_EQ(false,enterKeyPressed);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent20)
{
	EXPECT_CALL(*_SleepScrLib,SleepScrSetTypeMocks(eDispOperType)).Times(1);

	guiOperState = eGuiOperRunning;
	isSleepShowing = false;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiSleepScreenShowId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(true,isSleepShowing);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent21)
{
	EXPECT_CALL(*_SleepScrLib,SleepScrSetTypeMocks(eDispIdleType)).Times(1);

	guiOperState = eGuiOperDrying;
	isSleepShowing = false;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiSleepScreenShowId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(true,isSleepShowing);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent22)
{
	isSleepShowing = false;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiSleepScreenHideId;
	OperScreenHandleEvent(guiEvent);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent23)
{
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStartMocks(eSoftTimer1Id)).Times(1);

	isSleepShowing = true;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiSleepScreenHideId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(false,isSleepShowing);
	EXPECT_EQ(false,leftKeyPressed);
	EXPECT_EQ(false,rightKeyPressed);
	EXPECT_EQ(false,enterKeyPressed);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent24)
{
	EXPECT_CALL(*_settingLib,SettingReadFromSdMocks()).Times(1);

	guiOperState = eGuiOperIdle;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiRequestReadSdId;
	OperScreenHandleEvent(guiEvent);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent25)
{
	EXPECT_CALL(*_settingLib,SettingSetRequestReadSdMocks()).Times(1);

	guiOperState = eGuiOperRunning;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiRequestReadSdId;
	OperScreenHandleEvent(guiEvent);
}

TEST_F(OperationScreenTest, OperScreenHandleEvent26)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	changeScreenTimerId = eChangeClinicScrTimerId;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiChangeScreenTimerId;
	OperScreenHandleEvent(guiEvent);

	EXPECT_EQ(false,leftKeyPressed);
	EXPECT_EQ(false,rightKeyPressed);
	EXPECT_EQ(false,enterKeyPressed);
}

}


