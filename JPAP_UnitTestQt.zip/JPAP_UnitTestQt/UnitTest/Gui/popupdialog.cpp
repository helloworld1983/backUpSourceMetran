/*
 * popupdialog.cpp
 *
 *  Created on: Apr 20, 2018
 *      Author: Quoc Viet
 */

#include "popupdialog.h"

#include <stddef.h>
#include "guidefine.h"
#include "popupdialog.h"

#include <guiinterface.h>
#include <motorctrlinterface.h>
#include <setting.h>
#include <systeminterface.h>
#include "string.h"
#include "WM.h"
//#include "FRAMEWIN.h"
//#include "BUTTON.h"
//#include "IMAGE.h"
//#include "TEXT.h"
//#include "fonts.h"
#include "maintenancescreen.h"
#include "strings.h"
//#include "debuguart.h"
//#include "motorupgrade.h"
//#include "mainupgrade.h"
//#include "eeprom.h"
//#include "digitaloutput.h"
#include "deviceinterface.h"
//#include "delay.h"
#include "crc.h"
//#include "rtc.h"
//#include "systeminformation.h"
#include "guiglobal.h"
//#include "softtimer.h"
//#include "bleupgrade.h"
#include "WMMocks.h"
#include "WString.h"
#include "queue.h"
#include "SettingMocks.h"
#include "MainScreenMocks.h"
#include "eepromMocks.h"
#include "SoftTimerMocks.h"

//define color
//#define POPUP_TITLE_COLOR					GUI_WHITE
#define POPUP_BK_COLOR						GUI_WHITE
#define POPUP_PERCENT_COLOR					COLOR_ULTRA_LIGHT_BLUE
#define POPUP_LOADING_COLOR					COLOR_ULTRA_LIGHT_BLUE
#define POPUP_YES_NO_SELECTED_COLOR			COLOR_LIGHT_ORANGE
#define POPUP_YES_NO_UNSELECTED_COLOR		COLOR_ULTRA_LIGHT_BLUE
#define POPUP_OK_COLOR						COLOR_ULTRA_LIGHT_BLUE
#define POPUP_BORDER_COLOR					COLOR_ULTRA_LIGHT_BLUE
#define POPUP_TITLE_BK_COLOR				COLOR_ULTRA_LIGHT_BLUE

int testPopupInit = 0;
PopUpButtonContent yesNoButton[POPUP_NUM_YES_NO_BTN] =
{
		{ strYes,  eRelease },
		{ strNo, ePoint }
};

const char* testnameStrPopupButtonCallback = "";
int testbuttonStatusPopupButtonCallback;
int testPopupCallback = 0;
bool isReceiveKey = false;
E_PopupId popupId = eFirstPopupId;
int testPopupBlowerUpdatePercent = 0;
int testPopupBLEUpdatePercent = 0;
E_PopUpState currentStatePopUp = eNoState;
bool isDryingMode = false;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//WM_HWIN popUp;
//
//static BUTTON_Handle yesButton;
//static BUTTON_Handle noButton;
//static BUTTON_Handle okButton;
//static TEXT_Handle titleLabel;
//static TEXT_Handle percentLabel;
//static TEXT_Handle loadingLabel;

//static E_PopUpState currentStatePopUp = eNoState;
//static WM_HWIN currentScreen;
//static E_PopupId popupId = eFirstPopupId;

//extern WM_HWIN mainWindow;
//extern WM_HWIN clinicScreen;
//extern WM_HWIN userOptionScreen;
//extern WM_HWIN timeSettingDialog;

static xQueueHandle systemQueue;
static xQueueHandle deviceQueue;
static xQueueHandle motorQueue;

//void PopupCallback(WM_MESSAGE * pMsg);
//void PopupEnterKeyHandle();
//void PopupRightLeftKeyHandle();
//void PopupButtonCallback(WM_MESSAGE * pMsg);
//void PopupButtonSetStatus(void* hObj, E_ButtonStatus status);//void PopupButtonSetStatus(BUTTON_Handle hObj, E_ButtonStatus status);
//void PopupBlowerUpdatePercent(int percent);
//void PopupUpgradeError();
//void PopupBlowerUpgradeSuccess();
//void PopupBlowerUpgradeStart();
//void PopupBlowerUpgradeReset();
//void PopupBLEUpgradeSuccess();
//void PopupBLEUpdatePercent(int percent);
//void PopupBLEUpgradeStart();
//void PopupBLEUpgradeReset();
//void PopupExportLogSuccess();
//void PopupExportLogFail();
//void PopupApplyTimeChange();
//void PopupStartCalibrate();
//void PopupStartMaskCalibrate();
//void PopupStartRestoreDefaults();
//void PopupStartClearUsedHours();
//void PopupStartUpgradeControlUnit();
//void PopupStartUpgradeBlowerUnit();
//void PopupStartUpgradeBLEUnit();
//void PopupStartExportLog();
//void PopupStartConnectBLEDevice();
//void PopupStartDisconnectBLE();
//void PopupPreparationDrying();
//void PopupCircuitCalibrateShow();
//void PopupConnectTheMaskShow();
//void PopupCalibrateDone();
//void PopupCalibrateError();
//void PopupTimeChangeShow();
//void PopupRestoreDefaultsShow();
//void PopupClearUsedHoursShow();
//void PopupControlUpgradeShow();
//void PopupBlowerUpgradeShow();
//void PopupBLEUpgradeShow();
//void PopupExportLogShow();
//void PopupConnectBLEDevice(/*int BLEDevice*/);
//void PopupDisconnectBLE(/*int BLEDevice*/);
//void PopupConnectBLEFailed();
//void PopupConnectBLESuccess();
//void PopupConfirmDryingMode();

//static bool isReceiveKey = false;
//static bool isDryingMode = false;
//static PopUpButtonContent yesNoButton[POPUP_NUM_YES_NO_BTN] =
//{
//		{ strYes,  eRelease },
//		{ strNo, ePoint }
//};

typedef enum
{
	eFirstPopupItemId,
	ePopupYesButtonId = eFirstPopupItemId,
	ePopupNoButtonId,
	ePopupOkButtonId,
	ePopupTitleLabelId,
	ePopupPercentLabelId,
	ePopupLoadingLabelId,
	eLastPopupItemId = ePopupLoadingLabelId
} E_PopUpItemId;

//static const GUI_FONT* guiFont14[] = { &GUI_FontMeiryo14B_2bpp, &GUI_FontJPAPJPFont14B };	//font 14
//static const GUI_FONT* guiFont16[] = { &GUI_FontMeiryo16B_2bpp, &GUI_FontJPAPJPFont16B };

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupInit(void)
//
//    Processing:
//		The operation creates pop up for maintenance screen
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupInit(void)
{
	//create reset pop up
	//	popUp = WM_CreateWindowAsChild(POPUP_SCREEN_X, POPUP_SCREEN_Y, POPUP_SCREEN_LENGTH, POPUP_SCREEN_HEIGHT, mainWindow, WM_CF_HIDE | WM_CF_HASTRANS, PopupCallback, 0);
	//	//init YES button
	//	yesButton = BUTTON_CreateEx(POPUP_YES_BUTTON_X, POPUP_YES_BUTTON_Y, POPUP_YES_BUTTON_LENGTH, POPUP_YES_BUTTON_HEIGHT, popUp, WM_CF_SHOW, WM_CF_MEMDEV, ePopupYesButtonId);
	//	WM_SetCallback(yesButton, PopupButtonCallback);
	//	BUTTON_SetFont(yesButton, guiFont16[language]);
	//	BUTTON_SetText(yesButton, strYes[language]);
	//
	//	//init NO button
	//	noButton = BUTTON_CreateEx(POPUP_NO_BUTTON_X, POPUP_NO_BUTTON_Y, POPUP_NO_BUTTON_LENGTH, POPUP_NO_BUTTON_HEIGHT, popUp, WM_CF_SHOW, WM_CF_MEMDEV, ePopupNoButtonId);
	//	WM_SetCallback(noButton, PopupButtonCallback);
	//	BUTTON_SetFont(noButton, guiFont16[language]);
	//	BUTTON_SetText(noButton, strNo[language]);
	//
	//	//init TITLE
	//	titleLabel = TEXT_CreateEx(POPUP_TITLE_LABEL_X, POPUP_TITLE_LABEL_Y, POPUP_TITLE_LABEL_LENGTH, POPUP_TITLE_LABEL_HEIGHT, popUp, WM_CF_SHOW, TEXT_CF_HCENTER/*WM_CF_MEMDEV*/, ePopupTitleLabelId, "");
	//	//	TEXT_SetTextAlign(titleLabel, GUI_TA_CENTER);
	//	TEXT_SetTextColor(titleLabel, POPUP_TITLE_COLOR);
	//	TEXT_SetFont(titleLabel, guiFont16[language]);
	//
	//	//init PERCENT
	//	percentLabel = TEXT_CreateEx(POUP_LOADING_TEXT_X, POUP_LOADING_TEXT_Y, POUP_LOADING_TEXT_LENGTH, POUP_LOADING_TEXT_HEIGHT, popUp, WM_CF_HIDE, TEXT_CF_HCENTER/*WM_CF_MEMDEV*/, ePopupPercentLabelId, "0%");
	//	//	TEXT_SetTextAlign(percentLabel, GUI_TA_CENTER);
	//	TEXT_SetTextColor(percentLabel, POPUP_PERCENT_COLOR);
	//	TEXT_SetFont(percentLabel, &GUI_FontJPAPJPFont18B);
	//
	//	//init ok BUTTON
	//	okButton = BUTTON_CreateEx(POPUP_OK_BUTTON_X, POPUP_OK_BUTTON_Y, POPUP_OK_BUTTON_LENGTH, POPUP_OK_BUTTON_HEIGHT, popUp, WM_CF_HIDE, WM_CF_MEMDEV, ePopupOkButtonId);
	//	BUTTON_SetText(okButton, "OK");
	//	BUTTON_SetTextColor(okButton, BUTTON_CI_UNPRESSED, POPUP_OK_COLOR);
	//	BUTTON_SetFont(okButton, &GUI_FontJPAPJPFont16B);
	//
	//	//init loading text
	//	loadingLabel = TEXT_CreateEx(POUP_LOADING_TEXT_X, POUP_LOADING_TEXT_Y, POUP_LOADING_TEXT_LENGTH, POUP_LOADING_TEXT_HEIGHT, popUp, WM_CF_HIDE, TEXT_CF_HCENTER/*WM_CF_MEMDEV*/, ePopupLoadingLabelId, "Please wait...");
	//	//	TEXT_SetTextAlign(loadingLabel, GUI_TA_CENTER);
	//	TEXT_SetTextColor(loadingLabel, POPUP_LOADING_COLOR);
	//	TEXT_SetFont(loadingLabel, guiFont14[language]);
	//	TEXT_SetText(loadingLabel, strPleaseWait[language]);

	testPopupInit = 2000;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupButtonSetStatus(BUTTON_Handle hObj, int status)
//
//    Processing:
//		The operation sets status for YES/NO button
//
//    Input Parameters:
//		BUTTON_Handle hObj, int status
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupButtonSetStatus(void* hObj, E_ButtonStatus status)//void PopupButtonSetStatus(BUTTON_Handle hObj, E_ButtonStatus status)
{
	yesNoButton[WM_GetId(hObj) - ePopupYesButtonId].status = status;
	//	WM_Paint(hObj);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PuCalibrationCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		The callback function of pop up
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupButtonCallback(WM_MESSAGE * pMsg) {
	//	GUI_RECT Rect;
	const char* nameStr;
	int buttonStatus;

	switch (pMsg->MsgId) {
	case WM_PAINT:
		//		WM_GetClientRect(&Rect);	//get position: x0, x1, y0, y1
		nameStr = yesNoButton[WM_GetId(nullptr)/*(pMsg->hWin)*/ - ePopupYesButtonId].nameStr[eEnglish];//[language];	//get name
		testnameStrPopupButtonCallback = nameStr;
		//		GUI_SetFont(guiFont16[language]);	//set font
		buttonStatus = yesNoButton[WM_GetId(nullptr)/*(pMsg->hWin)*/ - ePopupYesButtonId].status;	//get status
		testbuttonStatusPopupButtonCallback = buttonStatus;
		//set color for label
		if(buttonStatus == eRelease)
		{
			//			GUI_SetColor(POPUP_YES_NO_UNSELECTED_COLOR);
		}
		else
		{
			//			GUI_SetColor(POPUP_YES_NO_SELECTED_COLOR);
		}

		//		GUI_SetBkColor(POPUP_BK_COLOR);	//set background color for label
		//		GUI_DispStringInRect(nameStr, &Rect, GUI_TA_HCENTER | GUI_TA_VCENTER);
		break;
	default:
		//		BUTTON_Callback(pMsg); 					// The original callback
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		This operation handles all events of pop up
//
//    Input Parameters:
//		WM_MESSAGE * pMsg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupCallback(WM_MESSAGE * pMsg) {
	//	GUI_RECT Rect;
	switch (pMsg->MsgId) {
	case WM_PAINT:
		//		WM_GetClientRect(&Rect);
		//		GUI_SetPenShape(GUI_PS_ROUND);
		//		GUI_SetTextMode(GUI_TM_TRANS);
		//draw background
		//		GUI_SetColor(POPUP_BK_COLOR);
		//		GUI_AA_FillRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1, 10);

		//draw title bacKground
		//		GUI_SetColor(POPUP_TITLE_BK_COLOR);
		//		GUI_AA_FillRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y0+32, 10);
		//		GUI_FillRect(Rect.x0, Rect.y0+15, Rect.x1, Rect.y0+32);

		//draw border
		//		GUI_SetColor(POPUP_BORDER_COLOR);
		//		GUI_SetPenSize(2);
		//		GUI_AA_DrawRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1, 10);

		testPopupCallback = WM_PAINT;
		break;
	case WM_KEY:
	{
		if(isReceiveKey == false)
			return;
		switch (((WM_KEY_INFO*)(pMsg->Data.p))->Key) {
		case GUI_KEY_RIGHT:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
			{
				testPopupCallback = GUI_KEY_RIGHT;
				PopupRightLeftKeyHandle();
			}
			break;
		case GUI_KEY_LEFT:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
			{
				testPopupCallback = GUI_KEY_LEFT;
				PopupRightLeftKeyHandle();
			}
			break;
		case GUI_KEY_HOME:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
			{
				testPopupCallback = GUI_KEY_HOME;
				PopupEnterKeyHandle();
			}
			break;
		}
	}
	break;
	//	case WM_TIMER:
	//		if(WM_GetTimerId(pMsg->Data.v) == 0)
	//		{
	//			DigitalOutputSetState(OUTPUT_PORT, RESET_PIN, 0);		//pull the reset pin to zero
	//			WM_DeleteTimer(pMsg->Data.v);				//delete timer
	//		}
	//		break;
	default:
		//		WM_DefaultProc(pMsg);
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupBlowerUpdatePercent(int percent)
//
//    Processing:
//		The function updates the percent
//
//    Input Parameters:
//		E_PopUpItem id
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupBlowerUpdatePercent(int percent)
{
	//set pop up ID
	popupId = ePopupBlowerUpgradeId;
	char temp[5] = {'\0'};		//maximum 5 characters
	int index = 0;
	int numOfDigit = 0;
	//set num of digit
	if(percent < 10)
	{
		numOfDigit = 1;
	}
	else if(percent < 100)
	{
		numOfDigit = 2;
	}
	else if(percent == 100)
	{
		numOfDigit = 3;
	}
	testPopupBlowerUpdatePercent = numOfDigit;
	//convert int to char
	StrToolItoA(percent, &temp[index], numOfDigit);
	index += numOfDigit;
	//insert '%'
	temp[index++] = '%';
	temp[index++] = '\0';

	//End test
	//set text for loading label
	//	TEXT_SetText(percentLabel, (const char*)&temp[0]);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupBLEUpdatePercent(int percent)
//
//    Processing:
//		The function updates the percent
//
//    Input Parameters:
//		E_PopUpItem id
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupBLEUpdatePercent(int percent)
{
	//set pop up ID
	popupId = ePopupBLEUpgradeId;
	char temp[5] = {'\0'};		//maximum 5 characters
	int index = 0;
	int numOfDigit = 0;
	//set num of digit
	if(percent < 10)
		numOfDigit = 1;
	else if(percent < 100)
		numOfDigit = 2;
	else if(percent == 100)
		numOfDigit = 3;
	testPopupBLEUpdatePercent = numOfDigit;
	//convert int to char
	StrToolItoA(percent, &temp[index], numOfDigit);
	index += numOfDigit;
	//insert '%'
	temp[index++] = '%';
	temp[index++] = '\0';
	//set text for loading label
	//	TEXT_SetText(percentLabel, (const char*)&temp[0]);
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupSetFocus()
//
//    Processing:
//		The operation sets focus for pop up
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupReload()
{
	isReceiveKey = true;
	//get current screen
	//	currentScreen = WM_GetFocussedWindow();
	//set current state
	currentStatePopUp = eNoState;
	//hide percent label
	//	WM_HideWindow(percentLabel);
	//hide loading label
	//	WM_HideWindow(loadingLabel);
	//hide button OK
	//	WM_HideWindow(okButton);
	//show button YES
	//	WM_ShowWindow(yesButton);
	//show button NO
	//	WM_ShowWindow(noButton);

	//set status for button YES NO
	PopupButtonSetStatus(nullptr, eRelease);//(yesButton, eRelease);
	PopupButtonSetStatus(nullptr, ePoint);//(noButton, ePoint);

	//set font and text for loading label
	//	TEXT_SetFont(loadingLabel, guiFont14[language]);
	//	TEXT_SetText(loadingLabel, strPleaseWait[language]);
	//set font for title label
	//	TEXT_SetFont(titleLabel, guiFont16[language]);
	//	WM_SetSize(loadingLabel, POUP_LOADING_TEXT_LENGTH, POUP_LOADING_TEXT_HEIGHT);

	//	WM_SetSize(popUp, POPUP_SCREEN_LENGTH, POPUP_SCREEN_HEIGHT);
	//	WM_MoveChildTo(okButton, POPUP_OK_BUTTON_X, POPUP_OK_BUTTON_Y);
	//	WM_MoveChildTo(popUp, POPUP_SCREEN_X, POPUP_SCREEN_Y);
	//	WM_SetSize(titleLabel, POPUP_TITLE_LABEL_LENGTH, POPUP_TITLE_LABEL_HEIGHT);
	//	WM_MoveChildTo(loadingLabel, POUP_LOADING_TEXT_X, POUP_LOADING_TEXT_Y);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupKeyEventHandle()
//
//    Processing:
//		The operation handles all key events
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupApplyTimeChange()
{
	//hide pop up
	//	WM_HideWindow(popUp);
	//focus user setting dialog
	//	WM_SetFocus(maintenanceScreen);
	//send event to release time setting dialog
	GuiTaskSendEvent(eGuiFactoryReleaseTimeSettingId, 0);
	//send event to apply time
	//	WM_SendMessageNoPara(timeSettingDialog, WM_APPLY_TIME);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupKeyEventHandle()
//
//    Processing:
//		The operation handles all key events
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupStartCalibrate()
{
	isReceiveKey = false;
	//set text for pop up
	//	TEXT_SetText(titleLabel, strDoingCalibration[language]);
	//hide button YES and NO
	//	WM_HideWindow(yesButton);
	//	WM_HideWindow(noButton);
	//set text for loading label
	//	TEXT_SetText(loadingLabel, strPleaseWait[language]);
	//display loading label
	//	WM_ShowWindow(loadingLabel);
	//send event to system task to start circuit calibration
	SystemEventStruct event;
	event.Id = eSystemDoCalibrationId;
	event.Data.type1 = 0;
	//send event to queue
	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
	{

	}
	//	SystemTaskSendEvent(eSystemDoCalibrationId, 0);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupStartMaskCalibrate()
//
//    Processing:
//		The operation handles all key events
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupStartMaskCalibrate()
{
	isReceiveKey = false;
	//set text for pop up
	//	TEXT_SetText(titleLabel, strDoingCalibration[language]);
	//hide button YES
	//	WM_HideWindow(yesButton);
	//hide button NO
	//	WM_HideWindow(noButton);
	//set text for loding label
	//	TEXT_SetText(loadingLabel, strPleaseWait[language]);
	//display loading label
	//	WM_ShowWindow(loadingLabel);
	//send event to system task to start circuit calibration
	SystemEventStruct event;
	event.Id = eSystemCalibrateWithMask;
	event.Data.type1 = 0;
	//send event to queue
	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
	{

	}
	//	SystemTaskSendEvent(eSystemCalibrateWithMask, 0);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupKeyEventHandle()
//
//    Processing:
//		The operation handles all key events
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupStartRestoreDefaults()
{
	//hide button YES
	//	WM_HideWindow(yesButton);
	//hide button NO
	//	WM_HideWindow(noButton);
	//show button OK
	//	WM_ShowWindow(okButton);

	//set default for all settings
	SettingSetDefaultMocks();//SettingSetDefault();
	SettingSaveMocks();//SettingSave();

	//get current language
	language = SettingGetMocks(eLanguageSettingId);//SettingGet(eLanguageSettingId);
	if(language > 1)
		language = 1;

	//set font and text for title label
	//	TEXT_SetFont(titleLabel, guiFont16[language]);
	//	TEXT_SetText(titleLabel, resetDoneStr[language]);

	//change current state
	currentStatePopUp = eDoneState;
	//send event to restore default
	GuiTaskSendEvent(eGuiFactoryRestoreDefaultsId, 0);
	//	WM_Paint(popUp);
	//log event restore defaults
	SystemEventStruct event;
	event.Id = eSettingResetLogId;
	event.Data.type1 = 0;
	//send event to queue
	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
	{

	}
	//	SystemTaskSendEvent(eSettingResetLogId, 0);
	//check Bluetooth setting and display
	if(SettingGetMocks(eBluetoothSettingId) == eOn)//if(SettingGet(eBluetoothSettingId) == eOn)
	{
		//set event to wake up Bluetooth module
		DeviceEventStruct event;
		event.id = eDeviceBleStatusChangeId;
		event.data = eDeviceBleEnableId;
		//send event to queue
		if(xQueueSendToBack(deviceQueue, &event, 2) != pdPASS)
		{
			//reset device queue
			xQueueReset(deviceQueue);
		}
		//		DeviceTaskSendEvent(eDeviceBleStatusChangeId, eDeviceBleEnableId);
		//show BLE icon
		GuiTaskSendEvent(eGuiShowBleIconId, 0);
	}
	else
	{
		//set event to wake up Bluetooth module
		DeviceEventStruct event;
		event.id = eDeviceBleStatusChangeId;
		event.data = eDeviceBleDisableId;
		//send event to queue
		if(xQueueSendToBack(deviceQueue, &event, 2) != pdPASS)
		{
			//reset device queue
			xQueueReset(deviceQueue);
		}
		//		DeviceTaskSendEvent(eDeviceBleStatusChangeId, eDeviceBleDisableId);
		//hide BLE icon
		GuiTaskSendEvent(eGuiHideBleIconId, 0);
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupKeyEventHandle()
//
//    Processing:
//		The operation handles all key events
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupStartClearUsedHours()
{
	//	WM_HideWindow(popUp);	//hide pop up
	//	WM_SetFocus(currentScreen);		//focus maintenance screen
	//send event to reset time usage
	SystemEventStruct event;
	event.Id = eSystemResetOperationTimeId;
	event.Data.type1 = 0;
	//send event to queue
	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
	{

	}
	//	SystemTaskSendEvent(eSystemResetOperationTimeId, 0);
	//log event restore defaults
	event.Id = eClearUsedHoursLogId;
	//send event to queue
	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
	{

	}

	//	SystemTaskSendEvent(eClearUsedHoursLogId, 0);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupKeyEventHandle()
//
//    Processing:
//		The operation handles all key events
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupStartUpgradeControlUnit()
{
	if(MainUpgradeCheckMocks() == true)//(MainUpgradeCheck(/*&errorId*/) == true)
	{
		isReceiveKey = false;
		//		TEXT_SetText(titleLabel, strSavingData[language]);					//set text for pop up
		SettingSaveMocks();	//SettingSave();			//save all settings to EEPROM
		//		WM_HideWindow(yesButton);
		//		WM_HideWindow(noButton);
		//		WM_Paint(popUp);				//repaint pop up
		//upgrade boot loader
#if UPGRADE_BOOTLOADER
		BootLoaderUpgrade();
#endif
		//set flag to update main unit software

		char data[EEPROM_SW_UPGRADE_SIZE] = {0};
		data[0] = 0xFF;
		//add crc code
		unsigned short temp = CrcCheckNoInit(1, &data[0]);
		data[1] = (char)(temp&0xFF);
		data[2] = (char)((temp>>8)&0xFF);
		EEPROMWriteMocks(EEPROM_SW_UPGRADE_PAGE_ADDR, EEPROM_SW_UPGRADE_BYTE_ADDR, &data[0], EEPROM_SW_UPGRADE_SIZE);//EEPROMWrite(EEPROM_SW_UPGRADE_PAGE_ADDR, EEPROM_SW_UPGRADE_BYTE_ADDR, &data[0], EEPROM_SW_UPGRADE_SIZE);
		//start timer 1 to wait and reset system
		SoftTimerStartMocks(eSoftTimer0Id);//SoftTimerStart(eSoftTimer0Id);
		//		WM_CreateTimer(maintenanceScreen, 0, 1000, 0);
	}
	else
	{
		//		TEXT_SetText(titleLabel, strUpgradeError[language]);//set text for title
		//		WM_HideWindow(yesButton);							//hide YES
		//		WM_HideWindow(noButton);							//hide NO
		//		WM_ShowWindow(okButton);							//show OK
		currentStatePopUp = eDoneState;							//change state
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupKeyEventHandle()
//
//    Processing:
//		The operation starts upgrading blower unit
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupStartUpgradeBlowerUnit()
{
	//	if(MotorUpgradeCheck(/*&errorId*/) == false)
	//	{
	//		//annouce error
	//		GuiTaskSendEvent(eGuiPopupMotorUpgradeErrorId, 0);
	//	}
	//	else
	//	{
	//send message to run motor upgrade software
	SystemEventStruct event;
	event.Id = eSystemDoMotorUpgradeId;
	event.Data.type1 = 0;
	//send event to queue
	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
	{

	}
	//SystemTaskSendEvent(eSystemDoMotorUpgradeId, 0);
	//set text for title label
	//	TEXT_SetText(titleLabel, strUpgradeBlowerUnit[language]);
	//hide button YES
	//	WM_HideWindow(yesButton);
	//hide button NO
	//	WM_HideWindow(noButton);
	//	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupStartUpgradeBLEUnit()
//
//    Processing:
//		The operation starts upgrading BLE unit
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupStartUpgradeBLEUnit()
{
	//send event to start BLE upgrade
	SystemEventStruct event;
	event.Id = eSystemDoBleUpgradeId;
	event.Data.type1 = 0;
	//send event to queue
	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
	{

	}
	//SystemTaskSendEvent(eSystemDoBleUpgradeId, 0);

	//	WM_MoveChildTo(popUp, POPUP_SCREEN_X, POPUP_SCREEN_Y);
	//	WM_SetSize(popUp, POPUP_SCREEN_LENGTH, POPUP_SCREEN_HEIGHT);
	//	WM_SetSize(titleLabel, POPUP_SCREEN_LENGTH, POPUP_TITLE_LABEL_HEIGHT);

	//set text for title label
	//	TEXT_SetText(titleLabel, strUpgradebleUnit[language]);
	//hide button YES
	//	WM_HideWindow(yesButton);
	//hide button NO
	//	WM_HideWindow(noButton);
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupStartExportLog()
//
//    Processing:
//		The operation starts exporting log data to SD card
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupStartExportLog()
{
	SystemEventStruct event;
	event.Id = eSystemLogExportLogDataEventId;
	event.Data.type1 = 0;
	//send event to queue
	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
	{

	}
	//SystemTaskSendEvent(eSystemLogExportLogDataEventId, 0);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupStartConnectBLEDevice()
//
//    Processing:
//		The operation starts connecting BLE device
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
//void PopupStartConnectBLEDevice()
//{
//	//hide popup
//	WM_HideWindow(popUp);
//	//focus current screen
//	WM_SetFocus(currentScreen);
//	//start connecting to current BLE device
//	BleDialogConnecting();
//}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupStartDisconnectBLE()
//
//    Processing:
//		The operation starts disconnecting BLE device
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
//void PopupStartDisconnectBLE()
//{
//	//hide popup
//	WM_HideWindow(popUp);
//	//focus current screen
//	WM_SetFocus(currentScreen);
//	//disconnecting to current BLE device
//	BleDialogDisconnect();
//}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupPreparationDrying()
//
//    Processing:
//		The operation preparations drying mode
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupPreparationDrying()
{
	//	DebugStr("PopupPreparationDrying");
	//	WM_SetSize(titleLabel, POPUP_TITLE_LABEL_LENGTH+60, POPUP_TITLE_LABEL_HEIGHT);
	//	TEXT_SetText(titleLabel, strPreparation[language]);	//set text for pop up
	//	WM_ShowWindow(loadingLabel);							//hide Loading
	if(language == eJapanese)
	{
		//		TEXT_SetFont(loadingLabel, &GUI_FontJapanes14Add2);
	}
	//	TEXT_SetText(loadingLabel, strPreparationContent[language]);	//set text for pop up
	//	WM_MoveChildTo(loadingLabel, POUP_LOADING_TEXT_X, POUP_LOADING_TEXT_Y-15);
	//	WM_SetSize(loadingLabel, POUP_LOADING_TEXT_LENGTH, POUP_LOADING_TEXT_HEIGHT + 30);
	//	WM_SetSize(popUp, POPUP_SCREEN_LENGTH, POPUP_SCREEN_HEIGHT + 30);
	//	WM_MoveChildTo(popUp, POPUP_SCREEN_X-30, POPUP_SCREEN_Y -30);
	//	WM_HideWindow(yesButton);
	//	WM_HideWindow(noButton);
	//	WM_ShowWindow(okButton);								//show DONE
	//	WM_MoveChildTo(okButton, POPUP_OK_BUTTON_X, POPUP_OK_BUTTON_Y + 40);
	currentStatePopUp = eDoneState;
	isReceiveKey = true;
	isDryingMode = true;
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupEnterKeyHandle()
//
//    Processing:
//		The operation handles enter key event
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupEnterKeyHandle()
{
	if((currentStatePopUp == eDoneState)&&(isDryingMode == true))
	{
		//		WM_HideWindow(popUp);
		//		WM_HideWindow(userOptionScreen);
		isDryingMode = false;
		//check setting to do corresponding drying mode
		if(SettingGetMocks(eCircuitTypeSettingId) == eQE)//if(SettingGet(eCircuitTypeSettingId) == eQE)
		{
			//send event to motor task to start drying
			unsigned char sendEvent = eMotorEnterStrongDryEventId;
			if(xQueueSendToBack(motorQueue, &sendEvent, 2) != pdPASS)
			{
			}
			//MotorTaskSendEvent(eMotorEnterStrongDryEventId);
			//log go to drying by user push ON/OFF button while operation
			SystemEventStruct event;
			event.Id = eSystemStateLogId;
			event.Data.type1 = eSystemStrongDrying;
			//send event to queue
			if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
			{

			}
			//SystemTaskSendEvent(eSystemStateLogId, eSystemStrongDrying);
		}
		else		//other circuit not QE
		{
			//send event to motor task to start drying
			unsigned char sendEvent = eMotorEnterWeakDryEventId;
			if(xQueueSendToBack(motorQueue, &sendEvent, 2) != pdPASS)
			{
			}
			//MotorTaskSendEvent(eMotorEnterWeakDryEventId);
			//log go to drying by user push ON/OFF button while operation
			SystemEventStruct event;
			event.Id = eSystemStateLogId;
			event.Data.type1 = eSystemWeakDrying;
			//send event to queue
			if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
			{

			}
			//SystemTaskSendEvent(eSystemStateLogId, );
		}

		return;
	}

	if(currentStatePopUp != eYesState)
	{
		//		WM_HideWindow(popUp);
		//		WM_SetFocus(currentScreen);
		if(popupId == ePopupTimeChangeId)
		{
			GuiTaskSendEvent(eGuiFactoryReleaseTimeSettingId, 0);
		}
		return;
	}
	//if current state = YES
	switch (popupId) {
	case ePopupTimeChangeId:		PopupApplyTimeChange();			break;
	case ePopupCircuitCalibrateId:	PopupStartCalibrate();			break;
	case ePopupMaskCalibrateId:		PopupStartMaskCalibrate();		break;
	case ePopupRestoreDefaultsId:	PopupStartRestoreDefaults();	break;
	case ePopupClearUsedHoursId:	PopupStartClearUsedHours();		break;
	case ePopupControlUpgradeId:	PopupStartUpgradeControlUnit();	break;
	case ePopupBlowerUpgradeId:		PopupStartUpgradeBlowerUnit();	break;
	case ePopupBLEUpgradeId:		PopupStartUpgradeBLEUnit();		break;
	case ePopupExportLogId:			PopupStartExportLog();			break;
	//	case ePopupBLEConnectId: 		PopupStartConnectBLEDevice();	break;
	//	case ePopupBLEDisconnectId:		PopupStartDisconnectBLE();		break;
	case ePopupConfirmDryingModeId: PopupPreparationDrying();		break;
	default:	break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupRightLeftKeyHandle()
//
//    Processing:
//		The operation handles right/left key event
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupRightLeftKeyHandle()
{
	switch(currentStatePopUp) {
	case eNoState:
		PopupButtonSetStatus(nullptr, ePoint);//(yesButton, ePoint);		//focus YES
		PopupButtonSetStatus(nullptr, eRelease);//(noButton, eRelease);	//release NO
		currentStatePopUp = eYesState;				//change state
		break;
	case eYesState:
		PopupButtonSetStatus(nullptr, eRelease);//(yesButton, eRelease);	//release YES
		PopupButtonSetStatus(nullptr, ePoint);	//(noButton, ePoint);		//focus NO
		currentStatePopUp = eNoState;				//change state
		break;
	default:
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupUpgradeError()
//
//    Processing:
//		The function reports blower upgrade error
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupUpgradeError()
{
	//	TEXT_SetText(titleLabel, strUpgradeError[language]);//set text for pop up
	currentStatePopUp = eDoneState;							//change state
	//	WM_HideWindow(yesButton);							//hide YES
	//	WM_HideWindow(noButton);							//hide NO
	//	WM_ShowWindow(okButton);							//show OK
	//	WM_HideWindow(percentLabel);							//hide percent
	//	WM_HideWindow(loadingLabel);
	isReceiveKey = true;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupBlowerUpgradeSuccess()
//
//    Processing:
//		The function performs action when blower upgrade software is success
//			and hides progress bar on blower software upgrade
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupBlowerUpgradeSuccess()
{
	//	TEXT_SetText(titleLabel, strUpgradeSuccess[language]);	//set text for pop up
	currentStatePopUp = eDoneState;								//change state
	//	WM_HideWindow(yesButton);								//hide YES
	//	WM_HideWindow(noButton);								//hide NO
	//	WM_HideWindow(loadingLabel);							//hide percent
	//	WM_ShowWindow(okButton);								//show OK
	//send event to log
	SystemEventStruct event;
	event.Id = eBlowerUnitUpgradeLogId;
	event.Data.type1 = 0;
	//send event to queue
	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
	{

	}
	//SystemTaskSendEvent(eBlowerUnitUpgradeLogId, 0);
	isReceiveKey = true;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupBLEUpgradeSuccess()
//
//    Processing:
//		The function performs action when BLE upgrade software is success
//			and hides progress bar on BLE software upgrade
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupBLEUpgradeSuccess()
{
	//	TEXT_SetText(titleLabel, strUpgradeSuccess[language]);	//set text for pop up
	currentStatePopUp = eDoneState;								//change state
	//	WM_HideWindow(yesButton);								//hide YES
	//	WM_HideWindow(noButton);								//hide NO
	//	WM_HideWindow(loadingLabel);							//hide percent
	//	WM_ShowWindow(okButton);								//show OK
	//send event to log
	SystemEventStruct event;
	event.Id = eBLEUnitUpgradeLogId;
	event.Data.type1 = 0;
	//send event to queue
	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
	{

	}

	//	SystemTaskSendEvent(eBLEUnitUpgradeLogId, 0);
	isReceiveKey = true;
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupKeyEventHandle()
//
//    Processing:
//		The operation handles all key events
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupExportLogSuccess()
{
	//	TEXT_SetText(titleLabel, strExportSuccess[language]);	//set text for pop up
	currentStatePopUp = eDoneState;								//change state
	//	WM_HideWindow(yesButton);								//hide YES
	//	WM_HideWindow(noButton);								//hide NO
	//	WM_ShowWindow(okButton);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupKeyEventHandle()
//
//    Processing:
//		The operation handles all key events
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupExportLogFail()
{
	//	TEXT_SetText(titleLabel, strExportFail[language]);	//set text for pop up
	currentStatePopUp = eDoneState;								//change state
	//	WM_HideWindow(yesButton);								//hide YES
	//	WM_HideWindow(noButton);								//hide NO
	//	WM_ShowWindow(okButton);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupBlowerUpgradeStart()
//
//    Processing:
//		The function starts upgrading blower
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupBlowerUpgradeStart()
{
	//	WM_HideWindow(loadingLabel);
	//show percent
	//	WM_ShowWindow(percentLabel);
	PopupBlowerUpdatePercent(0);
	isReceiveKey = false;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupBLEUpgradeStart()
//
//    Processing:
//		The function starts upgrading BLE
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupBLEUpgradeStart()
{
	//	WM_HideWindow(loadingLabel);
	//show percent
	//	WM_ShowWindow(percentLabel);
	PopupBLEUpdatePercent(0);
	isReceiveKey = false;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupBlowerUpgradeStart()
//
//    Processing:
//		The operation resets blower unit
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupBlowerUpgradeReset()
{
	//	TEXT_SetText(loadingLabel, strResettingBlowerUnit[language]);
	//	WM_ShowWindow(loadingLabel);
	//	WM_HideWindow(percentLabel);

	testPopupBlowerUpdatePercent = 0;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupBLEUpgradeReset()
//
//    Processing:
//		The operation resets BLE unit
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupBLEUpgradeReset()
{
	//	TEXT_SetText(loadingLabel, strResettingBLEUnit[language]);
	//	WM_ShowWindow(loadingLabel);
	//	WM_HideWindow(percentLabel);

	testPopupBLEUpdatePercent = 0;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupCircuitCalibrateShow()
//
//    Processing:
//		The operation shows pop up calibration
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupCircuitCalibrateShow()
{
	popupId = ePopupCircuitCalibrateId;
	PopupReload();
	//	TEXT_SetText(titleLabel, strDoCircuitCalibration[language]);
	//	WM_SetFocus(popUp);		//focus pop up
	//	WM_ShowWindow(popUp);	//show pop up
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupConnectTheMaskShow()
//
//    Processing:
//		The operation shows pop up to request connecting the mask
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupConnectTheMaskShow()
{
	popupId = ePopupMaskCalibrateId;	//set pop up ID
	PopupReload();	//reload pop up
	//	currentScreen = clinicScreen;	//set current screen
	//	TEXT_SetText(titleLabel, strConnectTheMask[language]);
	//	WM_SetFocus(popUp);		//focus pop up
	//	WM_ShowWindow(popUp);	//show pop up
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupCalibrateDone()
//
//    Processing:
//		The operation shows pop up calibrating done
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupCalibrateDone()
{
	//	TEXT_SetText(titleLabel, strCalibrationDone[language]);	//set text for pop up
	//	WM_HideWindow(loadingLabel);							//hide Loading
	//	WM_ShowWindow(okButton);								//show DONE
	currentStatePopUp = eDoneState;								//change state
	isReceiveKey = true;
	//log event restore defaults
	SystemEventStruct event;
	event.Id = eCalibrateSuccessLogId;
	event.Data.type1 = 0;
	//send event to queue
	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
	{

	}
	//SystemTaskSendEvent(eCalibrateSuccessLogId, 0);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupCalibrateError()
//
//    Processing:
//		The operation shows pop up calibration failed
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupCalibrateError()
{
//	TEXT_SetText(titleLabel, strCalibrationError[language]);	//set text for pop up
//	WM_HideWindow(loadingLabel);							//hide Loading
//	WM_ShowWindow(okButton);								//show DONE
	currentStatePopUp = eDoneState;
	isReceiveKey = true;
	//log event restore defaults
	SystemEventStruct event;
	event.Id = eCalibrateFailLogId;
	event.Data.type1 = 0;
	//send event to queue
	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
	{

	}
	//SystemTaskSendEvent(eCalibrateFailLogId, 0);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupTimeChangeShow()
//
//    Processing:
//		The operation shows pop up to change date time
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupTimeChangeShow()
{
	popupId = ePopupTimeChangeId;		//set popup ID
	PopupReload();						//reload pop up
//	currentScreen = maintenanceScreen;	//set current screen
//	WM_SetFocus(popUp);					//focus pop up
//	WM_ShowWindow(popUp);				//show pop up
//	TEXT_SetText(titleLabel, strSaveTime[language]);	//set text for pop up
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupRestoreDefaultsShow()
//
//    Processing:
//		The operation shows pop up to restore defaults
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupRestoreDefaultsShow()
{
	popupId = ePopupRestoreDefaultsId;
	PopupReload();
//	WM_SetFocus(popUp);		//focus pop up
//	WM_ShowWindow(popUp);	//show pop up
//	TEXT_SetText(titleLabel, strResetSetting[language]);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupClearUsedHoursShow()
//
//    Processing:
//		The operation shows pop up to clear used hours
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupClearUsedHoursShow()
{
	popupId = ePopupClearUsedHoursId;
	PopupReload();
//	WM_SetFocus(popUp);
//	WM_ShowWindow(popUp);
//	TEXT_SetText(titleLabel, strDoResetTimeUsing[language]);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupControlUpgradeShow()
//
//    Processing:
//		The operation shows pop up to upgrade control unit
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupControlUpgradeShow()
{
	popupId = ePopupControlUpgradeId;
	PopupReload();
//	WM_SetFocus(popUp);
//	WM_ShowWindow(popUp);
//	TEXT_SetText(titleLabel, upgradeMainUnitStr[language]);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupBlowerUpgradeShow()
//
//    Processing:
//		The operation shows pop up to upgrade blower unit
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupBlowerUpgradeShow()
{
	popupId = ePopupBlowerUpgradeId;
	PopupReload();
//	WM_SetFocus(popUp);
//	WM_ShowWindow(popUp);
//	TEXT_SetText(titleLabel, upgradeBlowerUnitStr[language]);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupBLEUpgradeShow()
//
//    Processing:
//		The operation shows pop up to upgrade BLE unit
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupBLEUpgradeShow()
{
	popupId = ePopupBLEUpgradeId;
	PopupReload();
//	WM_MoveChildTo(popUp, POPUP_SCREEN_X -10, POPUP_SCREEN_Y);
//	WM_SetSize(popUp, POPUP_SCREEN_LENGTH + 20, POPUP_SCREEN_HEIGHT);
//	WM_SetSize(titleLabel, POPUP_SCREEN_LENGTH + 20, POPUP_TITLE_LABEL_HEIGHT);
//	WM_SetFocus(popUp);
//	WM_ShowWindow(popUp);
//	TEXT_SetText(titleLabel, upgradeBLEUnitStr[language]);
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupExportLogShow()
//
//    Processing:
//		The operation shows pop up to export log data
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupExportLogShow()
{
	popupId = ePopupExportLogId;
	PopupReload();
//	WM_SetFocus(popUp);
//	WM_ShowWindow(popUp);
//	TEXT_SetText(titleLabel, exportLogStr[language]);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupConnectBLEDevice()
//
//    Processing:
//		The operation shows pop up to connect a BLE device
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
//void PopupConnectBLEDevice(/*int BLEDevice*/)
//{
//	popupId = ePopupBLEConnectId;
//	//	popupData = BLEDevice;
//	PopupReload();
//	WM_SetFocus(popUp);
//	WM_ShowWindow(popUp);
//	WM_BringToTop(popUp);
//	TEXT_SetText(titleLabel, strConnect[language]);
//}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupDisconnectBLE()
//
//    Processing:
//		The operation shows pop up to disconnect a BLE device
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
//void PopupDisconnectBLE(/*int BLEDevice*/)
//{
//	popupId = ePopupBLEDisconnectId;
//	//	popupData = BLEDevice;
//	PopupReload();
//	WM_SetFocus(popUp);
//	WM_ShowWindow(popUp);
//	WM_BringToTop(popUp);
//	TEXT_SetText(titleLabel, strDisconnect[language]);
//}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupConnectBLEFailed()
//
//    Processing:
//		The operation shows pop up to
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
//void PopupConnectBLEFailed()
//{
//	popupId = ePopupBLEConnectFailedId;
//	PopupReload();
//	WM_SetFocus(popUp);
//	WM_HideWindow(yesButton);								//hide YES
//	WM_HideWindow(noButton);								//hide NO
//	WM_ShowWindow(okButton);
//	WM_ShowWindow(popUp);
//	WM_BringToTop(popUp);
//	TEXT_SetText(titleLabel, strBLEConnectFailed[language]);
//}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupConnectBLESuccess()
//
//    Processing:
//		The operation shows pop up to
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
//void PopupConnectBLESuccess()
//{
//	popupId = ePopupBLEConnectSuccessId;
//	PopupReload();
//	WM_SetFocus(popUp);
//	WM_HideWindow(yesButton);								//hide YES
//	WM_HideWindow(noButton);								//hide NO
//	WM_ShowWindow(okButton);
//	WM_ShowWindow(popUp);
//	WM_BringToTop(popUp);
//	TEXT_SetText(titleLabel, strBLEConnectSuccess[language]);
//}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupConfirmDryingMode()
//
//    Processing:
//		The operation shows pop up to
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupConfirmDryingMode()
{
	PopupReload();
//	WM_SetFocus(popUp);
//	WM_ShowWindow(popUp);
//	WM_BringToTop(popUp);
	if(language == eJapanese)
	{
//		TEXT_SetFont(titleLabel, &GUI_FontPreparationFont16);
	}
//	TEXT_SetText(titleLabel, strPreparation[language]);	//set text for pop up
//	WM_ShowWindow(loadingLabel);							//hide Loading
	if(language == eJapanese)
	{
//		TEXT_SetFont(loadingLabel, &GUI_FontJapanes14Add2);
	}
//	TEXT_SetText(loadingLabel, strPreparationContent[language]);	//set text for pop up
//	WM_SetSize(popUp, POPUP_SCREEN_LENGTH, POPUP_SCREEN_HEIGHT + 30);
//	WM_HideWindow(yesButton);
//	WM_HideWindow(noButton);
//	WM_ShowWindow(okButton);								//show DONE
//	WM_MoveChildTo(okButton, POPUP_OK_BUTTON_X, POPUP_OK_BUTTON_Y + 40);
	currentStatePopUp = eDoneState;
	isReceiveKey = true;
	isDryingMode = true;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: PopupHandleEvent(GuiEventStruct guiEvent)
//
//    Processing:
//		The operation handles event of pop up
//
//    Input Parameters:
//		GuiEventStruct guiEvent: event of GUI
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void PopupHandleEvent(GuiEventStruct guiEvent)
{
	switch(guiEvent.id)
	{
	case eGuiPopupMotorUpgradeErrorId:		PopupUpgradeError();			break;
	case eGuiPopupMotorUpgradeEndId:		PopupBlowerUpgradeSuccess();	break;
	case eGuiPopupMotorUpgradeRunId:		PopupBlowerUpdatePercent(guiEvent.data);	break;
	case eGuiPopupMotorUpgradeStartId:		PopupBlowerUpgradeStart();		break;
	case eGuiPopupMotorUpgradeResetId:		PopupBlowerUpgradeReset();		break;
	case eGuiPopupBLEUpgradeErrorId:		PopupUpgradeError();			break;
	case eGuiPopupBLEUpgradeEndId:			PopupBLEUpgradeSuccess();		break;
	case eGuiPopupBLEUpgradeRunId:			PopupBLEUpdatePercent(guiEvent.data); break;
	case eGuiPopupBLEUpgradeStartId:		PopupBLEUpgradeStart();			break;
	case eGuiPopupBLEUpgradeResetId:		PopupBLEUpgradeReset();			break;
	case eGuiPopupExportLogSuccessId:		PopupExportLogSuccess();		break;
	case eGuiPopupExportLogFailId:			PopupExportLogFail();			break;
	case eGuiPopupCircuitCalibrateShowId:	PopupCircuitCalibrateShow();	break;
	case eGuiPopupCircuitCalibrateDoneId:	PopupConnectTheMaskShow();		break;
	case eGuiPopupMaskCalibrateDoneId:		PopupCalibrateDone();			break;
	case eGuiPopupCircuitCalibrateErrorId:	PopupCalibrateError();			break;
	case eGuiPopupTimeSettingShowId:		PopupTimeChangeShow();			break;
	case eGuiPopupRestoreDefaultsShowId:	PopupRestoreDefaultsShow();		break;
	case eGuiPopupClearUsedHoursShowId:		PopupClearUsedHoursShow();		break;
	case eGuiPopupControlUpgradeShowId:		PopupControlUpgradeShow();		break;
	case eGuiPopupMotorUpgradeShowId:		PopupBlowerUpgradeShow();		break;
	case eGuiBLEUpgradeShowId:				PopupBLEUpgradeShow();			break;
	case eGuiPopupExportLogShowId:			PopupExportLogShow();			break;
	//	case eGuiPopupConnectBLEDeviceId:		PopupConnectBLEDevice();		break;
	//	case eGuiPopupDisconnectBLEId:			PopupDisconnectBLE();			break;
	//	case eGuiPopupFailedToConnectBLEId:		PopupConnectBLEFailed();		break;
	//	case eGuiPopupSuccessToConnectBLEId:  	PopupConnectBLESuccess();		break;
	case eGuiPopupConfirmDryingModeId:		PopupConfirmDryingMode();		break;
	default:	break;
	}
}

#if defined(__cplusplus)
}
#endif
