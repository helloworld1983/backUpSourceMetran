/*
 * popupdialog.h
 *
 *  Created on: Apr 20, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_GUI_POPUPDIALOG_H_
#define UNITTEST_GUI_POPUPDIALOG_H_

#include <guiinterface.h>

#include "WM.h"
#include "guidefine.h"

//extern WM_HWIN popUp;

typedef enum
{
	eFirstPopupId,
	ePopupCircuitCalibrateId = eFirstPopupId,
	ePopupMaskCalibrateId,
	ePopupWoMaskCalibrate,
	ePopupClearUsedHoursId,
	ePopupTimeChangeId,
	ePopupRestoreDefaultsId,
	ePopupControlUpgradeId,
	ePopupBlowerUpgradeId,
	ePopupBLEUpgradeId,
	ePopupExportLogId,
//	ePopupBLEConnectId,
//	ePopupBLEDisconnectId,
//	ePopupBLEConnectFailedId,
//	ePopupBLEConnectSuccessId,
	ePopupConfirmDryingModeId,
	eLastPopupId = ePopupConfirmDryingModeId
} E_PopupId;


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void PopupButtonSetStatus(void* hObj, E_ButtonStatus status);//void PopupButtonSetStatus(BUTTON_Handle hObj, E_ButtonStatus status);
void PopupButtonCallback(WM_MESSAGE * pMsg);
void PopupCallback(WM_MESSAGE * pMsg);
void PopupBlowerUpdatePercent(int percent);
void PopupBLEUpdatePercent(int percent);
void PopupInit(void);
void PopupHandleEvent(GuiEventStruct guiEvent);
void PopupReload();
void PopupApplyTimeChange();
void PopupStartCalibrate();
void PopupStartMaskCalibrate();
void PopupStartRestoreDefaults();
void PopupStartClearUsedHours();
void PopupStartUpgradeControlUnit();
void PopupStartUpgradeBlowerUnit();
void PopupStartUpgradeBLEUnit();
void PopupStartExportLog();
void PopupPreparationDrying();
void PopupEnterKeyHandle();
void PopupRightLeftKeyHandle();
void PopupUpgradeError();
void PopupBlowerUpgradeSuccess();
void PopupBLEUpgradeSuccess();
void PopupExportLogSuccess();
void PopupExportLogFail();
void PopupBlowerUpgradeStart();
void PopupBLEUpgradeStart();
void PopupBlowerUpgradeReset();
void PopupBLEUpgradeReset();
void PopupCircuitCalibrateShow();
void PopupConnectTheMaskShow();
void PopupCalibrateDone();
void PopupCalibrateError();
void PopupTimeChangeShow();
void PopupRestoreDefaultsShow();
void PopupClearUsedHoursShow();
void PopupControlUpgradeShow();
void PopupBlowerUpgradeShow();
void PopupBLEUpgradeShow();
void PopupExportLogShow();
void PopupConfirmDryingMode();

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_POPUPDIALOG_H_ */
