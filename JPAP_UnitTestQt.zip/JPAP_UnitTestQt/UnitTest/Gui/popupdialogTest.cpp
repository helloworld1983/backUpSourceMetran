/*
 * popupdialogTest.cpp
 *
 *  Created on: Apr 20, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "popupdialog.h"

#include <setting.h>

#include "guidefine.h"
#include "guiglobal.h"
#include "SoftTimerMocks.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern int testPopupInit;
extern PopUpButtonContent yesNoButton[];
extern int testbuttonStatusPopupButtonCallback;
extern const char* testnameStrPopupButtonCallback;
extern int testPopupCallback;
extern bool isReceiveKey;
extern E_PopupId popupId;
extern int testPopupBlowerUpdatePercent;
extern int testPopupBLEUpdatePercent;
extern E_PopUpState currentStatePopUp;
extern bool isDryingMode;

namespace EmbeddedCUnitTest {


class PopUpDialogTest : public TestFixture
{
public:
	PopUpDialogTest() : TestFixture(new ModuleMock) {}
};

TEST_F(PopUpDialogTest, PopupInit)
{
	PopupInit();
	EXPECT_EQ(2000,testPopupInit);
}

TEST_F(PopUpDialogTest, PopupButtonSetStatus)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(1));

	PopupButtonSetStatus(nullptr,eRelease);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
}

TEST_F(PopUpDialogTest, PopupButtonCallback)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(1));

	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	PopupButtonCallback(&pMsg);

	EXPECT_EQ("No",std::string(testnameStrPopupButtonCallback));
	EXPECT_EQ(eRelease,testbuttonStatusPopupButtonCallback);
}

TEST_F(PopUpDialogTest, PopupCallback1)
{
	isReceiveKey = true;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	PopupCallback(&pMsg);

	EXPECT_EQ(WM_PAINT,testPopupCallback);
}

TEST_F(PopUpDialogTest, PopupCallback2)
{
	isReceiveKey = true;
	WM_MESSAGE pMsg;
	WM_KEY_INFO* keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_RIGHT;
	keyData->PressedCnt = 1;
	pMsg.MsgId = WM_KEY;
	pMsg.Data.p = keyData;
	PopupCallback(&pMsg);

	EXPECT_EQ(GUI_KEY_RIGHT,testPopupCallback);
}

TEST_F(PopUpDialogTest, PopupCallback3)
{
	isReceiveKey = true;
	WM_MESSAGE pMsg;
	WM_KEY_INFO* keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_LEFT;
	keyData->PressedCnt = 1;
	pMsg.MsgId = WM_KEY;
	pMsg.Data.p = keyData;
	PopupCallback(&pMsg);

	EXPECT_EQ(GUI_KEY_LEFT,testPopupCallback);
}

TEST_F(PopUpDialogTest, PopupCallback4)
{
	isReceiveKey = true;
	WM_MESSAGE pMsg;
	WM_KEY_INFO* keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_HOME;
	keyData->PressedCnt = 1;
	pMsg.MsgId = WM_KEY;
	pMsg.Data.p = keyData;
	PopupCallback(&pMsg);

	EXPECT_EQ(GUI_KEY_HOME,testPopupCallback);
}

TEST_F(PopUpDialogTest, PopupBlowerUpdatePercent1)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);
	PopupBlowerUpdatePercent(5);

	EXPECT_EQ(ePopupBlowerUpgradeId,popupId);
	EXPECT_EQ(1,testPopupBlowerUpdatePercent);
}

TEST_F(PopUpDialogTest, PopupBlowerUpdatePercent2)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);
	PopupBlowerUpdatePercent(50);

	EXPECT_EQ(ePopupBlowerUpgradeId,popupId);
	EXPECT_EQ(2,testPopupBlowerUpdatePercent);
}

TEST_F(PopUpDialogTest, PopupBlowerUpdatePercent3)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);
	PopupBlowerUpdatePercent(100);

	EXPECT_EQ(ePopupBlowerUpgradeId,popupId);
	EXPECT_EQ(3,testPopupBlowerUpdatePercent);
}

TEST_F(PopUpDialogTest, PopupBLEUpdatePercent1)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);
	PopupBLEUpdatePercent(8);

	EXPECT_EQ(ePopupBLEUpgradeId,popupId);
	EXPECT_EQ(1,testPopupBLEUpdatePercent);
}

TEST_F(PopUpDialogTest, PopupBLEUpdatePercent2)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);
	PopupBLEUpdatePercent(68);

	EXPECT_EQ(ePopupBLEUpgradeId,popupId);
	EXPECT_EQ(2,testPopupBLEUpdatePercent);
}

TEST_F(PopUpDialogTest, PopupBLEUpdatePercent3)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);
	PopupBLEUpdatePercent(100);

	EXPECT_EQ(ePopupBLEUpgradeId,popupId);
	EXPECT_EQ(3,testPopupBLEUpdatePercent);
}

TEST_F(PopUpDialogTest, PopupReload)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));
	PopupReload();

	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupApplyTimeChange)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	PopupApplyTimeChange();
}

TEST_F(PopUpDialogTest, PopupStartCalibrate)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	PopupStartCalibrate();

	EXPECT_EQ(false,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupStartMaskCalibrate)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	PopupStartMaskCalibrate();

	EXPECT_EQ(false,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupStartRestoreDefaults1)
{
	EXPECT_CALL(*_settingLib,SettingSetDefaultMocks()).Times(1);
	EXPECT_CALL(*_settingLib,SettingSaveMocks()).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eLanguageSettingId)).Times(1).WillOnce(Return(2));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(4);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eBluetoothSettingId)).Times(1).WillOnce(Return(eOn));

	PopupStartRestoreDefaults();

	EXPECT_EQ(1,language);
	EXPECT_EQ(eDoneState,currentStatePopUp);
}

TEST_F(PopUpDialogTest, PopupStartRestoreDefaults2)
{
	EXPECT_CALL(*_settingLib,SettingSetDefaultMocks()).Times(1);
	EXPECT_CALL(*_settingLib,SettingSaveMocks()).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eLanguageSettingId)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(4);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eBluetoothSettingId)).Times(1).WillOnce(Return(eOn));

	PopupStartRestoreDefaults();

	EXPECT_EQ(0,language);
	EXPECT_EQ(eDoneState,currentStatePopUp);
}

TEST_F(PopUpDialogTest, PopupStartRestoreDefaults3)
{
	EXPECT_CALL(*_settingLib,SettingSetDefaultMocks()).Times(1);
	EXPECT_CALL(*_settingLib,SettingSaveMocks()).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eLanguageSettingId)).Times(1).WillOnce(Return(3));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(4);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eBluetoothSettingId)).Times(1).WillOnce(Return(eOff));

	PopupStartRestoreDefaults();

	EXPECT_EQ(1,language);
	EXPECT_EQ(eDoneState,currentStatePopUp);
}

TEST_F(PopUpDialogTest, PopupStartClearUsedHours)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(2);

	PopupStartClearUsedHours();
}

TEST_F(PopUpDialogTest, PopupStartUpgradeControlUnit1)
{
	EXPECT_CALL(*_MainScreenLib,MainUpgradeCheckMocks()).Times(1).WillOnce(Return(true));
	EXPECT_CALL(*_EEPROMLib,EEPROMWriteMocks(_,_,_,_)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStartMocks(eSoftTimer0Id)).Times(1);

	PopupStartUpgradeControlUnit();

	EXPECT_EQ(false,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupStartUpgradeControlUnit2)
{
	EXPECT_CALL(*_MainScreenLib,MainUpgradeCheckMocks()).Times(1).WillOnce(Return(false));

	PopupStartUpgradeControlUnit();

	EXPECT_EQ(eDoneState,currentStatePopUp);
}

TEST_F(PopUpDialogTest, PopupStartUpgradeBlowerUnit)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	PopupStartUpgradeBlowerUnit();
}

TEST_F(PopUpDialogTest, PopupStartUpgradeBLEUnit)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	PopupStartUpgradeBLEUnit();
}

TEST_F(PopUpDialogTest, PopupStartExportLog)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	PopupStartExportLog();
}

TEST_F(PopUpDialogTest, PopupPreparationDrying)
{
	PopupPreparationDrying();

	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(true,isDryingMode);
}

TEST_F(PopUpDialogTest, PopupEnterKeyHandle1)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eCircuitTypeSettingId)).Times(1).WillOnce(Return(eQE));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(2);

	currentStatePopUp = eDoneState;
	popupId = ePopupTimeChangeId;
	isDryingMode = true;
	PopupEnterKeyHandle();

	EXPECT_EQ(false,isDryingMode);
}

TEST_F(PopUpDialogTest, PopupEnterKeyHandle2)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eCircuitTypeSettingId)).Times(1).WillOnce(Return(eOthers));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(2);

	currentStatePopUp = eDoneState;
	popupId = ePopupTimeChangeId;
	isDryingMode = true;
	PopupEnterKeyHandle();

	EXPECT_EQ(false,isDryingMode);
}

TEST_F(PopUpDialogTest, PopupEnterKeyHandle3)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eNoState;
	isDryingMode = false;
	popupId = ePopupTimeChangeId;
	PopupEnterKeyHandle();
}

TEST_F(PopUpDialogTest, PopupEnterKeyHandle4)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eYesState;
	popupId = ePopupTimeChangeId;
	PopupEnterKeyHandle();
}

TEST_F(PopUpDialogTest, PopupEnterKeyHandle5)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eYesState;
	isReceiveKey = true;
	popupId = ePopupCircuitCalibrateId;
	PopupEnterKeyHandle();

	EXPECT_EQ(false,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupEnterKeyHandle6)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eYesState;
	isReceiveKey = true;
	popupId = ePopupMaskCalibrateId;
	PopupEnterKeyHandle();

	EXPECT_EQ(false,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupEnterKeyHandle7)
{
	EXPECT_CALL(*_settingLib,SettingSetDefaultMocks()).Times(1);
	EXPECT_CALL(*_settingLib,SettingSaveMocks()).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eLanguageSettingId)).Times(1).WillOnce(Return(2));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(4);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eBluetoothSettingId)).Times(1).WillOnce(Return(eOn));

	currentStatePopUp = eYesState;
	isReceiveKey = true;
	popupId = ePopupRestoreDefaultsId;
	PopupEnterKeyHandle();

	EXPECT_EQ(1,language);
	EXPECT_EQ(eDoneState,currentStatePopUp);
}

TEST_F(PopUpDialogTest, PopupEnterKeyHandle8)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(2);

	currentStatePopUp = eYesState;
	popupId = ePopupClearUsedHoursId;
	PopupEnterKeyHandle();
}

TEST_F(PopUpDialogTest, PopupEnterKeyHandle9)
{
	EXPECT_CALL(*_MainScreenLib,MainUpgradeCheckMocks()).Times(1).WillOnce(Return(true));
	EXPECT_CALL(*_EEPROMLib,EEPROMWriteMocks(_,_,_,_)).Times(1);
	EXPECT_CALL(*_SoftTimerLib,SoftTimerStartMocks(eSoftTimer0Id)).Times(1);

	currentStatePopUp = eYesState;
	popupId = ePopupControlUpgradeId;
	PopupEnterKeyHandle();

	EXPECT_EQ(false,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupEnterKeyHandle10)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eYesState;
	popupId = ePopupBlowerUpgradeId;
	PopupEnterKeyHandle();
}

TEST_F(PopUpDialogTest, PopupEnterKeyHandle11)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eYesState;
	popupId = ePopupBLEUpgradeId;
	PopupEnterKeyHandle();
}

TEST_F(PopUpDialogTest, PopupEnterKeyHandle12)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eYesState;
	popupId = ePopupExportLogId;
	PopupEnterKeyHandle();
}

TEST_F(PopUpDialogTest, PopupEnterKeyHandle13)
{
	currentStatePopUp = eYesState;
	popupId = ePopupConfirmDryingModeId;
	PopupEnterKeyHandle();

	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(true,isDryingMode);
}

TEST_F(PopUpDialogTest, PopupRightLeftKeyHandle1)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	currentStatePopUp = eNoState;
	PopupRightLeftKeyHandle();

	EXPECT_EQ(ePoint,yesNoButton[1].status);
	EXPECT_EQ(eRelease,yesNoButton[0].status);
	EXPECT_EQ(eYesState,currentStatePopUp);
}

TEST_F(PopUpDialogTest, PopupRightLeftKeyHandle2)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	currentStatePopUp = eYesState;
	PopupRightLeftKeyHandle();

	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
	EXPECT_EQ(eNoState,currentStatePopUp);
}

TEST_F(PopUpDialogTest, PopupUpgradeError)
{
	currentStatePopUp = eNoState;
	isReceiveKey = false;
	PopupUpgradeError();

	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupBlowerUpgradeSuccess)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eNoState;
	isReceiveKey = false;
	PopupBlowerUpgradeSuccess();

	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupBLEUpgradeSuccess)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eNoState;
	isReceiveKey = false;
	PopupBLEUpgradeSuccess();

	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupExportLogSuccess)
{
	currentStatePopUp = eNoState;
	PopupExportLogSuccess();

	EXPECT_EQ(eDoneState,currentStatePopUp);
}

TEST_F(PopUpDialogTest, PopupExportLogFail)
{
	currentStatePopUp = eNoState;
	PopupExportLogFail();

	EXPECT_EQ(eDoneState,currentStatePopUp);
}

TEST_F(PopUpDialogTest, PopupBlowerUpgradeStart)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);

	isReceiveKey = false;
	PopupBlowerUpgradeStart();

	EXPECT_EQ(ePopupBlowerUpgradeId,popupId);
	EXPECT_EQ(1,testPopupBlowerUpdatePercent);
	EXPECT_EQ(false,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupBLEUpgradeStart)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);

	isReceiveKey = false;
	PopupBLEUpgradeStart();

	EXPECT_EQ(ePopupBLEUpgradeId,popupId);
	EXPECT_EQ(1,testPopupBLEUpdatePercent);
	EXPECT_EQ(false,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupBlowerUpgradeReset)
{
	testPopupBlowerUpdatePercent = 9;
	PopupBlowerUpgradeReset();

	EXPECT_EQ(0,testPopupBlowerUpdatePercent);
}

TEST_F(PopUpDialogTest, PopupBLEUpgradeReset)
{
	testPopupBLEUpdatePercent = 19;
	PopupBLEUpgradeReset();

	EXPECT_EQ(0,testPopupBLEUpdatePercent);
}

TEST_F(PopUpDialogTest, PopupCircuitCalibrateShow)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	PopupCircuitCalibrateShow();

	EXPECT_EQ(ePopupCircuitCalibrateId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupConnectTheMaskShow)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	PopupConnectTheMaskShow();

	EXPECT_EQ(ePopupMaskCalibrateId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupCalibrateDone)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eNoState;
	isReceiveKey = false;
	PopupCalibrateDone();

	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupCalibrateError)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eNoState;
	isReceiveKey = false;
	PopupCalibrateError();

	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupTimeChangeShow)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	PopupTimeChangeShow();

	EXPECT_EQ(ePopupTimeChangeId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupRestoreDefaultsShow)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	PopupRestoreDefaultsShow();

	EXPECT_EQ(ePopupRestoreDefaultsId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupClearUsedHoursShow)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	PopupClearUsedHoursShow();

	EXPECT_EQ(ePopupClearUsedHoursId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupControlUpgradeShow)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	PopupControlUpgradeShow();

	EXPECT_EQ(ePopupControlUpgradeId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupBlowerUpgradeShow)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	PopupBlowerUpgradeShow();

	EXPECT_EQ(ePopupBlowerUpgradeId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupBLEUpgradeShow)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	PopupBLEUpgradeShow();

	EXPECT_EQ(ePopupBLEUpgradeId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupExportLogShow)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	PopupExportLogShow();

	EXPECT_EQ(ePopupExportLogId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupConfirmDryingMode)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	PopupConfirmDryingMode();

	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(true,isDryingMode);
}

TEST_F(PopUpDialogTest, PopupHandleEvent1)
{
	currentStatePopUp = eNoState;
	isReceiveKey = false;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupMotorUpgradeErrorId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupHandleEvent2)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eNoState;
	isReceiveKey = false;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupMotorUpgradeEndId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupHandleEvent3)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupMotorUpgradeRunId;
	guiEvent.data = 5;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(ePopupBlowerUpgradeId,popupId);
	EXPECT_EQ(1,testPopupBlowerUpdatePercent);
}

TEST_F(PopUpDialogTest, PopupHandleEvent4)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);

	isReceiveKey = false;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupMotorUpgradeStartId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(ePopupBlowerUpgradeId,popupId);
	EXPECT_EQ(1,testPopupBlowerUpdatePercent);
	EXPECT_EQ(false,isReceiveKey);

}

TEST_F(PopUpDialogTest, PopupHandleEvent5)
{
	testPopupBlowerUpdatePercent = 9;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupMotorUpgradeResetId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(0,testPopupBlowerUpdatePercent);
}

TEST_F(PopUpDialogTest, PopupHandleEvent6)
{
	currentStatePopUp = eNoState;
	isReceiveKey = false;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupBLEUpgradeErrorId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupHandleEvent7)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eNoState;
	isReceiveKey = false;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupBLEUpgradeEndId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupHandleEvent8)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);

	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupBLEUpgradeRunId;
	guiEvent.data = 8;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(ePopupBLEUpgradeId,popupId);
	EXPECT_EQ(1,testPopupBLEUpdatePercent);
}

TEST_F(PopUpDialogTest, PopupHandleEvent9)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);

	isReceiveKey = false;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupBLEUpgradeStartId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(ePopupBLEUpgradeId,popupId);
	EXPECT_EQ(1,testPopupBLEUpdatePercent);
	EXPECT_EQ(false,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupHandleEvent10)
{
	testPopupBLEUpdatePercent = 19;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupBLEUpgradeResetId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(0,testPopupBLEUpdatePercent);
}

TEST_F(PopUpDialogTest, PopupHandleEvent11)
{
	currentStatePopUp = eNoState;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupExportLogSuccessId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(eDoneState,currentStatePopUp);
}

TEST_F(PopUpDialogTest, PopupHandleEvent12)
{
	currentStatePopUp = eNoState;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupExportLogFailId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(eDoneState,currentStatePopUp);
}

TEST_F(PopUpDialogTest, PopupHandleEvent13)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupCircuitCalibrateShowId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(ePopupCircuitCalibrateId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupHandleEvent14)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupCircuitCalibrateDoneId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(ePopupMaskCalibrateId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupHandleEvent15)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eNoState;
	isReceiveKey = false;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupMaskCalibrateDoneId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupHandleEvent16)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStatePopUp = eNoState;
	isReceiveKey = false;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupCircuitCalibrateErrorId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
}

TEST_F(PopUpDialogTest, PopupHandleEvent17)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupTimeSettingShowId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(ePopupTimeChangeId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupHandleEvent18)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupRestoreDefaultsShowId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(ePopupRestoreDefaultsId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupHandleEvent19)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupClearUsedHoursShowId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(ePopupClearUsedHoursId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupHandleEvent20)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupControlUpgradeShowId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(ePopupControlUpgradeId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupHandleEvent21)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupMotorUpgradeShowId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(ePopupBlowerUpgradeId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupHandleEvent22)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiBLEUpgradeShowId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(ePopupBLEUpgradeId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupHandleEvent23)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(1)).WillOnce(Return(0));

	isReceiveKey = false;
	popupId = eFirstPopupId;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupExportLogShowId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(ePopupExportLogId,popupId);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(eNoState,currentStatePopUp);
	EXPECT_EQ(eRelease,yesNoButton[1].status);
	EXPECT_EQ(ePoint,yesNoButton[0].status);
}

TEST_F(PopUpDialogTest, PopupHandleEvent24)
{
	currentStatePopUp = eYesState;
	popupId = ePopupConfirmDryingModeId;
	GuiEventStruct guiEvent;
	guiEvent.id = eGuiPopupConfirmDryingModeId;
	PopupHandleEvent(guiEvent);

	EXPECT_EQ(eDoneState,currentStatePopUp);
	EXPECT_EQ(true,isReceiveKey);
	EXPECT_EQ(true,isDryingMode);
}

}


