/*
 * setting.cpp
 *
 *  Created on: Apr 23, 2018
 *      Author: Quoc Viet
 */

//#include <stdlib.h>
//#include "FreeRTOS.h"
//#include "task.h"
#include <guiinterface.h>
#include <setting.h>
//#include "crc.h"
//#include "eeprom.h"
//#include "debuguart.h"
//#include "ff.h"
#include "section.h"
#include "guiglobal.h"
#include "ff.h"
#include "queue.h"
#include "eepromMocks.h"
#include "WString.h"
#include "CrcMocks.h"
#include "systeminfortableMocks.h"
#include "RTCMocks.h"

//define number of setting
//#define NUM_OF_SETTING			eLastSettingId
#define BUFFER_SIZE				25
#define FILE_NUM_OF_STRING 		7
#define CRC_LENGTH				6
#define NAME_LENGTH				11
#define VALUE_LENGTH			6

SettingItem settingList[NUM_OF_SETTING];
bool requestReadSd = false;
RTC_TIME_Type testTime;
int testSettingGetStringFromFile = 0;
char buffer[BUFFER_SIZE];   /* File copy buffer */

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//create setting list in  (peripheral RAM)
//static SettingItem settingList[NUM_OF_SETTING];
//static char buffer[BUFFER_SIZE];   /* File copy buffer */
static FIL settingFile;
//declare a flag to request read setting from SD card
//static bool requestReadSd = false;
static xSemaphoreHandle settingMutex;

//bool SettingRestore();		//restore setting from EEPROM
//bool SettingGetStringFromFile();
//void SettingParseData(unsigned char id, int value);
//void SettingSetDefaultNoOS();
//void SettingSaveNoOS();

const char* settingHeaderStr[] = {
		"NS",
		"Ptreat",
		"Pmin",
		"Pmax",
		"Pdelay",
		"DevSetInfo",
		"RDTi"
};
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingInit()
//
//    Processing:
//      This operation recovers all setting is saved on on-chip EEPROM
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingInit()
{
	//read setting from EEPROM
	bool result = SettingRestore();
	if(result == false)		//data not available or wrong data
	{
		SettingSetDefaultNoOS();	//use default settings
		SettingSaveNoOS();
	}
}

//function to set request update setting from SD card
void SettingSetRequestReadSd()
{
	requestReadSd = true;
}

//function to get request read setting from SD card
bool SettingGetRequestReadSd()
{
	return requestReadSd;
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingSetDefaultNoOS()
//
//    Processing:
//      This operation set all settings to default value without runing OS
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      this function only be used in initialize system
//
//    Requirements:
//
/******************************************************************************/
void SettingSetDefaultNoOS()
{
	//initial ID
	for(int i = 0; i < NUM_OF_SETTING; i++)
	{
		settingList[i].id = (E_SettingId)i;
	}
	//initial default value for setting list
	settingList[eVentModeSettingId].data = eAutoMode;
	settingList[eBrightnessSettingId].data = 70;
	settingList[eLanguageSettingId].data = eEnglish;
	settingList[ePressUnitSettingId].data = ecmH2O;
	settingList[eBluetoothSettingId].data = eDisable;
	settingList[eOperPressSettingId].data = 40;				//4cmH20*10
	settingList[eDelayPressSettingId].data = 40;
	settingList[eDelayTimeSettingId].data = 0;
	settingList[eRampTimeSettingId].data = 0;
	settingList[eInhPressSupportSettingId].data = 0;		//off
	settingList[eExhPressSupportSettingId].data = 0;
	settingList[eAutoUpperPressSettingId].data = 100;
	settingList[eAutoLowerPressSettingId].data = 40;
	settingList[eAutoAdjustPressSettingId].data = eOff;
	settingList[eAutoCADetectSettingId].data = eOff;
	settingList[eAutoOADetectSettingId].data = eOff;
	settingList[eAutoHDetectSettingId].data = eOff;
	settingList[eAutoSDetectSettingId].data = eOff;
	settingList[eAutoFLDetectSettingId].data = eOff;
	settingList[eSleepTimerSettingId].data = 1;
	settingList[eNsTypeSettingId].data = 0;
	settingList[eAutoOFFSettingId].data = eOn;
	settingList[eFLSettingId].data = eOn;
	settingList[eCircuitTypeSettingId].data = eQE;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingSetDefault()
//
//    Processing:
//      This operation set all settings to default value
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingSetDefault()
{
	//take setting semaphore to access setting
	if(xSemaphoreTake(settingMutex, 2) == pdTRUE)		//wait maximum 1 tick
	{
		taskENTER_CRITICAL();
		SettingSetDefaultNoOS();
		//release semaphore
		xSemaphoreGive(settingMutex);
		taskEXIT_CRITICAL();
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingSet()
//
//    Processing:
//      This operation set value to an indicated setting id
//
//    Input Parameters:
//      unsigned char id:	setting ID
//		unsigned char value:	value of setting ID
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingSet(E_SettingId id, unsigned char value)
{
//	DebugStr("\n SettingSet: id = ");
//	DebugNumber(id);
//	DebugStr("; value = ");
//	DebugNumber(value);
	//convert setting id
	int settingId = (int)id;
	//check for the setting in table
	if(settingId >= NUM_OF_SETTING)
		return;
	//set setting
	if(xSemaphoreTake(settingMutex, 2) == pdTRUE)		//wait maximum 2 tick
	{
		taskENTER_CRITICAL();
		//set value to corresponding setting
		settingList[id].data = value;
		//release semaphore
		xSemaphoreGive(settingMutex);
		taskEXIT_CRITICAL();
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingGet()
//
//    Processing:
//      This operation set value to an indicated setting
//
//    Input Parameters:
//      unsigned char id:	setting ID
//
//    Output Parameters:
//      None
//
//    Return Values:
//      unsigned char: value of the setting
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
unsigned char SettingGet(E_SettingId id)
{
	unsigned char settingData = 0;
	//convert setting id
	int settingId = (int)id;
	//check for the setting in table
	if(settingId >= NUM_OF_SETTING)
		return settingData;
	//get setting from list
	if(xSemaphoreTake(settingMutex, 2) == pdTRUE)		//wait maximum 2 tick
	{
		taskENTER_CRITICAL();
		settingData = settingList[id].data;
		//release semaphore
		xSemaphoreGive(settingMutex);
		taskEXIT_CRITICAL();
	}
	return settingData;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingSaveNoOS()
//
//    Processing:
//      This operation save all settings from fist to last to EEPROM without OS running
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      This operation only be used in initialize system
//
//    Requirements:
//
/******************************************************************************/
void SettingSaveNoOS()
{
	unsigned char dataLength = NUM_OF_SETTING + 2;	//add 2 bytes for CRC check

	//copy data from settings to data array
	char data[dataLength];
	for(int i = eFirstSettingId; i < eLastSettingId; i++)
		data[i] = settingList[i].data;

	//add 2 byte CRC
	unsigned short temp = CrcCheckNoInitMocks(dataLength-2, &data[0]);
	data[dataLength-2] = (char)(temp&0xFF);
	data[dataLength-1] = (char)((temp>>8)&0xFF);
	//erase memory first
	EEPROM_EraseMocks(EEPROM_SETTING_PAGE_ADDR);//EEPROM_Erase(EEPROM_SETTING_PAGE_ADDR);
	//save setting to EEPROM
	EEPROMWriteMocks(EEPROM_SETTING_PAGE_ADDR, 0, &data[0], dataLength);//EEPROMWrite(EEPROM_SETTING_PAGE_ADDR, 0, &data[0], dataLength);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingSave()
//
//    Processing:
//      This operation save all settings from fist to last to EEPROM
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingSave()
{
	unsigned char dataLength = NUM_OF_SETTING + 2;	//add 2 bytes for CRC check

	//copy data from settings to data array
	char data[dataLength];
	for(int i = eFirstSettingId; i < eLastSettingId; i++)
		data[i] = SettingGet((E_SettingId)i);

	//add 2 byte CRC
	unsigned short temp = CrcCheckNoInitMocks(dataLength-2, &data[0]);
	data[dataLength-2] = (char)(temp&0xFF);
	data[dataLength-1] = (char)((temp>>8)&0xFF);
	//save setting to EEPROM
	EEPROMWriteMocks(EEPROM_SETTING_PAGE_ADDR, 0, &data[0], dataLength);//EEPROMWrite(EEPROM_SETTING_PAGE_ADDR, 0, &data[0], dataLength);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingRestore()
//
//    Processing:
//      This operation restores setting by reading data from EEPROM, then check CRC and apply them
//		if the data is correct
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      bool	: result of restoring process
//			true: restore success
//			false: restore failed, may no data or wrong data
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      This operation only be called in initialize system
//
//    Requirements:
//
/******************************************************************************/
bool SettingRestore()
{
	bool rtn = false;	//return value
	char data[NUM_OF_SETTING + 2] = {0};		//buffer to store data read from EEPROM

	//read settings from EEPROM
	taskENTER_CRITICAL();
	EEPROMReadMocks(EEPROM_SETTING_PAGE_ADDR, 0, &data[0], NUM_OF_SETTING + 2);//EEPROMRead(EEPROM_SETTING_PAGE_ADDR, 0, &data[0], NUM_OF_SETTING + 2);
	taskEXIT_CRITICAL();
	//check crc for the data has been read
	unsigned short temp = CrcCheckNoInitMocks(NUM_OF_SETTING + 2, &data[0]);//CrcCheckNoInit(NUM_OF_SETTING + 2, &data[0]);
	if(temp == 0)	//crc good
	{
		taskENTER_CRITICAL();
		//use settings had just restored for application
		for(int i = eFirstSettingId; i < eLastSettingId; i++)
			SettingSet((E_SettingId)i, data[i]);

		//force settings in range
		if(settingList[eVentModeSettingId].data > 1)		// 0 = CPAP; 1 = AUTO_CPAP
			settingList[eVentModeSettingId].data = 1;
		if(settingList[eBrightnessSettingId].data > 100)	//maximum pressrue setting = 20*10;
			settingList[eBrightnessSettingId].data = 100;
		else if(settingList[eBrightnessSettingId].data < 30)
			settingList[eBrightnessSettingId].data = 30;
		if(settingList[eLanguageSettingId].data > 1)
			settingList[eLanguageSettingId].data = 1;
		if(settingList[ePressUnitSettingId].data > 1)
			settingList[ePressUnitSettingId].data = 1;
		if(settingList[eBluetoothSettingId].data > 1)
			settingList[eBluetoothSettingId].data = 1;
		if(settingList[eOperPressSettingId].data > 200)				//4cmH20*10
			settingList[eOperPressSettingId].data = 200;
		else if(settingList[eOperPressSettingId].data < 40)
			settingList[eOperPressSettingId].data = 40;
		if(settingList[eDelayPressSettingId].data > 40)
			settingList[eDelayPressSettingId].data = 40;
		else if(settingList[eDelayPressSettingId].data < 20)
			settingList[eDelayPressSettingId].data = 20;
		if(settingList[eDelayTimeSettingId].data > 30)
			settingList[eDelayTimeSettingId].data = 30;
		if(settingList[eRampTimeSettingId].data > 45)
			settingList[eRampTimeSettingId].data = 45;
		if(settingList[eCircuitTypeSettingId].data > 1)
			settingList[eCircuitTypeSettingId].data = 1;
		if(settingList[eInhPressSupportSettingId].data > 5)
			settingList[eInhPressSupportSettingId].data = 5;
		if(settingList[eExhPressSupportSettingId].data > 5)
			settingList[eExhPressSupportSettingId].data = 5;
		if(settingList[eAutoUpperPressSettingId].data > 200)
			settingList[eAutoUpperPressSettingId].data = 200;
		else if(settingList[eAutoUpperPressSettingId].data < settingList[eAutoLowerPressSettingId].data)
			settingList[eAutoUpperPressSettingId].data = settingList[eAutoLowerPressSettingId].data;
		if(settingList[eAutoLowerPressSettingId].data > settingList[eAutoUpperPressSettingId].data)
			settingList[eAutoLowerPressSettingId].data = settingList[eAutoUpperPressSettingId].data;
		else if(settingList[eAutoLowerPressSettingId].data < 40)
			settingList[eAutoLowerPressSettingId].data = 40;
		if(settingList[eAutoAdjustPressSettingId].data > 1)
			settingList[eAutoAdjustPressSettingId].data = 1;
		if(settingList[eAutoCADetectSettingId].data > 1)
			settingList[eAutoCADetectSettingId].data = 1;
		if(settingList[eAutoOADetectSettingId].data > 1)
			settingList[eAutoOADetectSettingId].data = 1;
		if(settingList[eAutoHDetectSettingId].data > 1)
			settingList[eAutoHDetectSettingId].data = 1;
		if(settingList[eAutoSDetectSettingId].data > 1)
			settingList[eAutoSDetectSettingId].data = 1;
		if(settingList[eAutoFLDetectSettingId].data > 1)
			settingList[eAutoFLDetectSettingId].data = 1;
		if(settingList[eSleepTimerSettingId].data > 4)
			settingList[eSleepTimerSettingId].data = 4;
		if(settingList[eNsTypeSettingId].data > 1)
			settingList[eNsTypeSettingId].data = 1;
		if(settingList[eAutoOFFSettingId].data > 1)
			settingList[eAutoOFFSettingId].data = 1;
		if(settingList[eFLSettingId].data > 1)
			settingList[eFLSettingId].data = 1;

		taskEXIT_CRITICAL();
		//set flag to indicate restore process is success
		rtn = true;
	}
	return rtn;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingReadOperInfor()
//
//    Processing:
//      This operation read and apply operation setting from SD card and store them
//		into internal memory
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      bool: 	true if reading data from SD card OK
//				false if can not read data from SD card
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
bool SettingReadOperInfor()
{
	bool rc;
	bool rtn = false;

	const char* fileReadName = "Settings/Settings.cfg";
	//make sure RTOS will not switch context
	taskENTER_CRITICAL();
	//check Settings directory is available or not
	if(f_open(&settingFile, fileReadName, FA_READ) != FR_OK)
	{
		//allow context switch
		taskEXIT_CRITICAL();
		//break from function
		return rtn;
	}
	//read pocket data
	for(int i = 0; i < FILE_NUM_OF_STRING; i++)
	{
		rc = SettingGetStringFromFile();

		if(rc == false)
		{
			//close file
			f_close(&settingFile);
			//allow context switch
			taskEXIT_CRITICAL();
			//break from function
			return rtn;
		}
	}

	//close file
	f_close(&settingFile);
	//delete file
	f_unlink(fileReadName);
	//save setting to EEPROM
	SettingSave();
	//get language
	language = SettingGet(eLanguageSettingId);
	if(language > 1)
		language = 1;
	//check and show BLE icon
	if(SettingGet(eBluetoothSettingId) == eOn)
	{
		//show BLE icon
		GuiTaskSendEvent(eGuiShowBleIconId, 0);
	}
	else
	{
		//hide BLE icon
		GuiTaskSendEvent(eGuiHideBleIconId, 0);
	}

	//update setting to operation screen
	GuiTaskSendEvent(eGuiOperUpdateSettingId, 0);
	//set flag indicate that restore setting from SD card was success
	rtn = true;
	//clear flag
	requestReadSd = false;
	//allow context switch
	taskEXIT_CRITICAL();
	return rtn;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingReadSystemInfor()
//
//    Processing:
//      This operation read system information from SD card and apply to the system
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      bool: 	true if reading data from SD card OK
//				false if can not read data from SD card
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
#if 1//SUPPORT_SERIAL_NUMBER_FROM_SD
bool SettingReadSystemInfor()
{
	char inforStr[20];
	bool rtn = false;
	//do copy serial number and real time data from SD card to internal memory if require
	const char* configFileName = "Settings/config.mt";
	//make sure RTOS will not switch context
	taskENTER_CRITICAL();
	//open configure file
	bool rc = f_open(&settingFile, configFileName, FA_READ);
	if(rc != FR_OK)
	{
		//allow context switch
		taskEXIT_CRITICAL();
		//break from function
		return rtn;
	}
	//read serial number
	f_gets(&inforStr[0], EEPROM_SERIALNUMBER_SIZE, &settingFile);
	//save serial number to system memory
	SystemInforSetSerialNumberMocks(&inforStr[0], EEPROM_SERIALNUMBER_SIZE);
	//write serial number to EEPROM
	EEPROMWriteMocks(EEPROM_SERIALNUMBER_PAGE_ADDR, EEPROM_SERIALNUMBER_BYTE_ADDR, &inforStr[0], EEPROM_SERIALNUMBER_SIZE);
	//get time
	char tempStr[8];
	//read year
	f_gets(&tempStr[0], 8, &settingFile);
	//convert string to integer
	int year = atoi(&tempStr[0]);
	if(year < 2000)
	{
		testTime.YEAR = 2000;
		year = 2000;
	}
	//read month
	f_gets(&tempStr[0], 8, &settingFile);
	int month = atoi(&tempStr[0]);
	if(month <= 1)
	{
		testTime.MONTH = 1;
		month = 1;
	}
	else if(month >= 12)
	{
		testTime.MONTH = 12;
		month = 12;
	}

	//read date
	f_gets(&tempStr[0], 8, &settingFile);
	int date = atoi(&tempStr[0]);
	if(date <= 1)
	{
		testTime.DOM = 1;
		date = 1;
	}
	else if(date >= 31)
	{
		testTime.DOM = 31;
		date = 31;
	}

	//update time
	RTC_TIME_Type time = RTCGetMocks();
	time.YEAR = year;
	time.MONTH = month;
	time.DOM = date;
	time.HOUR = 0;
	time.MIN = 0;
	time.SEC = 0;
	RTCSetMocks(&time);
	//close file
	f_close(&settingFile);
	//delete file
	f_unlink(configFileName);
	//set result is success
	rtn = true;
	//allow context switch
	taskEXIT_CRITICAL();
	return rtn;
}
#endif

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingReadFromSd()
//
//    Processing:
//      This operation reads setting from SD card
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//		None
//
//    Return Values:
//      bool: 	true if reading data from SD card OK
//				false if can not read data from SD card
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
bool SettingReadFromSd()
{
	bool rtn1 = false;
//	bool rtn2 = false;
	rtn1 = SettingReadOperInfor();
#if 1//SUPPORT_SERIAL_NUMBER_FROM_SD
	/*rtn2 = */SettingReadSystemInfor();
#endif
	return (rtn1/*&&rtn2*/);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingGetStringFromFile(unsigned char byte)
//
//    Processing:
//      This operation reads setting from SD card
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//		None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
bool SettingGetStringFromFile()
{
	f_gets((char*)&buffer[0], BUFFER_SIZE, &settingFile);

	unsigned char id = 0;
	unsigned char dataLength = 0;
	unsigned char numOfHashtag = 2;
	unsigned char posFirstHashtag = 0;
	unsigned char posSecondHashtag = 0;
	unsigned char crc[BUFFER_SIZE] = {'\0'};
	char crcString[CRC_LENGTH] = {'\0'};
	char nameString[NAME_LENGTH] = {'\0'};
	char valueString[VALUE_LENGTH] = {'\0'};

	for(int i = 0; i < BUFFER_SIZE; i++)
	{
		if(buffer[i] == 0x0A)	//detect end of string, get crc and get out of loop
		{
			dataLength = i - 1;	//get data length
			for(int j = posSecondHashtag + 1; j < dataLength; j++)
			{
				if(((j-(posSecondHashtag + 1)) < CRC_LENGTH) && (j < BUFFER_SIZE))
					crc[j-(posSecondHashtag + 1)] = buffer[j];//get crc string
			}
			testSettingGetStringFromFile = dataLength;
			break;
		}
		else
		{
			if((buffer[i] == '#')&&(numOfHashtag > 1))	//detect the first #
			{
				posFirstHashtag = i;	//position of the first hashtag
				numOfHashtag--;			//decrease number of hashtags
				for(int i = 0; i < posFirstHashtag; i++)
				{
					if(i < NAME_LENGTH)
						nameString[i] = buffer[i];	//get name string
				}
				testSettingGetStringFromFile = numOfHashtag;
			}
			else if(buffer[i] == '#')	//detect the second #
			{
				posSecondHashtag = i;	//position of the second hashtag
				for(int i = posFirstHashtag + 1; i < posSecondHashtag; i++)
				{
					if( (i - (posFirstHashtag+1)) < VALUE_LENGTH)
						valueString[i - (posFirstHashtag+1)] = buffer[i];	//get value string
				}
				testSettingGetStringFromFile = i;
			}
		}
	}
	//calculate crc and covert to string
	itoa(CrcCheckNoInitMocks(posSecondHashtag+1, &buffer[0]), &crcString[0], 10);
	//check crc
	if(strcmp((const char*)crcString, (const char*)crc) != 0)
	{
//		DebugStr("\n crc wrong");
		return false;
	}
	//check name string
	for(int i = 0; i < FILE_NUM_OF_STRING; i++)
	{
		if(strcmp(nameString, settingHeaderStr[i]) == 0)
		{
			id = i;	//set id
			break;
		}
	}

	int value = atof(valueString)*10;	//convert valueString to float, x10 to convert to int
	SettingParseData(id, value);	//parse data to apply setting

	return true;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingParseData(unsigned char id, int value)
//
//    Processing:
//      This operation parses data to apply setting
//
//    Input Parameters:
//      None
//
//    Output Parameters:
//		None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingParseData(unsigned char id, int value)
{
	DevSetInfoUnion infoByteGet;		//declare variable to get information
	RampDelayTimeUnion rampDelayGet;	//declare variable to get ramp time
	NaturalSupportUnion naturalSupportGet;	//declare variable to get NS

	switch (id) {
	case eNsSettingLogId:
		value /= 10;
		naturalSupportGet.data = value;
		SettingSet(eInhPressSupportSettingId, naturalSupportGet.naturalSupportStruct.inhSupport);
		SettingSet(eExhPressSupportSettingId, naturalSupportGet.naturalSupportStruct.exhSupport);
		break;
	case ePtreatSettingLogid:
		SettingSet(eOperPressSettingId, value);	//set value for treatment pressure
		break;
	case ePminSettingLogId:
		SettingSet(eAutoLowerPressSettingId, value);
		break;
	case ePmaxSettingLogId:
		SettingSet(eAutoUpperPressSettingId, value);
		break;
	case ePdelaySettingLogId:
		SettingSet(eDelayPressSettingId, value);
		break;
	case eDevSetInfoSettingLogId:
		value /= 10;
		infoByteGet.data = value;
		SettingSet(eVentModeSettingId, infoByteGet.devSetInfoStruct.ventilationMode);
		SettingSet(ePressUnitSettingId, infoByteGet.devSetInfoStruct.pressureUnit);
		SettingSet(eNsTypeSettingId, infoByteGet.devSetInfoStruct.naturalSupportType);
		SettingSet(eBluetoothSettingId, infoByteGet.devSetInfoStruct.bluetoothStat);
		SettingSet(eFLSettingId, infoByteGet.devSetInfoStruct.fL);
		SettingSet(eAutoOFFSettingId, infoByteGet.devSetInfoStruct.autoOFF);
		SettingSet(eCircuitTypeSettingId, infoByteGet.devSetInfoStruct.circuitType);
		break;
	case eRDTiSettingLogId:
		value /= 10;
		rampDelayGet.data = value;	//get value
		SettingSet(eRampTimeSettingId, rampDelayGet.rampDelayTimeStruct.rampTime*RAMP_TIME_SETTING_STEP);
		break;
	default:
		break;
	}
}

#if defined(__cplusplus)
}
#endif

