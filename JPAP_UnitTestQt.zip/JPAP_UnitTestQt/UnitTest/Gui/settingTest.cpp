/*
 * settingTest.cpp
 *
 *  Created on: Apr 23, 2018
 *      Author: Quoc Viet
 */

#include <setting.h>
#include "stdafx.h"
#include "Fixture.h"
#include "RTCMocks.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern SettingItem settingList[];
extern bool requestReadSd;
extern RTC_TIME_Type testTime;
extern int testSettingGetStringFromFile;
extern char buffer[];

namespace EmbeddedCUnitTest {


class SettingTest : public TestFixture
{
public:
	SettingTest() : TestFixture(new ModuleMock) {}
};

TEST_F(SettingTest, SettingInit)
{
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(2);
	EXPECT_CALL(*_EEPROMLib,EEPROMReadMocks(_,_,_,_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(2);
	EXPECT_CALL(*_CRCJAPLib,CrcCheckNoInitMocks(_,_)).Times(1).WillOnce(Return(0));

	SettingInit();
}

TEST_F(SettingTest, SettingSetRequestReadSd)
{
	SettingSetRequestReadSd();

	EXPECT_EQ(true,requestReadSd);
}

TEST_F(SettingTest, SettingGetRequestReadSd)
{
	requestReadSd = false;
	SettingGetRequestReadSd();

	EXPECT_EQ(false,requestReadSd);
}

TEST_F(SettingTest, SettingSetDefaultNoOS)
{
	SettingSetDefaultNoOS();

	for(int i = 0; i < NUM_OF_SETTING; i++)
	{
		EXPECT_EQ((E_SettingId)i,settingList[i].id);
	}

	EXPECT_EQ(eAutoMode,settingList[eVentModeSettingId].data);
	EXPECT_EQ(70,settingList[eBrightnessSettingId].data);
	EXPECT_EQ(eEnglish,settingList[eLanguageSettingId].data);
	EXPECT_EQ(ecmH2O,settingList[ePressUnitSettingId].data);
	EXPECT_EQ(eDisable,settingList[eBluetoothSettingId].data);
	EXPECT_EQ(40,settingList[eOperPressSettingId].data);
	EXPECT_EQ(40,settingList[eDelayPressSettingId].data);
	EXPECT_EQ(0,settingList[eDelayTimeSettingId].data);
	EXPECT_EQ(0,settingList[eRampTimeSettingId].data);
	EXPECT_EQ(0,settingList[eInhPressSupportSettingId].data);
	EXPECT_EQ(0,settingList[eExhPressSupportSettingId].data);
	EXPECT_EQ(100,settingList[eAutoUpperPressSettingId].data);
	EXPECT_EQ(40,settingList[eAutoLowerPressSettingId].data);
	EXPECT_EQ(eOff,settingList[eAutoAdjustPressSettingId].data);
	EXPECT_EQ(eOff,settingList[eAutoCADetectSettingId].data);
	EXPECT_EQ(eOff,settingList[eAutoOADetectSettingId].data);
	EXPECT_EQ(eOff,settingList[eAutoHDetectSettingId].data);
	EXPECT_EQ(eOff,settingList[eAutoSDetectSettingId].data);
	EXPECT_EQ(eOff,settingList[eAutoFLDetectSettingId].data);
	EXPECT_EQ(1,settingList[eSleepTimerSettingId].data);
	EXPECT_EQ(0,settingList[eNsTypeSettingId].data);
	EXPECT_EQ(eOn,settingList[eAutoOFFSettingId].data);
	EXPECT_EQ(eOn,settingList[eFLSettingId].data);
	EXPECT_EQ(eQE,settingList[eCircuitTypeSettingId].data);
}

TEST_F(SettingTest, SettingSetDefault)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSetDefault();

	for(int i = 0; i < NUM_OF_SETTING; i++)
	{
		EXPECT_EQ((E_SettingId)i,settingList[i].id);
	}

	EXPECT_EQ(eAutoMode,settingList[eVentModeSettingId].data);
	EXPECT_EQ(70,settingList[eBrightnessSettingId].data);
	EXPECT_EQ(eEnglish,settingList[eLanguageSettingId].data);
	EXPECT_EQ(ecmH2O,settingList[ePressUnitSettingId].data);
	EXPECT_EQ(eDisable,settingList[eBluetoothSettingId].data);
	EXPECT_EQ(40,settingList[eOperPressSettingId].data);
	EXPECT_EQ(40,settingList[eDelayPressSettingId].data);
	EXPECT_EQ(0,settingList[eDelayTimeSettingId].data);
	EXPECT_EQ(0,settingList[eRampTimeSettingId].data);
	EXPECT_EQ(0,settingList[eInhPressSupportSettingId].data);
	EXPECT_EQ(0,settingList[eExhPressSupportSettingId].data);
	EXPECT_EQ(100,settingList[eAutoUpperPressSettingId].data);
	EXPECT_EQ(40,settingList[eAutoLowerPressSettingId].data);
	EXPECT_EQ(eOff,settingList[eAutoAdjustPressSettingId].data);
	EXPECT_EQ(eOff,settingList[eAutoCADetectSettingId].data);
	EXPECT_EQ(eOff,settingList[eAutoOADetectSettingId].data);
	EXPECT_EQ(eOff,settingList[eAutoHDetectSettingId].data);
	EXPECT_EQ(eOff,settingList[eAutoSDetectSettingId].data);
	EXPECT_EQ(eOff,settingList[eAutoFLDetectSettingId].data);
	EXPECT_EQ(1,settingList[eSleepTimerSettingId].data);
	EXPECT_EQ(0,settingList[eNsTypeSettingId].data);
	EXPECT_EQ(eOn,settingList[eAutoOFFSettingId].data);
	EXPECT_EQ(eOn,settingList[eFLSettingId].data);
	EXPECT_EQ(eQE,settingList[eCircuitTypeSettingId].data);
}

TEST_F(SettingTest, SettingSet1)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eVentModeSettingId, 0);
	EXPECT_EQ(0,settingList[eVentModeSettingId].data);
}

TEST_F(SettingTest, SettingSet2)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eBrightnessSettingId, 105);
	EXPECT_EQ(105,settingList[eBrightnessSettingId].data);
}

TEST_F(SettingTest, SettingSet3)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eLanguageSettingId, 3);
	EXPECT_EQ(3,settingList[eLanguageSettingId].data);
}

TEST_F(SettingTest, SettingSet4)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(ePressUnitSettingId, 5);
	EXPECT_EQ(5,settingList[ePressUnitSettingId].data);
}

TEST_F(SettingTest, SettingSet5)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eBluetoothSettingId, 11);
	EXPECT_EQ(11,settingList[eBluetoothSettingId].data);
}

TEST_F(SettingTest, SettingSet6)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eOperPressSettingId, 21);
	EXPECT_EQ(21,settingList[eOperPressSettingId].data);
}

TEST_F(SettingTest, SettingSet7)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eDelayPressSettingId, 30);
	EXPECT_EQ(30,settingList[eDelayPressSettingId].data);
}

TEST_F(SettingTest, SettingSet8)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eDelayTimeSettingId, 45);
	EXPECT_EQ(45,settingList[eDelayTimeSettingId].data);
}

TEST_F(SettingTest, SettingSet9)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eRampTimeSettingId, 55);
	EXPECT_EQ(55,settingList[eRampTimeSettingId].data);
}

TEST_F(SettingTest, SettingSet10)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eCircuitTypeSettingId, 23);
	EXPECT_EQ(23,settingList[eCircuitTypeSettingId].data);
}

TEST_F(SettingTest, SettingSet11)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eExhPressSupportSettingId, 9);
	EXPECT_EQ(9,settingList[eExhPressSupportSettingId].data);
}

TEST_F(SettingTest, SettingSet12)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eInhPressSupportSettingId, 1);
	EXPECT_EQ(1,settingList[eInhPressSupportSettingId].data);
}

TEST_F(SettingTest, SettingSet13)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eAutoUpperPressSettingId,0);
	EXPECT_EQ(0,settingList[eAutoUpperPressSettingId].data);
}

TEST_F(SettingTest, SettingSet14)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eAutoLowerPressSettingId, 1);
	EXPECT_EQ(1,settingList[eAutoLowerPressSettingId].data);
}

TEST_F(SettingTest, SettingSet15)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eAutoAdjustPressSettingId, 0);
	EXPECT_EQ(0,settingList[eAutoAdjustPressSettingId].data);
}

TEST_F(SettingTest, SettingSet16)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eAutoCADetectSettingId, 1);
	EXPECT_EQ(1,settingList[eAutoCADetectSettingId].data);
}

TEST_F(SettingTest, SettingSet17)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eAutoOADetectSettingId, 0);
	EXPECT_EQ(0,settingList[eAutoOADetectSettingId].data);
}

TEST_F(SettingTest, SettingSet18)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eAutoHDetectSettingId, 1);
	EXPECT_EQ(1,settingList[eAutoHDetectSettingId].data);
}

TEST_F(SettingTest, SettingSet19)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eAutoSDetectSettingId, 0);
	EXPECT_EQ(0,settingList[eAutoSDetectSettingId].data);
}

TEST_F(SettingTest, SettingSet20)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eAutoFLDetectSettingId, 1);
	EXPECT_EQ(1,settingList[eAutoFLDetectSettingId].data);
}

TEST_F(SettingTest, SettingSet21)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eSleepTimerSettingId, 10);
	EXPECT_EQ(10,settingList[eSleepTimerSettingId].data);
}

TEST_F(SettingTest, SettingSet22)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eNsTypeSettingId, 50);
	EXPECT_EQ(50,settingList[eNsTypeSettingId].data);
}

TEST_F(SettingTest, SettingSet23)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eAutoOFFSettingId, 1);
	EXPECT_EQ(1,settingList[eAutoOFFSettingId].data);
}

TEST_F(SettingTest, SettingSet24)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingSet(eFLSettingId, 20);
	EXPECT_EQ(20,settingList[eFLSettingId].data);
}

TEST_F(SettingTest, SettingGet)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	settingList[eFLSettingId].data = 108;

	EXPECT_EQ(108,SettingGet(eFLSettingId));
}

TEST_F(SettingTest, SettingSaveNoOS)
{
	EXPECT_CALL(*_CRCJAPLib,CrcCheckNoInitMocks(_,_)).Times(1).WillOnce(Return(5027));
	EXPECT_CALL(*_EEPROMLib,EEPROM_EraseMocks(_)).Times(1);
	EXPECT_CALL(*_EEPROMLib,EEPROMWriteMocks(_,_,_,_)).Times(1);

	SettingSaveNoOS();
}

TEST_F(SettingTest, SettingSave)
{
	EXPECT_CALL(*_CRCJAPLib,CrcCheckNoInitMocks(_,_)).Times(1).WillOnce(Return(5028));
	EXPECT_CALL(*_EEPROMLib,EEPROMWriteMocks(_,_,_,_)).Times(1);

	SettingSave();
}

TEST_F(SettingTest, SettingRestore1)
{
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(2);
	EXPECT_CALL(*_EEPROMLib,EEPROMReadMocks(_,_,_,_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(2);
	EXPECT_CALL(*_CRCJAPLib,CrcCheckNoInitMocks(_,_)).Times(1).WillOnce(Return(0));

	EXPECT_EQ(true,SettingRestore());
}

TEST_F(SettingTest, SettingRestore2)
{
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_EEPROMLib,EEPROMReadMocks(_,_,_,_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);
	EXPECT_CALL(*_CRCJAPLib,CrcCheckNoInitMocks(_,_)).Times(1).WillOnce(Return((unsigned short)5027));

	EXPECT_EQ(false,SettingRestore());
}

TEST_F(SettingTest, SettingReadOperInfor1)
{
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_FFLib,f_open(_,_,_)).Times(1).WillOnce(Return(1));
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	EXPECT_EQ(false,SettingReadOperInfor());
}

TEST_F(SettingTest, SettingReadOperInfor2)
{
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_FFLib,f_open(_,_,_)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,itoa(_,_,_)).Times(1);
	EXPECT_CALL(*_CRCJAPLib,CrcCheckNoInitMocks(_,_)).Times(1);
	EXPECT_CALL(*_wstring,strcmp(_,_)).Times(1).WillOnce(Return(1));
	EXPECT_CALL(*_FFLib,f_close(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	EXPECT_EQ(false,SettingReadOperInfor());
}

TEST_F(SettingTest, SettingReadOperInfor3)
{
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_FFLib,f_open(_,_,_)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,itoa(_,_,_)).Times(7);
	EXPECT_CALL(*_CRCJAPLib,CrcCheckNoInitMocks(_,_)).Times(8);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	requestReadSd = true;
	EXPECT_EQ(true,SettingReadOperInfor());
	EXPECT_EQ(false,requestReadSd);
}

TEST_F(SettingTest, SettingReadSystemInfor1)
{
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_FFLib,f_open(_,_,_)).Times(1).WillOnce(Return(1));
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	EXPECT_EQ(false,SettingReadSystemInfor());
}

TEST_F(SettingTest, SettingReadSystemInfor2)
{
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_FFLib,f_open(_,_,_)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_FFLib,f_gets(_,_,_)).Times(4);
	EXPECT_CALL(*_SysInforTableLib,SystemInforSetSerialNumberMocks(_,_)).Times(1);
	EXPECT_CALL(*_EEPROMLib,EEPROMWriteMocks(_,_,_,_)).Times(1);
	EXPECT_CALL(*_wstring,atoi(_)).Times(3).WillOnce(Return(1998)).WillOnce(Return(0)).WillOnce(Return(0));
	EXPECT_CALL(*_RTCLib,RTCGetMocks()).Times(1);
	EXPECT_CALL(*_RTCLib,RTCSetMocks(_)).Times(1);
	EXPECT_CALL(*_FFLib,f_close(_)).Times(1);
	EXPECT_CALL(*_FFLib,f_unlink(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	EXPECT_EQ(true,SettingReadSystemInfor());
	EXPECT_EQ((uint32_t)2000,testTime.YEAR);
	EXPECT_EQ((uint32_t)1,testTime.MONTH);
	EXPECT_EQ((uint32_t)1,testTime.DOM);
}

TEST_F(SettingTest, SettingReadSystemInfor3)
{
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_FFLib,f_open(_,_,_)).Times(1).WillOnce(Return(0));
	EXPECT_CALL(*_FFLib,f_gets(_,_,_)).Times(4);
	EXPECT_CALL(*_SysInforTableLib,SystemInforSetSerialNumberMocks(_,_)).Times(1);
	EXPECT_CALL(*_EEPROMLib,EEPROMWriteMocks(_,_,_,_)).Times(1);
	EXPECT_CALL(*_wstring,atoi(_)).Times(3).WillOnce(Return(1998)).WillOnce(Return(15)).WillOnce(Return(32));
	EXPECT_CALL(*_RTCLib,RTCGetMocks()).Times(1);
	EXPECT_CALL(*_RTCLib,RTCSetMocks(_)).Times(1);
	EXPECT_CALL(*_FFLib,f_close(_)).Times(1);
	EXPECT_CALL(*_FFLib,f_unlink(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	EXPECT_EQ(true,SettingReadSystemInfor());
	EXPECT_EQ((uint32_t)2000,testTime.YEAR);
	EXPECT_EQ((uint32_t)12,testTime.MONTH);
	EXPECT_EQ((uint32_t)31,testTime.DOM);
}

TEST_F(SettingTest, SettingReadFromSd)
{
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(2);
	EXPECT_CALL(*_FFLib,f_open(_,_,_)).Times(2).WillOnce(Return(1)).WillOnce(Return(1));
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(2);

	EXPECT_EQ(false,SettingReadFromSd());
}

TEST_F(SettingTest, SettingGetStringFromFile1)
{
	EXPECT_CALL(*_FFLib,f_gets(_,_,_)).Times(1);
	EXPECT_CALL(*_wstring,itoa(_,_,_)).Times(1);
	EXPECT_CALL(*_CRCJAPLib,CrcCheckNoInitMocks(_,_)).Times(1);
	EXPECT_CALL(*_wstring,strcmp(_,_)).Times(1).WillOnce(Return(1));

	buffer[10] = 0x0A;

	EXPECT_EQ(false,SettingGetStringFromFile());
	EXPECT_EQ(9,testSettingGetStringFromFile);
}

TEST_F(SettingTest, SettingGetStringFromFile2)
{
	EXPECT_CALL(*_FFLib,f_gets(_,_,_)).Times(1);
	EXPECT_CALL(*_wstring,itoa(_,_,_)).Times(1);
	EXPECT_CALL(*_CRCJAPLib,CrcCheckNoInitMocks(_,_)).Times(1);
	EXPECT_CALL(*_wstring,strcmp(_,_)).Times(1).WillOnce(Return(1));

	buffer[10] = '#';

	EXPECT_EQ(false,SettingGetStringFromFile());
	EXPECT_EQ(1,testSettingGetStringFromFile);
}

TEST_F(SettingTest, SettingGetStringFromFile3)
{
	EXPECT_CALL(*_FFLib,f_gets(_,_,_)).Times(1);
	EXPECT_CALL(*_wstring,itoa(_,_,_)).Times(1);
	EXPECT_CALL(*_CRCJAPLib,CrcCheckNoInitMocks(_,_)).Times(1);
	EXPECT_CALL(*_wstring,strcmp(_,_)).Times(1).WillOnce(Return(1));

	buffer[9] = '#';
	buffer[10] = '#';

	EXPECT_EQ(false,SettingGetStringFromFile());
	EXPECT_EQ(10,testSettingGetStringFromFile);
}

TEST_F(SettingTest, SettingGetStringFromFile4)
{
	EXPECT_CALL(*_FFLib,f_gets(_,_,_)).Times(1);
	EXPECT_CALL(*_wstring,itoa(_,_,_)).Times(1);
	EXPECT_CALL(*_CRCJAPLib,CrcCheckNoInitMocks(_,_)).Times(1);
	EXPECT_CALL(*_wstring,strcmp(_,_)).Times(2).WillOnce(Return(0)).WillOnce(Return(0));
	EXPECT_CALL(*_wstring,atof(_)).Times(1);

	buffer[9] = '#';
	buffer[10] = '#';

	EXPECT_EQ(true,SettingGetStringFromFile());
	EXPECT_EQ(10,testSettingGetStringFromFile);
}

TEST_F(SettingTest, SettingGetStringFromFile5)
{
	EXPECT_CALL(*_FFLib,f_gets(_,_,_)).Times(1);
	EXPECT_CALL(*_wstring,itoa(_,_,_)).Times(1);
	EXPECT_CALL(*_CRCJAPLib,CrcCheckNoInitMocks(_,_)).Times(1);
	EXPECT_CALL(*_wstring,strcmp(_,_)).Times(8).WillOnce(Return(0)).WillOnce(Return(1)).WillOnce(Return(1)).WillOnce(Return(1)).WillOnce(Return(1)).WillOnce(Return(1)).WillOnce(Return(1)).WillOnce(Return(1));
	EXPECT_CALL(*_wstring,atof(_)).Times(1);

	buffer[9] = '#';
	buffer[10] = '#';

	EXPECT_EQ(true,SettingGetStringFromFile());
	EXPECT_EQ(10,testSettingGetStringFromFile);
}

TEST_F(SettingTest, SettingParseData1)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(2).WillOnce(Return(pdTRUE)).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(2);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(2);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(2);

	SettingParseData(eNsSettingLogId,200);

	EXPECT_EQ(4,settingList[eInhPressSupportSettingId].data);
	EXPECT_EQ(1,settingList[eExhPressSupportSettingId].data);
}

TEST_F(SettingTest, SettingParseData2)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingParseData(ePtreatSettingLogid,100);

	EXPECT_EQ(100,settingList[eOperPressSettingId].data);
}

TEST_F(SettingTest, SettingParseData3)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingParseData(ePminSettingLogId,1);

	EXPECT_EQ(1,settingList[eAutoLowerPressSettingId].data);
}

TEST_F(SettingTest, SettingParseData4)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingParseData(ePmaxSettingLogId,0);

	EXPECT_EQ(0,settingList[eAutoUpperPressSettingId].data);
}

TEST_F(SettingTest, SettingParseData5)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(7).WillOnce(Return(pdTRUE)).WillOnce(Return(pdTRUE)).WillOnce(Return(pdTRUE)).WillOnce(Return(pdTRUE)).WillOnce(Return(pdTRUE)).WillOnce(Return(pdTRUE)).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(7);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(7);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(7);

	SettingParseData(eDevSetInfoSettingLogId,2560);

	EXPECT_EQ(0,settingList[eVentModeSettingId].data);
	EXPECT_EQ(0,settingList[ePressUnitSettingId].data);
	EXPECT_EQ(0,settingList[eNsTypeSettingId].data);
	EXPECT_EQ(0,settingList[eBluetoothSettingId].data);
	EXPECT_EQ(0,settingList[eFLSettingId].data);
	EXPECT_EQ(0,settingList[eAutoOFFSettingId].data);
	EXPECT_EQ(0,settingList[eCircuitTypeSettingId].data);
}

TEST_F(SettingTest, SettingParseData6)
{
	EXPECT_CALL(*_queueLib,xSemaphoreTake(_,2)).Times(1).WillOnce(Return(pdTRUE));
	EXPECT_CALL(*_queueLib,taskENTER_CRITICAL()).Times(1);
	EXPECT_CALL(*_queueLib,xSemaphoreGive(_)).Times(1);
	EXPECT_CALL(*_queueLib,taskEXIT_CRITICAL()).Times(1);

	SettingParseData(eRDTiSettingLogId,200);

	EXPECT_EQ(5,settingList[eRampTimeSettingId].data);
}

}
