/*
 * settingbutton.cpp
 *
 *  Created on: Apr 24, 2018
 *      Author: Quoc Viet
 */

#include "settingbutton.h"

#include <guiinterface.h>
#include <motorctrlinterface.h>
#include <setting.h>
#include <systeminterface.h>

#include "strings.h"
#include "guiglobal.h"
#include "deviceinterface.h"
#include "WMMocks.h"
#include "SettingMocks.h"
#include "PWMLib.h"

#include "stdio.h"

#define NUM_OF_SETTING_BUTTON 		(eLastSettingBtnId - eFirstSettingBtnId + 1)
//define for slider
#define SLIDER_LENGTH			280
#define SLIDER_HEIGHT			4
#define SLIDER_X				10
#define SLIDER_Y				37

#define VALUE_LABEL_X				270
//define num of string
#define INH_EXH_NUM_STR				6
#define RAMP_TIME_NUM_STR			10
#define BRIGHTNESS_NUM_STR			8
#define LANGUAGE_NUM_STR			2
#define VENTILATION_NUM_STR			2
#define PRESSURE_NUM_STR			33
#define BLUETOOTH_NUM_STR			2
#define INITIAL_PRESS_NUM_STR		2
#define CHANGE_UNIT_NUM_STR			2
#define EXH_TRIGGER_NUM_STR			9
#define DISP_OFF_TIMER_NUM_TR		5
#define NS_TYPE_NUM_STR				2
#define AUTOOFF_NUM_STR				2
#define FL_NUM_STR					2
#define CIRCUIT_TYPE_NUM_STR		2
#define INIT_PRESS_MIN				20
#define INIT_PRESS_MAX				40

#define SIZE_OF_CMH2O				55
#define SIZE_OF_HPA					35

const char* inhExhSliderStr[] = { "0", "1", "2", "3", "4", "5" };
const char* inhExhValueStr[] = { "L0", "L1", "L2", "L3", "L4", "L5" };
const char* rampSliderStr[] = {"0", "5", "10", "15", "20", "25", "30", "35", "40", "45"};
const char* delayRampValueStr[] = {"0", "5", "10", "15", "20", "25", "30", "35", "40", "45"};
const char* brightnessAdjustStr[] = {"30%", "40%", "50%", "60%", "70%", "80%", "90%", "100%"};
const char* languageSettingStr[] = {"Japanese", "English"};
const char* ventilationTypeStr[] = {"AutoCPAP", "CPAP"};
const char* pressureSliderStr[] = {"4", "4.5", "5", "5.5", "6", "6.5", "7", "7.5", "8", "8.5", "9", "9.5", "10", "10.5", "11", "11.5", "12",
		"12.5", "13", "13.5", "14", "14.5", "15", "15.5", "16", "16.5", "17", "17.5", "18", "18.5", "19", "19.5", "20"};
const char* initialPressStr[] = { "2cmH�O", "4cmH�O", "2 hPa", "4 hPa" };
const char* changeUnitStr[] = { "cmH�O", "hPa" };
const char* onOffStr[] = { "OFF", "ON" };
const char* displayOffTimerStr[] = { "1", "2", "3", "4", "5" };
const char* circuitTypeStr[] = { "QE", "Others" };
const char* modeStr[] = { "CPAP", "AutoCPAP" };	//mode string
const char* nsTypeStr[] = { "Type 1", "Type 2" };

//static const GUI_POINT rightArrow[] = {
//		{0, 0},	{10, 10}, {0, 20}, {0, 16},	{6, 10}, {0, 4},
//};
//define down arrow sign
//static const GUI_POINT downArrow[] = {
//		{0, 0},	{10, 10}, {20, 0},	{16, 0}, {10, 6}, {4, 0},
//};

//static const GUI_FONT* guiFont12[] = { &GUI_FontMeiryo12B_2bpp, &GUI_FontJPAPJPFont12B };	//font 12
//static const GUI_FONT* guiFont16[] = { &GUI_FontMeiryo16B_2bpp, &GUI_FontJPAPJPFont16B };	//font 16

SliderContent sliderStr[NUM_OF_SETTING_BUTTON] =
{
		{inhExhSliderStr, INH_EXH_NUM_STR, 0},
		{inhExhSliderStr, INH_EXH_NUM_STR, 0},
		{rampSliderStr, RAMP_TIME_NUM_STR, 0},
		{brightnessAdjustStr, BRIGHTNESS_NUM_STR, 0},
		{languageSettingStr, LANGUAGE_NUM_STR, 0},
		{ventilationTypeStr, VENTILATION_NUM_STR, 0},
		{pressureSliderStr, PRESSURE_NUM_STR, 0},
		{pressureSliderStr, PRESSURE_NUM_STR, 0},
		{pressureSliderStr, PRESSURE_NUM_STR, 0},
		{onOffStr, BLUETOOTH_NUM_STR, 0},
		{initialPressStr, INITIAL_PRESS_NUM_STR, 0},
		{changeUnitStr, CHANGE_UNIT_NUM_STR, 0},
		{displayOffTimerStr, DISP_OFF_TIMER_NUM_TR, 0},
		{nsTypeStr, NS_TYPE_NUM_STR, 0},
		{onOffStr, AUTOOFF_NUM_STR, 0},
		{onOffStr, FL_NUM_STR, 0},
		{circuitTypeStr, CIRCUIT_TYPE_NUM_STR, 0}
};

SettingBtnStruct buttonString[NUM_OF_SETTING_BUTTON] =
{
		{inhExhValueStr, strInhalationSupport, "0", eRelease},
		{inhExhValueStr, strExhalationSupport, "0", eRelease},
		{delayRampValueStr, strRampTime, "0", eRelease},
		{brightnessAdjustStr, strBrightness, "0%", eRelease},
		{languageSettingStr, strLanguge, "English", eRelease},
		{ventilationTypeStr, strVentilationMode, "AutoCPAP", eRelease},
		{pressureSliderStr, strTreatPressure, "4.5cmH2O", eRelease},
		{pressureSliderStr, strUpperLimit, "4.5cmH2O", eRelease},
		{pressureSliderStr, strLowerLimit, "4.5cmH2O", eRelease},
		{onOffStr, strBluetooth, "ON", eRelease},
		{initialPressStr, strInitialPressure, "2cmH2O", eRelease},
		{changeUnitStr, strChangeUnit, "cmH�O", eRelease},
		{displayOffTimerStr, strDisplayOffTimer, "1", eRelease},
		{nsTypeStr, strNsType, "Type 1", eRelease},
		{onOffStr, strAutoOff, "OFF", eRelease},
		{onOffStr, strFL, "OFF", eRelease},
		{circuitTypeStr, strCircuitType, "QE", eRelease }
};

int testSettingBtnExpandArea = 0;
int testSettingBtnDrawSlider = 0;
int testSettingBtnCustom = 0;
unsigned char testunitSettingBtnDispValue = 0;
int testSettingBtnManageDisp = 0;
int testSettingbtnLog = 0;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//static void SettingBtnCustom(unsigned char id);
//static void SettingBtnExpandArea(unsigned char id);
//static void SettingBtnDrawSlider(int pos,  GUI_RECT Rect);
//static void SettingBtnDispValue(unsigned char id,  GUI_RECT Rect);
//static void SettingBtnApply(unsigned char id);
//static int SettingBtnGetThumpPos(unsigned char id);
//static void SettingBtnManageDisp(unsigned char id, unsigned char numOfString, int pos,  GUI_RECT Rect);
static xQueueHandle deviceQueue;
static xQueueHandle motorQueue;
static xQueueHandle systemQueue;

//extern WM_HWIN maintenanceScreen;
//extern WM_HWIN operationScreen;
//extern WM_HWIN clinicScreen;

//const char* inhExhSliderStr[] = { "0", "1", "2", "3", "4", "5" };
//const char* inhExhValueStr[] = { "L0", "L1", "L2", "L3", "L4", "L5" };
//const char* rampSliderStr[] = {"0", "5", "10", "15", "20", "25", "30", "35", "40", "45"};
//const char* delayRampValueStr[] = {"0", "5", "10", "15", "20", "25", "30", "35", "40", "45"};
//const char* brightnessAdjustStr[] = {"30%", "40%", "50%", "60%", "70%", "80%", "90%", "100%"};
//const char* languageSettingStr[] = {"Japanese", "English"};
//const char* ventilationTypeStr[] = {"AutoCPAP", "CPAP"};
//const char* pressureSliderStr[] = {"4", "4.5", "5", "5.5", "6", "6.5", "7", "7.5", "8", "8.5", "9", "9.5", "10", "10.5", "11", "11.5", "12",
//		"12.5", "13", "13.5", "14", "14.5", "15", "15.5", "16", "16.5", "17", "17.5", "18", "18.5", "19", "19.5", "20"};
//const char* initialPressStr[] = { "2cmH�O", "4cmH�O", "2 hPa", "4 hPa" };
//const char* changeUnitStr[] = { "cmH�O", "hPa" };
//const char* onOffStr[] = { "OFF", "ON" };
//const char* displayOffTimerStr[] = { "1", "2", "3", "4", "5" };
//const char* circuitTypeStr[] = { "QE", "Others" };
//static const char* modeStr[] = { "CPAP", "AutoCPAP" };	//mode string
//static const char* nsTypeStr[] = { "Type 1", "Type 2" };
//
////static const GUI_POINT rightArrow[] = {
////		{0, 0},	{10, 10}, {0, 20}, {0, 16},	{6, 10}, {0, 4},
////};
////define down arrow sign
////static const GUI_POINT downArrow[] = {
////		{0, 0},	{10, 10}, {20, 0},	{16, 0}, {10, 6}, {4, 0},
////};
//
////static const GUI_FONT* guiFont12[] = { &GUI_FontMeiryo12B_2bpp, &GUI_FontJPAPJPFont12B };	//font 12
////static const GUI_FONT* guiFont16[] = { &GUI_FontMeiryo16B_2bpp, &GUI_FontJPAPJPFont16B };	//font 16
//
//SliderContent sliderStr[NUM_OF_SETTING_BUTTON] =
//{
//		{inhExhSliderStr, INH_EXH_NUM_STR, 0},
//		{inhExhSliderStr, INH_EXH_NUM_STR, 0},
//		{rampSliderStr, RAMP_TIME_NUM_STR, 0},
//		{brightnessAdjustStr, BRIGHTNESS_NUM_STR, 0},
//		{languageSettingStr, LANGUAGE_NUM_STR, 0},
//		{ventilationTypeStr, VENTILATION_NUM_STR, 0},
//		{pressureSliderStr, PRESSURE_NUM_STR, 0},
//		{pressureSliderStr, PRESSURE_NUM_STR, 0},
//		{pressureSliderStr, PRESSURE_NUM_STR, 0},
//		{onOffStr, BLUETOOTH_NUM_STR, 0},
//		{initialPressStr, INITIAL_PRESS_NUM_STR, 0},
//		{changeUnitStr, CHANGE_UNIT_NUM_STR, 0},
//		{displayOffTimerStr, DISP_OFF_TIMER_NUM_TR, 0},
//		{nsTypeStr, NS_TYPE_NUM_STR, 0},
//		{onOffStr, AUTOOFF_NUM_STR, 0},
//		{onOffStr, FL_NUM_STR, 0},
//		{circuitTypeStr, CIRCUIT_TYPE_NUM_STR, 0}
//};
//
//SettingBtnStruct buttonString[NUM_OF_SETTING_BUTTON] =
//{
//		{inhExhValueStr, strInhalationSupport, "0", eRelease},
//		{inhExhValueStr, strExhalationSupport, "0", eRelease},
//		{delayRampValueStr, strRampTime, "0", eRelease},
//		{brightnessAdjustStr, strBrightness, "0%", eRelease},
//		{languageSettingStr, strLanguge, "English", eRelease},
//		{ventilationTypeStr, strVentilationMode, "AutoCPAP", eRelease},
//		{pressureSliderStr, strTreatPressure, "4.5cmH2O", eRelease},
//		{pressureSliderStr, strUpperLimit, "4.5cmH2O", eRelease},
//		{pressureSliderStr, strLowerLimit, "4.5cmH2O", eRelease},
//		{onOffStr, strBluetooth, "ON", eRelease},
//		{initialPressStr, strInitialPressure, "2cmH2O", eRelease},
//		{changeUnitStr, strChangeUnit, "cmH�O", eRelease},
//		{displayOffTimerStr, strDisplayOffTimer, "1", eRelease},
//		{nsTypeStr, strNsType, "Type 1", eRelease},
//		{onOffStr, strAutoOff, "OFF", eRelease},
//		{onOffStr, strFL, "OFF", eRelease},
//		{circuitTypeStr, strCircuitType, "QE", eRelease }
//};

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingBtnExpandArea(unsigned char id)
//
//    Processing:
//		The function draws slider bar
//
//    Input Parameters:
//		int id
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingBtnExpandArea(unsigned char id)
{
	GUI_RECT Rect;
	//	WM_GetClientRect(&Rect);
	unsigned char numOfString = sliderStr[id].numOfValue;				//get num of string on slider bar
	int pos = sliderStr[id].position*(Rect.x1-20)/(numOfString - 1) + SLIDER_X;
	//draw slider background
	//	GUI_SetColor(SETTING_EXPAND_BK_COLOR);
	if((id != eInhSupBtnId) &&(id != eExhSupBtnId)&&(id != eDryingModeBtnId))
	{
		testSettingBtnExpandArea = id;
		//		GUI_FillRect(Rect.x0, Rect.y0 + NORMAL_BUTTON_HEIGHT, Rect.x1, Rect.y0 + EXPAND_BUTTON_HEIGHT);
	}
	//set font
	//	GUI_SetFont(&GUI_FontJPAPJPFont12B);
	if((id == eInhSupBtnId) || (id == eExhSupBtnId) || (id == eDryingModeBtnId))
	{
		testSettingBtnExpandArea = id;
		//		GUI_SetColor(COLOR_ULTRA_LIGHT_BLUE);
	}
	else
	{
		//		GUI_SetColor(GUI_WHITE);
	}

	//	GUI_SetTextAlign(GUI_TA_CENTER);
	//handle display on setting button
	SettingBtnManageDisp(id, numOfString, pos, Rect);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingBtnDrawSlider()
//
//    Processing:
//		The function draws slider bar for setting button
//
//    Input Parameters:
//		BUTTON_Handle hObj
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingBtnDrawSlider(int pos,  GUI_RECT Rect)
{
	//	GUI_SetColor(COLOR_LIGHT_ORANGE);
	//	GUI_AA_FillRoundedRect(SLIDER_X, SLIDER_Y, pos, SLIDER_Y + SLIDER_HEIGHT, 2);
	//	GUI_SetColor(COLOR_H_SLIDER);
	//	GUI_AA_FillRoundedRect(pos, SLIDER_Y, SLIDER_X + (Rect.x1-20), SLIDER_Y + SLIDER_HEIGHT, 2);
	//	//draw thump
	//	GUI_SetColor(GUI_WHITE);
	//	GUI_AA_FillCircle(pos, (33 + 64)/2 - 9, 5);
	//	GUI_SetColor(COLOR_LIGHT_ORANGE);
	//	GUI_DrawCircle(pos, (33 + 64)/2 - 9, 5);

	testSettingBtnDrawSlider = pos;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingBtnCustom(unsigned char id)
//
//    Processing:
//		The function is to custom setting button
//
//    Input Parameters:
//		BUTTON_Handle hObj
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingBtnCustom(unsigned char id)
{
	GUI_RECT Rect;
	//	WM_GetClientRect(&Rect);	//get size: x0, x1, y0, y1
	const char* nameStr = buttonString[id].nameStr[language];	//get name
	unsigned char status = buttonString[id].status;				//get status

	//	GUI_AA_SetFactor(6);
	//	GUI_SetPenShape(GUI_PS_ROUND);
	//	GUI_SetTextMode(GUI_TM_TRANS);

	if((id != eInhSupBtnId) && (id != eExhSupBtnId) && (id != eDryingModeBtnId))
	{
		testSettingBtnCustom = 10;
		//		GUI_DrawGradientV(Rect.x0, Rect.y0, Rect.x1, Rect.y0+NORMAL_BUTTON_HEIGHT, SETTING_BAR_TOP_COLOR, SETTING_BAR_BOTTOM_COLOR);	//draw background
	}

	switch(status) {
	case eRelease:
		if((id == eInhSupBtnId) || (id == eExhSupBtnId) || (id == eDryingModeBtnId))
		{
			testSettingBtnCustom = 11;
			//			GUI_SetColor(COLOR_ULTRA_LIGHT_BLUE);            //set color
		}
		else
		{
			testSettingBtnCustom = 12;
			//			GUI_SetColor(GUI_WHITE);														//set color
		}
		//		GUI_FillPolygon(&rightArrow[0], ARROW_NUM_OF_POINTS, RIGHT_ARROW_X, RIGHT_ARROW_Y);	//draw arrow sign
		//		GUI_FillPolygon(&rightArrow[0], ARROW_NUM_OF_POINTS, Rect.x1-20, RIGHT_ARROW_Y);	//draw arrow sign
		//		GUI_SetTextAlign(GUI_TA_LEFT);														//set align for text
		//		GUI_SetFont(guiFont16[language]);													//set font
		if((id == eDryingModeBtnId)&&(language == eJapanese))
		{
			testSettingBtnCustom = 13;
			//			GUI_SetFont(&GUI_FontJapanese16Add2);	//set font
		}
		//		GUI_DispStringAt(nameStr, SLIDER_X, 5);										//display name string
		if((id == eInhSupBtnId) || (id == eExhSupBtnId) || (id == eDryingModeBtnId))
		{
			testSettingBtnCustom = 14;
			//			GUI_SetColor(COLOR_ULTRA_LIGHT_BLUEHT_BLUE);														//set color
		}
		else
		{
			testSettingBtnCustom = 15;
			//			GUI_SetColor(GUI_WHITE);														//set color
		}
		break;
	case ePoint:
		//		GUI_SetColor(COLOR_LIGHT_ORANGE);														//set color
		//		GUI_FillPolygon(&rightArrow[0], ARROW_NUM_OF_POINTS, Rect.x1-20, RIGHT_ARROW_Y);	//draw arrow sign
		//		GUI_SetTextAlign(GUI_TA_LEFT);														//set align
		//		GUI_SetFont(guiFont16[language]);													//set font
		if((id == eDryingModeBtnId)&&(language == eJapanese))
		{
			testSettingBtnCustom = 16;
			//			GUI_SetFont(&GUI_FontJapanese16Add2);	//set font
		}
		//		GUI_DispStringAt(nameStr, SLIDER_X, 5);										//display name
		//		GUI_SetColor(COLOR_LIGHT_ORANGE);														//set color
		break;
	case eEnter:
		//		GUI_SetColor(COLOR_LIGHT_ORANGE);														//set color
		//		GUI_FillPolygon(&downArrow[0], ARROW_NUM_OF_POINTS, Rect.x1-25, DOWN_ARROW_Y);	//draw arrow sign
		//		GUI_SetTextAlign(GUI_TA_LEFT);														//set align
		//		GUI_SetFont(guiFont16[language]);													//set font
		if((id == eDryingModeBtnId)&&(language == eJapanese))
		{
			testSettingBtnCustom = 17;
			//			GUI_SetFont(&GUI_FontJapanese16Add2);	//set font
		}
		//		GUI_DispStringAt(nameStr, SLIDER_X, 5);										//display name
		SettingBtnExpandArea(id);																	//draw slider area
		//		GUI_SetColor(COLOR_LIGHT_ORANGE);														//set color
		break;
	default:
		break;
	}

	SettingBtnDispValue(id, Rect);		//display setting value
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingBtnDispValue(unsigned char id)
//
//    Processing:
//		The function is to display value of setting button
//
//    Input Parameters:
//		BUTTON_Handle hObj
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingBtnDispValue(unsigned char id, GUI_RECT Rect)
{
	const char* valueStr = buttonString[id].valueStr;				//get value
	unsigned char unit = SettingGetMocks(ePressUnitSettingId);//SettingGet(ePressUnitSettingId);			//get unit: cmH2O or hPa
	if(unit > 1)
		unit = 1;
	testunitSettingBtnDispValue = unit;
	unsigned char bluetooth = SettingGetMocks(eBluetoothSettingId);//SettingGet(eBluetoothSettingId);		//get bluetooth
	if(bluetooth > 1)
		bluetooth = 1;
	unsigned char mode = SettingGetMocks(eVentModeSettingId);//SettingGet(eVentModeSettingId);			//get mode
	if(mode > 1)
		mode = 1;
	unsigned char autoOffStatus = SettingGetMocks(eAutoOFFSettingId);//SettingGet(eAutoOFFSettingId);
	if(autoOffStatus > 1)
		autoOffStatus = 1;
	unsigned char flStatus = SettingGetMocks(eFLSettingId);//SettingGet(eFLSettingId);
	if(flStatus > 1)
		flStatus = 1;
	unsigned char nsType = SettingGetMocks(eNsTypeSettingId);//SettingGet(eNsTypeSettingId);
	if(nsType > 1)
		nsType = 1;
	unsigned char circuitType = SettingGetMocks(eCircuitTypeSettingId);//SettingGet(eCircuitTypeSettingId);
	if(circuitType > 1)
		circuitType = 1;

	unsigned char sizeOfUnit[] = { SIZE_OF_CMH2O, SIZE_OF_HPA };	//get length of unit
	unsigned char initPress = 0;
	switch (id) {
	case eSettingPressBtnId:
	case eUpperPressBtnId:
	case eLowerPressBtnId:
		//		GUI_SetTextAlign(GUI_TA_RIGHT);										//set align for value text
		//		GUI_SetFont(&GUI_FontJPAPJPFont16B);								//set font for value text
		//		GUI_DispStringAt(valueStr, VALUE_LABEL_X - sizeOfUnit[unit], 5);	//display value
		//		GUI_SetTextAlign(GUI_TA_RIGHT);										//set align for unit text
		//		GUI_SetFont(&GUI_FontJPAPJPFont14B);								//set font for unit text
		//		GUI_DispStringAt(unitStr[unit], VALUE_LABEL_X, 7);					//display unit
		break;
	case eRampTimeBtnId:
	case eDisplayOffTimerBtnId:
		//		GUI_SetTextAlign(GUI_TA_RIGHT);							//set align for unit text
		//		GUI_SetFont(guiFont16[language]);						//set font
		//		GUI_DispStringAt(strMin[language], VALUE_LABEL_X, 5);	//display unit (min)
		//		GUI_SetTextAlign(GUI_TA_RIGHT);							//set align for value
		if(language == eEnglish)
		{
			//			GUI_DispStringAt(valueStr, VALUE_LABEL_X - 35, 5);		//display value
		}
		else
		{
			//			GUI_DispStringAt(valueStr, VALUE_LABEL_X - 25, 5);
		}
		break;
	case eLanguageSettingBtnId:
		//		GUI_SetTextAlign(GUI_TA_RIGHT);		//set align
		//		GUI_SetFont(guiFont16[language]);	//set font
		if(language == eEnglish)
		{
			//			GUI_DispStringAt(strEnglish[eEnglish], VALUE_LABEL_X, 5);
		}
		else
		{
			//			GUI_DispStringAt(strJapanese[eJapanese], VALUE_LABEL_X, 5);
		}
		break;
	case eDryingModeBtnId:
		//		GUI_SetTextAlign(GUI_TA_RIGHT);		//set align
		if(circuitType == eQE)
		{
			//			GUI_SetFont(guiFont16[eEnglish]);	//set font
			//			GUI_DispStringAt(strQE[eEnglish], Rect.x1-30, 5);
		}
		else
		{
			//			GUI_SetFont(&GUI_FontOthersFont16);
			//			GUI_DispStringAt(strOthers[language], Rect.x1-30, 5);
		}
		break;
	case eChangeUnitBtnId:
		//		GUI_SetTextAlign(GUI_TA_RIGHT);						//set align
		//		GUI_SetFont(&GUI_FontJPAPJPFont16B);				//set font
		//		GUI_DispStringAt(unitStr[unit], VALUE_LABEL_X, 5);	//display unit
		break;
	case eBluetoothSettingBtnId:
		//		GUI_SetTextAlign(GUI_TA_RIGHT);						//set align
		//		GUI_SetFont(&GUI_FontJPAPJPFont16B);							//set font
		//		GUI_DispStringAt(onOffStr[bluetooth], VALUE_LABEL_X, 5);	//display bluetooth
		break;
	case eVentilationTypeBtnId:
		//		GUI_SetFont(&GUI_FontJPAPJPFont16B);				//set font
		//		GUI_SetTextAlign(GUI_TA_RIGHT);						//set align
		//		GUI_DispStringAt(modeStr[mode], VALUE_LABEL_X, 5);	//display mode
		break;
	case eInitialPressBtnId:
		//		GUI_SetFont(&GUI_FontJPAPJPFont16B);				//set font
		//		GUI_SetTextAlign(GUI_TA_RIGHT);						//set align
		//get initial pressure
		initPress = SettingGetMocks(eDelayPressSettingId);//SettingGet(eDelayPressSettingId);
		if(initPress < INIT_PRESS_MIN)
			initPress = INIT_PRESS_MIN;
		else if(initPress > INIT_PRESS_MAX)
			initPress = INIT_PRESS_MAX;

		if(SettingGetMocks(ePressUnitSettingId) == ecmH2O)//(SettingGet(ePressUnitSettingId) == ecmH2O)
		{
			//			GUI_DispStringAt(initialPressStr[initPress/INIT_PRESS_MIN - 1], VALUE_LABEL_X, 5);
		}
		else if(SettingGetMocks(ePressUnitSettingId) == ehPa)//(SettingGet(ePressUnitSettingId) == ehPa)
		{
			//			GUI_DispStringAt(initialPressStr[initPress/INIT_PRESS_MIN + 1], VALUE_LABEL_X, 5);
		}
		break;
	case eNaturalSupportTypeBtnId:
		//		GUI_SetFont(guiFont16[language]);
		//		GUI_SetTextAlign(GUI_TA_RIGHT);
		if(nsType == eEType)
		{
			//			GUI_DispStringAt(strType1[language], VALUE_LABEL_X, 5);
		}
		else
		{
			//			GUI_DispStringAt(strType2[language], VALUE_LABEL_X, 5);
		}
		break;
	case eAutoOffBtnId:
		//		GUI_SetFont(guiFont16[language]);
		//		GUI_SetTextAlign(GUI_TA_RIGHT);
		//		GUI_DispStringAt(onOffStr[autoOffStatus], VALUE_LABEL_X, 5);
		break;
	case eFLBtnId:
		//		GUI_SetFont(guiFont16[language]);
		//		GUI_SetTextAlign(GUI_TA_RIGHT);
		//		GUI_DispStringAt(onOffStr[flStatus], VALUE_LABEL_X, 5);
		break;
	default:
		//		GUI_SetFont(&GUI_FontJPAPJPFont16B);			//set font
		//		GUI_SetTextAlign(GUI_TA_RIGHT);					//set align
		//		//		GUI_DispStringAt(valueStr, VALUE_LABEL_X, 5);	//display value
		//		GUI_DispStringAt(valueStr, Rect.x1-30, 5);	//display value
		break;
	}
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingBtnCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		The callback function of setting button
//
//    Input Parameters:
//		WM_MESSAGE * pMsg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingBtnCallback(WM_MESSAGE * pMsg) {
	switch (pMsg->MsgId) {
	case WM_PAINT:
		SettingBtnCustom(WM_GetId(nullptr));//(WM_GetId(pMsg->hWin));
		break;
	default:
		//		BUTTON_Callback(pMsg); // The original callback
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingBtnSetStatus(BUTTON_Handle hObj, E_ButtonStatus stt)
//
//    Processing:
//		The function is to set status for setting button
//
//    Input Parameters:
//		BUTTON_Handle hObj
//		E_ButtonStatus stt
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingBtnSetStatus(void* hObj, E_ButtonStatus stt)//(BUTTON_Handle hObj, E_ButtonStatus stt)
{
	buttonString[WM_GetId(hObj)].status = stt;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingBtnGetThumpPos(BUTTON_Handle hObj)
//
//    Processing:
//		The function is to get position of slider thump
//
//    Input Parameters:
//		BUTTON_Handle hObj
//
//    Output Parameters:
//      slider position
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
int SettingBtnGetThumpPos(unsigned char id)
{
	return sliderStr[id].position;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SetValue(BUTTON_Handle hObj, int pos)
//
//    Processing:
//		The function is to set position for slider thump
//
//    Input Parameters:
//		BUTTON_Handle hObj
//		int position
//
//    Output Parameters:
//      slider position
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingBtnSetValue(void* hObj, int pos)//(BUTTON_Handle hObj, int pos)
{
	sliderStr[WM_GetId(hObj)].position = pos;
	buttonString[WM_GetId(hObj)].valueStr = (char*)buttonString[WM_GetId(hObj)].buttonArrayPtr[pos];
	//	WM_Paint(hObj);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingBtnIncThumpPos(BUTTON_Handle hObj)
//
//    Processing:
//		The function increases the thump's position
//
//    Input Parameters:
//		BUTTON_Handle hObj
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingBtnIncThumpPos(void* hObj)//(BUTTON_Handle hObj)
{
	//get id
	int id = WM_GetId(hObj);
	if(buttonString[id].status != eEnter)
		return;

	//increase position of thump
	SettingBtnSetValue(hObj, SettingBtnGetThumpPos(id) + 1);

	switch (id) {
	case eLowerPressBtnId:
	{
		if(SettingBtnGetThumpPos(id) > SettingBtnGetThumpPos(eUpperPressBtnId))
			SettingBtnSetValue(hObj, 0);
		else if(SettingBtnGetThumpPos(id) < 0)
			SettingBtnSetValue(hObj, SettingBtnGetThumpPos(eUpperPressBtnId));
	}
	break;
	case eUpperPressBtnId:
	{
		if(SettingBtnGetThumpPos(id) >= PRESSURE_NUM_STR)
			SettingBtnSetValue(hObj, SettingBtnGetThumpPos(eLowerPressBtnId));
		else if(SettingBtnGetThumpPos(id) < SettingBtnGetThumpPos(eLowerPressBtnId))
			SettingBtnSetValue(hObj, PRESSURE_NUM_STR - 1);
	}
	break;
	case eBluetoothSettingBtnId:
	{
		if(SettingBtnGetThumpPos(id) > (sliderStr[id].numOfValue-1))
			SettingBtnSetValue(hObj, 0);
		else if(SettingBtnGetThumpPos(id) < 0)
			SettingBtnSetValue(hObj, (sliderStr[id].numOfValue-1));

		if(SettingBtnGetThumpPos(eBluetoothSettingBtnId) == eOn)
		{
			//set event to wake up Bluetooth module
			DeviceEventStruct event;
			event.id = eDeviceBleStatusChangeId;
			event.data = eDeviceBleEnableId;
			//send event to queue
			if(xQueueSendToBack(deviceQueue, &event, 2) != pdPASS)
			{
				//reset device queue
				xQueueReset(deviceQueue);
			}
			//			DeviceTaskSendEvent(eDeviceBleStatusChangeId, eDeviceBleEnableId);
			//show BLE icon
			GuiTaskSendEvent(eGuiShowBleIconId, 0);
		}
		else
		{
			//set event to wake up Bluetooth module
			DeviceEventStruct event;
			event.id = eDeviceBleStatusChangeId;
			event.data = eDeviceBleDisableId;
			//send event to queue
			if(xQueueSendToBack(deviceQueue, &event, 2) != pdPASS)
			{
				//reset device queue
				xQueueReset(deviceQueue);
			}
			//DeviceTaskSendEvent(eDeviceBleStatusChangeId, eDeviceBleDisableId);
			//hide BLE icon
			GuiTaskSendEvent(eGuiHideBleIconId, 0);
		}
	}
	break;
	default:
	{
		if(SettingBtnGetThumpPos(id) > (sliderStr[id].numOfValue-1))
			SettingBtnSetValue(hObj, 0);
		else if(SettingBtnGetThumpPos(id) < 0)
			SettingBtnSetValue(hObj, (sliderStr[id].numOfValue-1));
	}
	break;
	}
	SettingBtnApply(id);		//apply setting
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingBtnDecThumpPos(BUTTON_Handle hObj)
//
//    Processing:
//		The function decreases the thump's position
//
//    Input Parameters:
//		BUTTON_Handle hObj
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingBtnDecThumpPos(void* hObj)//(BUTTON_Handle hObj)
{
	//get id
	int id = WM_GetId(hObj);

	if(buttonString[id].status != eEnter)
		return;
	//decrease position of thump
	SettingBtnSetValue(hObj, SettingBtnGetThumpPos(id) - 1);
	switch (id) {
	case eLowerPressBtnId:
	{
		if(SettingBtnGetThumpPos(id) < 0)
			SettingBtnSetValue(hObj, SettingBtnGetThumpPos(eUpperPressBtnId));
		else if(SettingBtnGetThumpPos(id) > SettingBtnGetThumpPos(eUpperPressBtnId))
			SettingBtnSetValue(hObj, 0);
	}
	break;
	case eUpperPressBtnId:
	{
		if(SettingBtnGetThumpPos(id) < SettingBtnGetThumpPos(eLowerPressBtnId))
			SettingBtnSetValue(hObj, PRESSURE_NUM_STR - 1);
		else if(SettingBtnGetThumpPos(id) >= PRESSURE_NUM_STR)
			SettingBtnSetValue(hObj, SettingBtnGetThumpPos(eLowerPressBtnId));
	}
	break;
	case eBluetoothSettingBtnId:
	{
		//handle min max
		if(SettingBtnGetThumpPos(id) < 0)
			SettingBtnSetValue(hObj, (sliderStr[id].numOfValue-1));
		else if(SettingBtnGetThumpPos(id) > (sliderStr[id].numOfValue-1))
			SettingBtnSetValue(hObj, 0);

		if(SettingBtnGetThumpPos(eBluetoothSettingBtnId) == eOn)
		{
			//set event to wake up Bluetooth module
			DeviceEventStruct event;
			event.id = eDeviceBleStatusChangeId;
			event.data = eDeviceBleEnableId;
			//send event to queue
			if(xQueueSendToBack(deviceQueue, &event, 2) != pdPASS)
			{
				//reset device queue
				xQueueReset(deviceQueue);
			}
			//DeviceTaskSendEvent(eDeviceBleStatusChangeId, eDeviceBleEnableId);
			//show BLE icon
			GuiTaskSendEvent(eGuiShowBleIconId, 0);
		}
		else
		{
			//send event to sleep BLE module
			DeviceEventStruct event;
			event.id = eDeviceBleStatusChangeId;
			event.data = eDeviceBleDisableId;
			//send event to queue
			if(xQueueSendToBack(deviceQueue, &event, 2) != pdPASS)
			{
				//reset device queue
				xQueueReset(deviceQueue);
			}
			//DeviceTaskSendEvent(eDeviceBleStatusChangeId, eDeviceBleDisableId);
			//hide ble icon
			GuiTaskSendEvent(eGuiHideBleIconId, 0);
		}
	}
	break;
	default:
	{
		if(SettingBtnGetThumpPos(id) < 0)
			SettingBtnSetValue(hObj, (sliderStr[id].numOfValue-1));
		else if(SettingBtnGetThumpPos(id) > (sliderStr[id].numOfValue-1))
			SettingBtnSetValue(hObj, 0);
	}
	break;
	}
	//apply setting
	SettingBtnApply(id);
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingBtnApply(unsigned char id)
//
//    Processing:
//		The function applies setting
//
//    Input Parameters:
//		int id
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingBtnApply(unsigned char id)
{
	unsigned char sendEvent = 0;//Add test
	//	unsigned char event = 0;
	//set setting
	switch (id) {
	case eDryingModeBtnId:
		SettingSetMocks(eCircuitTypeSettingId, SettingBtnGetThumpPos(id));//SettingSet(eCircuitTypeSettingId, SettingBtnGetThumpPos(id));
		break;
	case eInhSupBtnId:
		SettingSetMocks(eInhPressSupportSettingId, SettingBtnGetThumpPos(id));//SettingSet(eInhPressSupportSettingId, SettingBtnGetThumpPos(id));
		sendEvent = eMotorChangeInhId;
		if(xQueueSendToBack(motorQueue, &sendEvent, 2) != pdPASS)
		{
		}
		//MotorTaskSendEvent(eMotorChangeInhId);
		//update setting on GUI
		GuiTaskSendEvent(eGuiOperUpdateSettingId, 0);
		break;
	case eExhSupBtnId:
		SettingSetMocks(eExhPressSupportSettingId, SettingBtnGetThumpPos(id));//SettingSet(eExhPressSupportSettingId, SettingBtnGetThumpPos(id));
		//send event change phase to motor task
		sendEvent = eMotorChangeExhId;
		if(xQueueSendToBack(motorQueue, &sendEvent, 2) != pdPASS)
		{
		}
		//MotorTaskSendEvent(eMotorChangeExhId);
		//update setting on GUI
		GuiTaskSendEvent(eGuiOperUpdateSettingId, 0);
		break;
	case eRampTimeBtnId:
		SettingSetMocks(eRampTimeSettingId, SettingBtnGetThumpPos(id)*5);//SettingSet(eRampTimeSettingId, SettingBtnGetThumpPos(id)*5);
		break;
	case eBrightnessAdjustBtnId:
		SettingSetMocks(eBrightnessSettingId, PWM_LCDBL_MIN + PWM_LCDBL_STEP*SettingBtnGetThumpPos(id));//SettingSet(eBrightnessSettingId, PWM_LCDBL_MIN + PWM_LCDBL_STEP*SettingBtnGetThumpPos(id));
		PWMSetDutyMocks(ePWMLCDBLId, SettingGetMocks(eBrightnessSettingId));//PWMSetDuty(ePWMLCDBLId, SettingGet(eBrightnessSettingId));
		break;
	case eLanguageSettingBtnId:
		SettingSetMocks(eLanguageSettingId, SettingBtnGetThumpPos(id));//SettingSet(eLanguageSettingId, SettingBtnGetThumpPos(id));
		language = SettingGetMocks(eLanguageSettingId);//SettingGet(eLanguageSettingId);
		if(language > 1)
			language = 1;
		//send event to repaint maintenance screen
		GuiTaskSendEvent(eGuiFactoryRepaint, 0);
		break;
	case eVentilationTypeBtnId:
		SettingSetMocks(eVentModeSettingId, SettingBtnGetThumpPos(id));//SettingSet(eVentModeSettingId, SettingBtnGetThumpPos(id));
		//send signal to change mode
		GuiTaskSendEvent(eGuiClinicChangeVentModeId, 0);
		break;
	case eSettingPressBtnId:
		SettingSetMocks(eOperPressSettingId, SettingBtnGetThumpPos(id)*PRESSURE_SETTING_STEP + PRESSURE_SETTING_MIN*PRESSURE_SCALE);//SettingSet(eOperPressSettingId, SettingBtnGetThumpPos(id)*PRESSURE_SETTING_STEP + PRESSURE_SETTING_MIN*PRESSURE_SCALE);
		break;
	case eUpperPressBtnId:
		SettingSetMocks(eAutoUpperPressSettingId, SettingBtnGetThumpPos(id)*PRESSURE_SETTING_STEP + PRESSURE_SETTING_MIN*PRESSURE_SCALE);//SettingSet(eAutoUpperPressSettingId, SettingBtnGetThumpPos(id)*PRESSURE_SETTING_STEP + PRESSURE_SETTING_MIN*PRESSURE_SCALE);
		break;
	case eLowerPressBtnId:
		SettingSetMocks(eAutoLowerPressSettingId, SettingBtnGetThumpPos(id)*PRESSURE_SETTING_STEP + PRESSURE_SETTING_MIN*PRESSURE_SCALE);
		break;
	case eInitialPressBtnId:
		SettingSetMocks(eDelayPressSettingId, (SettingBtnGetThumpPos(id) + 1)*INIT_PRESS_MIN);
		break;
	case eChangeUnitBtnId:
		SettingSetMocks(ePressUnitSettingId, SettingBtnGetThumpPos(id));
		break;
	case eBluetoothSettingBtnId:
		SettingSetMocks(eBluetoothSettingId, SettingBtnGetThumpPos(id));
		break;
	case eDisplayOffTimerBtnId:
		SettingSetMocks(eSleepTimerSettingId, SettingBtnGetThumpPos(id));
		break;
	case eNaturalSupportTypeBtnId: //Trigger
		SettingSetMocks(eNsTypeSettingId, SettingBtnGetThumpPos(id));
		break;
	case eAutoOffBtnId:
		SettingSetMocks(eAutoOFFSettingId, SettingBtnGetThumpPos(id));
		break;
	case eFLBtnId:
		SettingSetMocks(eFLSettingId, SettingBtnGetThumpPos(id));
		break;
	default:
		break;
	}
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SettingBtnManageDisp()
//
//    Processing:
//		The function manages all displays
//
//    Input Parameters:
//
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SettingBtnManageDisp(unsigned char id, unsigned char numOfString, int pos,  GUI_RECT Rect)
{
	int i;
	//display string of slider bar
	switch (id) {
	case eBrightnessAdjustBtnId:
		//		GUI_SetFont(guiFont12[language]);
		//		GUI_SetTextAlign(GUI_TA_LEFT);
		//		GUI_DispStringAt(strDark[language], SLIDER_X, 44);
		//		GUI_SetTextAlign(GUI_TA_RIGHT);
		//		GUI_DispStringAt(strBright[language], SLIDER_X + (Rect.x1-20), 44);
		//draw slider bar
		SettingBtnDrawSlider(pos, Rect);
		break;
	case eLanguageSettingBtnId:
		//		GUI_SetColor(COLOR_ULTRA_LIGHT_BLUE);
		if(language == eJapanese)
		{
			testSettingBtnManageDisp = 11;
			//			GUI_FillRoundedRect(45, 37, 140, 60, 3);
		}
		else
		{
			testSettingBtnManageDisp = 12;
			//			GUI_FillRoundedRect(180, 37, 255, 60, 3);
		}

		//		GUI_SetColor(GUI_WHITE);
		//		GUI_SetTextAlign(GUI_TA_CENTER);
		//		GUI_SetFont(guiFont16[0]);
		//		GUI_DispStringAt(strJapanese[0], 92, 35);
		//		GUI_SetFont(guiFont16[1]);
		//		GUI_SetTextAlign(GUI_TA_CENTER);
		//		GUI_DispStringAt(strEnglish[1], 217, 35);
		break;
	case eNaturalSupportTypeBtnId:
		//		GUI_SetColor(COLOR_ULTRA_LIGHT_BLUE);

		if(SettingBtnGetThumpPos(id) == eEType)
		{
			testSettingBtnManageDisp = 13;
			//			GUI_FillRoundedRect(40, 37, 140, 60, 3);
		}
		else
		{
			testSettingBtnManageDisp = 14;
			//			GUI_FillRoundedRect(160, 37, 260, 60, 3);
		}
		//		GUI_SetFont(guiFont16[language]);
		//		GUI_SetColor(GUI_WHITE);
		//		GUI_SetTextAlign(GUI_TA_CENTER);
		//		GUI_DispStringAt(strType1[language], 90, 35);
		//		GUI_SetTextAlign(GUI_TA_CENTER);
		//		GUI_DispStringAt(strType2[language], 210, 35);
		break;
	case eVentilationTypeBtnId:
		//		GUI_SetColor(COLOR_ULTRA_LIGHT_BLUE);
		//		GUI_SetFont(&GUI_FontJPAPJPFont16B);
		if(SettingBtnGetThumpPos(id) == eCpapMode)
		{
			testSettingBtnManageDisp = 15;
			//			GUI_FillRoundedRect(45, 37, 105, 60, 3);
		}
		else
		{
			testSettingBtnManageDisp = 16;
			//			GUI_FillRoundedRect(157, 37, 255, 60, 3);
		}
		//		GUI_SetColor(GUI_WHITE);
		//		GUI_SetTextAlign(GUI_TA_LEFT);
		//		GUI_DispStringAt(modeStr[0], 50, 35);
		//		GUI_SetTextAlign(GUI_TA_RIGHT);
		//		GUI_DispStringAt(modeStr[1], 250, 35);
		break;
	case eChangeUnitBtnId:
		//		GUI_SetFont(&GUI_FontJPAPJPFont16B);
		//		GUI_SetColor(COLOR_ULTRA_LIGHT_BLUE);
		if(SettingBtnGetThumpPos(id) == ecmH2O)
		{
			testSettingBtnManageDisp = 17;
			//			GUI_FillRoundedRect(45, 37, 120, 60, 3);
		}
		else
		{
			testSettingBtnManageDisp = 18;
			//			GUI_FillRoundedRect(210, 37, 255, 60, 3);
		}

		//		GUI_SetColor(GUI_WHITE);
		//		GUI_SetTextAlign(GUI_TA_LEFT);
		//		GUI_DispStringAt(unitStr[0], 50, 35);
		//		GUI_SetTextAlign(GUI_TA_RIGHT);
		//		GUI_DispStringAt(unitStr[1], 250, 35);
		break;
	case eBluetoothSettingBtnId:
		//		GUI_SetFont(&GUI_FontJPAPJPFont16B);
		//		GUI_SetColor(COLOR_ULTRA_LIGHT_BLUE);
		if(SettingBtnGetThumpPos(id) == eOff)
		{
			testSettingBtnManageDisp = 19;
			//			GUI_FillRoundedRect(45, 37, 90, 60, 3);
		}
		else
		{
			testSettingBtnManageDisp = 20;
			//			GUI_FillRoundedRect(215, 37, 255, 60, 3);
		}
		//		GUI_SetColor(GUI_WHITE);
		//		GUI_SetTextAlign(GUI_TA_LEFT);
		//		GUI_DispStringAt(onOffStr[0], 50, 35);
		//		GUI_SetTextAlign(GUI_TA_RIGHT);
		//		GUI_DispStringAt(onOffStr[1], 250, 35);
		break;
	case eDryingModeBtnId:
		//		GUI_SetFont(&GUI_FontJPAPJPFont16B);
		//		GUI_SetColor(COLOR_ULTRA_LIGHT_BLUE);
		if(SettingBtnGetThumpPos(id) == eQE)
		{
			testSettingBtnManageDisp = 21;
			//			GUI_FillRoundedRect(45, 37, 80, 60, 3);
		}
		else
		{
			testSettingBtnManageDisp = 22;
			//			GUI_FillRoundedRect(155, 37, 220, 60, 3);
		}

		//		GUI_SetColor(GUI_WHITE);
		//		GUI_SetTextAlign(GUI_TA_LEFT);
		//		GUI_DispStringAt(strQE[language], 50, 35);
		//		GUI_SetFont(&GUI_FontOthersFont16);
		//		GUI_SetTextAlign(GUI_TA_RIGHT);
		//		GUI_DispStringAt(strOthers[language], 218, 35);
		break;
	case eAutoOffBtnId:
		//		GUI_SetFont(&GUI_FontJPAPJPFont16B);
		//		GUI_SetColor(COLOR_ULTRA_LIGHT_BLUE);
		if(SettingBtnGetThumpPos(id) == eOff)
		{
			testSettingBtnManageDisp = 23;
			//			GUI_FillRoundedRect(45, 37, 90, 60, 3);
		}
		else
		{
			testSettingBtnManageDisp = 24;
			//			GUI_FillRoundedRect(215, 37, 255, 60, 3);
		}
		//		GUI_SetColor(GUI_WHITE);
		//		GUI_SetTextAlign(GUI_TA_LEFT);
		//		GUI_DispStringAt(onOffStr[0], 50, 35);
		//		GUI_SetTextAlign(GUI_TA_RIGHT);
		//		GUI_DispStringAt(onOffStr[1], 250, 35);
		break;
	case eFLBtnId:
		//		GUI_SetFont(&GUI_FontJPAPJPFont16B);
		//		GUI_SetColor(COLOR_ULTRA_LIGHT_BLUE);
		if(SettingBtnGetThumpPos(id) == eOff)
		{
			testSettingBtnManageDisp = 25;
			//			GUI_FillRoundedRect(45, 37, 90, 60, 3);
		}
		else
		{
			testSettingBtnManageDisp = 26;
			//			GUI_FillRoundedRect(215, 37, 255, 60, 3);
		}
		//		GUI_SetColor(GUI_WHITE);
		//		GUI_SetTextAlign(GUI_TA_LEFT);
		//		GUI_DispStringAt(onOffStr[0], 50, 35);
		//		GUI_SetTextAlign(GUI_TA_RIGHT);
		//		GUI_DispStringAt(onOffStr[1], 250, 35);
		break;
	case eSettingPressBtnId:
	case eUpperPressBtnId:
	case eLowerPressBtnId:
		for(i = 0; i < numOfString; i++)
		{
			if(i%8 == 0)
			{
				testSettingBtnManageDisp = 27 + i;
				//				GUI_DispStringHCenterAt(sliderStr[id].stringArrayPtr[i], SLIDER_X+i*(Rect.x1-20)/(numOfString-1), 44);
			}
		}
		//draw slider bar
		SettingBtnDrawSlider(pos, Rect);
		break;
	case eInitialPressBtnId:
		//		GUI_SetFont(&GUI_FontJPAPJPFont16B);
		//		GUI_SetColor(COLOR_ULTRA_LIGHT_BLUE);

		if(SettingBtnGetThumpPos(id) == e2cmH2O)
		{
			testSettingBtnManageDisp = 100;
			//			GUI_FillRoundedRect(45, 37, 130, 60, 3);
		}
		else
		{
			testSettingBtnManageDisp = 101;
			//			GUI_FillRoundedRect(175, 37, 255, 60, 3);
		}
		//		GUI_SetColor(GUI_WHITE);

		if(SettingGetMocks(ePressUnitSettingId) == ecmH2O)//(SettingGet(ePressUnitSettingId) == ecmH2O)
		{
			testSettingBtnManageDisp = 102;
			//			GUI_SetTextAlign(GUI_TA_CENTER);
			//			GUI_DispStringAt(initialPressStr[0], 87, 35);
			//			GUI_SetTextAlign(GUI_TA_CENTER);
			//			GUI_DispStringAt(initialPressStr[1], 215, 35);
		}
		else
		{
			testSettingBtnManageDisp = 103;
			//			GUI_SetTextAlign(GUI_TA_CENTER);
			//			GUI_DispStringAt(initialPressStr[2], 87, 35);
			//			GUI_SetTextAlign(GUI_TA_CENTER);
			//			GUI_DispStringAt(initialPressStr[3], 215, 35);
		}
		break;
	default:
		for(i = 0; i < numOfString; i++)
		{
			testSettingBtnManageDisp += i;
			//			GUI_DispStringHCenterAt(sliderStr[id].stringArrayPtr[i], SLIDER_X+i*(Rect.x1-20)/(numOfString-1), 44);
		}
		//draw slider bar
		SettingBtnDrawSlider(pos, Rect);
		break;
	}
}

void SettingbtnLog(void* hObj)//(BUTTON_Handle hObj)
{
	unsigned char id = eSystemLogSettingChangedId;
	unsigned char data = 0;
	unsigned char buttonId = WM_GetId(hObj);

	switch (buttonId) {
	case eInhSupBtnId:				data = eInhPressSupportSettingId;	break;
	case eExhSupBtnId:				data = eExhPressSupportSettingId;	break;
	case eRampTimeBtnId:			data = eRampTimeSettingId;			break;
	case eVentilationTypeBtnId:		data = eVentModeSettingId;			break;
	case eSettingPressBtnId:		data = eOperPressSettingId;			break;
	case eUpperPressBtnId:			data = eAutoUpperPressSettingId;	break;
	case eLowerPressBtnId:			data = eAutoLowerPressSettingId;	break;
	case eInitialPressBtnId:		data = eDelayPressSettingId;		break;
	case eBrightnessAdjustBtnId:	data = eBrightnessSettingId; 		break;
	case eNaturalSupportTypeBtnId:	data = eNsTypeSettingId;			break;
	case eLanguageSettingBtnId:		data = eLanguageSettingId;			break;
	case eChangeUnitBtnId: 			data = ePressUnitSettingId;			break;
	case eDisplayOffTimerBtnId:		data = eSleepTimerSettingId;		break;
	case eFLBtnId:					data = eFLSettingId;				break;
	case eAutoOffBtnId:				data = eAutoOFFSettingId; 			break;
	default:		return;
	}

	testSettingbtnLog = data;

	SystemEventStruct event;
	event.Id = id;
	event.Data.type1 = data;
	//send event to queue
	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
	{
	}
	//SystemTaskSendEvent(id, data);
}


#if defined(__cplusplus)
}
#endif
