/*
 * settingbutton.h
 *
 *  Created on: Apr 24, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_GUI_SETTINGBUTTON_H_
#define UNITTEST_GUI_SETTINGBUTTON_H_

#include "guidefine.h"
#include "WM.h"
//#include "BUTTON.h"
//#include "SLIDER.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void SettingBtnCallback(WM_MESSAGE * pMsg);
void SettingBtnSetStatus(void* hObj, E_ButtonStatus stt);//(BUTTON_Handle hObj, E_ButtonStatus stt);
void SettingBtnSetValue(void* hObj, int pos);//(BUTTON_Handle hObj, int pos);
void SettingBtnIncThumpPos(void* hObj);//(BUTTON_Handle hObj);
void SettingBtnDecThumpPos(void* hObj);//(BUTTON_Handle hObj);
void SettingbtnLog(void* hObj);//(BUTTON_Handle hObj);
void SettingBtnExpandArea(unsigned char id);
void SettingBtnDrawSlider(int pos,  GUI_RECT Rect);
void SettingBtnCustom(unsigned char id);
void SettingBtnDispValue(unsigned char id,  GUI_RECT Rect);
int SettingBtnGetThumpPos(unsigned char id);
void SettingBtnApply(unsigned char id);
void SettingBtnManageDisp(unsigned char id, unsigned char numOfString, int pos,  GUI_RECT Rect);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_GUI_SETTINGBUTTON_H_ */
