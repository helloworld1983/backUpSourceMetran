/*
 * settingbuttonTest.cpp
 *
 *  Created on: Apr 24, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "settingbutton.h"

#include <setting.h>

#include "guiglobal.h"
#include "strings.h"
#include "PWMLib.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern SliderContent sliderStr[];
extern int testSettingBtnExpandArea;
extern int testSettingBtnDrawSlider;
extern SettingBtnStruct buttonString[];
extern int testSettingBtnCustom;
extern SliderContent sliderStr[];
extern int testSettingBtnManageDisp;
extern int testSettingbtnLog;

namespace EmbeddedCUnitTest {


class SettingButtonTest : public TestFixture
{
public:
	SettingButtonTest() : TestFixture(new ModuleMock) {}
};

TEST_F(SettingButtonTest, SettingBtnExpandArea1)
{
	SettingBtnExpandArea(eRampTimeBtnId);

	EXPECT_EQ(10,sliderStr[eRampTimeBtnId].numOfValue);
	EXPECT_EQ(eRampTimeBtnId,testSettingBtnExpandArea);
}

TEST_F(SettingButtonTest, SettingBtnDrawSlider)
{
	GUI_RECT Rect;
	SettingBtnDrawSlider(100,Rect);

	EXPECT_EQ(100,testSettingBtnDrawSlider);
}

TEST_F(SettingButtonTest, SettingBtnCustom1)
{
	language = 1;
	buttonString[eRampTimeBtnId].status = eRelease;
	SettingBtnCustom(eRampTimeBtnId);

	EXPECT_EQ("Ramp time",std::string(buttonString[eRampTimeBtnId].nameStr[language]));
	EXPECT_EQ(15,testSettingBtnCustom);
}

TEST_F(SettingButtonTest, SettingBtnCustom2)
{
	language = 0;
	buttonString[eDryingModeBtnId].status = eRelease;
	SettingBtnCustom(eDryingModeBtnId);

	EXPECT_EQ(14,testSettingBtnCustom);
}

TEST_F(SettingButtonTest, SettingBtnCustom3)
{
	language = 1;
	buttonString[eExhSupBtnId].status = eRelease;
	SettingBtnCustom(eExhSupBtnId);

	EXPECT_EQ(14,testSettingBtnCustom);
}

TEST_F(SettingButtonTest, SettingBtnCustom4)
{
	language = 0;
	buttonString[eDryingModeBtnId].status = ePoint;
	SettingBtnCustom(eDryingModeBtnId);

	EXPECT_EQ(16,testSettingBtnCustom);
}

TEST_F(SettingButtonTest, SettingBtnCustom5)
{
	language = 0;
	buttonString[eDryingModeBtnId].status = eEnter;
	SettingBtnCustom(eDryingModeBtnId);

	EXPECT_EQ(17,testSettingBtnCustom);
}

TEST_F(SettingButtonTest, SettingBtnDispValue)
{
	GUI_RECT Rect;
	SettingBtnDispValue(eInhSupBtnId,Rect);

	EXPECT_EQ("0",std::string(buttonString[eInhSupBtnId].valueStr));
}

TEST_F(SettingButtonTest, SettingBtnSetStatus1)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(1));

	SettingBtnSetStatus(nullptr,eRelease);

	EXPECT_EQ(eRelease,buttonString[1].status);
}

TEST_F(SettingButtonTest, SettingBtnSetStatus2)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(2));

	SettingBtnSetStatus(nullptr,ePoint);

	EXPECT_EQ(ePoint,buttonString[2].status);
}

TEST_F(SettingButtonTest, SettingBtnSetStatus3)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(3));

	SettingBtnSetStatus(nullptr,eEnter);

	EXPECT_EQ(eEnter,buttonString[3].status);
}

TEST_F(SettingButtonTest, SettingBtnGetThumpPos1)
{
	SettingBtnGetThumpPos(0);

	EXPECT_EQ(0,sliderStr[0].position);
}

TEST_F(SettingButtonTest, SettingBtnGetThumpPos2)
{
	SettingBtnGetThumpPos(1);

	EXPECT_EQ(0,sliderStr[1].position);
}

TEST_F(SettingButtonTest, SettingBtnGetThumpPos3)
{
	SettingBtnGetThumpPos(2);

	EXPECT_EQ(0,sliderStr[2].position);
}

TEST_F(SettingButtonTest, SettingBtnSetValue)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(1)).WillOnce(Return(1)).WillOnce(Return(1));

	SettingBtnSetValue(nullptr,1);

	EXPECT_EQ(1,sliderStr[1].position);
	EXPECT_EQ("L1",std::string(buttonString[1].valueStr));
}

TEST_F(SettingButtonTest, SettingBtnIncThumpPos)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(4).WillOnce(Return(1)).WillOnce(Return(1)).WillOnce(Return(1)).WillOnce(Return(1));

	buttonString[1].status = eEnter;
	SettingBtnIncThumpPos(nullptr);

	EXPECT_EQ(2,sliderStr[1].position);
	EXPECT_EQ("L2",std::string(buttonString[1].valueStr));
}

TEST_F(SettingButtonTest, SettingBtnDecThumpPos)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(4).WillOnce(Return(1)).WillOnce(Return(1)).WillOnce(Return(1)).WillOnce(Return(1));

	buttonString[1].status = eEnter;
	SettingBtnDecThumpPos(nullptr);

	EXPECT_EQ(1,sliderStr[1].position);
	EXPECT_EQ("L1",std::string(buttonString[1].valueStr));
}

TEST_F(SettingButtonTest, SettingBtnApply1)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eCircuitTypeSettingId,_)).Times(1);

	SettingBtnApply(eDryingModeBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply2)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eInhPressSupportSettingId,_)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(2);

	SettingBtnApply(eInhSupBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply3)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eExhPressSupportSettingId,_)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(2);

	SettingBtnApply(eExhSupBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply4)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eRampTimeSettingId,_)).Times(1);

	SettingBtnApply(eRampTimeBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply5)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eBrightnessSettingId,_)).Times(1);
	EXPECT_CALL(*_PWMLib,PWMSetDutyMocks(ePWMLCDBLId,_)).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eBrightnessSettingId)).Times(1);

	SettingBtnApply(eBrightnessAdjustBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply6)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eLanguageSettingId,_)).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eLanguageSettingId)).Times(1).WillOnce(Return(2));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingBtnApply(eLanguageSettingBtnId);

	EXPECT_EQ(1,language);
}

TEST_F(SettingButtonTest, SettingBtnApply7)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eVentModeSettingId,_)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingBtnApply(eVentilationTypeBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply8)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eOperPressSettingId,_)).Times(1);

	SettingBtnApply(eSettingPressBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply9)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eAutoUpperPressSettingId,_)).Times(1);

	SettingBtnApply(eUpperPressBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply10)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eAutoLowerPressSettingId,_)).Times(1);

	SettingBtnApply(eLowerPressBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply11)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eDelayPressSettingId,_)).Times(1);

	SettingBtnApply(eInitialPressBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply12)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(ePressUnitSettingId,_)).Times(1);

	SettingBtnApply(eChangeUnitBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply13)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eBluetoothSettingId,_)).Times(1);

	SettingBtnApply(eBluetoothSettingBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply14)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eSleepTimerSettingId,_)).Times(1);

	SettingBtnApply(eDisplayOffTimerBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply15)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eNsTypeSettingId,_)).Times(1);

	SettingBtnApply(eNaturalSupportTypeBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply16)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eAutoOFFSettingId,_)).Times(1);

	SettingBtnApply(eAutoOffBtnId);
}

TEST_F(SettingButtonTest, SettingBtnApply17)
{
	EXPECT_CALL(*_settingLib,SettingSetMocks(eFLSettingId,_)).Times(1);

	SettingBtnApply(eFLBtnId);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp1)
{
	GUI_RECT Rect;
	SettingBtnManageDisp(eBrightnessAdjustBtnId,0,10,Rect);

	EXPECT_EQ(10,testSettingBtnDrawSlider);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp2)
{
	GUI_RECT Rect;
	language = 0;
	SettingBtnManageDisp(eLanguageSettingBtnId,0,10,Rect);

	EXPECT_EQ(11,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp3)
{
	GUI_RECT Rect;
	language = 1;
	SettingBtnManageDisp(eLanguageSettingBtnId,0,10,Rect);

	EXPECT_EQ(12,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp4)
{
	GUI_RECT Rect;
	language = 1;
	sliderStr[eNaturalSupportTypeBtnId].position = eEType;
	SettingBtnManageDisp(eNaturalSupportTypeBtnId,0,10,Rect);

	EXPECT_EQ(13,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp5)
{
	GUI_RECT Rect;
	language = 1;
	sliderStr[eNaturalSupportTypeBtnId].position = eSType;
	SettingBtnManageDisp(eNaturalSupportTypeBtnId,0,10,Rect);

	EXPECT_EQ(14,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp6)
{
	GUI_RECT Rect;
	sliderStr[eVentilationTypeBtnId].position = eCpapMode;
	SettingBtnManageDisp(eVentilationTypeBtnId,0,10,Rect);

	EXPECT_EQ(15,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp7)
{
	GUI_RECT Rect;
	sliderStr[eVentilationTypeBtnId].position = eAutoMode;
	SettingBtnManageDisp(eVentilationTypeBtnId,0,10,Rect);

	EXPECT_EQ(16,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp8)
{
	GUI_RECT Rect;
	sliderStr[eChangeUnitBtnId].position = ecmH2O;
	SettingBtnManageDisp(eChangeUnitBtnId,0,10,Rect);

	EXPECT_EQ(17,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp9)
{
	GUI_RECT Rect;
	sliderStr[eChangeUnitBtnId].position = ehPa;
	SettingBtnManageDisp(eChangeUnitBtnId,0,10,Rect);

	EXPECT_EQ(18,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp10)
{
	GUI_RECT Rect;
	sliderStr[eBluetoothSettingBtnId].position = eOff;
	SettingBtnManageDisp(eBluetoothSettingBtnId,0,10,Rect);

	EXPECT_EQ(19,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp11)
{
	GUI_RECT Rect;
	sliderStr[eBluetoothSettingBtnId].position = eOn;
	SettingBtnManageDisp(eBluetoothSettingBtnId,0,10,Rect);

	EXPECT_EQ(20,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp12)
{
	GUI_RECT Rect;
	sliderStr[eDryingModeBtnId].position = eQE;
	SettingBtnManageDisp(eDryingModeBtnId,0,10,Rect);

	EXPECT_EQ(21,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp13)
{
	GUI_RECT Rect;
	sliderStr[eDryingModeBtnId].position = eOthers;
	SettingBtnManageDisp(eDryingModeBtnId,0,10,Rect);

	EXPECT_EQ(22,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp14)
{
	GUI_RECT Rect;
	sliderStr[eAutoOffBtnId].position = eOff;
	SettingBtnManageDisp(eAutoOffBtnId,0,10,Rect);

	EXPECT_EQ(23,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp15)
{
	GUI_RECT Rect;
	sliderStr[eAutoOffBtnId].position = eOn;
	SettingBtnManageDisp(eAutoOffBtnId,0,10,Rect);

	EXPECT_EQ(24,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp16)
{
	GUI_RECT Rect;
	sliderStr[eFLBtnId].position = eOff;
	SettingBtnManageDisp(eFLBtnId,0,10,Rect);

	EXPECT_EQ(25,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp17)
{
	GUI_RECT Rect;
	sliderStr[eFLBtnId].position = eOn;
	SettingBtnManageDisp(eFLBtnId,0,10,Rect);

	EXPECT_EQ(26,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp18)
{
	GUI_RECT Rect;
	SettingBtnManageDisp(eSettingPressBtnId,10,10,Rect);

	EXPECT_EQ(35,testSettingBtnManageDisp);
	EXPECT_EQ(10,testSettingBtnDrawSlider);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp19)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(ePressUnitSettingId)).Times(1).WillOnce(Return(0));

	GUI_RECT Rect;
	sliderStr[eInitialPressBtnId].position = e2cmH2O;
	SettingBtnManageDisp(eInitialPressBtnId,10,10,Rect);

	EXPECT_EQ(102,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp20)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(ePressUnitSettingId)).Times(1).WillOnce(Return(1));

	GUI_RECT Rect;
	sliderStr[eInitialPressBtnId].position = e4cmH2O;
	SettingBtnManageDisp(eInitialPressBtnId,10,10,Rect);

	EXPECT_EQ(103,testSettingBtnManageDisp);
}

TEST_F(SettingButtonTest, SettingBtnManageDisp21)
{
	GUI_RECT Rect;
	SettingBtnManageDisp(eRampTimeBtnId,10,30,Rect);

	EXPECT_EQ(148,testSettingBtnManageDisp);
	EXPECT_EQ(30,testSettingBtnDrawSlider);
}

TEST_F(SettingButtonTest, SettingbtnLog1)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eInhSupBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(eInhPressSupportSettingId,testSettingbtnLog);
}

TEST_F(SettingButtonTest, SettingbtnLog2)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eExhSupBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(eExhPressSupportSettingId,testSettingbtnLog);
}

TEST_F(SettingButtonTest, SettingbtnLog3)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eRampTimeBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(eRampTimeSettingId,testSettingbtnLog);
}

TEST_F(SettingButtonTest, SettingbtnLog4)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eVentilationTypeBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(eVentModeSettingId,testSettingbtnLog);
}

TEST_F(SettingButtonTest, SettingbtnLog5)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eSettingPressBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(eOperPressSettingId,testSettingbtnLog);
}

TEST_F(SettingButtonTest, SettingbtnLog6)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eUpperPressBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(eAutoUpperPressSettingId,testSettingbtnLog);
}

TEST_F(SettingButtonTest, SettingbtnLog7)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eLowerPressBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(eAutoLowerPressSettingId,testSettingbtnLog);
}

TEST_F(SettingButtonTest, SettingbtnLog8)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eInitialPressBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(eDelayPressSettingId,testSettingbtnLog);
}

TEST_F(SettingButtonTest, SettingbtnLog9)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eBrightnessAdjustBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(eBrightnessSettingId,testSettingbtnLog);
}

TEST_F(SettingButtonTest, SettingbtnLog10)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eNaturalSupportTypeBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(eNsTypeSettingId,testSettingbtnLog);
}

TEST_F(SettingButtonTest, SettingbtnLog11)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eLanguageSettingBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(eLanguageSettingId,testSettingbtnLog);
}

TEST_F(SettingButtonTest, SettingbtnLog12)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eChangeUnitBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(ePressUnitSettingId,testSettingbtnLog);
}

TEST_F(SettingButtonTest, SettingbtnLog13)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eDisplayOffTimerBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(eSleepTimerSettingId,testSettingbtnLog);
}

TEST_F(SettingButtonTest, SettingbtnLog14)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eFLBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(eFLSettingId,testSettingbtnLog);
}

TEST_F(SettingButtonTest, SettingbtnLog15)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eAutoOffBtnId));
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	SettingbtnLog(nullptr);

	EXPECT_EQ(eAutoOFFSettingId,testSettingbtnLog);
}

}


