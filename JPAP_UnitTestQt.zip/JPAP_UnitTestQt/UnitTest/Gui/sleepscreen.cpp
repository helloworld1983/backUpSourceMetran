/*
 * sleepscreen.cpp
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */
#include "sleepscreen.h"

#include <guiinterface.h>
#include <motorctrlinterface.h>
#include <setting.h>

#include "guidefine.h"
//#include "debuguart.h"
#include "mainscreen.h"
#include "operationscreen.h"
//#include "TEXT.h"
//#include "fonts.h"
//#include "rtc.h"
//#include "strings.h"
//#include "string.h"
//#include "stringtools.h"
#include "mode.h"
#include "SettingMocks.h"
//#include "motorcmd.h"
//#include "pwm.h"
//#include "systemconfig.h"
//#include "analyzeinterface.h"
#include "guiglobal.h"
#include "RTCMocks.h"
#include "WMMocks.h"
#include "strings.h"
#include "WString.h"
#include "RTCMocks.h"
#include "AnalyzeDataMocks.h"

////1. define parameters for Display-OFF screen
//#define SLEEP_SCR_X					0
//#define SLEEP_SCR_Y					0
//#define SLEEP_SCR_LENGTH			320
//#define SLEEP_SCR_HEIGHT			240
//
////2. define parameters for time label
//#define SLEEP_SCR_TIME_X			0
//#define SLEEP_SCR_TIME_Y			100
//#define SLEEP_SCR_TIME_LENGTH		120
//#define SLEEP_SCR_TIME_HEIGHT		26
//
////3. define parameters for date label
//#define SLEEP_SCR_DATE_X			0
//#define SLEEP_SCR_DATE_Y			130
//#define SLEEP_SCR_DATE_LENGTH		225
//#define SLEEP_SCR_DATE_HEIGHT		26
//
////4. define parameters for pressure label
//#define SLEEP_SCR_PRESSURE_X		0
//#define SLEEP_SCR_PRESSURE_Y		80
//#define SLEEP_SCR_PRESSURE_LENGTH	230
//#define SLEEP_SCR_PRESSURE_HEIGHT	40
//
////5. define parameters for pressure unit
//#define SLEEP_SCR_UNIT_X			0
//#define SLEEP_SCR_UNIT_Y			90
//#define SLEEP_SCR_UNIT_LENGTH		275
//#define SLEEP_SCR_UNIT_HEIGHT		30
//
////6. define parameters for the line
//#define SLEEP_SCR_LINE_X			280
//#define SLEEP_SCR_LINE_Y0			80
//#define SLEEP_SCR_LINE_Y1			160
//
////7. define color for label
//#define COLOR_OFF_SCREEN			COLOR_ULTRA_LIGHT_BLUE
//
//#define HOURS_HALF_DAY				12
//#define HOURS_WHOLE_DAY				24

E_SleepDispType displayType = eDispIdleType;
int testSleepScrInit = 0;
RTC_TIME_Type testTimeSleepScreen;
float testSleepScrUpdatePressure = 0;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//extern WM_HWIN mainWindow;			//main window

//WM_HWIN sleepScreen;				//Display-OFF screen

//internal function declaration
//void SleepScrCallback(WM_MESSAGE * pMsg);
//void SleepScrShowDate(RTC_TIME_Type* time);
void SleepScrShowTime(RTC_TIME_Type* time);
//static void SleepScrHandleKeyEvent();
//void SleepScrSetFocus();

//internal variable declaration
//static RTC_TIME_Type realTimeInstance = {0};//real time
//static WM_MESSAGE msgUpateRealTime;			//real time message
//static TEXT_Handle sleepScrDateLabel;		//date label
//static TEXT_Handle sleepScrTimeLabel;		//time label
//static TEXT_Handle sleepScrPressureLabel;	//pressure label
//static TEXT_Handle sleepScrUnitLabel;		//pressure unit label

//static E_SleepDispType displayType = eDispIdleType;
//static const GUI_FONT* guiFont16[] = { &GUI_FontMeiryo16B_2bpp, &GUI_FontJPAPJPFont16B };
//static const GUI_FONT* guiFont20[] = { &GUI_FontSleepJapaneseFont20, &GUI_FontSleepEnglishFont20 };

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SleepScrCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		The callback function of Display-OFF screen
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SleepScrCallback(WM_MESSAGE * pMsg)
{
	GUI_RECT Rect;

	switch (pMsg->MsgId) {
	case WM_PAINT:
		WM_GetInsideRect(&Rect);
		GUI_SetBkColor(GUI_BLACK);
		GUI_ClearRectEx(&Rect);
		GUI_SetColor(COLOR_OFF_SCREEN);
		GUI_SetPenSize(2);
		//draw a line
		if(displayType == eDispIdleType)
			GUI_DrawLine(SLEEP_SCR_LINE_X-50, SLEEP_SCR_LINE_Y0, SLEEP_SCR_LINE_X-50, SLEEP_SCR_LINE_Y1);
		else
			GUI_DrawLine(SLEEP_SCR_LINE_X, SLEEP_SCR_LINE_Y0, SLEEP_SCR_LINE_X, SLEEP_SCR_LINE_Y1);
		break;
	default:
		WM_DefaultProc(pMsg);
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SleepScrInit(void)
//
//    Processing:
//		The function creates Display-OFF screen and initializes its items
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SleepScrInit(void)
{
	//create operation window
	//	sleepScreen = WM_CreateWindowAsChild(SLEEP_SCR_X, SLEEP_SCR_Y, SLEEP_SCR_LENGTH, SLEEP_SCR_HEIGHT, mainWindow, WM_CF_HIDE | WM_CF_MEMDEV | WM_CF_LATE_CLIP, SleepScrCallback, 0);
	//#if SUPPORT_SLEEP_MODE
	//	//create text for date and time
	//	sleepScrTimeLabel = TEXT_CreateEx(SLEEP_SCR_TIME_X, SLEEP_SCR_TIME_Y, SLEEP_SCR_TIME_LENGTH, SLEEP_SCR_TIME_HEIGHT, sleepScreen,WM_CF_SHOW, GUI_TA_RIGHT | GUI_TA_VCENTER, GUI_ID_TEXT0, "");
	//	TEXT_SetFont(sleepScrTimeLabel,&GUI_FontJPAPJPFont16B);
	//	TEXT_SetTextColor(sleepScrTimeLabel, COLOR_OFF_SCREEN);
	//
	//	//create text for date and time
	//	sleepScrDateLabel = TEXT_CreateEx(SLEEP_SCR_DATE_X, SLEEP_SCR_DATE_Y, SLEEP_SCR_DATE_LENGTH, SLEEP_SCR_DATE_HEIGHT, sleepScreen,WM_CF_SHOW, GUI_TA_RIGHT | GUI_TA_VCENTER, GUI_ID_TEXT1, "");
	//	TEXT_SetFont(sleepScrDateLabel,&GUI_FontJPAPJPFont16B);
	//	TEXT_SetTextColor(sleepScrDateLabel, COLOR_OFF_SCREEN);
	//
	//	//init pressure label
	//	sleepScrPressureLabel = TEXT_CreateEx(SLEEP_SCR_PRESSURE_X, SLEEP_SCR_PRESSURE_Y, SLEEP_SCR_PRESSURE_LENGTH, SLEEP_SCR_PRESSURE_HEIGHT, sleepScreen,WM_CF_SHOW, GUI_TA_RIGHT | GUI_TA_VCENTER, GUI_ID_TEXT2, "");
	//	TEXT_SetFont(sleepScrPressureLabel, &GUI_FontJPAPJPFont36B);
	//	TEXT_SetTextColor(sleepScrPressureLabel, COLOR_OFF_SCREEN);
	//
	//	//init pressure unit
	//	sleepScrUnitLabel = TEXT_CreateEx(SLEEP_SCR_UNIT_X, SLEEP_SCR_UNIT_Y, SLEEP_SCR_UNIT_LENGTH, SLEEP_SCR_UNIT_HEIGHT, sleepScreen,WM_CF_SHOW, GUI_TA_RIGHT | GUI_TA_BOTTOM, GUI_ID_TEXT3, "");
	//	TEXT_SetFont(sleepScrUnitLabel, &GUI_FontJPAPJPFont12B);
	//	TEXT_SetTextColor(sleepScrUnitLabel, COLOR_OFF_SCREEN);
	//#endif

	testSleepScrInit = 1000;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SleepScrShowDate(RTC_TIME_Type* time)
//
//    Processing:
//		This operation displays date
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SleepScrShowDate(RTC_TIME_Type* time)
{
	char temp[20] = {'\0'};								//maximum 20 characters
	int index = 0;
	if(language == eEnglish)
	{
		//date of month was changed, should update it on status bar
		int month = time->MONTH;							//get current month
		month = (month > 12)?12:((month < 1)?1:month);		//handle month value
		StrAppend(temp, monthStrEng[month - 1], 20);
		index += 3;											//ship 3 characters
		temp[index++] = ' ';								//insert space

		int date = time->DOM;								//get current date
		date = (date > 31)?31:((date < 1)?1:date);
		StrToolItoA(date, &temp[index], 2);					//convert date to string
		index += 2;											//ship 2 characters
		temp[index++] = ',';								//insert comma
		temp[index++] = ' ';								//insert space

		int year = time->YEAR;								//get current year
		StrToolItoA(year, &temp[index], 4);					//convert to string
		//		TEXT_SetText(sleepScrDateLabel, (const char*)&temp[0]);	//set text
	}
	else
	{
		//date of month was changed, should update it on status bar
		//put year
		int year = time->YEAR;
		StrToolItoA(year, &temp[index], 4);
		index += 4;		//ship 4 characters
		StrAppend(temp, strYear, 20);
		index += 3;		//ship 3 characters
		//put month
		int month = time->MONTH;
		StrToolItoA(month, &temp[index], 2);
		index += 2;		//ship 2 characters
		StrAppend(temp, strMonth, 20);
		index += 3;		//ship 3 characters
		//put date
		int date = time->DOM;
		date = (date > 31)?31:((date < 1)?1:date);
		StrToolItoA(date, &temp[index], 2);
		index += 2;		//ship 2 characters
		StrAppend(temp, strDate, 20);
		//set text
		//		TEXT_SetText(sleepScrDateLabel, (const char*)&temp[0]);
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SleepScrShowTime(RTC_TIME_Type* time)
//
//    Processing:
//		This operation displays time
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SleepScrShowTime(RTC_TIME_Type* time)
{
	//	DebugStr(": time = ");
	//	DebugNumber(time->HOUR);
	//	DebugStr(":");
	//	DebugNumber(time->MIN);

	if(language == eEnglish)
	{
		char temp[20] = {'\0'};		//maximum 20 characters
		int index = 0;
		//put hour
		const char* ampm = strAm[1];
		int hour = time->HOUR;

		//handle hour and AM/PM
		if(time->HOUR == 0){
			hour = HOURS_HALF_DAY;
			ampm = strAm[1];
		}
		else if((time->HOUR >= 1)&&(time->HOUR < HOURS_HALF_DAY)){
			hour = time->HOUR;
			ampm = strAm[1];
		}
		else if(time->HOUR == HOURS_HALF_DAY){
			ampm = strPm[1];
		}
		else if((time->HOUR >= 13) && (time->HOUR < HOURS_WHOLE_DAY)){
			hour = time->HOUR - HOURS_HALF_DAY;
			ampm = strPm[1];
		}

		testTimeSleepScreen.HOUR = hour;//Add test

		StrToolItoA(hour, &temp[index], 2);		//convert hour to string
		index += 2;								//ship 2 characters
		temp[index++] = ':';					//insert ':'

		int minute = time->MIN;					//get current minute
		StrToolItoA(minute, &temp[index], 2);	//convert minute to string
		index += 2;								//ship 2 character
		temp[index++] = ' ';					//insert space
		StrAppend(temp, ampm, 20);			//insert AM/PM
		index += 2;								//ship 2 characters
		if(displayType == eDispOperType)
		{
			displayType = eDispIdleType;//Add test
			temp[index++] = ' ';
			temp[index++] = '-';
		}
		//		TEXT_SetText(sleepScrTimeLabel, (const char*)&temp[0]);	//set text to display
	}
	else
	{
		const char* ampm = strAm[0];
		char temp[20] = {'\0'};			//maximum 20 characters
		int index = 0;
		index = 0;	//reset index
		//put hour
		int hour = time->HOUR;

		if(time->HOUR == 0)
		{
			hour = HOURS_HALF_DAY;
			ampm = strAm[0];
		}
		else if((time->HOUR >= 1)&&(time->HOUR < HOURS_HALF_DAY))
		{
			hour = time->HOUR;
			ampm = strAm[0];
		}
		else if(time->HOUR == HOURS_HALF_DAY)
		{
			ampm = strPm[0];
		}
		else if((time->HOUR > HOURS_HALF_DAY) && (time->HOUR < HOURS_WHOLE_DAY))
		{
			hour = time->HOUR - HOURS_HALF_DAY;
			ampm = strPm[0];
		}

		testTimeSleepScreen.HOUR = hour;//Add test

		StrAppend(temp, ampm, 20);
		index += 6;
		StrToolItoA(hour, &temp[index], 2);
		index += 2;		//ship 2 characters
		temp[index++] = ':';
		//put minute
		int min = time->MIN;
		StrToolItoA(min, &temp[index], 2);

		//set text
		//		TEXT_SetText(sleepScrTimeLabel, (const char*)&temp[0]);
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SleepScrUpdateTime(RTC_TIME_Type* time)
//
//    Processing:
//		This operation sends signal to update date time
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SleepScrUpdateTime()
{
	//	DebugStr("; SleepScrUpdateTime");
	RTC_TIME_Type time = RTCGetMocks();
	SleepScrShowDate(&time);	//display date
	SleepScrShowTime(&time);	//display time
	//	realTimeInstance = RTCGet();							//get current real time
	//	msgUpateRealTime.MsgId = WM_SLEEP_SCREEN_UPDATE_TIME;	//set message to sent
	//	msgUpateRealTime.hWin = sleepScreen;					//set destination window
	//	msgUpateRealTime.Data.p = &realTimeInstance;			//set data
	//	WM_SendMessage(sleepScreen, &msgUpateRealTime);			//send message
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SleepScrUpdatePressure()
//
//    Processing:
//		This operation updates pressure on sleep screen
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SleepScrUpdatePressure()
{
	float pressure = 0.0;
	char str[10] = {'\0'};
	//get real time treatment pressure value
	if(AnalyzeDataGetTreatmentPressureMocks(&pressure) == false)
		return;

	//	if(pressure <= 0)
	//		pressure = 0;
	//	else if(pressure >= 20)
	//		pressure = 20;

	if(testSleepScrUpdatePressure <= 0)
		testSleepScrUpdatePressure = 0;
	else if(testSleepScrUpdatePressure >= 20)
		testSleepScrUpdatePressure = 20;

	//display pressure as text
	StrToolFtoA(testSleepScrUpdatePressure, &str[0], 1);
	//set value text
	//	TEXT_SetText(sleepScrPressureLabel, &str[0]);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SleepScrShow()
//
//    Processing:
//		This operation changes to sleep screen
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
//void SleepScrShow()
//{
//	WM_SetFocus(sleepScreen);		//focus sleep screen
//	WM_HideWindow(operationScreen);	//hide operation
//	WM_ShowWindow(sleepScreen);		//show sleep screen
//}

//function to set type of display
void SleepScrSetType(E_SleepDispType type)
{
	//set type of display
	displayType = type;
	//	TEXT_SetFont(sleepScrTimeLabel, guiFont16[language]);	//set font 16 for time label
	//	TEXT_SetFont(sleepScrDateLabel, guiFont16[language]);	//set font 16 for date label
	//re-layout sleep screen
	if(displayType == eDispIdleType)
	{
		WM_HideWindow(nullptr);//(sleepScrUnitLabel);						//hide unit
		WM_HideWindow(nullptr);//(sleepScrPressureLabel);					//hide pressure
		//		TEXT_SetFont(sleepScrTimeLabel, guiFont20[language]);	//set font 20 for time label
		WM_MoveChildTo(nullptr,105,SLEEP_SCR_TIME_Y);//(sleepScrTimeLabel, 105, SLEEP_SCR_TIME_Y);	//move time label
		WM_MoveChildTo(nullptr, 0, SLEEP_SCR_DATE_Y);//(sleepScrDateLabel, 0, SLEEP_SCR_DATE_Y);		//move date label
	}
	else
	{
		WM_ShowWindow(nullptr);//(sleepScrUnitLabel);		//show unit
		WM_ShowWindow(nullptr);//(sleepScrPressureLabel);	//show pressure
		//move time label
		if(language == eJapanese)
			WM_MoveChildTo(nullptr, 5, SLEEP_SCR_DATE_Y);//(sleepScrTimeLabel, 5, SLEEP_SCR_DATE_Y);
		else
			WM_MoveChildTo(nullptr, 40, SLEEP_SCR_DATE_Y);//(sleepScrTimeLabel, 40, SLEEP_SCR_DATE_Y);

		WM_MoveChildTo(nullptr, 50, SLEEP_SCR_DATE_Y);//(sleepScrDateLabel, 50, SLEEP_SCR_DATE_Y);	//move date label

		//check unit
		if(SettingGetMocks(ePressUnitSettingId) == ecmH2O)
		{
			//			TEXT_SetText(sleepScrUnitLabel, unitStr[0]);	//set text for unit (cmH2O)
			WM_MoveChildTo(nullptr, 0, SLEEP_SCR_PRESSURE_Y);//(sleepScrPressureLabel, 0, SLEEP_SCR_PRESSURE_Y);	//move pressure label
		}
		else
		{
			//			TEXT_SetText(sleepScrUnitLabel, unitStr[1]);	//set text for unit (hPa)
			WM_MoveChildTo(nullptr, 15, SLEEP_SCR_PRESSURE_Y);//(sleepScrPressureLabel, 15, SLEEP_SCR_PRESSURE_Y);	//move pressure label
		}
	}

	//display time
	SleepScrUpdateTime();
	//display pressure
	SleepScrUpdatePressure();
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SleepScrSetFocus()
//
//    Processing:
//		This operation shows all items of sleep screen
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
/*
void SleepScrSetFocus()
{
	language = SettingGet(eLanguageSettingId);	//get language
//	mode = ModeGet();							//get ventilation mode
	TEXT_SetFont(sleepScrTimeLabel, guiFont16[language]);	//set font 16 for time label
	TEXT_SetFont(sleepScrDateLabel, guiFont16[language]);	//set font 16 for date label

	SleepScrUpdateTime();	//update date time

	if(displayType == eDispIdleType)
	{
		WM_HideWindow(sleepScrUnitLabel);						//hide unit
		WM_HideWindow(sleepScrPressureLabel);					//hide pressure
		TEXT_SetFont(sleepScrTimeLabel, guiFont20[language]);	//set font 20 for time label
		WM_MoveChildTo(sleepScrTimeLabel, 105, SLEEP_SCR_TIME_Y);	//move time label
		WM_MoveChildTo(sleepScrDateLabel, 0, SLEEP_SCR_DATE_Y);		//move date label
	}
	else
	{
		WM_ShowWindow(sleepScrUnitLabel);		//show unit
		WM_ShowWindow(sleepScrPressureLabel);	//show pressure
		//move time label
		if(language == eJapanese)
			WM_MoveChildTo(sleepScrTimeLabel, 5, SLEEP_SCR_DATE_Y);
		else
			WM_MoveChildTo(sleepScrTimeLabel, 40, SLEEP_SCR_DATE_Y);

		WM_MoveChildTo(sleepScrDateLabel, 50, SLEEP_SCR_DATE_Y);	//move date label

		//check unit
		if(SettingGet(ePressUnitSettingId) == ecmH2O)
		{
			TEXT_SetText(sleepScrUnitLabel, unitStr[0]);	//set text for unit (cmH2O)
			WM_MoveChildTo(sleepScrPressureLabel, 0, SLEEP_SCR_PRESSURE_Y);	//move pressure label
		}
		else
		{
			TEXT_SetText(sleepScrUnitLabel, unitStr[1]);	//set text for unit (hPa)
			WM_MoveChildTo(sleepScrPressureLabel, 15, SLEEP_SCR_PRESSURE_Y);	//move pressure label
		}
	}
}
 */


#if defined(__cplusplus)
}
#endif
