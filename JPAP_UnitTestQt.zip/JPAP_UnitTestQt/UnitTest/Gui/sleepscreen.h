/*
 * sleepscreen.h
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_GUI_SLEEPSCREEN_H_
#define UNITTEST_GUI_SLEEPSCREEN_H_

#include "WM.h"
#include "RTCMocks.h"

//1. define parameters for Display-OFF screen
#define SLEEP_SCR_X					0
#define SLEEP_SCR_Y					0
#define SLEEP_SCR_LENGTH			320
#define SLEEP_SCR_HEIGHT			240

//2. define parameters for time label
#define SLEEP_SCR_TIME_X			0
#define SLEEP_SCR_TIME_Y			100
#define SLEEP_SCR_TIME_LENGTH		120
#define SLEEP_SCR_TIME_HEIGHT		26

//3. define parameters for date label
#define SLEEP_SCR_DATE_X			0
#define SLEEP_SCR_DATE_Y			130
#define SLEEP_SCR_DATE_LENGTH		225
#define SLEEP_SCR_DATE_HEIGHT		26

//4. define parameters for pressure label
#define SLEEP_SCR_PRESSURE_X		0
#define SLEEP_SCR_PRESSURE_Y		80
#define SLEEP_SCR_PRESSURE_LENGTH	230
#define SLEEP_SCR_PRESSURE_HEIGHT	40

//5. define parameters for pressure unit
#define SLEEP_SCR_UNIT_X			0
#define SLEEP_SCR_UNIT_Y			90
#define SLEEP_SCR_UNIT_LENGTH		275
#define SLEEP_SCR_UNIT_HEIGHT		30

//6. define parameters for the line
#define SLEEP_SCR_LINE_X			280
#define SLEEP_SCR_LINE_Y0			80
#define SLEEP_SCR_LINE_Y1			160

//7. define color for label
#define COLOR_OFF_SCREEN			COLOR_ULTRA_LIGHT_BLUE

#define HOURS_HALF_DAY				12
#define HOURS_WHOLE_DAY				24

//define sleep screen display type
//there are 2 type: - type1: display only time if system in idle
//					- type2: display time and pressure treatment if system in operation
typedef enum
{
	eDispIdleType = 0,	//display as idle type
	eDispOperType		//display as operation type
} E_SleepDispType;


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//sleep screen object
//extern WM_HWIN sleepScreen;

void SleepScrCallback(WM_MESSAGE * pMsg);
void SleepScrShowDate(RTC_TIME_Type* time);
void SleepScrShowTime(RTC_TIME_Type* time);
//function to initialize sleep screen
void SleepScrInit(void);
//function to set type of display
void SleepScrSetType(E_SleepDispType type);
//function to update time on sleep screen
void SleepScrUpdateTime();
//function to update treatment pressure on sleep screen
void SleepScrUpdatePressure();


#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_GUI_SLEEPSCREEN_H_ */
