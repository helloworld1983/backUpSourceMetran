/*
 * sleepscreenTest.cpp
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "sleepscreen.h"

#include <setting.h>
#include "RTCMocks.h"
#include "guiglobal.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern E_SleepDispType displayType;
extern int testSleepScrInit;
extern RTC_TIME_Type testTimeSleepScreen;
extern float testSleepScrUpdatePressure;

namespace EmbeddedCUnitTest {


class SleepScreenTest : public TestFixture
{
public:
	SleepScreenTest() : TestFixture(new ModuleMock) {}
};

TEST_F(SleepScreenTest, SleepScrCallback1)
{
	EXPECT_CALL(*_WMLib,WM_GetInsideRect(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetBkColor(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_ClearRectEx(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetPenSize(2)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DrawLine(SLEEP_SCR_LINE_X-50, SLEEP_SCR_LINE_Y0, SLEEP_SCR_LINE_X-50, SLEEP_SCR_LINE_Y1)).Times(1);

	WM_MESSAGE *pMsg = new WM_MESSAGE;
	pMsg->MsgId = WM_PAINT;
	displayType = eDispIdleType;
	SleepScrCallback(pMsg);
}

TEST_F(SleepScreenTest, SleepScrCallback2)
{
	EXPECT_CALL(*_WMLib,WM_GetInsideRect(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetBkColor(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_ClearRectEx(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetPenSize(2)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DrawLine(SLEEP_SCR_LINE_X, SLEEP_SCR_LINE_Y0, SLEEP_SCR_LINE_X, SLEEP_SCR_LINE_Y1)).Times(1);

	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	displayType = eDispOperType;
	SleepScrCallback(&pMsg);
}

TEST_F(SleepScreenTest, SleepScrCallback3)
{
	EXPECT_CALL(*_WMLib,WM_DefaultProc(_)).Times(1);

	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT + 5;
	SleepScrCallback(&pMsg);
}

TEST_F(SleepScreenTest, SleepScrInit)
{
	SleepScrInit();

	EXPECT_EQ(1000,testSleepScrInit);
}

TEST_F(SleepScreenTest, SleepScrShowDate1)
{
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,4)).Times(1);

	language = 1;
	RTC_TIME_Type* time = new RTC_TIME_Type;
	SleepScrShowDate(time);
}

TEST_F(SleepScreenTest, SleepScrShowDate2)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,4)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(3);

	language = 0;
	RTC_TIME_Type* time = new RTC_TIME_Type;
	SleepScrShowDate(time);
}

TEST_F(SleepScreenTest, SleepScrShowTime1)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);

	displayType = eDispOperType;
	language = 1;
	RTC_TIME_Type* time = new RTC_TIME_Type;
	time->HOUR = 0;
	SleepScrShowTime(time);

	EXPECT_EQ((uint32_t)12,testTimeSleepScreen.HOUR);
	EXPECT_EQ(eDispIdleType,displayType);
}

TEST_F(SleepScreenTest, SleepScrShowTime2)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);

	displayType = eDispOperType;
	language = 1;
	RTC_TIME_Type* time = new RTC_TIME_Type;
	time->HOUR = 5;
	SleepScrShowTime(time);

	EXPECT_EQ((uint32_t)5,testTimeSleepScreen.HOUR);
	EXPECT_EQ(eDispIdleType,displayType);
}

TEST_F(SleepScreenTest, SleepScrShowTime3)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);

	displayType = eDispOperType;
	language = 1;
	RTC_TIME_Type* time = new RTC_TIME_Type;
	time->HOUR = 12;
	SleepScrShowTime(time);

	EXPECT_EQ((uint32_t)12,testTimeSleepScreen.HOUR);
	EXPECT_EQ(eDispIdleType,displayType);
}

TEST_F(SleepScreenTest, SleepScrShowTime4)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);

	displayType = eDispOperType;
	language = 1;
	RTC_TIME_Type* time = new RTC_TIME_Type;
	time->HOUR = 15;
	SleepScrShowTime(time);

	EXPECT_EQ((uint32_t)3,testTimeSleepScreen.HOUR);
	EXPECT_EQ(eDispIdleType,displayType);
}

TEST_F(SleepScreenTest, SleepScrShowTime5)
{
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);

	language = 0;
	RTC_TIME_Type* time = new RTC_TIME_Type;
	time->HOUR = 0;
	SleepScrShowTime(time);

	EXPECT_EQ((uint32_t)12,testTimeSleepScreen.HOUR);
}

TEST_F(SleepScreenTest, SleepScrShowTime6)
{
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);

	language = 0;
	RTC_TIME_Type* time = new RTC_TIME_Type;
	time->HOUR = 8;
	SleepScrShowTime(time);

	EXPECT_EQ((uint32_t)8,testTimeSleepScreen.HOUR);
}

TEST_F(SleepScreenTest, SleepScrShowTime7)
{
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);

	language = 0;
	RTC_TIME_Type* time = new RTC_TIME_Type;
	time->HOUR = 12;
	SleepScrShowTime(time);

	EXPECT_EQ((uint32_t)12,testTimeSleepScreen.HOUR);
}

TEST_F(SleepScreenTest, SleepScrShowTime8)
{
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);

	language = 0;
	RTC_TIME_Type* time = new RTC_TIME_Type;
	time->HOUR = 18;
	SleepScrShowTime(time);

	EXPECT_EQ((uint32_t)6,testTimeSleepScreen.HOUR);
}

TEST_F(SleepScreenTest, SleepScrUpdateTime)
{
	EXPECT_CALL(*_RTCLib,RTCGetMocks()).Times(1);
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(2);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(3);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,4)).Times(1);

	language = 1;
	SleepScrUpdateTime();
}

TEST_F(SleepScreenTest, SleepScrUpdatePressure1)
{
	EXPECT_CALL(*_AnalyzeDataLib,AnalyzeDataGetTreatmentPressureMocks(_)).Times(1).WillOnce(Return(true));
	EXPECT_CALL(*_wstring,StrToolFtoA(_,_,_)).Times(1);

	testSleepScrUpdatePressure = -1.0f;
	SleepScrUpdatePressure();

	EXPECT_EQ(0.0f, testSleepScrUpdatePressure);
}

TEST_F(SleepScreenTest, SleepScrUpdatePressure2)
{
	EXPECT_CALL(*_AnalyzeDataLib,AnalyzeDataGetTreatmentPressureMocks(_)).Times(1).WillOnce(Return(true));
	EXPECT_CALL(*_wstring,StrToolFtoA(_,_,_)).Times(1);

	testSleepScrUpdatePressure = 21.0f;
	SleepScrUpdatePressure();

	EXPECT_EQ(20.0f, testSleepScrUpdatePressure);
}

TEST_F(SleepScreenTest, SleepScrSetType1)
{
	EXPECT_CALL(*_WMLib,WM_HideWindow(_)).Times(2);
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,105,_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,0,_)).Times(1);

	SleepScrSetType(eDispIdleType);

	EXPECT_EQ(eDispIdleType, displayType);
}

TEST_F(SleepScreenTest, SleepScrSetType2)
{
	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(2);
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,40,_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,50,_)).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(ePressUnitSettingId)).Times(1).WillOnce(Return(ecmH2O));
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,0,_)).Times(1);


	EXPECT_CALL(*_RTCLib,RTCGetMocks()).Times(1);
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(2);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(3);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,4)).Times(1);

	EXPECT_CALL(*_AnalyzeDataLib,AnalyzeDataGetTreatmentPressureMocks(_)).Times(1).WillOnce(Return(true));
	EXPECT_CALL(*_wstring,StrToolFtoA(_,_,_)).Times(1);

	testSleepScrUpdatePressure = 21.0f;
	language = 1;
	SleepScrSetType(eDispOperType);

	EXPECT_EQ(eDispIdleType, displayType);

	EXPECT_EQ(20.0f, testSleepScrUpdatePressure);
}

TEST_F(SleepScreenTest, SleepScrSetType3)
{
	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(2);
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,5,_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,50,_)).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(ePressUnitSettingId)).Times(1).WillOnce(Return(ehPa));
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,15,_)).Times(1);


	EXPECT_CALL(*_RTCLib,RTCGetMocks()).Times(1);
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(4);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(4);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,4)).Times(1);

	EXPECT_CALL(*_AnalyzeDataLib,AnalyzeDataGetTreatmentPressureMocks(_)).Times(1).WillOnce(Return(true));
	EXPECT_CALL(*_wstring,StrToolFtoA(_,_,_)).Times(1);

	testSleepScrUpdatePressure = 21.0f;
	language = 0;
	SleepScrSetType(eDispOperType);

	EXPECT_EQ(eDispOperType, displayType);

	EXPECT_EQ(20.0f, testSleepScrUpdatePressure);
}

}

