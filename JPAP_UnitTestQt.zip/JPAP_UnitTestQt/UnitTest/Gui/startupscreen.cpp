/*
 * startupscreen.cpp
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */

#include "startupscreen.h"
//#include "IMAGE.h"
//#include "bitmap.h"
#include "WMMocks.h"

#define STARTUP_SCREEN_X_START 	0
#define STARTUP_SCREEN_Y_START	0
#define STARTUP_SCREEN_LENGTH	320
#define	STARTUP_SCREEN_HEIGHT	240

#define LOGO_X_START			65
#define LOGO_Y_START			58
#define LOGO_LENGTH				190
#define LOGO_HEIGHT				124

int testStartupScreenInit = 0;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//WM_HWIN startupScreen;
// main window instance
//extern WM_HWIN mainWindow;

//static IMAGE_Handle metranLogo;

void StartupScreenCallback(WM_MESSAGE * pMsg) {
	GUI_RECT Rect;
	switch (pMsg->MsgId) {
	case WM_PAINT:
		//get size: x0, x1, y0, y1
		WM_GetClientRect(&Rect);
//		GUI_SetPenShape(GUI_PS_ROUND);
//		GUI_SetTextMode(GUI_TM_TRANS);
		GUI_SetColor(GUI_WHITE);
		GUI_FillRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1);
		break;
	default:
		WM_DefaultProc(pMsg);
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: StartupScreenInit(void)
//
//    Processing:
//		The operation initialize the startup screen
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void StartupScreenInit(void)
{
//	startupScreen = WM_CreateWindowAsChild(STARTUP_SCREEN_X_START, STARTUP_SCREEN_Y_START, STARTUP_SCREEN_LENGTH, STARTUP_SCREEN_HEIGHT, mainWindow, WM_CF_SHOW, StartupScreenCallback, 0);
//	//create alarm image
//	metranLogo = IMAGE_CreateEx(LOGO_X_START, LOGO_Y_START, LOGO_LENGTH, LOGO_HEIGHT, startupScreen, WM_CF_SHOW, /*IMAGE_CF_MEMDEV*/0, GUI_ID_IMAGE7);
//	IMAGE_SetBitmap(metranLogo, &bmmetranlogo);

	testStartupScreenInit = 1001;
}

void StartupScreenShow(void)
{
	WM_ShowWindow(nullptr);//(startupScreen);
	WM_SetFocus(nullptr);//(startupScreen);
}

void StartupScreenHide(void)
{
	WM_HideWindow(nullptr);//(startupScreen);
}


#if defined(__cplusplus)
}
#endif


