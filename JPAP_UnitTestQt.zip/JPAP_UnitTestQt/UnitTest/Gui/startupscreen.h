/*
 * startupscreen.h
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_GUI_STARTUPSCREEN_H_
#define UNITTEST_GUI_STARTUPSCREEN_H_

#include "WM.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//extern WM_HWIN startupScreen;
void StartupScreenCallback(WM_MESSAGE * pMsg);
void StartupScreenInit(void);
void StartupScreenShow(void);
void StartupScreenHide(void);


#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_GUI_STARTUPSCREEN_H_ */
