/*
 * startupscreenTest.cpp
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "startupscreen.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern int testStartupScreenInit;

namespace EmbeddedCUnitTest {


class StartUpScreenTest : public TestFixture
{
public:
	StartUpScreenTest() : TestFixture(new ModuleMock) {}
};

TEST_F(StartUpScreenTest, StartupScreenCallback1)
{
	EXPECT_CALL(*_WMLib,WM_GetClientRect(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRect(_,_,_,_)).Times(1);

	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	StartupScreenCallback(&pMsg);
}

TEST_F(StartUpScreenTest, StartupScreenCallback2)
{
	EXPECT_CALL(*_WMLib,WM_DefaultProc(_)).Times(1);

	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT + 10;
	StartupScreenCallback(&pMsg);
}

TEST_F(StartUpScreenTest, StartupScreenInit)
{
	StartupScreenInit();

	EXPECT_EQ(1001,testStartupScreenInit);
}

TEST_F(StartUpScreenTest, StartupScreenShow)
{
	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_SetFocus(_)).Times(1);

	StartupScreenShow();
}

TEST_F(StartUpScreenTest, StartupScreenHide)
{
	EXPECT_CALL(*_WMLib,WM_HideWindow(_)).Times(1);

	StartupScreenHide();
}

}


