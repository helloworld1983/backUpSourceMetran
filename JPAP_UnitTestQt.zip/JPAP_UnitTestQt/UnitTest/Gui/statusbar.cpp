/*
 * statusbar.cpp
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */

#include "statusbar.h"

#include <setting.h>

//#include "bitmap.h"
//#include "GUI.h"
//#include "rtc.h"
//#include "stringtools.h"
//#include "debuguart.h"
//#include "fonts.h"
//#include "TEXT.h"
#include "mainscreen.h"
#include "WM.h"
#include "string.h"
#include "strings.h"
#include "guiglobal.h"
#include "RTCMocks.h"
#include "WMMocks.h"
#include "WString.h"
#include "SettingMocks.h"

//define parameters for status bar window
#define STAT_WINDOW_X		0
#define STAT_WINDOW_Y		2
#define STAT_WINDOW_SIZE_X	320
#define STAT_WINDOW_SIZE_Y	33

//define parameters for date text string
#define STAT_DATE_LABEL_X		75
#define STAT_DATE_LABEL_Y		5		//4
#define STAT_DATE_LABEL_SIZE_X	160
#define STAT_DATE_LABEL_SIZE_Y	23		//20

//define parameters for time text string
#define STAT_TIME_LABEL_X		220
#define STAT_TIME_LABEL_Y	5	//5
#define STAT_TIME_LABEL_SIZE_X	90
#define STAT_TIME_LABEL_SIZE_Y	23	//20

#define SD_ICON_X			10
#define SD_ICON_Y			0
#define SD_ICON_SIZE_X		18
#define SD_ICON_SIZE_Y		33

#define BLE_ICON_X			40
#define BLE_ICON_Y			0
#define BLE_ICON_SIZE_X		18
#define BLE_ICON_SIZE_Y		33

#define ERR_ICON_X			60
#define ERR_ICON_Y			0
#define ERR_ICON_SIZE_X		16
#define ERR_ICON_SIZE_Y		33

//#define STATUSBAR_DATE_COLOR	GUI_WHITE
//#define STATUSBAR_TIME_COLOR	GUI_WHITE


#if 1//SUPPORT_EVENT_DISPLAY
#define EVENT_LABEL_X		40
#define EVENT_LABEL_Y		5
#define EVENT_LABEL_SIZE_X	40
#define EVENT_LABEL_SIZE_Y	23

#define PHASE_LABEL_X		200
#define PHASE_LABEL_Y		5
#define PHASE_LABEL_SIZE_X	28
#define PHASE_LABEL_SIZE_Y	23

#endif


int testcbStatusBar = 0;
int testStatBarInit = 0;
int testStatusBarHandeEvent = 0;
RTC_TIME_Type testTimeStatusBar;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//label to display date
//static TEXT_Handle dateLabel;
//label to display time
//static TEXT_Handle timeLabel;
//status bar
//IMAGE_Handle statusBar;
//SD card icon
//static IMAGE_Handle statBarSDIcon;
//BLE icon
//static IMAGE_Handle statBarBLEIcon;
//ERR icon
//static IMAGE_Handle statBarErrIcon;

//event and phase label
#if SUPPORT_EVENT_DISPLAY
static TEXT_Handle eventLabel;
static TEXT_Handle phaseLabel;
#endif

//real time structure
//static RTC_TIME_Type realTimeInstance = {0};
//real time message
//static WM_MESSAGE msgUpateRealTime;

//extern GUI_CONST_STORAGE GUI_BITMAP statBarImageInfor;

// internal function declaration
//void StatBarDisplayTime();
//display date
//void DisplayDate(RTC_TIME_Type time);
//display time
//void DisplayTime(RTC_TIME_Type time);

//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: cbMainWindow()
//
//    Processing:		This operation is a function callback for status bar.
//						it check event come to status bar and re-draw status bar
//
//    Input Parameters: None
//
//    Output Parameters:None
//
//    Return Values:    None
//
//    Pre-Conditions:   None
//
//    Miscellaneous:    None
//
//    Requirements:
//
//******************************************************************************
#if 1//SUPPORT_EVENT_DISPLAY
void cbStatusBar(WM_MESSAGE * pMsg)
{
	switch (pMsg->MsgId) {
//	case WM_UPDATE_TIME:
//		//get time from message
//		StatBarDisplayTime((RTC_TIME_Type*)pMsg->Data.p);
//		break;
//	case WM_SHOW_SDICON:
//		IMAGE_SetBitmap(statBarSDIcon,&sdImageInfor);
//		WM_ShowWindow(statBarSDIcon);
//		break;
//	case WM_HIDE_SDICON:
//		WM_HideWindow(statBarSDIcon);
//		break;
//	case WM_SHOW_BLEICON:
//		WM_ShowWindow(statBarBLEIcon);
//		break;
//	case WM_HIDE_BLEICON:
//		WM_HideWindow(statBarBLEIcon);
//		break;
//	case WM_SHOW_ERRICON:
//		WM_ShowWindow(statBarErrIcon);
//		break;
//	case WM_SHOW_SD_ERROR_ICON:
//		IMAGE_SetBitmap(statBarSDIcon,&bmSdCardError);
//		WM_ShowWindow(statBarSDIcon);
//		break;
	case WM_NONE_EVENT:
		//set color as red
//		TEXT_SetBkColor(eventLabel, GUI_BLUE);
//		//set text as "NONE"
//		TEXT_SetText(eventLabel, "NONE");
		break;
	case WM_FL_EVENT:
		//set color as red
//		TEXT_SetBkColor(eventLabel, GUI_RED);
//		//set text as "NONE"
//		TEXT_SetText(eventLabel, "FL");
		break;
	case WM_H_EVENT:
		//set color as red
//		TEXT_SetBkColor(eventLabel, GUI_RED);
//		//set text as "NONE"
//		TEXT_SetText(eventLabel, "H");
		break;
	case WM_CA_EVENT:
		//set color as red
//		TEXT_SetBkColor(eventLabel, GUI_RED);
//		//set text as "NONE"
//		TEXT_SetText(eventLabel, "CA");
		break;
	case WM_OA_EVENT:
		//set color as red
//		TEXT_SetBkColor(eventLabel, GUI_RED);
//		//set text as "NONE"
//		TEXT_SetText(eventLabel, "OA");
		break;
	case WM_S_EVENT:
		//set color as red
//		TEXT_SetBkColor(eventLabel, GUI_RED);
//		//set text as "NONE"
//		TEXT_SetText(eventLabel, "S");
		break;
	case WM_SHOW_INH:
		//set color as red
//		TEXT_SetBkColor(phaseLabel, GUI_RED);
//		//set text as "INH"
//		TEXT_SetText(phaseLabel, "INH");
		break;
	case WM_SHOW_EXH:
		//set color as red
//		TEXT_SetBkColor(phaseLabel, GUI_BLUE);
//		//set text as "EXH"
//		TEXT_SetText(phaseLabel, "EXH");
		break;
	default:
//		IMAGE_Callback(pMsg);
		break;
	}

	testcbStatusBar = pMsg->MsgId;
}
#endif

//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: StatusBarHandeEvent()
//
//    Processing:		This operation handle event come to status bar.
//
//    Input Parameters: unsigned char eventId: event need to process
//
//    Output Parameters:None
//
//    Return Values:    None
//
//    Pre-Conditions:   None
//
//    Miscellaneous:    None
//
//    Requirements:
//
//******************************************************************************
void StatusBarHandeEvent(unsigned char eventId)
{
	switch(eventId)
	{
	case eGuiUpdateRtcId:
		//update date and time
		StatBarDisplayTime();
		break;
	case eGuiShowSdIconId:
		//set image as normal SD
//		IMAGE_SetBitmap(statBarSDIcon,&sdImageInfor);
		//show SD icon
		WM_ShowWindow(nullptr);//(statBarSDIcon);
		break;
	case eGuiHideSdIconId:
		//hide SD icon
		WM_HideWindow(nullptr);//(statBarSDIcon);
		break;
	case eGuiShowSdErrIconId:
		//set image as error SD icon
//		IMAGE_SetBitmap(statBarSDIcon,&bmSdCardError);
		//show error SD icon
		WM_ShowWindow(nullptr);//(statBarSDIcon);
		break;
	case eGuiShowBleIconId:
		//show bluetooth icon
		WM_ShowWindow(nullptr);//(statBarBLEIcon);
		break;
	case eGuiHideBleIconId:
		//hide bluetooth icon
		WM_HideWindow(nullptr);//(statBarBLEIcon);
		break;
	case eGuiShowErrIconId:
		//show error icon
		WM_ShowWindow(nullptr);//(statBarErrIcon);
		break;
	default:
		break;
	}

	testStatusBarHandeEvent = eventId + 1;
}

//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: StatBarInit()
//
//    Processing:		This operation create status bar object and its child.
//
//    Input Parameters: None
//
//    Output Parameters:None
//
//    Return Values:    None
//
//    Pre-Conditions:   None
//
//    Miscellaneous:    None
//
//    Requirements:
//
//******************************************************************************
void StatBarInit()
{
	//create window for status bar
//	statusBar = IMAGE_CreateEx(STAT_WINDOW_X, STAT_WINDOW_Y, STAT_WINDOW_SIZE_X, STAT_WINDOW_SIZE_Y, mainWindow, WM_CF_SHOW, 0/*IMAGE_CF_MEMDEV*/, GUI_ID_IMAGE4);
//	IMAGE_SetBitmap(statusBar,&statBarImageInfor);
#if SUPPORT_EVENT_DISPLAY
	WM_SetCallback(statusBar, cbStatusBar);
#endif

	//create SD icon image
//	statBarSDIcon = IMAGE_CreateEx(SD_ICON_X, SD_ICON_Y, SD_ICON_SIZE_X, SD_ICON_SIZE_Y, statusBar, WM_CF_HIDE, 0/*IMAGE_CF_MEMDEV*/, GUI_ID_IMAGE5);
//	IMAGE_SetBitmap(statBarSDIcon,&sdImageInfor);
	//create BLE icon image
//	statBarBLEIcon = IMAGE_CreateEx(BLE_ICON_X, BLE_ICON_Y, BLE_ICON_SIZE_X, BLE_ICON_SIZE_Y, statusBar, WM_CF_HIDE, 0/*IMAGE_CF_MEMDEV*/, GUI_ID_IMAGE6);
//	IMAGE_SetBitmap(statBarBLEIcon,&bleImageInfor);
	if(SettingGetMocks(eBluetoothSettingId) == eOn)
	{
		testStatBarInit = 100;
		WM_ShowWindow(nullptr);//(statBarBLEIcon);
	}
	else
	{
		testStatBarInit = 101;
		WM_HideWindow(nullptr);//(statBarBLEIcon);
	}
	//create ERR icon image
//	statBarErrIcon = IMAGE_CreateEx(ERR_ICON_X, ERR_ICON_Y, ERR_ICON_SIZE_X, ERR_ICON_SIZE_Y, statusBar, WM_CF_HIDE, 0/*IMAGE_CF_MEMDEV*/, GUI_ID_IMAGE7);
//	IMAGE_SetBitmap(statBarErrIcon, &bmerrorIcon);
//
//	//create text for date and time
//	dateLabel = TEXT_CreateEx(STAT_DATE_LABEL_X, STAT_DATE_LABEL_Y, STAT_DATE_LABEL_SIZE_X, STAT_DATE_LABEL_SIZE_Y,statusBar,WM_CF_SHOW, TEXT_CF_HCENTER, GUI_ID_TEXT11, "");
//	TEXT_SetFont(dateLabel,&GUI_FontJPAPJPFont14B);
//	TEXT_SetTextColor(dateLabel, STATUSBAR_DATE_COLOR);
//	//create text for date and time
//	timeLabel = TEXT_CreateEx(STAT_TIME_LABEL_X, STAT_TIME_LABEL_Y, STAT_TIME_LABEL_SIZE_X, STAT_TIME_LABEL_SIZE_Y,statusBar,WM_CF_SHOW, TEXT_CF_RIGHT, GUI_ID_TEXT12, "");
//	TEXT_SetFont(timeLabel,&GUI_FontJPAPJPFont14B);
//	TEXT_SetTextColor(timeLabel, STATUSBAR_TIME_COLOR);

#if SUPPORT_EVENT_DISPLAY
	//create text for event
	eventLabel = TEXT_CreateEx(EVENT_LABEL_X, EVENT_LABEL_Y, EVENT_LABEL_SIZE_X, EVENT_LABEL_SIZE_Y, statusBar, WM_CF_SHOW, TEXT_CF_HCENTER, GUI_ID_TEXT13, "NONE");
	TEXT_SetFont(eventLabel, &GUI_FontJPAPJPFont12B);
	TEXT_SetBkColor(eventLabel, GUI_BLUE);
	TEXT_SetTextColor(eventLabel, GUI_WHITE);
	TEXT_SetText(phaseLabel, "NONE");
	//create text for phase (Inh/Exh)
	phaseLabel = TEXT_CreateEx(PHASE_LABEL_X, PHASE_LABEL_Y, PHASE_LABEL_SIZE_X, PHASE_LABEL_SIZE_Y, statusBar, WM_CF_SHOW, TEXT_CF_HCENTER, GUI_ID_TEXT14, "EXH");
	TEXT_SetFont(phaseLabel, &GUI_FontJPAPJPFont12B);
	TEXT_SetBkColor(phaseLabel, GUI_BLUE);
	TEXT_SetTextColor(phaseLabel, GUI_WHITE);
	TEXT_SetText(phaseLabel, "EXH");
#endif
}


#if SUPPORT_EVENT_DISPLAY
void StatBarSetEventBkColor(GUI_COLOR color)
{
	TEXT_SetBkColor(eventLabel, color);
}
void StatBarSetEventText(const char* text)
{
	TEXT_SetText(eventLabel, text);
}
void StatBarSetPhaseBkColor(GUI_COLOR color)
{
	TEXT_SetBkColor(phaseLabel, color);
}
void StatBarSetPhaseText(const char* text)
{
	TEXT_SetText(phaseLabel, text);
}
#endif


//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: StatBarDisplayTime()
//
//    Processing:		This operation update RTC clock on status bar when RTC changed
//
//    Input Parameters: RTC_TIME_Type time: current time
//
//    Output Parameters:None
//
//    Return Values:    None
//
//    Pre-Conditions:   None
//
//    Miscellaneous:    None
//
//    Requirements:
//
//******************************************************************************
void StatBarDisplayTime()
{
	RTC_TIME_Type time = RTCGetMocks();
	//display date
	DisplayDate(time);
	//display time
	DisplayTime(time);
}

//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: StatBarDisplayTime()
//
//    Processing:		This operation update year, month,date when the RTC changed
//
//    Input Parameters: RTC_TIME_Type time: current time
//
//    Output Parameters:None
//
//    Return Values:    None
//
//    Pre-Conditions:   None
//
//    Miscellaneous:    None
//
//    Requirements:
//
//******************************************************************************
void DisplayDate(RTC_TIME_Type time)
{
	char temp[40] = {'\0'};			//maximum 20 characters
	int index = 0;

	if(language == eEnglish)
	{
		//date of month was changed, should update it on status bar
		//put day on the array
		int month = time.MONTH;
		month = (month > 12)?12:((month < 1)?1:month);
		StrAppend(temp, monthStrEng[month - 1], 20);
		index += 3;				//ship 3 characters
		temp[index++] = ' ';	//insert space
		//put date
		int date = time.DOM;
		date = (date > 31)?31:((date < 1)?1:date);
		StrToolItoA(date, &temp[index], 2);
		index += 2;		//ship 2 characters
		//insert ','
		temp[index++] = ',';
		temp[index++] = ' ';
		//put year
		int year = time.YEAR;
		StrToolItoA(year, &temp[index], 4);
		//set text
//		TEXT_SetFont(dateLabel,&GUI_FontJPAPJPFont14B);
//		TEXT_SetText(dateLabel, (const char*)&temp[0]);
	}
	else
	{
		//date of month was changed, should update it on status bar
		//put year
		int year = time.YEAR;
		StrToolItoA(year, &temp[index], 4);
		index += 4;		//ship 4 characters
		StrAppend(temp, strYear, 20);
		index += 3;		//ship 3 characters
		//put month
		int month = time.MONTH;
		StrToolItoA(month, &temp[index], 2);
		index += 2;		//ship 2 characters
		StrAppend(temp, strMonth, 20);
		index += 3;		//ship 3 characters
		//put date
		int date = time.DOM;
		date = (date > 31)?31:((date < 1)?1:date);
		StrToolItoA(date, &temp[index], 2);
		index += 2;		//ship 2 characters
		StrAppend(temp, strDate, 20);
		//set text
//		TEXT_SetFont(dateLabel,&GUI_FontMeiryo14B_2bpp);
//		TEXT_SetText(dateLabel, (const char*)&temp[0]);
	}
}

//******************************************************************************
//$COMMON.OPERATION$
//    Operation Name: StatBarDisplayTime()
//
//    Processing:		This operation update minute and hour when the RTC changed
//
//    Input Parameters: RTC_TIME_Type time: current time
//
//    Output Parameters:None
//
//    Return Values:    None
//
//    Pre-Conditions:   None
//
//    Miscellaneous:    None
//
//    Requirements:
//
//******************************************************************************
void DisplayTime(RTC_TIME_Type time)
{
	char temp[40] = {'\0'};		//maximum 20 characters
	int index = 0;

	if(language == eEnglish)
	{
		//put hour
		const char* ampm = strAm[1];
		int hour = time.HOUR;

		if(time.HOUR == 0){
			hour = 12;
			ampm = strAm[1];
		}
		else if((time.HOUR >= 1)&&(time.HOUR <= 11)){
			hour = time.HOUR;
			ampm = strAm[1];
		}
		else if(time.HOUR == 12){
			ampm = strPm[1];
		}
		else if((time.HOUR >= 13) && (time.HOUR <= 23)){
			hour = time.HOUR - 12;
			ampm = strPm[1];
		}

		testTimeStatusBar.HOUR = hour;//Add test

		StrToolItoA(hour, &temp[index], 2);
		index += 2;
		//insert ':'
		temp[index++] = ':';
		//put minute
		int minute = time.MIN;
		StrToolItoA(minute, &temp[index], 2);
		index += 2;
		temp[index++] = ' ';	//insert space
		//insert AM or PM
		StrAppend(temp, ampm, 20);
		index += 2;
//		TEXT_SetFont(timeLabel, &GUI_FontJPAPJPFont14B);
//		TEXT_SetText(timeLabel, (const char*)&temp[0]);
	}
	else
	{
		const char* ampm = strAm[0];
//		char temp[20] = {'\0'};			//maximum 20 characters
//		int index = 0;
		index = 0;	//reset index
		//put hour
		int hour = time.HOUR;

		if(time.HOUR == 0)
		{
			hour = 12;
			ampm = strAm[0];
		}
		else if((time.HOUR >= 1)&&(time.HOUR <= 11))
		{
			hour = time.HOUR;
			ampm = strAm[0];
		}
		else if(time.HOUR == 12)
		{
			ampm = strPm[0];
		}
		else if((time.HOUR >= 13) && (time.HOUR <= 23))
		{
			hour = time.HOUR - 12;
			ampm = strPm[0];
		}

		testTimeStatusBar.HOUR = hour;//Add test

		StrAppend(temp, ampm, 20);
		index += 6;
		StrToolItoA(hour, &temp[index], 2);
		index += 2;		//ship 2 characters
		temp[index++] = ':';
		//put minute
		int min = time.MIN;
		StrToolItoA(min, &temp[index], 2);

		//set text
//		TEXT_SetFont(timeLabel,&GUI_FontMeiryo14B_2bpp);
//		TEXT_SetText(timeLabel, (const char*)&temp[0]);
	}
}

//static GUI_CONST_STORAGE unsigned char statBarImageData[] = {
//		/* RLE: 320 Pixels @ 000,000*/ 254, 0xC2, 0x82, 66, 0xC2, 0x82,
//		/* RLE: 320 Pixels @ 000,001*/ 254, 0xC2, 0x7A, 66, 0xC2, 0x7A,
//		/* RLE: 320 Pixels @ 000,002*/ 254, 0xA2, 0x7A, 66, 0xA2, 0x7A,
//		/* RLE: 320 Pixels @ 000,003*/ 254, 0xA2, 0x72, 66, 0xA2, 0x72,
//		/* RLE: 320 Pixels @ 000,004*/ 254, 0x82, 0x72, 66, 0x82, 0x72,
//		/* RLE: 320 Pixels @ 000,005*/ 254, 0x62, 0x72, 66, 0x62, 0x72,
//		/* RLE: 320 Pixels @ 000,006*/ 254, 0x62, 0x6A, 66, 0x62, 0x6A,
//		/* RLE: 320 Pixels @ 000,007*/ 254, 0x41, 0x6A, 66, 0x41, 0x6A,
//		/* RLE: 320 Pixels @ 000,008*/ 254, 0x21, 0x6A, 66, 0x21, 0x6A,
//		/* RLE: 320 Pixels @ 000,009*/ 254, 0x21, 0x62, 66, 0x21, 0x62,
//		/* RLE: 640 Pixels @ 000,010*/ 254, 0x01, 0x62, 254, 0x01, 0x62, 132, 0x01, 0x62,
//		/* RLE: 320 Pixels @ 000,012*/ 254, 0xE1, 0x59, 66, 0xE1, 0x59,
//		/* RLE: 640 Pixels @ 000,013*/ 254, 0xC1, 0x59, 254, 0xC1, 0x59, 132, 0xC1, 0x59,
//		/* RLE: 320 Pixels @ 000,015*/ 254, 0xA1, 0x51, 66, 0xA1, 0x51,
//		/* RLE: 320 Pixels @ 000,016*/ 254, 0xA0, 0x51, 66, 0xA0, 0x51,
//		/* RLE: 320 Pixels @ 000,017*/ 254, 0x81, 0x51, 66, 0x81, 0x51,
//		/* RLE: 320 Pixels @ 000,018*/ 254, 0x60, 0x49, 66, 0x60, 0x49,
//		/* RLE: 320 Pixels @ 000,019*/ 254, 0x61, 0x49, 66, 0x61, 0x49,
//		/* RLE: 320 Pixels @ 000,020*/ 254, 0x40, 0x49, 66, 0x40, 0x49,
//		/* RLE: 320 Pixels @ 000,021*/ 254, 0x40, 0x41, 66, 0x40, 0x41,
//		/* RLE: 640 Pixels @ 000,022*/ 254, 0x20, 0x41, 254, 0x20, 0x41, 132, 0x20, 0x41,
//		/* RLE: 640 Pixels @ 000,024*/ 254, 0x00, 0x41, 254, 0x00, 0x41, 132, 0x00, 0x41,
//		/* RLE: 320 Pixels @ 000,026*/ 254, 0x20, 0x41, 66, 0x20, 0x41,
//		/* RLE: 320 Pixels @ 000,027*/ 254, 0x60, 0x49, 66, 0x60, 0x49,
//		/* RLE: 320 Pixels @ 000,028*/ 254, 0x80, 0x51, 66, 0x80, 0x51,
//		/* RLE: 320 Pixels @ 000,029*/ 254, 0xC0, 0x59, 66, 0xC0, 0x59,
//		/* RLE: 320 Pixels @ 000,030*/ 254, 0xE0, 0x61, 66, 0xE0, 0x61,
//		/* RLE: 320 Pixels @ 000,031*/ 254, 0x20, 0x6A, 66, 0x20, 0x6A,
//		/* RLE: 320 Pixels @ 000,032*/ 254, 0x40, 0x72, 66, 0x40, 0x72,
//
//
//		0
//};  // 96 for 10240 pixels
//
//GUI_CONST_STORAGE GUI_BITMAP statBarImageInfor = {
//		320, /* XSize */
//		33, /* YSize */
//		640, /* BytesPerLine */
//		16, /* BitsPerPixel */
//		(unsigned char *)statBarImageData,  /* Pointer to picture data */
//		NULL,  /* Pointer to palette */
//		GUI_DRAW_RLE16
//};


#if defined(__cplusplus)
}
#endif
