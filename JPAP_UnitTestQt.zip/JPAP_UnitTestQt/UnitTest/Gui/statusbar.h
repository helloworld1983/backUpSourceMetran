/*
 * statusbar.h
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_GUI_STATUSBAR_H_
#define UNITTEST_GUI_STATUSBAR_H_

#include "WM.h"
#include "RTCMocks.h"

#if 1//SUPPORT_EVENT_DISPLAY
//define show phase text
#define WM_SHOW_INH		(WM_USER + 25)
//define hide phase text
#define WM_SHOW_EXH		(WM_USER + 26)
//define none event text
#define WM_NONE_EVENT	(WM_USER + 27)
//define FL event text
#define WM_FL_EVENT		(WM_USER + 28)
//define Hypo event text
#define WM_H_EVENT		(WM_USER + 29)
//define CA event text
#define WM_CA_EVENT		(WM_USER + 30)
//define OA event text
#define WM_OA_EVENT		(WM_USER + 31)
//define snore event text
#define WM_S_EVENT		(WM_USER + 32)

#endif

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//status bar instance
//extern IMAGE_Handle statusBar;

void cbStatusBar(WM_MESSAGE * pMsg);
void StatBarDisplayTime();
void DisplayDate(RTC_TIME_Type time);
void DisplayTime(RTC_TIME_Type time);
//function to create status bar object and its child
void StatBarInit();

//function to handle event send to status bar
void StatusBarHandeEvent(unsigned char eventId);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_STATUSBAR_H_ */
