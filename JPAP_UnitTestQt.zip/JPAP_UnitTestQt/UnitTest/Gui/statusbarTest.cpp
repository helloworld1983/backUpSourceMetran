/*
 * statusbarTest.cpp
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "statusbar.h"

#include <guiinterface.h>
#include <setting.h>

#include "guiglobal.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern int testcbStatusBar;
extern int testStatBarInit;
extern int testStatusBarHandeEvent;
extern RTC_TIME_Type testTimeStatusBar;

namespace EmbeddedCUnitTest {


class StatusBarTest : public TestFixture
{
public:
	StatusBarTest() : TestFixture(new ModuleMock) {}
};

TEST_F(StatusBarTest, cbStatusBar1)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_NONE_EVENT;
	cbStatusBar(&pMsg);

	EXPECT_EQ(WM_NONE_EVENT,testcbStatusBar);
}

TEST_F(StatusBarTest, cbStatusBar2)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_FL_EVENT;
	cbStatusBar(&pMsg);

	EXPECT_EQ(WM_FL_EVENT,testcbStatusBar);
}

TEST_F(StatusBarTest, cbStatusBar3)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_H_EVENT;
	cbStatusBar(&pMsg);

	EXPECT_EQ(WM_H_EVENT,testcbStatusBar);
}

TEST_F(StatusBarTest, cbStatusBar4)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_CA_EVENT;
	cbStatusBar(&pMsg);

	EXPECT_EQ(WM_CA_EVENT,testcbStatusBar);
}

TEST_F(StatusBarTest, cbStatusBar5)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_OA_EVENT;
	cbStatusBar(&pMsg);

	EXPECT_EQ(WM_OA_EVENT,testcbStatusBar);
}

TEST_F(StatusBarTest, cbStatusBar6)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_S_EVENT;
	cbStatusBar(&pMsg);

	EXPECT_EQ(WM_S_EVENT,testcbStatusBar);
}

TEST_F(StatusBarTest, cbStatusBar7)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_SHOW_INH;
	cbStatusBar(&pMsg);

	EXPECT_EQ(WM_SHOW_INH,testcbStatusBar);
}

TEST_F(StatusBarTest, cbStatusBar8)
{
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_SHOW_EXH;
	cbStatusBar(&pMsg);

	EXPECT_EQ(WM_SHOW_EXH,testcbStatusBar);
}

TEST_F(StatusBarTest, StatusBarHandeEvent1)
{
	StatusBarHandeEvent(eGuiUpdateRtcId);

	EXPECT_EQ(eGuiUpdateRtcId + 1,testStatusBarHandeEvent);
}

TEST_F(StatusBarTest, StatusBarHandeEvent2)
{
	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(1);

	StatusBarHandeEvent(eGuiShowSdIconId);

	EXPECT_EQ(eGuiShowSdIconId + 1,testStatusBarHandeEvent);
}

TEST_F(StatusBarTest, StatusBarHandeEvent3)
{
	StatusBarHandeEvent(eGuiHideSdIconId);

	EXPECT_EQ(eGuiHideSdIconId + 1,testStatusBarHandeEvent);
}

TEST_F(StatusBarTest, StatusBarHandeEvent4)
{
	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(1);

	StatusBarHandeEvent(eGuiShowSdErrIconId);

	EXPECT_EQ(eGuiShowSdErrIconId + 1,testStatusBarHandeEvent);
}

TEST_F(StatusBarTest, StatusBarHandeEvent5)
{
	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(1);

	StatusBarHandeEvent(eGuiShowBleIconId);

	EXPECT_EQ(eGuiShowBleIconId + 1,testStatusBarHandeEvent);
}

TEST_F(StatusBarTest, StatusBarHandeEvent6)
{
	StatusBarHandeEvent(eGuiHideBleIconId);

	EXPECT_EQ(eGuiHideBleIconId + 1,testStatusBarHandeEvent);
}

TEST_F(StatusBarTest, StatusBarHandeEvent7)
{
	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(1);

	StatusBarHandeEvent(eGuiShowErrIconId);

	EXPECT_EQ(eGuiShowErrIconId + 1,testStatusBarHandeEvent);
}

TEST_F(StatusBarTest, StatBarInit1)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eBluetoothSettingId)).Times(1).WillOnce(Return(eOn));
	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(1);

	StatBarInit();

	EXPECT_EQ(100,testStatBarInit);
}

TEST_F(StatusBarTest, StatBarInit2)
{
	EXPECT_CALL(*_settingLib,SettingGetMocks(eBluetoothSettingId)).Times(1).WillOnce(Return(eOff));

	StatBarInit();

	EXPECT_EQ(101,testStatBarInit);
}

TEST_F(StatusBarTest, StatBarDisplayTime)
{
	EXPECT_CALL(*_RTCLib,RTCGetMocks()).Times(1);

	StatBarDisplayTime();
}

TEST_F(StatusBarTest, DisplayDate1)
{
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,4)).Times(1);

	language = 1;
	RTC_TIME_Type time1;
	DisplayDate(time1);
}

TEST_F(StatusBarTest, DisplayDate2)
{
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(3);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,4)).Times(1);

	language = 0;
	RTC_TIME_Type time1;
	DisplayDate(time1);
}

TEST_F(StatusBarTest, DisplayTime1)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);

	RTC_TIME_Type time1;
	time1.HOUR = 0;
	language = 1;
	DisplayTime(time1);

	EXPECT_EQ((uint32_t)12,testTimeStatusBar.HOUR);
}

TEST_F(StatusBarTest, DisplayTime2)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);

	RTC_TIME_Type time1;
	time1.HOUR = 5;
	language = 1;
	DisplayTime(time1);

	EXPECT_EQ((uint32_t)5,testTimeStatusBar.HOUR);
}

TEST_F(StatusBarTest, DisplayTime3)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);

	RTC_TIME_Type time1;
	time1.HOUR = 12;
	language = 1;
	DisplayTime(time1);

	EXPECT_EQ((uint32_t)12,testTimeStatusBar.HOUR);
}

TEST_F(StatusBarTest, DisplayTime4)
{
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);

	RTC_TIME_Type time1;
	time1.HOUR = 16;
	language = 1;
	DisplayTime(time1);

	EXPECT_EQ((uint32_t)4,testTimeStatusBar.HOUR);
}

TEST_F(StatusBarTest, DisplayTime5)
{
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);

	RTC_TIME_Type time1;
	time1.HOUR = 0;
	language = 0;
	DisplayTime(time1);

	EXPECT_EQ((uint32_t)12,testTimeStatusBar.HOUR);
}

TEST_F(StatusBarTest, DisplayTime6)
{
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);

	RTC_TIME_Type time1;
	time1.HOUR = 8;
	language = 0;
	DisplayTime(time1);

	EXPECT_EQ((uint32_t)8,testTimeStatusBar.HOUR);
}

TEST_F(StatusBarTest, DisplayTime7)
{
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);

	RTC_TIME_Type time1;
	time1.HOUR = 12;
	language = 0;
	DisplayTime(time1);

	EXPECT_EQ((uint32_t)12,testTimeStatusBar.HOUR);
}

TEST_F(StatusBarTest, DisplayTime8)
{
	EXPECT_CALL(*_wstring,StrAppend(_,_,20)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,2)).Times(2);

	RTC_TIME_Type time1;
	time1.HOUR = 23;
	language = 0;
	DisplayTime(time1);

	EXPECT_EQ((uint32_t)11,testTimeStatusBar.HOUR);
}

}


