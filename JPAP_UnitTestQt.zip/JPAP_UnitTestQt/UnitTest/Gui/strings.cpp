/*
 * strings.cpp
 *
 *  Created on: Apr 10, 2018
 *      Author: QUOCVIET
 */

#include "string.h"

//#if defined(__cplusplus)
//namespace EmbeddedC {
//#endif

const char* strDate = "日";
const char* strMonth = "月";
const char* strYear = "年";
const char* strPleaseWait[] = { "お待ちください", "Please wait..."};								//Please wait...
const char* strYes[] = { "はい", "Yes" };														//YES
const char* strNo[] = { "いいえ", "No" };														//NO
const char* strDoCircuitCalibration[] = {  "補正を開始しますか?", "Calibrate circuit?"}; 		//Do circuit calibration?
const char* strDoingCalibration[] = { "呼吸回路補正中", "Calibrating"};						//Doing calibration
const char* strCalibrationDone[] = { "補正完了", "Done!"};									//Done!
const char* strCalibrationError[] = { "補正エラー", "Calibrate error"};									//Done!
const char* strConnectTheMask[] = { "マスクを回路に接続？", "Connect the mask?"};									//Done!
const char* strDark[] = { "暗", "Dark"};														//Dark
const char* strBright[] = { "明", "Bright" };												//Bright
const char* strJapanese[] = { "日本語", "Japanese" };										//Japanese
const char* strEnglish[] = { "英語", "English" };											//English
const char* strType1[] = { "E-タイプ", "E-type" };												//Type 1
const char* strType2[] = { "S-タイプ", "S-type" };												//Type 2
const char* strMin[] = { "分", "min." };														//minute
const char* strInhalationSupport[] = { "吸気補助", "Inhalation support" };							//Inhalation Support
const char* strExhalationSupport[] = { "呼気補助", "Exhalation support" };							//Exhalation Support
const char* strRampTime[] = { "ランプ時間", "Ramp time" };										//Ramp Time
const char* strBrightness[] = { "輝度調整", "Brightness" };									//Brightness
const char* strLanguge[] = { "言語設定", "Language" };										//Language
const char* strVentilationMode[] = { "換気モード", "Ventilation mode" };						//Ventilation Mode
const char* strTreatPressure[] = { "治療圧", "Treat pressure" };								//Treat Pressure
const char* strUpperLimit[] = { "上限圧", "High press. limit" };								//Upper Limit
const char* strLowerLimit[] = { "下限圧", "Low press. limit" };								//Lower Limit
const char* strBluetooth[] = { "ブルートゥース", "Bluetooth" };									//Bluetooth
const char* strInitialPressure[] = { "初期圧", "Initial pressure" };							//Initial Pressure
const char* strChangeUnit[] = { "圧力単位切替", "Unit option" };								//Change Unit
const char* strDisplayOffTimer[] = { "表示オフタイマー設定", "Screen timeout" };					//Display OFF Timer
const char* strNsType[] = { "NSタイプ", "NS type" };											//natural support type
const char* strDateTime[] = { "日時設定", "Date & time" };									//Date & Time
const char* strAutoOff[] = { "Auto OFF", "Auto OFF" };
const char* strFL[] = { "FL", "FL" };
const char* strCircuitType[] = { "乾燥モード", "Drying mode" };
const char* strOthers[] = { "その他", "Others" };
const char* strQE[] = { "QE", "QE" };
/****************************CONFIRM BUTTON*****************************************/
const char* strReset[] = { "設定初期化", "Restore defaults" };								//Reset setting
const char* strCircuitCalibration[] = { "呼吸回路補正", "Circuit calibration" };				//Circuit Calibration
const char* strCircuitCalibrationWOMask[] = { "呼吸回路補正", "Circuit calibration without mask" };				//Circuit Calibration
const char* strResetTimeUsing[] = { "運転時間リセット", "Clear used hours" };					//Reset Time Using
const char* strMainUnitUpgrade[] = { "メインソフト更新", "Control unit upgrade" };				//Control Unit Upgrade
const char* strBlowerUpgrade[] = { "ブロアソフト更新", "Blower unit upgrade" };					//Blower Unit Upgrade
const char* strBLEUnitUpgrade[] = { "ブルートゥース更新", "Bluetooth upgrade" };
const char* strExportToCSVFile[] = { "システムログ転送", "Export system log" };					//Blower Unit Upgrade
const char* strDryingMode[] = { "乾燥モード", "Drying mode"};
const char* strSystemInformation[] = { "デバイス情報", "Device information" };					//System Information
const char* strTotalTime[] = { "運転時間", "Used hours" };									//Total Time (hours)
const char* strMainUnitVersion[] = { "メインバージョン", "Control unit version" };				//Control Unit Version
const char* strBlowerUnitVersion[] = { "ブロアバージョン", "Blower unit version" };				//Blower Unit Version
const char* strSerialNumber[] = { "シリアル", "Serial number" };							//Serial Number
const char* strDoResetTimeUsing[] = { "運転時間リセット?", "Clear used time?" };					//Clear Used Time?
const char* strResetSetting[] = { "初期化しますか?", "Restore defaults?" };						//Restore Setting
const char* upgradeMainUnitStr[] = { "メイン更新しますか?", "Control unit upgrade?" };			//Upgrade Control Unit
const char* upgradeBlowerUnitStr[] = { "ブロア更新しますか?", "Blower unit upgrade?" };			//Upgrade Blower Unit
const char* upgradeBLEUnitStr[] = { "BTソフト更新しますか？", "Bluetooth upgrade?" };			//Upgrade Blower Unit
const char* exportLogStr[] = { "システムログ転送?", "Export system log?" };				//Upgrade Blower Unit
const char* resetDoneStr[] = { "初期化完了！", "Done!" };										//Done!
const char* strSavingData[] = { "書込み中", "Saving data..."};								//Saving Data...
const char* strUpgradeError[] = { "更新エラー!", "Upgrade error!" };							//Upgrade Error
const char* strUpgradeBlowerUnit[] = { "アップデート中", "Upgrading blower unit" };				//Upgrading Blower Unit
const char* strUpgradebleUnit[] = { "BTソフト更新中", "Upgrading Bluetooth" };				//Upgrading Blower Unit
const char* strUpgradeSuccess[] = { "更新成功", "Upgrade successfully!" };					//Upgrade Successfully
const char* strExportSuccess[] = { "転送正常終了", "Export successfully!" };
const char* strExportFail[] = { "転送エラー", "Export fail!" };
const char* strRamp[] = { "ランプ", "Ramp" };													//Ramp
const char* strHome[] = { "戻る", "Home" };													//Home
const char* strPatientSetting[] = { "ユーザー設定", "User setting" };							//Patient Setting
const char* strHealthcareWorker[] = { "医療従事者設定画面", "Clinician menu" };				//Healthcare worker
const char* strMaintenance[] = { "工場設定画面", "Factory option" };							//Maintenance
const char* strHistory[] = { "システムログ", "System log" };									//History
const char* strSaveTime[] = { "設定を保存しますか?", "Save date & time?" };						//Save Time?
const char* strAm[] = { "午前", "AM" };														//AM
const char* strPm[] = { "午後", "PM" };														//PM
const char* monthStrEng[] = { "Jan", "Feb",	"Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
const char* monthStrJap[] = { "1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月" };
const char* strCpap = "CPAP";				//string CPAP
const char* autoCpapStr = "AUTO\n\rCPAP";	//string AUTO CPAP
const char* unitStr[] = { "cmH²O", "hPa" };	//pressure unit string
const char* strLogUnit[] = { "cmH2O", "hPa" };	//pressure unit string
const char* strOnOff[] = { "OFF", "ON" };
const char* strInh[] = { "吸気:", "Inh:" };
const char* strExh[] = { "呼気:", "Exh:" };
const char* strStarting[] = { "送気開始", "STARTING..."};
const char* strDrying[] = {"乾燥中", "DRYING..."};

//---------------------ALARM STRING-------------------------------------------
//const char* strAlarm[] = { "警告", "Alarm"};
const char* strError[] = { "エラー", "ERROR"};
const char* strWarning[] = {"警告", "WARNING"};
const char* strBlowerAlarm[] = { "ブロア異常", "Blower error" };							//blower alarm
const char* strPressSensorAlarm[] = { "圧力センサー異常", "P-sensor error" };				//pressure sensor alarm
const char* strFlowSensorAlarm[] = { "流用センサー異常", "F-sensor error" };				//flow sensor alarm
const char* strPowerSupplyAlarm[] = { "供給電源遮断", "Power supply lost" };					//power supply alarm
const char* strMediaAlarm[] = { "メモリー異常", "SD card error" };							//media alarm
const char* strLeak[] = { "リーク", "Mask leak" };											//leak
const char* strResettingBlowerUnit[] = { "ブロアユニットリセット中", "Resetting blower unit..." };
const char* strResettingBLEUnit[] = { "BTをリセット中", "Resetting Bluetooth unit..." };
const char* strPressEnterToConfirm[] = { "ENTERキーで確認", "Press ENTER to confirm" };
const char* strPleaseContactTheManufacturer[] = {"製造発売元に問合せ", "Please contact the manufacturer" };
const char* strCannotDetectSdCard[] = { "メモリーカードがありません", "Cannot detect SD card"};
const char* strPowerSuddenlyOffLastTime[] = { "前回異常終了", "Power suddenly off last time"};
//const char* strTheMaskLeaks[] = { "The mask leaks", "The mask leaks" };
const char* strPleasePutTheMaskOn[] = { "マスクを(正しく)装着してください", "Please put the mask on"};

//-----------------------LOG STRING-----------------------------
const char* strNumOrder = "No.";
const char* strTime[] = { "時間", "Time" };
const char* strEvent[] = { "イベント", "Event" };
const char* strMode[] = { "モード:", "Mode: " };
const char* strCpapAutoCpap[] = {"CPAP", "AutoCPAP"};
const char* strTreatmenPress[] = { "治療圧:", "Treat P.: " };
const char* strInitPress[] = { "初期圧:", "Init press: "};
const char* strExhSupport[] = { "呼気補助:L", "Exh support: L"};
const char* strInhSupport[] = { "吸気補助:L", "Inh support: L"};
const char* strHighPressLimit[] = { "上限圧:", "High P.: "};
const char* strLowPressLimit[] = { "下限圧:", "Low P.: " };
const char* strPowerOn[] = {"電源ON", "Power ON"};
const char* strPowerOff[] = {"電源OFF", "Power OFF"};

const char* strAutoStart[] = {"自動開始", "Auto start"};
const char* strManualStart[] = {"手動開始", "Manual start"};
const char* strAutoOFF[] = { "Auto OFF", "Auto OFF" };
const char* strStrongDrying[] = { "強乾燥開始", "Strong drying" };
const char* strWeakDrying[] = { "弱乾燥開始", "Weak drying" };
const char* strAutoStop[] = { "自動停止", "Auto stop"};
const char* strCompleteDrying[] = { "乾燥終了", "Complete drying"};
const char* strManualStop[] = { "手動オフ", "OFF by key" };
const char* strInterruptionDrying[] = { "乾燥中断", "Interruption of drying" };
const char* strMaskOnAfterAirLeak[] = { "マスク装着後リーク", "Mask on after air leak"};

const char* strMaskOff[] = { "マスク解除", "Mask OFF" };
const char* strMaskOn[] = { "マスク装着", "Mask ON" };
const char* strSnore[] = { "いびき検知", "Snore detected" };
const char* strHyponea[] = { "低呼吸検知", "H detected" };
const char* strFl[] = { "気道狭窄検知", "FL detected" };
const char* strOa[] = { "OA検知", "OA detected" };
const char* strCa[] = { "CA検知", "CA detected" };
const char* strCsr[] = { "CSR検知", "CSR detected" };
const char* strNormalBreath[] = { "正常呼吸検知", "Normal breath detected" };
const char* strControlVer[] = { "メイン:ver", "Control: ver"};
const char* strBlowerVer[] = { "ブロア:ver", "Blower: ver"};
const char* strSdCard[] = { "SD:", "SD card: "};
const char* strInsert[] = { "挿入", "Insert" };
const char* strEject[] = { "取出", "Eject" };
const char* strAlarm[] = { "警報:", "Alarm: "};
const char* strChangeDateTime[] = { "時間変更", "Change time" };
const char* strTimeoutLog[] = { "表示タイマー", "Screen timeout" };
const char* strAutoOffAfter[] = { "終了まで", "" };
//const char* strHours[] = { "hour(s)", "hour(s)" };
const char* strMinutes[] = { "分", " minute(s) remaining"};
const char* strPressToTurnOff[] = {  "^でストップ可能", "Press O to stop" };
const char* strInsertSDCard[] = { "SDカード挿入", "Insert SD card" };
const char* strRemoveSDCard[] = { "SDカード抜去", "Remove SD card" };
//const char* strConnect[] = { "Connect?", "Connect?" };
//const char* strDisconnect[] = { "Disconnect?", "Disconnect?" };
//const char* strBLEConnectFailed[] = { "Connect failed", "Connect failed" };
//const char* strBLEConnectSuccess[] = { "Connect Successfully!", "Connect Successfully!" };
const char* strAreYouSure[] = { "乾燥しますか?", "Do drying mode?" };
const char* strPreparation[] = { "準備", "Preparation" };
const char* strPreparationContent[] = { "乾燥準備できましたか?","Ready for Drying?" };
//const char* strPreparationContent[] = { "1. 給水チューブコネクタを外す\n2. Hummax QEマスク接続\n部に乾燥キャップを被せる","1. Disconnect water tube\nconnecter\n2. Connect drying cap to\nHummax QE mask connecter" };
const char* strInspection[] = { "点検", "Inspection"};
const char* strAirIsLeaking[] = { "空気が漏れています", "Air is leaking" };
const char* strPressOnOffToStandby[] = { "^でストップ可能", "Press O to stop"};

//#if defined(__cplusplus)
//}
//#endif


