/*
 * strings.h
 *
 *  Created on: Apr 10, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_GUI_STRINGS_H_
#define UNITTEST_GUI_STRINGS_H_


//#if defined(__cplusplus)
//namespace EmbeddedC {
//#endif

extern const char* strDate;
extern const char* strMonth;
extern const char* strYear;
extern const char* strPleaseWait[];
extern const char* strYes[];
extern const char* strNo[];
extern const char* strDoCircuitCalibration[];
extern const char* strDoingCalibration[];
extern const char* strCalibrationDone[];
extern const char* strDark[];
extern const char* strBright[];
extern const char* strJapanese[];
extern const char* strEnglish[];
extern const char* strMin[];
extern const char* strInhalationSupport[];
extern const char* strExhalationSupport[];
extern const char* strRampTime[];
extern const char* strBrightness[];
extern const char* strLanguge[];
extern const char* strVentilationMode[];
extern const char* strTreatPressure[];
extern const char* strUpperLimit[];
extern const char* strLowerLimit[];
extern const char* strBluetooth[];
extern const char* strInitialPressure[];
extern const char* strChangeUnit[];
extern const char* strDisplayOffTimer[];
extern const char* strDateTime[];
extern const char* strReset[];
extern const char* strCircuitCalibration[];
extern const char* strResetTimeUsing[];
extern const char* strMainUnitUpgrade[];
extern const char* strBlowerUpgrade[];
extern const char* strBLEUnitUpgrade[];
extern const char* strSystemInformation[];
extern const char* strTotalTime[];
extern const char* strMainUnitVersion[];
extern const char* strBlowerUnitVersion[];
extern const char* strSerialNumber[];
extern const char* strDoResetTimeUsing[];
extern const char* strResetSetting[];
extern const char* upgradeMainUnitStr[];
extern const char* upgradeBlowerUnitStr[];
extern const char* resetDoneStr[];
extern const char* strSavingData[];
extern const char* strUpgradeError[];
extern const char* strUpgradeBlowerUnit[];
extern const char* strUpgradeSuccess[];
extern const char* strRamp[];
extern const char* strHome[];
extern const char* strPatientSetting[];
extern const char* strHealthcareWorker[];
extern const char* strMaintenance[];
extern const char* strHistory[];
extern const char* strSaveTime[];
extern const char* strAm[];
extern const char* strPm[];
extern const char* monthStrEng[];
extern const char* strCpap;
extern const char* autoCpapStr;
extern const char* unitStr[];
extern const char* strNsType[];
extern const char* strType1[];
extern const char* strType2[];
extern const char* monthStrJap[];
extern const char* strInh[];
extern const char* strExh[];
extern const char* strStarting[];
extern const char* strDrying[];
extern const char* strError[];
extern const char* strBlowerAlarm[];
extern const char* strPressSensorAlarm[];
extern const char* strFlowSensorAlarm[];
extern const char* strPowerSupplyAlarm[];
extern const char* strMediaAlarm[];
extern const char* strLeak[];
extern const char* strResettingBlowerUnit[];
extern const char* strWarning[];
extern const char* strPressEnterToConfirm[];
extern const char* strPleaseContactTheManufacturer[];
extern const char* strCannotDetectSdCard[];
extern const char* strPowerSuddenlyOffLastTime[];
extern const char* strTheMaskLeaks[];
extern const char* strPleasePutTheMaskOn[];
extern const char* strNumOrder;
extern const char* strTime[];
extern const char* strEvent[];
extern const char* strMode[];
extern const char* strCpapAutoCpap[];
extern const char* strTreatmenPress[];
extern const char* strInitPress[];
extern const char* strExhSupport[];
extern const char* strInhSupport[];
extern const char* strHighPressLimit[];
extern const char* strLowPressLimit[];
extern const char* strPowerOn[];
extern const char* strPowerOff[];
extern const char* strAutoStart[];
extern const char* strManualStart[];
extern const char* strAutoOFF[];
extern const char* strStrongDrying[];
extern const char* strWeakDrying[];
extern const char* strAutoStop[];
extern const char* strManualStop[];
extern const char* strMaskOnAfterAirLeak[];

extern const char* strMaskOff[];
extern const char* strMaskOn[];
extern const char* strSnore[];
extern const char* strHyponea[];
extern const char* strFl[];
extern const char* strOa[];
extern const char* strCa[];
extern const char* strCsr[];
extern const char* strControlVer[];
extern const char* strBlowerVer[];
extern const char* strSdCard[];
extern const char* strInsert[];
extern const char* strEject[];
extern const char* strAlarm[];
extern const char* strChangeDateTime[];
extern const char* strNormalBreath[];
extern const char* strExportToCSVFile[];
extern const char* exportLogStr[];
extern const char* strExportSuccess[];
extern const char* strExportFail[];
extern const char* strCalibrationError[];
extern const char* strLogUnit[];
extern const char* strCircuitCalibrationWOMask[];
extern const char* strConnectTheMask[];
extern const char* strTimeoutLog[];
extern const char* strAutoOffAfter[];
//extern const char* strHours[];
extern const char* strMinutes[];
extern const char* strPressToTurnOff[];
extern const char* strInsertSDCard[];
extern const char* strRemoveSDCard[];
//extern const char* strConnect[];
//extern const char* strDisconnect[];
//extern const char* strBLEConnectFailed[];
//extern const char* strBLEConnectSuccess[];
extern const char* strDryingMode[];
extern const char* strAreYouSure[];
extern const char* strPreparation[];
extern const char* strPreparationContent[];
extern const char* strInspection[];
extern const char* strAirIsLeaking[];
extern const char* strPressOnOffToStandby[];
extern const char* strAutoOff[];
extern const char* strFL[];
extern const char* strOnOff[];
extern const char* strCircuitType[];
extern const char* strInterruptionDrying[];
extern const char* strCompleteDrying[];
extern const char* strOthers[];
extern const char* strQE[];
extern const char* upgradeBLEUnitStr[];
extern const char* strUpgradebleUnit[];
extern const char* strResettingBLEUnit[];

//#if defined(__cplusplus)
//}
//#endif


#endif /* UNITTEST_GUI_STRINGS_H_ */
