/*
 * systeminfortable.cpp
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */

#include "guidefine.h"
//#include "operationtime.h"
#include "systeminfortable.h"

#include <setting.h>

//#include "BUTTON.h"
//#include "TEXT.h"
//#include "IMAGE.h"
//#include "fonts.h"
//#include "debuguart.h"
//#include "systeminformation.h"
#include "strings.h"
//#include "stringtools.h"
#include "guiglobal.h"
#include "WMMocks.h"
#include "WString.h"
#include "systeminfortableMocks.h"

//information dialog
#define INFOR_DIALOG_X					0
#define INFOR_DIALOG_Y					32
#define INFOR_DIALOG_LENGHT				300
#define INFOR_DIALOG_HEIGHT				128
#define INFOR_DIALOG_HEADER_HEIGHT		32
//total time
#define TOTAL_TIME_NAME_X				20
#define TOTAL_TIME_NAME_Y				33
#define TOTAL_TIME_NAME_LENGTH			220
#define TOTAL_TIME_NAME_HEIGHT			30
//main version
#define MAIN_VER_NAME_X					20
#define MAIN_VER_NAME_Y					57
#define MAIN_VER_NAME_LENGTH			220
#define MAIN_VER_NAME_HEIGHT			30
//blower version
#define BLOWER_VER_NAME_X				20
#define BLOWER_VER_NAME_Y				81
#define BLOWER_VER_NAME_LENGTH			220
#define BLOWER_VER_NAME_HEIGHT			30
//serial number
#define SERIAL_NUM_NAME_X				20
#define SERIAL_NUM_NAME_Y				105
#define SERIAL_NUM_NAME_LENGTH			220
#define SERIAL_NUM_NAME_HEIGHT			30
//total time value
#define TOTAL_TIME_VALUE_X				TOTAL_TIME_NAME_X
#define TOTAL_TIME_VALUE_Y				TOTAL_TIME_NAME_Y
#define TOTAL_TIME_VALUE_LENGTH			260
#define TOTAL_TIME_VALUE_HEIGHT			TOTAL_TIME_NAME_HEIGHT
//main version value
#define MAIN_VER_VALUE_X				MAIN_VER_NAME_X
#define MAIN_VER_VALUE_Y				MAIN_VER_NAME_Y
#define MAIN_VER_VALUE_LENGTH			260
#define MAIN_VER_VALUE_HEIGHT			MAIN_VER_NAME_HEIGHT
//blower version
#define BLOWER_VER_VALUE_X				BLOWER_VER_NAME_X
#define BLOWER_VER_VALUE_Y				BLOWER_VER_NAME_Y
#define BLOWER_VER_VALUE_LENGTH			260
#define BLOWER_VER_VALUE_HEIGHT			BLOWER_VER_NAME_HEIGHT
//serial number value
#define SERIAL_NUM_VALUE_X				SERIAL_NUM_NAME_X
#define SERIAL_NUM_VALUE_Y				SERIAL_NUM_NAME_Y
#define SERIAL_NUM_VALUE_LENGTH			260
#define SERIAL_NUM_VALUE_HEIGHT			SERIAL_NUM_NAME_HEIGHT
//name string
#define INFOR_DIALOG_NAME_X				10
#define INFOR_DIALOG_NAME_Y				5
#define INFOR_SELECTED_COLOR			COLOR_LIGHT_ORANGE
#define INFOR_UNSELECTED_COLOR			GUI_WHITE

E_ButtonStatus inforDialogStatus = eRelease;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//void InforDlgCallback(WM_MESSAGE * pMsg);
//void InforDlgCustom();

//BUTTON_Handle informationDialog;

//extern WM_HWIN maintenanceScreen;
//static TEXT_Handle totalTimeName;
//static TEXT_Handle mainVerName;
//static TEXT_Handle blowerVerName;
//static TEXT_Handle serialNumberName;

//static TEXT_Handle totalTimeLabel;
//static TEXT_Handle mainVerLabel;
//static TEXT_Handle blowerVerLabel;
//static TEXT_Handle serialNumberLabel;
//static E_ButtonStatus inforDialogStatus = eRelease;
char totalTimeStr[10] = {'\0'};

//static const GUI_FONT* guiFont14[] = { &GUI_FontMeiryo14B_2bpp, &GUI_FontJPAPJPFont14B };
//static const GUI_FONT* guiFont16[] = { &GUI_FontMeiryo16B_2bpp, &GUI_FontJPAPJPFont16B };

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: InforDlgInit(void)
//
//    Processing:
//		This operation initialize the information dialog and its items
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void InforDlgInit(void)
{
	//initialize information dialog
//	informationDialog = BUTTON_CreateEx(INFOR_DIALOG_X, INFOR_DIALOG_Y, INFOR_DIALOG_LENGHT, INFOR_DIALOG_HEIGHT, maintenanceScreen, WM_CF_SHOW, WM_CF_MEMDEV, eInformationDlgId);
//	WM_SetCallback(informationDialog, InforDlgCallback);
//	//initialize total time name
//	totalTimeName = TEXT_CreateEx(TOTAL_TIME_NAME_X, TOTAL_TIME_NAME_Y, TOTAL_TIME_NAME_LENGTH, TOTAL_TIME_NAME_HEIGHT, informationDialog, WM_CF_SHOW, TEXT_CF_LEFT/*WM_CF_MEMDEV*/, eTotalTimeInforId, "Total Time (hours)");
////	TEXT_SetTextAlign(totalTimeName, GUI_TA_LEFT);
//	TEXT_SetTextColor(totalTimeName, GUI_WHITE);
//	TEXT_SetFont(totalTimeName, &GUI_FontJPAPJPFont14B);
//	//initialize main version name
//	mainVerName = TEXT_CreateEx(MAIN_VER_NAME_X, MAIN_VER_NAME_Y, MAIN_VER_NAME_LENGTH, MAIN_VER_NAME_HEIGHT, informationDialog, WM_CF_SHOW, TEXT_CF_LEFT/*WM_CF_MEMDEV*/, eMainVersionInforId, "Main Version");
////	TEXT_SetTextAlign(mainVerName, GUI_TA_LEFT);
//	TEXT_SetTextColor(mainVerName, GUI_WHITE);
//	TEXT_SetFont(mainVerName, &GUI_FontJPAPJPFont14B);
//	//initialize blower version name
//	blowerVerName = TEXT_CreateEx(BLOWER_VER_NAME_X, BLOWER_VER_NAME_Y, BLOWER_VER_NAME_LENGTH, BLOWER_VER_NAME_HEIGHT, informationDialog, WM_CF_SHOW, TEXT_CF_LEFT/*WM_CF_MEMDEV*/, eBlowerVersionInforId, "Blower Version");
////	TEXT_SetTextAlign(blowerVerName, GUI_TA_LEFT);
//	TEXT_SetTextColor(blowerVerName, GUI_WHITE);
//	TEXT_SetFont(blowerVerName, &GUI_FontJPAPJPFont14B);
//	//initialize serial number name
//	serialNumberName = TEXT_CreateEx(SERIAL_NUM_NAME_X, SERIAL_NUM_NAME_Y, SERIAL_NUM_NAME_LENGTH, SERIAL_NUM_NAME_HEIGHT, informationDialog, WM_CF_SHOW, TEXT_CF_LEFT/*WM_CF_MEMDEV*/, eSerialNumInforId, "Serial Number");
////	TEXT_SetTextAlign(serialNumberName, GUI_TA_LEFT);
//	TEXT_SetTextColor(serialNumberName, GUI_WHITE);
//	TEXT_SetFont(serialNumberName, &GUI_FontJPAPJPFont14B);
//	//initialize total time value text
//	totalTimeLabel = TEXT_CreateEx(TOTAL_TIME_VALUE_X, TOTAL_TIME_VALUE_Y, TOTAL_TIME_VALUE_LENGTH, TOTAL_TIME_VALUE_HEIGHT, informationDialog, WM_CF_SHOW, TEXT_CF_RIGHT/*WM_CF_MEMDEV*/, eTotalTimeInforValueId, "");
////	TEXT_SetTextAlign(totalTimeLabel, GUI_TA_RIGHT);
//	TEXT_SetTextColor(totalTimeLabel, GUI_WHITE);
//	TEXT_SetFont(totalTimeLabel, &GUI_FontJPAPJPFont14B);
//	//initialize main version infor
//	mainVerLabel = TEXT_CreateEx(MAIN_VER_VALUE_X, MAIN_VER_VALUE_Y, MAIN_VER_VALUE_LENGTH, MAIN_VER_VALUE_HEIGHT, informationDialog, WM_CF_SHOW, TEXT_CF_RIGHT/*WM_CF_MEMDEV*/, eMainVersionInforValueId, "");
////	TEXT_SetTextAlign(mainVerLabel, GUI_TA_RIGHT);
//	TEXT_SetTextColor(mainVerLabel, GUI_WHITE);
//	TEXT_SetFont(mainVerLabel, &GUI_FontJPAPJPFont14B);
//	//initialize blower version infor
//	blowerVerLabel = TEXT_CreateEx(BLOWER_VER_VALUE_X, BLOWER_VER_VALUE_Y, BLOWER_VER_VALUE_LENGTH, BLOWER_VER_VALUE_HEIGHT, informationDialog, WM_CF_SHOW, TEXT_CF_RIGHT/*WM_CF_MEMDEV*/, eBlowerVersionInforValueId, "");
////	TEXT_SetTextAlign(blowerVerLabel, GUI_TA_RIGHT);
//	TEXT_SetTextColor(blowerVerLabel, GUI_WHITE);
//	TEXT_SetFont(blowerVerLabel, &GUI_FontJPAPJPFont14B);
//	//initialize serial number infor
//	serialNumberLabel = TEXT_CreateEx(SERIAL_NUM_VALUE_X, SERIAL_NUM_VALUE_Y, SERIAL_NUM_VALUE_LENGTH, SERIAL_NUM_VALUE_HEIGHT, informationDialog, WM_CF_SHOW, TEXT_CF_RIGHT/*WM_CF_MEMDEV*/, eSerialNumInforValueId, "");
////	TEXT_SetTextAlign(serialNumberLabel, GUI_TA_RIGHT);
//	TEXT_SetTextColor(serialNumberLabel, GUI_WHITE);
//	TEXT_SetFont(serialNumberLabel, &GUI_FontJPAPJPFont14B);

	inforDialogStatus = eEnter;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: InforDlgCustom(BUTTON_Handle hObj)
//
//    Processing:
//		The function is to custom information dialog
//
//    Input Parameters:
//		BUTTON_Handle hObj
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void InforDlgCustom()
{
//	GUI_SetFont(guiFont16[language]);							//set font
	const char* nameStr = strSystemInformation[language];		//get name
	int status = inforDialogStatus;								//get status

	GUI_RECT Rect;
	WM_GetClientRect(&Rect);		//get size: x0, x1, y0, y1
	GUI_AA_SetFactor(6);
	GUI_SetPenShape(GUI_PS_ROUND);
	GUI_SetTextMode(GUI_TM_TRANS);
	//draw background
//	GUI_DrawGradientV(Rect.x0, Rect.y0, Rect.x1, Rect.y0 + INFOR_DIALOG_HEADER_HEIGHT, SETTING_BAR_TOP_COLOR, SETTING_BAR_BOTTOM_COLOR);
	GUI_SetColor(SETTING_EXPAND_BK_COLOR);
	GUI_FillRect(Rect.x0, Rect.y0 + INFOR_DIALOG_HEADER_HEIGHT, Rect.x1, Rect.y0 + INFORMATION_BTN_HEIGHT);

	//set color for name string
	if(status == eRelease)
		GUI_SetColor(INFOR_UNSELECTED_COLOR);
	else
		GUI_SetColor(INFOR_SELECTED_COLOR);

//	GUI_SetTextAlign(GUI_TA_LEFT);	//set text align for name string
//	GUI_DispStringAt(nameStr, INFOR_DIALOG_NAME_X, INFOR_DIALOG_NAME_Y);	//display name string
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: InforDlgCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		This is callback button for information dialog
//
//    Input Parameters:
//		WM_MESSAGE * pMsg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void InforDlgCallback(WM_MESSAGE * pMsg)
{
	switch (pMsg->MsgId) {
	case WM_PAINT:
		InforDlgCustom();
		break;
	default:
//		BUTTON_Callback(pMsg); // The original callback
		break;
	}
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: InforDlgSetStatus(E_ButtonStatus status)
//
//    Processing:
//		This operation sets status for information dialog
//
//    Input Parameters:
//		E_ButtonStatus status
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void InforDlgSetStatus(E_ButtonStatus status)
{
	inforDialogStatus = status;		//set status of information dialog
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: InforDialogGetBlowerVer()
//
//    Processing:
//		This operation updates blower version
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SystemInfortableReload()
{
	char tempStr[20] = {'\0'};
	char controlAndBoot[12] = {'\0'};
	unsigned char index = 0;
	//clear buffer
	memset(tempStr, '\0', sizeof(tempStr));
	//get software version
	SystemInforGetSwVersionMocks(tempStr, sizeof(tempStr));
	StrAppend(controlAndBoot, tempStr, sizeof(controlAndBoot));
	index = strlen(tempStr);
	controlAndBoot[index++] = '/';
	//clear buffer
	memset(tempStr, '\0', sizeof(tempStr));
	//get boot version
	SystemInforGetBootVersionMocks(tempStr, sizeof(tempStr));
	StrAppend(controlAndBoot, tempStr, sizeof(controlAndBoot));

	//get used hours and convert it to string
	StrToolItoA(OpertimeGetUsedHourMocks(), &totalTimeStr[0], sizeof OpertimeGetUsedHourMocks());
	//set font for all item
//	TEXT_SetFont(totalTimeName, guiFont14[language]);
//	TEXT_SetFont(mainVerName, guiFont14[language]);
//	TEXT_SetFont(blowerVerName, guiFont14[language]);
//	TEXT_SetFont(serialNumberName, guiFont14[language]);
//	//set text
//	TEXT_SetText(totalTimeName, strTotalTime[language]);
//	TEXT_SetText(mainVerName, strMainUnitVersion[language]);
//	TEXT_SetText(blowerVerName, strBlowerUnitVersion[language]);
//	TEXT_SetText(serialNumberName, strSerialNumber[language]);
//
//	TEXT_SetText(totalTimeLabel, totalTimeStr);
//	TEXT_SetText(mainVerLabel, controlAndBoot);
	//get serial number
	memset(tempStr, '\0', sizeof(tempStr));
	SystemInforGetSerialNoMocks(tempStr, sizeof(tempStr));
//	TEXT_SetText(serialNumberLabel, tempStr);
	//get motor version
	memset(tempStr, '\0', sizeof(tempStr));
	SystemInforGetMotorVersionMocks(tempStr, sizeof(tempStr));
//	TEXT_SetText(blowerVerLabel, tempStr);
}


#if defined(__cplusplus)
}
#endif
