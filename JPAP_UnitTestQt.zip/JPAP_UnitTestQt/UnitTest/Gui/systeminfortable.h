/*
 * systeminfortable.h
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_GUI_SYSTEMINFORTABLE_H_
#define UNITTEST_GUI_SYSTEMINFORTABLE_H_


#include "guidefine.h"
#include "WM.h"
//#include "BUTTON.h"
//#include "TEXT.h"

typedef enum
{
	eFirstSystemInforId,
	eTotalTimeInforId = eFirstSystemInforId,
	eMainVersionInforId,
	eBlowerVersionInforId,
	eSerialNumInforId,
	eLastSystemInforId = eSerialNumInforId,

	eFirstSystemInforValueId,
	eTotalTimeInforValueId = eFirstSystemInforValueId,
	eMainVersionInforValueId,
	eBlowerVersionInforValueId,
	eSerialNumInforValueId,
	eLastSystemInforValueId = eSerialNumInforValueId,
} E_InforDialogItemId;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//extern BUTTON_Handle informationDialog;
void InforDlgCallback(WM_MESSAGE * pMsg);
void InforDlgCustom();
void InforDlgInit(void);
void InforDlgSetStatus(E_ButtonStatus status);
void SystemInfortableReload();

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_SYSTEMINFORTABLE_H_ */
