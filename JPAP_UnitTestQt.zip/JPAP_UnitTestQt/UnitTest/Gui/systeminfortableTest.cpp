/*
 * systeminfortableTest.cpp
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "systeminfortable.h"
#include "WMMocks.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern E_ButtonStatus inforDialogStatus;

namespace EmbeddedCUnitTest {


class SystemInforTableTest : public TestFixture
{
public:
	SystemInforTableTest() : TestFixture(new ModuleMock) {}
};

TEST_F(SystemInforTableTest, ModeInit)
{
	InforDlgInit();
	EXPECT_EQ(eEnter,inforDialogStatus);
}

TEST_F(SystemInforTableTest, InforDlgCustom1)
{
	EXPECT_CALL(*_WMLib,WM_GetClientRect(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_AA_SetFactor(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetPenShape(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextMode(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(0x967100)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRect(_,_,_,_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(GUI_WHITE)).Times(1);

	inforDialogStatus = eRelease;
	InforDlgCustom();
}

TEST_F(SystemInforTableTest, InforDlgCustom2)
{
	EXPECT_CALL(*_WMLib,WM_GetClientRect(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_AA_SetFactor(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetPenShape(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextMode(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(0x967100)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRect(_,_,_,_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(COLOR_LIGHT_ORANGE)).Times(1);

	inforDialogStatus = ePoint;
	InforDlgCustom();
}

TEST_F(SystemInforTableTest, InforDlgCallback)
{
	EXPECT_CALL(*_WMLib,WM_GetClientRect(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_AA_SetFactor(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetPenShape(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextMode(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(0x967100)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRect(_,_,_,_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(COLOR_LIGHT_ORANGE)).Times(1);

	inforDialogStatus = ePoint;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	InforDlgCallback(&pMsg);
}

TEST_F(SystemInforTableTest, InforDlgSetStatus1)
{
	InforDlgSetStatus(eRelease);

	EXPECT_EQ(eRelease,inforDialogStatus);
}

TEST_F(SystemInforTableTest, InforDlgSetStatus2)
{
	InforDlgSetStatus(ePoint);

	EXPECT_EQ(ePoint,inforDialogStatus);
}

TEST_F(SystemInforTableTest, InforDlgSetStatus3)
{
	InforDlgSetStatus(eEnter);

	EXPECT_EQ(eEnter,inforDialogStatus);
}

TEST_F(SystemInforTableTest, SystemInfortableReload)
{
	EXPECT_CALL(*_wstring,memset(_,_,_)).Times(4);
	EXPECT_CALL(*_SysInforTableLib,SystemInforGetSwVersionMocks(_,_)).Times(1);
	EXPECT_CALL(*_wstring,StrAppend(_,_,_)).Times(2);
	EXPECT_CALL(*_SysInforTableLib,SystemInforGetBootVersionMocks(_,_)).Times(1);
	EXPECT_CALL(*_wstring,StrToolItoA(_,_,_)).Times(1);
	EXPECT_CALL(*_SysInforTableLib,SystemInforGetSerialNoMocks(_,_)).Times(1);
	EXPECT_CALL(*_SysInforTableLib,SystemInforGetMotorVersionMocks(_,_)).Times(1);

	SystemInfortableReload();
}

}


