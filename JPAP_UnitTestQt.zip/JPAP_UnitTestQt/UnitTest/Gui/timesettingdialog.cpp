/*
 * timesettingdialog.cpp
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */

#include "stdio.h"
#include <stdbool.h>
#include "timesettingdialog.h"

#include <guiinterface.h>
#include <setting.h>
#include <systeminterface.h>

//#include "debuguart.h"
//#include "fonts.h"
//#include "stdlib.h"
//#include "lpc_types.h"
//#include "timesettingwidget.h"
//#include "rtc.h"
#include "popupdialog.h"
#include "strings.h"
//#include "systemconfig.h"
#include "guiglobal.h"
#include "RTCMocks.h"
#include "WMMocks.h"
#include "TimeDialogMocks.h"

////time setting dialog
//#define TIME_DIALOG_X				0
//#define TIME_DIALOG_Y				96
//#define TIME_DIALOG_LENGTH			300
//#define TIME_DIALOG_HEIGHT			32
////pop up
//#define TIME_DIALOG_POPUP_X			50
//#define TIME_DIALOG_POPUP_Y			60
//#define TIME_DIALOG_POPUP_LENGTH	220
//#define TIME_DIALOG_POPUP_HEIGHT	120
//
//#define TIMEDIALOG_SELECTED_COLOR		COLOR_LIGHT_ORANGE
//#define TIMEDIALOG_UNSELECTED_COLOR		GUI_WHITE
//#define TIMEDIALOG_LINE_COLON_COLOR		GUI_WHITE
//
////define y start of 2 rows
//#define FIRST_ROW_Y					34
//#define SECOND_ROW_Y				64
//
////define x start of all widgets
//#define FIRST_WIDGET_X				20
//#define SECOND_WIDGET_X				115
//#define THIRD_WIDGET_X				210
//#define FOURTH_WIDGET_X				35
//#define FIFTH_WIDGET_X				95
//#define SIXTH_WIDGET_X				155
//#define SEVENTH_WIDGET_X			215
////define height of widgets
//#define WIDGET_HEIGHT				30
////define length of widgets
//#define DATE_LENGTH					75
//#define MONTH_LENGTH				70
//#define YEAR_LENGTH					75
//#define HOUR_LENGTH					50
//#define MIN_LENGTH					50
//#define SEC_LENGTH					50
//#define AMPM_LENGTH					50
//
////name string
//#define TIME_SETTING_NAME_X			10
//#define TIME_SETTING_NAME_Y			5
////line
//#define FIRST_LINE_X_START			105
//#define LINE_Y_START				37
//#define SECOND_LINE_X_START			198
//#define LINE_Y_STOP					60
////colon
//#define TIME_SETTING_COLON_X		88
//#define TIME_SETTING_COLON_Y		65
//
//#define HALF_DAY_HOURS				12
//#define FULL_DAY_HOURS				24

unsigned char timeSettingStatus;
E_TimeSettingState currentStateTimeSettingDialog = eReleaseItemState;
short currentWidget = 0;
RTC_TIME_Type currentTime;

int dateStart = 0;
int monthStart = 0;
int yearStart = 0;
int hourStart = 0;
int minStart = 0;
int secStart = 0;
int ampmStart = 0;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//BUTTON_Handle timeSettingDialog;
//extern WM_HWIN maintenanceScreen;

//void TimeDialogCallback(WM_MESSAGE * pMsg);
//void TimeDialogCustom();
//void TimeDialogEnterKeyHandle();
//void TimeDialogRightKeyHandle();
//void TimeDialogLeftKeyHandle();
//void TimeDialogRelayout();
//void TimeDialogSetItemStatus();

//static BUTTON_Handle dateLabel;
//static BUTTON_Handle monthLabel;
//static BUTTON_Handle yearLabel;
//static BUTTON_Handle hourLabel;
//static BUTTON_Handle minLabel;
//static BUTTON_Handle secLabel;
//static BUTTON_Handle ampmLabel;
//static BUTTON_Handle timeWidgetList[NUM_OF_TIME_WIDGET];

//static E_TimeSettingState currentStateTimeSettingDialog = eReleaseItemState;
//static short currentWidget = 0;
//static RTC_TIME_Type currentTime;

//declare position of all widgets
//static int dateStart = 0;
//static int monthStart = 0;
//static int yearStart = 0;
//static int hourStart = 0;
//static int minStart = 0;
//static int secStart = 0;
//static int ampmStart = 0;

//static const GUI_POINT rightArrow[] = {
//		{0, 0},	{10, 10}, {0, 20}, {0, 16},	{6, 10}, {0, 4},
//};
//define down arrow sign
//static const GUI_POINT downArrow[] = {
//		{0, 0},	{10, 10}, {20, 0},	{16, 0}, {10, 6}, {4, 0},
//};
//static unsigned char timeSettingStatus;
//font 16
//static const GUI_FONT* guiFont16[] = { &GUI_FontMeiryo16B_2bpp, &GUI_FontJPAPJPFont16B };

static xQueueHandle systemQueue;;

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeDialogInit()
//
//    Processing:
//		This operation initialize the time setting dialog item
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeDialogInit(void)
{
	timeSettingStatus = eRelease;
	//initialize time setting dialog
//	timeSettingDialog = BUTTON_CreateEx(TIME_DIALOG_X, TIME_DIALOG_Y, TIME_DIALOG_LENGTH, TIME_DIALOG_HEIGHT, maintenanceScreen, WM_CF_SHOW, WM_CF_MEMDEV, eTimeSettingBtnId);
//	WM_SetCallback(timeSettingDialog, TimeDialogCallback);
//	//init date button
//	dateLabel = BUTTON_CreateEx(FIRST_WIDGET_X, FIRST_ROW_Y, DATE_LENGTH, WIDGET_HEIGHT, timeSettingDialog, WM_CF_SHOW, WM_CF_MEMDEV, eDateSettingId);
//	WM_SetCallback(dateLabel, TimeWidgetCallback);
//	//init month label
//	monthLabel = BUTTON_CreateEx(SECOND_WIDGET_X, FIRST_ROW_Y, MONTH_LENGTH, WIDGET_HEIGHT, timeSettingDialog, WM_CF_SHOW, WM_CF_MEMDEV, eMonthSettingId);
//	WM_SetCallback(monthLabel, TimeWidgetCallback);
//	//init year label
//	yearLabel = BUTTON_CreateEx(THIRD_WIDGET_X, FIRST_ROW_Y, YEAR_LENGTH, WIDGET_HEIGHT, timeSettingDialog, WM_CF_SHOW, WM_CF_MEMDEV, eYearSettingId);
//	WM_SetCallback(yearLabel, TimeWidgetCallback);
//	//init hour label
//	hourLabel = BUTTON_CreateEx(FOURTH_WIDGET_X, SECOND_ROW_Y, HOUR_LENGTH, WIDGET_HEIGHT, timeSettingDialog, WM_CF_SHOW, WM_CF_MEMDEV, eHourSettingId);
//	WM_SetCallback(hourLabel, TimeWidgetCallback);
//	//init min label
//	minLabel = BUTTON_CreateEx(FIFTH_WIDGET_X, SECOND_ROW_Y, MIN_LENGTH,  WIDGET_HEIGHT, timeSettingDialog, WM_CF_SHOW, WM_CF_MEMDEV, eMinuteSettingId);
//	WM_SetCallback(minLabel, TimeWidgetCallback);
//	//init second label
//	secLabel = BUTTON_CreateEx(SIXTH_WIDGET_X, SECOND_ROW_Y, SEC_LENGTH,  WIDGET_HEIGHT, timeSettingDialog, WM_CF_SHOW, WM_CF_MEMDEV, eSecondSettingId);
//	WM_SetCallback(secLabel, TimeWidgetCallback);
//	//init AM/PM label
//	ampmLabel = BUTTON_CreateEx(SEVENTH_WIDGET_X, SECOND_ROW_Y, AMPM_LENGTH, WIDGET_HEIGHT, timeSettingDialog, WM_CF_SHOW, WM_CF_MEMDEV, eAmPmSettingId);
//	WM_SetCallback(ampmLabel, TimeWidgetCallback);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeDialogCustom(BUTTON_Handle hObj)
//
//    Processing:
//		The function is to custom time setting dialog
//
//    Input Parameters:
//		BUTTON_Handle hObj
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeDialogCustom()
{
	GUI_RECT Rect;
	WM_GetClientRect(&Rect);										//get size: x0, x1, y0, y1
	//const char* nameStr = strDateTime[language];	//get name string
	GUI_AA_SetFactor(6);
	GUI_SetPenShape(GUI_PS_ROUND);
	GUI_SetTextMode(GUI_TM_TRANS);
//	GUI_SetFont(&GUI_FontJPAPJPFont16B);
	//draw background
//	GUI_DrawGradientV(Rect.x0, Rect.y0, Rect.x1, Rect.y0 + NORMAL_BUTTON_HEIGHT, SETTING_BAR_TOP_COLOR, SETTING_BAR_BOTTOM_COLOR);

	switch(timeSettingStatus) {
	case eRelease:
		GUI_SetColor(TIMEDIALOG_UNSELECTED_COLOR);			//set color
//		GUI_SetTextAlign(GUI_TA_LEFT);			//set align
//		GUI_SetFont(guiFont16[language]);		//set font
//		GUI_DispStringAt(nameStr, TIME_SETTING_NAME_X, TIME_SETTING_NAME_Y);	//display name
//		GUI_FillPolygon(&rightArrow[0], ARROW_NUM_OF_POINTS, RIGHT_ARROW_X, RIGHT_ARROW_Y);	//draw arrow
		break;
	case ePoint:
		GUI_SetColor(TIMEDIALOG_SELECTED_COLOR);			//set color
//		GUI_SetTextAlign(GUI_TA_LEFT);			//set align
//		GUI_SetFont(guiFont16[language]);		//set font
//		GUI_DispStringAt(nameStr, TIME_SETTING_NAME_X, TIME_SETTING_NAME_Y);	//display name
//		GUI_FillPolygon(&rightArrow[0], ARROW_NUM_OF_POINTS, RIGHT_ARROW_X, RIGHT_ARROW_Y);	//draw arrow
		break;
	case eEnter:
		GUI_SetColor(TIMEDIALOG_SELECTED_COLOR);			//set color	for name
//		GUI_SetTextAlign(GUI_TA_LEFT);			//set align
//		GUI_SetFont(guiFont16[language]);		//set font
//		GUI_DispStringAt(nameStr, TIME_SETTING_NAME_X, TIME_SETTING_NAME_Y);	//display name
//		GUI_FillPolygon(&downArrow[0], ARROW_NUM_OF_POINTS, DOWN_ARROW_X, DOWN_ARROW_Y);	//draw arrow
		GUI_SetColor(SETTING_EXPAND_BK_COLOR);	//set color for background
		GUI_FillRect(Rect.x0, Rect.y0 + NORMAL_BUTTON_HEIGHT, Rect.x1, Rect.y0 + EXPAND_TIME_BTN_HEIGHT);	//draw background
		break;
	default:
		break;
	}

	GUI_SetColor(TIMEDIALOG_LINE_COLON_COLOR);		//set color for line and colon
//	GUI_AA_DrawLine(FIRST_LINE_X_START, LINE_Y_START, FIRST_LINE_X_START, LINE_Y_STOP);	//draw line between date and month
//	GUI_AA_DrawLine(SECOND_LINE_X_START, LINE_Y_START, SECOND_LINE_X_START, LINE_Y_STOP);	//draw line between month and year
//	GUI_DispStringAt(":", (WM_GetWinOrgX(hourLabel) + HOUR_LENGTH + WM_GetWinOrgX(minLabel))/2, TIME_SETTING_COLON_Y);		//display colon between hour and minute
//	GUI_DispStringAt(":", (WM_GetWinOrgX(minLabel) + MIN_LENGTH + WM_GetWinOrgX(secLabel))/2, TIME_SETTING_COLON_Y);	//display colon between minute and second
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeDialogCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		This is callback function for time dialog
//
//    Input Parameters:
//		WM_MESSAGE * pMsg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeDialogCallback(WM_MESSAGE * pMsg)
{
	switch (pMsg->MsgId) {
	case WM_PAINT:
		TimeDialogCustom();
		break;
	case WM_KEY:
	{
		switch (((WM_KEY_INFO*)(pMsg->Data.p))->Key) {
		case GUI_KEY_HOME:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
				TimeDialogEnterKeyHandle();	//handle key ENTER
			break;
		case GUI_KEY_LEFT:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
				TimeDialogLeftKeyHandle();
			break;
		case GUI_KEY_RIGHT:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
				TimeDialogRightKeyHandle();
			break;
		}
	}
	break;
	case WM_APPLY_TIME:
		TimeDialogApplyTime();	//apply new date time
		break;
	default:
//		BUTTON_Callback(pMsg); // The original callback
		break;
	}
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeDialogRelayout()
//
//    Processing:
//		This operation sets xStart for all widgets
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeDialogRelayout()
{
	switch (language) {
	case eEnglish:
		dateStart = FIRST_WIDGET_X;
		monthStart = SECOND_WIDGET_X;
		yearStart = THIRD_WIDGET_X;
		hourStart = FOURTH_WIDGET_X;
		minStart = FIFTH_WIDGET_X;
		secStart = SIXTH_WIDGET_X;
		ampmStart = SEVENTH_WIDGET_X;
		//create time widget list
//		timeWidgetList[0] = dateLabel;
//		timeWidgetList[1] = monthLabel;
//		timeWidgetList[2] = yearLabel;
//		timeWidgetList[3] = hourLabel;
//		timeWidgetList[4] = minLabel;
//		timeWidgetList[5] = secLabel;
//		timeWidgetList[6] = ampmLabel;
		break;
	case eJapanese:
		yearStart = FIRST_WIDGET_X;
		monthStart = SECOND_WIDGET_X;
		dateStart = THIRD_WIDGET_X;
		ampmStart = FOURTH_WIDGET_X;
		hourStart = FIFTH_WIDGET_X;
		minStart = SIXTH_WIDGET_X;
		secStart = SEVENTH_WIDGET_X;
		//create time widget list
//		timeWidgetList[0] = yearLabel;
//		timeWidgetList[1] = monthLabel;
//		timeWidgetList[2] = dateLabel;
//		timeWidgetList[3] = ampmLabel;
//		timeWidgetList[4] = hourLabel;
//		timeWidgetList[5] = minLabel;
//		timeWidgetList[6] = secLabel;
		break;
	default:
		break;
	}
	//layout dialog
	WM_MoveChildTo(nullptr, dateStart, FIRST_ROW_Y);//(dateLabel, dateStart, FIRST_ROW_Y);
	WM_MoveChildTo(nullptr, monthStart, FIRST_ROW_Y);//(monthLabel, monthStart, FIRST_ROW_Y);
	WM_MoveChildTo(nullptr, yearStart, FIRST_ROW_Y);//(yearLabel, yearStart, FIRST_ROW_Y);
	WM_MoveChildTo(nullptr, hourStart, SECOND_ROW_Y);//(hourLabel, hourStart, SECOND_ROW_Y);
	WM_MoveChildTo(nullptr, minStart, SECOND_ROW_Y);//(minLabel, minStart, SECOND_ROW_Y);
	WM_MoveChildTo(nullptr, secStart, SECOND_ROW_Y);//(secLabel, secStart, SECOND_ROW_Y);
	WM_MoveChildTo(nullptr, ampmStart, SECOND_ROW_Y);//(ampmLabel, ampmStart, SECOND_ROW_Y);
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeDlgSetStatus(BUTTON_Handle hObj, E_ButtonStatus stt)
//
//    Processing:
//		This function is to set status for time dialog
//
//    Input Parameters:
//		BUTTON_Handle hObj
//		E_ButtonStatus status
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeDialogSetStatus(E_ButtonStatus status)
{
	timeSettingStatus = status;
	//resize time setting
	if(eEnter == status)
		WM_SetYSize(nullptr, EXPAND_TIME_BTN_HEIGHT);//(timeSettingDialog, EXPAND_TIME_BTN_HEIGHT);
	else
		WM_SetYSize(nullptr, NORMAL_BUTTON_HEIGHT);//(timeSettingDialog, NORMAL_BUTTON_HEIGHT);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeDialogEnterKeyHandle()
//
//    Processing:
//		This function is called when key signal is transmitted
//
//    Input Parameters:
//		WM_HWIN hDlg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeDialogEnterKeyHandle()
{
	if(currentStateTimeSettingDialog == eReleaseItemState)
	{
		currentStateTimeSettingDialog = eEnterItemState;
		TimeWidgetSetStatusMocks(nullptr, eEnter);//(timeWidgetList[currentWidget], eEnter);	//enter time widget
	}
	else
	{
		currentStateTimeSettingDialog = eReleaseItemState;
		TimeWidgetSetStatusMocks(nullptr, ePoint);//(timeWidgetList[currentWidget], ePoint);	//point to time widget
	}
	//WM_Paint(timeWidgetList[currentWidget]);	//repaint current time widget
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeDialogRightKeyHandle()
//
//    Processing:
//		This function is called when right signal is transmitted
//
//    Input Parameters:
//		WM_HWIN hDlg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeDialogRightKeyHandle()
{
	switch (currentStateTimeSettingDialog) {
	case eReleaseItemState:
		currentWidget++;
		if(currentWidget > (7 - 1)) // NUM_OF_TIME_WIDGET = 7
		{
			currentWidget = 7 - 1;
			//send event to show pop up
			GuiTaskSendEvent(eGuiPopupTimeSettingShowId,0);
		}
		else
		{
			//set status for all items
			TimeDialogSetItemStatus();
		}

		break;
	case eEnterItemState:
		TimeWidgetIncreaseValueMocks(nullptr);//(timeWidgetList[currentWidget]);	//increase value of current time widget
		break;
	default:
		break;
	}
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeDialogApplyTime()
//
//    Processing:
//		This operation sets current time
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeDialogApplyTime()
{
	//set current time
	currentTime.DOM = TimeWidgetGetValueMocks(nullptr);//(dateLabel);
	currentTime.MONTH = TimeWidgetGetValueMocks(nullptr);//(monthLabel);
	currentTime.YEAR = TimeWidgetGetValueMocks(nullptr);//(yearLabel);
	currentTime.MIN = TimeWidgetGetValueMocks(nullptr);//(minLabel);
	currentTime.SEC = TimeWidgetGetValueMocks(nullptr);//(secLabel);

	//calculate hour
	if(TimeWidgetGetValueMocks(nullptr)/*(hourLabel)*/ == HALF_DAY_HOURS)
	{
		if(TimeWidgetGetValueMocks(nullptr)/*(ampmLabel)*/ == 0)
			currentTime.HOUR = 0;
		else if(TimeWidgetGetValueMocks(nullptr)/*(ampmLabel)*/ == 1)
			currentTime.HOUR = HALF_DAY_HOURS;
	}
	else
		currentTime.HOUR = TimeWidgetGetValueMocks(nullptr)/*(hourLabel)*/ + TimeWidgetGetValueMocks(nullptr)/*(ampmLabel)*/*HALF_DAY_HOURS;
	//apply for current time
	RTCSetMocks(&currentTime);
	//send event to log
	SystemEventStruct event;
	event.Id = eTimeSettingLogId;
	event.Data.type1 = 0;
	//send event to queue
	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
	{

	}
//	SystemTaskSendEvent(eTimeSettingLogId, 0);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeDialogLeftKeyHandle()
//
//    Processing:
//		This function is called when left signal is transmitted
//
//    Input Parameters:
//		WM_HWIN hDlg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeDialogLeftKeyHandle()
{
	switch (currentStateTimeSettingDialog) {
	case eReleaseItemState:
		currentWidget--;	//decrease current Time Widget
		if(currentWidget < 0)
			currentWidget = 0;
		//select current time widget
		TimeDialogSetItemStatus();
		break;
	case eEnterItemState:
		//decrease value of current time widget
		TimeWidgetDecreaseValueMocks(nullptr);//(timeWidgetList[currentWidget]);
		break;
	default:
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeDialogSetFocus()
//
//    Processing:
//		This operation restarts the time dialog
//
//    Input Parameters:
//		WM_HWIN hDlg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeDialogReload()
{
	RTC_TIME_Type currentTime1 = RTCGetMocks();	//get current time
	currentWidget = 0;						//set current Time Widget
	currentStateTimeSettingDialog = eReleaseItemState;		//set current state
	TimeDialogRelayout();					//relayout time setting dialog
	TimeDialogSetItemStatus();				//set status for all items

	//set time to display on time setting dialog
	TimeWidgetSetValueMocks(nullptr, currentTime.DOM);//(dateLabel, currentTime.DOM);		//set date
	TimeWidgetSetValueMocks(nullptr, currentTime.MONTH);//(monthLabel, currentTime.MONTH);	//set month
	TimeWidgetSetValueMocks(nullptr, currentTime.YEAR);//(yearLabel, currentTime.YEAR);	//set year
	TimeWidgetSetValueMocks(nullptr, currentTime.MIN);//(minLabel, currentTime.MIN);		//set minute
	TimeWidgetSetValueMocks(nullptr, currentTime.SEC);//(secLabel, currentTime.SEC);		//set second

	//calculate hour and AM/PM
	if(currentTime.HOUR == 0)
	{
		TimeWidgetSetValueMocks(nullptr, HALF_DAY_HOURS);//(hourLabel, HALF_DAY_HOURS);
		TimeWidgetSetValueMocks(nullptr, 0);//(ampmLabel, 0);
	}
	else if((currentTime.HOUR > 0)&&(currentTime.HOUR < HALF_DAY_HOURS))
	{
		TimeWidgetSetValueMocks(nullptr, currentTime.HOUR);;//(hourLabel, currentTime.HOUR);
		TimeWidgetSetValueMocks(nullptr, 0);//(ampmLabel, 0);
	}
	else if(currentTime.HOUR == HALF_DAY_HOURS)
	{
		TimeWidgetSetValueMocks(nullptr, HALF_DAY_HOURS);//(hourLabel, HALF_DAY_HOURS);
		TimeWidgetSetValueMocks(nullptr, 1);//(ampmLabel, 1);
	}
	else if((currentTime.HOUR > HALF_DAY_HOURS)&&(currentTime.HOUR < FULL_DAY_HOURS))
	{
		TimeWidgetSetValueMocks(nullptr, (currentTime.HOUR) - HALF_DAY_HOURS);//(hourLabel, (currentTime.HOUR) - HALF_DAY_HOURS);
		TimeWidgetSetValueMocks(nullptr, 1);//(ampmLabel, 1);
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeDialogSetItemStatus()
//
//    Processing:
//		This operation sets status for all items
//
//    Input Parameters:
//		WM_HWIN hDlg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeDialogSetItemStatus()
{
	for(int i = 0; i < 7; i++)//NUM_OF_TIME_WIDGET = 7
	{
		if(i == currentWidget)
			TimeWidgetSetStatusMocks(nullptr, ePoint);//(timeWidgetList[currentWidget], ePoint);	//select current time widget
		else
			TimeWidgetSetStatusMocks(nullptr, eRelease);//(timeWidgetList[i], eRelease);	//set focus for current time widget
//		WM_Paint(timeWidgetList[i]);	//repaint current time widget
	}
}


#if defined(__cplusplus)
}
#endif
