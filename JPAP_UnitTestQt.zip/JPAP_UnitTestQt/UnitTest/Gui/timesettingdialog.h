/*
 * timesettingdialog.h
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_GUI_TIMESETTINGDIALOG_H_
#define UNITTEST_GUI_TIMESETTINGDIALOG_H_

#include "guidefine.h"
#include "WM.h"
//#include "BUTTON.h"
//#include "TEXT.h"
//#include "DIALOG.h"

//extern BUTTON_Handle timeSettingDialog;

//time setting dialog
#define TIME_DIALOG_X				0
#define TIME_DIALOG_Y				96
#define TIME_DIALOG_LENGTH			300
#define TIME_DIALOG_HEIGHT			32
//pop up
#define TIME_DIALOG_POPUP_X			50
#define TIME_DIALOG_POPUP_Y			60
#define TIME_DIALOG_POPUP_LENGTH	220
#define TIME_DIALOG_POPUP_HEIGHT	120

#define TIMEDIALOG_SELECTED_COLOR		COLOR_LIGHT_ORANGE
#define TIMEDIALOG_UNSELECTED_COLOR		GUI_WHITE
#define TIMEDIALOG_LINE_COLON_COLOR		GUI_WHITE

//define y start of 2 rows
#define FIRST_ROW_Y					34
#define SECOND_ROW_Y				64

//define x start of all widgets
#define FIRST_WIDGET_X				20
#define SECOND_WIDGET_X				115
#define THIRD_WIDGET_X				210
#define FOURTH_WIDGET_X				35
#define FIFTH_WIDGET_X				95
#define SIXTH_WIDGET_X				155
#define SEVENTH_WIDGET_X			215
//define height of widgets
#define WIDGET_HEIGHT				30
//define length of widgets
#define DATE_LENGTH					75
#define MONTH_LENGTH				70
#define YEAR_LENGTH					75
#define HOUR_LENGTH					50
#define MIN_LENGTH					50
#define SEC_LENGTH					50
#define AMPM_LENGTH					50

//name string
#define TIME_SETTING_NAME_X			10
#define TIME_SETTING_NAME_Y			5
//line
#define FIRST_LINE_X_START			105
#define LINE_Y_START				37
#define SECOND_LINE_X_START			198
#define LINE_Y_STOP					60
//colon
#define TIME_SETTING_COLON_X		88
#define TIME_SETTING_COLON_Y		65

#define HALF_DAY_HOURS				12
#define FULL_DAY_HOURS				24


typedef enum
{
	eReleaseItemState,
	eEnterItemState
} E_TimeSettingState;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void TimeDialogInit(void);
void TimeDialogSetStatus(E_ButtonStatus status);
void TimeDialogApplyTime();
void TimeDialogReload();
void TimeDialogCustom();
void TimeDialogCallback(WM_MESSAGE * pMsg);
void TimeDialogEnterKeyHandle();
void TimeDialogLeftKeyHandle();
void TimeDialogSetItemStatus();
void TimeDialogRightKeyHandle();
void TimeDialogRelayout();

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_TIMESETTINGDIALOG_H_ */
