/*
 * timesettingdialogTest.cpp
 *
 *  Created on: Apr 27, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "timesettingdialog.h"
#include "WMMocks.h"
#include "RTCMocks.h"
#include "guiglobal.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern unsigned char timeSettingStatus;
extern E_TimeSettingState currentStateTimeSettingDialog;
extern short currentWidget;
extern RTC_TIME_Type currentTime;

extern int dateStart;
extern int monthStart;
extern int yearStart;
extern int hourStart;
extern int minStart;
extern int secStart;
extern int ampmStart;

namespace EmbeddedCUnitTest {


class TimeSettingDialogTestTest : public TestFixture
{
public:
	TimeSettingDialogTestTest() : TestFixture(new ModuleMock) {}
};

TEST_F(TimeSettingDialogTestTest, TimeDialogInit)
{
	TimeDialogInit();

	EXPECT_EQ(eRelease,timeSettingStatus);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogCustom1)
{
	EXPECT_CALL(*_WMLib,GUI_SetColor(GUI_WHITE)).Times(2);

	timeSettingStatus = eRelease;
	TimeDialogCustom();
}

TEST_F(TimeSettingDialogTestTest, TimeDialogCustom2)
{
	EXPECT_CALL(*_WMLib,GUI_SetColor(COLOR_LIGHT_ORANGE)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(GUI_WHITE)).Times(1);

	timeSettingStatus = ePoint;
	TimeDialogCustom();
}

TEST_F(TimeSettingDialogTestTest, TimeDialogCustom3)
{
	EXPECT_CALL(*_WMLib,GUI_SetColor(COLOR_LIGHT_ORANGE)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(GUI_WHITE)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(SETTING_EXPAND_BK_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRect(_,_,_,_)).Times(1);

	timeSettingStatus = eEnter;
	TimeDialogCustom();
}


TEST_F(TimeSettingDialogTestTest, TimeDialogEnterKeyHandle1)
{
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_,eEnter)).Times(1);

	currentStateTimeSettingDialog = eReleaseItemState;
	TimeDialogEnterKeyHandle();

	EXPECT_EQ(eEnterItemState,currentStateTimeSettingDialog);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogEnterKeyHandle2)
{
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_,ePoint)).Times(1);

	currentStateTimeSettingDialog = eEnterItemState;
	TimeDialogEnterKeyHandle();

	EXPECT_EQ(eReleaseItemState,currentStateTimeSettingDialog);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogSetItemStatus)
{
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, eRelease)).Times(6);

	currentWidget = 0;
	TimeDialogSetItemStatus();
}

TEST_F(TimeSettingDialogTestTest, TimeDialogLeftKeyHandle1)
{
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, eRelease)).Times(6);

	currentWidget = 0;
	currentStateTimeSettingDialog = eReleaseItemState;
	TimeDialogLeftKeyHandle();

	EXPECT_EQ(0,currentWidget);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogLeftKeyHandle2)
{
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetDecreaseValueMocks(_)).Times(1);

	currentStateTimeSettingDialog = eEnterItemState;
	TimeDialogLeftKeyHandle();
}

TEST_F(TimeSettingDialogTestTest, TimeDialogRightKeyHandle1)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStateTimeSettingDialog = eReleaseItemState;
	currentWidget = 7;
	TimeDialogRightKeyHandle();

	EXPECT_EQ(6,currentWidget);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogRightKeyHandle2)
{
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, eRelease)).Times(6);

	currentStateTimeSettingDialog = eReleaseItemState;
	currentWidget = 0;
	TimeDialogRightKeyHandle();
}

TEST_F(TimeSettingDialogTestTest, TimeDialogRightKeyHandle3)
{
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetIncreaseValueMocks(_)).Times(1);

	currentStateTimeSettingDialog = eEnterItemState;
	TimeDialogRightKeyHandle();
}

TEST_F(TimeSettingDialogTestTest, TimeDialogApplyTime1)
{
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetGetValueMocks(_)).Times(7)
					.WillOnce(Return(1))
					.WillOnce(Return(1))
					.WillOnce(Return(1))
					.WillOnce(Return(1))
					.WillOnce(Return(1))
					.WillOnce(Return(12))
					.WillOnce(Return(0));
	EXPECT_CALL(*_RTCLib,RTCSetMocks(_)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	TimeDialogApplyTime();

	EXPECT_EQ((uint32_t)0,currentTime.HOUR);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogApplyTime2)
{
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetGetValueMocks(_)).Times(8)
					.WillOnce(Return(1))
					.WillOnce(Return(1))
					.WillOnce(Return(1))
					.WillOnce(Return(1))
					.WillOnce(Return(1))
					.WillOnce(Return(12))
					.WillOnce(Return(1))
					.WillOnce(Return(1));
	EXPECT_CALL(*_RTCLib,RTCSetMocks(_)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	TimeDialogApplyTime();

	EXPECT_EQ((uint32_t)12,currentTime.HOUR);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogApplyTime3)
{
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetGetValueMocks(_)).Times(8)
					.WillOnce(Return(1))
					.WillOnce(Return(1))
					.WillOnce(Return(1))
					.WillOnce(Return(1))
					.WillOnce(Return(1))
					.WillOnce(Return(1))
					.WillOnce(Return(3))
					.WillOnce(Return(1));
	EXPECT_CALL(*_RTCLib,RTCSetMocks(_)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	TimeDialogApplyTime();

	EXPECT_EQ((uint32_t)15,currentTime.HOUR);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogCallback1)
{
	EXPECT_CALL(*_WMLib,GUI_SetColor(GUI_WHITE)).Times(2);

	timeSettingStatus = eRelease;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	TimeDialogCallback(&pMsg);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogCallback2)
{
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_,eEnter)).Times(1);

	currentStateTimeSettingDialog = eReleaseItemState;
	timeSettingStatus = eRelease;
	WM_KEY_INFO *keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_HOME;
	keyData->PressedCnt = 1;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	pMsg.Data.p = keyData;
	TimeDialogCallback(&pMsg);

	EXPECT_EQ(eEnterItemState,currentStateTimeSettingDialog);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogCallback3)
{
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, eRelease)).Times(6);

	currentWidget = 0;
	currentStateTimeSettingDialog = eReleaseItemState;
	WM_KEY_INFO *keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_LEFT;
	keyData->PressedCnt = 1;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	pMsg.Data.p = keyData;
	TimeDialogCallback(&pMsg);

	EXPECT_EQ(0,currentWidget);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogCallback4)
{
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	currentStateTimeSettingDialog = eReleaseItemState;
	currentWidget = 7;

	WM_KEY_INFO *keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_RIGHT;
	keyData->PressedCnt = 1;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	pMsg.Data.p = keyData;
	TimeDialogCallback(&pMsg);

	EXPECT_EQ(6,currentWidget);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogCallback5)
{
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetGetValueMocks(_)).Times(7)
						.WillOnce(Return(1))
						.WillOnce(Return(1))
						.WillOnce(Return(1))
						.WillOnce(Return(1))
						.WillOnce(Return(1))
						.WillOnce(Return(12))
						.WillOnce(Return(0));
	EXPECT_CALL(*_RTCLib,RTCSetMocks(_)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_APPLY_TIME;
	TimeDialogCallback(&pMsg);

	EXPECT_EQ((uint32_t)0,currentTime.HOUR);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogRelayout1)
{
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,_,_)).Times(7);

	language = 1;
	TimeDialogRelayout();

	EXPECT_EQ(FIRST_WIDGET_X,dateStart);
	EXPECT_EQ(SECOND_WIDGET_X,monthStart);
	EXPECT_EQ(THIRD_WIDGET_X,yearStart);
	EXPECT_EQ(FOURTH_WIDGET_X,hourStart);
	EXPECT_EQ(FIFTH_WIDGET_X,minStart);
	EXPECT_EQ(SIXTH_WIDGET_X,secStart);
	EXPECT_EQ(SEVENTH_WIDGET_X,ampmStart);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogRelayout2)
{
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,_,_)).Times(7);

	language = 0;
	TimeDialogRelayout();

	EXPECT_EQ(FIRST_WIDGET_X,yearStart);
	EXPECT_EQ(SECOND_WIDGET_X,monthStart);
	EXPECT_EQ(THIRD_WIDGET_X,dateStart);
	EXPECT_EQ(FOURTH_WIDGET_X,ampmStart);
	EXPECT_EQ(FIFTH_WIDGET_X,hourStart);
	EXPECT_EQ(SIXTH_WIDGET_X,minStart);
	EXPECT_EQ(SEVENTH_WIDGET_X,secStart);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogSetStatus1)
{
	EXPECT_CALL(*_WMLib,WM_SetYSize(_,EXPAND_TIME_BTN_HEIGHT)).Times(1);

	TimeDialogSetStatus(eEnter);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogSetStatus2)
{
	EXPECT_CALL(*_WMLib,WM_SetYSize(_,NORMAL_BUTTON_HEIGHT)).Times(1);

	TimeDialogSetStatus(ePoint);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogReload1)
{
	EXPECT_CALL(*_RTCLib,RTCGetMocks()).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,2)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,5)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,2018)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,59)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,58)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,HALF_DAY_HOURS)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,0)).Times(1);

	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,_,_)).Times(7);

	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, eRelease)).Times(6);

	currentWidget = 0;
	language = 1;
	currentWidget = 1;
	currentTime.HOUR = 0;
	currentTime.DOM = 2;
	currentTime.MONTH = 5;
	currentTime.YEAR = 2018;
	currentTime.MIN = 59;
	currentTime.SEC = 58;
	currentStateTimeSettingDialog = eEnterItemState;
	TimeDialogReload();

	EXPECT_EQ(0,currentWidget);
	EXPECT_EQ(eReleaseItemState,currentStateTimeSettingDialog);

	EXPECT_EQ(FIRST_WIDGET_X,dateStart);
	EXPECT_EQ(SECOND_WIDGET_X,monthStart);
	EXPECT_EQ(THIRD_WIDGET_X,yearStart);
	EXPECT_EQ(FOURTH_WIDGET_X,hourStart);
	EXPECT_EQ(FIFTH_WIDGET_X,minStart);
	EXPECT_EQ(SIXTH_WIDGET_X,secStart);
	EXPECT_EQ(SEVENTH_WIDGET_X,ampmStart);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogReload2)
{
	EXPECT_CALL(*_RTCLib,RTCGetMocks()).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,2)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,5)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,2018)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,59)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,58)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,10)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,0)).Times(1);

	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,_,_)).Times(7);

	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, eRelease)).Times(6);

	currentWidget = 0;
	language = 1;
	currentWidget = 1;
	currentTime.HOUR = 10;
	currentTime.DOM = 2;
	currentTime.MONTH = 5;
	currentTime.YEAR = 2018;
	currentTime.MIN = 59;
	currentTime.SEC = 58;
	currentStateTimeSettingDialog = eEnterItemState;
	TimeDialogReload();

	EXPECT_EQ(0,currentWidget);
	EXPECT_EQ(eReleaseItemState,currentStateTimeSettingDialog);

	EXPECT_EQ(FIRST_WIDGET_X,dateStart);
	EXPECT_EQ(SECOND_WIDGET_X,monthStart);
	EXPECT_EQ(THIRD_WIDGET_X,yearStart);
	EXPECT_EQ(FOURTH_WIDGET_X,hourStart);
	EXPECT_EQ(FIFTH_WIDGET_X,minStart);
	EXPECT_EQ(SIXTH_WIDGET_X,secStart);
	EXPECT_EQ(SEVENTH_WIDGET_X,ampmStart);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogReload3)
{
	EXPECT_CALL(*_RTCLib,RTCGetMocks()).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,2)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,5)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,2018)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,59)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,58)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,12)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,1)).Times(1);

	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,_,_)).Times(7);

	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, eRelease)).Times(6);

	currentWidget = 0;
	language = 1;
	currentWidget = 1;
	currentTime.HOUR = 12;
	currentTime.DOM = 2;
	currentTime.MONTH = 5;
	currentTime.YEAR = 2018;
	currentTime.MIN = 59;
	currentTime.SEC = 58;
	currentStateTimeSettingDialog = eEnterItemState;
	TimeDialogReload();

	EXPECT_EQ(0,currentWidget);
	EXPECT_EQ(eReleaseItemState,currentStateTimeSettingDialog);

	EXPECT_EQ(FIRST_WIDGET_X,dateStart);
	EXPECT_EQ(SECOND_WIDGET_X,monthStart);
	EXPECT_EQ(THIRD_WIDGET_X,yearStart);
	EXPECT_EQ(FOURTH_WIDGET_X,hourStart);
	EXPECT_EQ(FIFTH_WIDGET_X,minStart);
	EXPECT_EQ(SIXTH_WIDGET_X,secStart);
	EXPECT_EQ(SEVENTH_WIDGET_X,ampmStart);
}

TEST_F(TimeSettingDialogTestTest, TimeDialogReload4)
{
	EXPECT_CALL(*_RTCLib,RTCGetMocks()).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,2)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,5)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,2018)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,59)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,58)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,11)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetValueMocks(_,1)).Times(1);

	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,_,_)).Times(7);

	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_TimeDialogLib,TimeWidgetSetStatusMocks(_, eRelease)).Times(6);

	currentWidget = 0;
	language = 1;
	currentWidget = 1;
	currentTime.HOUR = 23;
	currentTime.DOM = 2;
	currentTime.MONTH = 5;
	currentTime.YEAR = 2018;
	currentTime.MIN = 59;
	currentTime.SEC = 58;
	currentStateTimeSettingDialog = eEnterItemState;
	TimeDialogReload();

	EXPECT_EQ(0,currentWidget);
	EXPECT_EQ(eReleaseItemState,currentStateTimeSettingDialog);

	EXPECT_EQ(FIRST_WIDGET_X,dateStart);
	EXPECT_EQ(SECOND_WIDGET_X,monthStart);
	EXPECT_EQ(THIRD_WIDGET_X,yearStart);
	EXPECT_EQ(FOURTH_WIDGET_X,hourStart);
	EXPECT_EQ(FIFTH_WIDGET_X,minStart);
	EXPECT_EQ(SIXTH_WIDGET_X,secStart);
	EXPECT_EQ(SEVENTH_WIDGET_X,ampmStart);
}

}


