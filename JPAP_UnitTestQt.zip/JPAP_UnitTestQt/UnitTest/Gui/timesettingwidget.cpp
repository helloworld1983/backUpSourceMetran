/*
 * timesettingwidget.cpp
 *
 *  Created on: May 2, 2018
 *      Author: Quoc Viet
 */

#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "timesettingwidget.h"

#include <setting.h>

//#include "fonts.h"
//#include "stringtools.h"
#include "strings.h"
//#include "debuguart.h"
#include "guiglobal.h"
#include "WMMocks.h"

////define color
//#define TIMEWIDGET_SELECTED_BK_COLOR		COLOR_ULTRA_LIGHT_BLUE
//#define TIMEWIDGET_UNSELECTED_BK_COLOR		SETTING_BAR_BOTTOM_COLOR
//#define TIMEWIDGET_SELECTED_VALUE_COLOR		COLOR_LIGHT_ORANGE
//#define TIMEWIDGET_UNSELECTED_VALUE_COLOR	GUI_WHITE
//
//#define TIMEWIDGET_
////define range of time
//#define SEC_MINUTE_MIN		0
//#define SEC_MINUTE_MAX		59
//#define HOUR_MIN			1
//#define HOUR_MAX			12
//#define DATE_MIN			1
//#define DATE_MAX			31
//#define MONTH_MIN			1
//#define MONTH_MAX			12
//#define YEAR_MIN			2000
//#define YEAR_MAX			2050
//#define AM					0
//#define PM					1

TimeWidgetContent timeWidget[NUM_OF_TIME_WIDGET] =
{
		{ DATE_MIN, eRelease },
		{ MONTH_MIN, eRelease },
		{ YEAR_MIN, eRelease },
		{ HOUR_MIN, eRelease },
		{ SEC_MINUTE_MIN, eRelease },
		{ SEC_MINUTE_MIN, eRelease },
		{ AM, eRelease }
};

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//void TimeWidgetCustom(int id);
//int GetTimeWidgetStatus(int id);
//void TimeWigetDisplayValue(int id, int value, GUI_RECT Rect);

//font 16
//static const GUI_FONT* guiFont16[] = { &GUI_FontMeiryo16B_2bpp, &GUI_FontJPAPJPFont16B };

//static TimeWidgetContent timeWidget[NUM_OF_TIME_WIDGET] =
//{
//		{ DATE_MIN, eRelease },
//		{ MONTH_MIN, eRelease },
//		{ YEAR_MIN, eRelease },
//		{ HOUR_MIN, eRelease },
//		{ SEC_MINUTE_MIN, eRelease },
//		{ SEC_MINUTE_MIN, eRelease },
//		{ AM, eRelease }
//};

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeWidgetCustom(WM_HWIN hDlg)
//
//    Processing:
//		This function is to custom time widget
//
//    Input Parameters:
//		WM_HWIN hDlg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeWidgetCustom(int id) {
	GUI_RECT Rect;
	WM_GetClientRect(&Rect);	//get x0, x1, y0, y1

	int timeValue = timeWidget[id - eFirstTimeWidgetId].value;	//get value
	int timeStatus = GetTimeWidgetStatus(id);					//get status
	//draw time widget
	switch (timeStatus) {
	case eRelease:
		GUI_SetColor(TIMEWIDGET_UNSELECTED_BK_COLOR);
		GUI_FillRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1, 3);
		GUI_SetColor(TIMEWIDGET_UNSELECTED_VALUE_COLOR);
		GUI_SetBkColor(TIMEWIDGET_UNSELECTED_BK_COLOR);
		break;
	case ePoint:
		GUI_SetColor(TIMEWIDGET_SELECTED_BK_COLOR);
		GUI_FillRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1, 3);
		GUI_SetColor(TIMEWIDGET_UNSELECTED_VALUE_COLOR);
		GUI_SetBkColor(TIMEWIDGET_SELECTED_BK_COLOR);
		break;
	case eEnter:
		GUI_SetColor(TIMEWIDGET_SELECTED_BK_COLOR);
		GUI_FillRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1, 3);
		GUI_SetColor(TIMEWIDGET_SELECTED_VALUE_COLOR);
		GUI_SetBkColor(TIMEWIDGET_SELECTED_BK_COLOR);
		break;
	default:
		break;
	}
	//display value
	TimeWigetDisplayValue(id, timeValue, Rect);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeWidgetCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		This is callback function of time widget
//
//    Input Parameters:
//		WM_MESSAGE * pMsg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeWidgetCallback(WM_MESSAGE * pMsg) {
	switch (pMsg->MsgId) {
	case WM_PAINT:
		TimeWidgetCustom(WM_GetId(nullptr)/*(pMsg->hWin)*/);
		break;
	default:
		//BUTTON_Callback(pMsg); // The original callback
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeWidgetSetStatus(BUTTON_Handle hObj, E_ButtonStatus stt)
//
//    Processing:
//		This function is to set status for time widget
//
//    Input Parameters:
//		BUTTON_Handle hObj
//		E_ButtonStatus status
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeWidgetSetStatus(void* hObj, E_ButtonStatus status)
{
	timeWidget[WM_GetId(hObj) - eFirstTimeWidgetId].status = status;	//set status for time widget
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: GetTimeWidgetStatus(BUTTON_Handle hObj)
//
//    Processing:
//		This function is to get status of time widget
//
//    Input Parameters:
//		BUTTON_Handle hObj
//
//    Output Parameters:
//      status of time widget
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
int GetTimeWidgetStatus(int id)
{
	return timeWidget[id - eFirstTimeWidgetId].status;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeWidgetIncreaseValue(BUTTON_Handle hObj)
//
//    Processing:
//		This function is to increase value of time widget
//
//    Input Parameters:
//		BUTTON_Handle hObj
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeWidgetIncreaseValue(void* hObj)
{
	int timeValue = timeWidget[WM_GetId(hObj) - eFirstTimeWidgetId].value;
	timeValue++;	//increase value
	//handle time value
	switch(WM_GetId(hObj))
	{
	case eDateSettingId:
		if(timeValue > DATE_MAX)
			timeValue = DATE_MIN;
		break;
	case eMonthSettingId:
		if(timeValue > MONTH_MAX)
			timeValue = MONTH_MIN;
		break;
	case eYearSettingId:
		break;
	case eHourSettingId:
		if(timeValue > HOUR_MAX)
			timeValue = HOUR_MIN;
		break;
	case eMinuteSettingId:
		if(timeValue > SEC_MINUTE_MAX)
			timeValue = SEC_MINUTE_MIN;
		break;
	case eSecondSettingId:
		if(timeValue > SEC_MINUTE_MAX)
			timeValue = SEC_MINUTE_MIN;
		break;
	case eAmPmSettingId:
		if(timeValue > PM)
			timeValue = AM;
		break;
	default:
		break;
	}
	timeWidget[WM_GetId(hObj) - eFirstTimeWidgetId].value = timeValue;	//set value for time widget
	WM_Paint(hObj);	//repaint
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeWidgetDecreaseValue(BUTTON_Handle hObj)
//
//    Processing:
//		This function is to decrease value of time widget
//
//    Input Parameters:
//		BUTTON_Handle hObj
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeWidgetDecreaseValue(void* hObj)
{
	int timeValue = timeWidget[WM_GetId(hObj) - eFirstTimeWidgetId].value;
	timeValue--;	//increase time value
	//handle time value
	switch(WM_GetId(hObj))
	{
	case eDateSettingId:
		if(timeValue < DATE_MIN)
			timeValue = DATE_MAX;
		break;
	case eMonthSettingId:
		if(timeValue < MONTH_MIN)
			timeValue = MONTH_MAX;
		break;
	case eYearSettingId:
		break;
	case eHourSettingId:
		if(timeValue < HOUR_MIN)
			timeValue = HOUR_MAX;
		break;
	case eMinuteSettingId:
		if(timeValue < SEC_MINUTE_MIN)
			timeValue = SEC_MINUTE_MAX;
		break;
	case eSecondSettingId:
		if(timeValue < SEC_MINUTE_MIN)
			timeValue = SEC_MINUTE_MAX;
		break;
	case eAmPmSettingId:
		if(timeValue < AM)
			timeValue = PM;
		break;
	default:
		break;
	}
	timeWidget[WM_GetId(hObj) - eFirstTimeWidgetId].value = timeValue; //set value for time widget
	WM_Paint(hObj);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: ConvertValueToString(BUTTON_Handle hObj, int value)
//
//    Processing:
//		This function is to convert value to string to display
//
//    Input Parameters:
//		BUTTON_Handle hObj
//		int value
//
//    Output Parameters:
//      string of value
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeWigetDisplayValue(int id, int timeValue, GUI_RECT Rect)
{
//	GUI_SetFont(guiFont16[language]);					//set font for value string

	if(language == eJapanese)
	{
		switch (id) {
		case eDateSettingId:
			GUI_SetTextAlign(GUI_TA_RIGHT);
			GUI_DispStringAt(strDate, Rect.x1 - 15, Rect.y0);
			GUI_SetTextAlign(GUI_TA_LEFT);
			GUI_DispDecAt(timeValue, Rect.x0 + 15, Rect.y0, 2);
			break;
		case eYearSettingId:
			GUI_SetTextAlign(GUI_TA_RIGHT);
			GUI_DispStringAt(strYear, Rect.x1 - 5, Rect.y0);
			GUI_SetTextAlign(GUI_TA_LEFT);
			GUI_DispDecAt(timeValue, Rect.x0 + 5, Rect.y0, 4);
			break;
		case eMonthSettingId:
			GUI_DispStringInRect(monthStrJap[timeValue - 1], &Rect, GUI_TA_HCENTER | GUI_TA_VCENTER);		//display value string
			break;
		case eAmPmSettingId:
			GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER);
			if(AM == timeValue)
				GUI_DispStringInRect(strAm[language], &Rect, GUI_TA_HCENTER | GUI_TA_VCENTER);		//display value string
			else if(PM == timeValue)
				GUI_DispStringInRect(strPm[language], &Rect, GUI_TA_HCENTER | GUI_TA_VCENTER);		//display value string
			break;
		default:
			GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER);
			GUI_DispDecAt(timeValue, (Rect.x0 + Rect.x1)/2, (Rect.y0 + Rect.y1)/2, 2);
			break;
		}
	}
	else if(language == eEnglish)
	{
		switch (id) {
		case eMonthSettingId:
			GUI_DispStringInRect(monthStrEng[timeValue - 1], &Rect, GUI_TA_HCENTER | GUI_TA_VCENTER);		//display value string
			break;
		case eAmPmSettingId:
			GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER);
			if(AM == timeValue)
				GUI_DispStringInRect(strAm[language], &Rect, GUI_TA_HCENTER | GUI_TA_VCENTER);		//display value string
			else if(PM == timeValue)
				GUI_DispStringInRect(strPm[language], &Rect, GUI_TA_HCENTER | GUI_TA_VCENTER);		//display value string
			break;
		case eYearSettingId:
			GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER);
			GUI_DispDecAt(timeValue, (Rect.x0 + Rect.x1)/2, (Rect.y0 + Rect.y1)/2, 4);
			break;
		default:
			GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER);
			GUI_DispDecAt(timeValue, (Rect.x0 + Rect.x1)/2, (Rect.y0 + Rect.y1)/2, 2);
			break;
		}
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeWidgetSetValue(BUTTON_Handle hObj, int value)
//
//    Processing:
//		This operation sets value for current time widget
//
//    Input Parameters:
//		BUTTON_Handle hObj
//		int value
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TimeWidgetSetValue(void* hObj, int value)
{
	timeWidget[WM_GetId(hObj) - eFirstTimeWidgetId].value = value;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TimeWidgetGetValue(BUTTON_Handle hObj)
//
//    Processing:
//		This operation gets value of current time widget
//
//    Input Parameters:
//		BUTTON_Handle hObj
//
//    Output Parameters:
//      current time value
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
int TimeWidgetGetValue(void* hObj)
{
	return timeWidget[WM_GetId(hObj) - eFirstTimeWidgetId].value;
}


#if defined(__cplusplus)
}
#endif

