/*
 * timesettingwidget.h
 *
 *  Created on: May 2, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_GUI_TIMESETTINGWIDGET_H_
#define UNITTEST_GUI_TIMESETTINGWIDGET_H_

#include "guidefine.h"
#include "WM.h"
//#include "BUTTON.h"

#define NUM_OF_TIME_WIDGET		7

//define color
#define TIMEWIDGET_SELECTED_BK_COLOR		COLOR_ULTRA_LIGHT_BLUE
#define TIMEWIDGET_UNSELECTED_BK_COLOR		SETTING_BAR_BOTTOM_COLOR
#define TIMEWIDGET_SELECTED_VALUE_COLOR		COLOR_LIGHT_ORANGE
#define TIMEWIDGET_UNSELECTED_VALUE_COLOR	GUI_WHITE

#define TIMEWIDGET_
//define range of time
#define SEC_MINUTE_MIN		0
#define SEC_MINUTE_MAX		59
#define HOUR_MIN			1
#define HOUR_MAX			12
#define DATE_MIN			1
#define DATE_MAX			31
#define MONTH_MIN			1
#define MONTH_MAX			12
#define YEAR_MIN			2000
#define YEAR_MAX			2050
#define AM					0
#define PM					1

//define id for time widget
typedef enum
{
	eFirstTimeWidgetId = 0,
	eDateSettingId = eFirstTimeWidgetId,
	eMonthSettingId,
	eYearSettingId,
	eHourSettingId,
	eMinuteSettingId,
	eSecondSettingId,
	eAmPmSettingId,
	eLastTimeWidgetId = eAmPmSettingId
} E_TimeWidgetId;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void TimeWidgetCallback(WM_MESSAGE * pMsg);
void TimeWidgetSetStatus(void* hObj, E_ButtonStatus status);//(BUTTON_Handle hObj, E_ButtonStatus status);
void TimeWidgetSetValue(void* hObj, int value);//(BUTTON_Handle hObj, int value);
int TimeWidgetGetValue(void* hObj);//(BUTTON_Handle hObj);
void TimeWidgetIncreaseValue(void* hObj);//(BUTTON_Handle hObj);
void TimeWidgetDecreaseValue(void* hObj);//(BUTTON_Handle hObj);
void TimeWidgetCustom(int id);
int GetTimeWidgetStatus(int id);
void TimeWigetDisplayValue(int id, int value, GUI_RECT Rect);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_TIMESETTINGWIDGET_H_ */
