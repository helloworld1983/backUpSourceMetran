/*
 * timesettingwidgetTest.cpp
 *
 *  Created on: May 2, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "timesettingwidget.h"
#include "guiglobal.h"
#include "WMMocks.h"
#include "strings.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern TimeWidgetContent timeWidget[];

namespace EmbeddedCUnitTest {


class TimeSettingWidgetTest : public TestFixture
{
public:
	TimeSettingWidgetTest() : TestFixture(new ModuleMock) {}
};

TEST_F(TimeSettingWidgetTest, GetTimeWidgetStatus)
{
	GetTimeWidgetStatus(eDateSettingId);

	EXPECT_EQ(eRelease,timeWidget[eDateSettingId - eFirstTimeWidgetId].status);
}

TEST_F(TimeSettingWidgetTest, TimeWigetDisplayValue1)
{
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_RIGHT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringAt(_,_,_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_LEFT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispDecAt(_,_,_,2)).Times(1);

	GUI_RECT Rect;
	language = 0;
	TimeWigetDisplayValue(eDateSettingId,10,Rect);
}

TEST_F(TimeSettingWidgetTest, TimeWigetDisplayValue2)
{
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_RIGHT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringAt(_,_,_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_LEFT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispDecAt(_,_,_,4)).Times(1);

	GUI_RECT Rect;
	language = 0;
	TimeWigetDisplayValue(eYearSettingId,10,Rect);
}

TEST_F(TimeSettingWidgetTest, TimeWigetDisplayValue3)
{
	EXPECT_CALL(*_WMLib,GUI_DispStringInRect(_,_,GUI_TA_HCENTER | GUI_TA_VCENTER)).Times(1);

	GUI_RECT Rect;
	language = 0;
	TimeWigetDisplayValue(eMonthSettingId,10,Rect);

	EXPECT_EQ("10月",std::string(monthStrJap[10 - 1]));

}

TEST_F(TimeSettingWidgetTest, TimeWigetDisplayValue4)
{
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringInRect(strAm[language],_,_)).Times(1);

	GUI_RECT Rect;
	language = 0;
	TimeWigetDisplayValue(eAmPmSettingId,0,Rect);

	EXPECT_EQ("午前",std::string(strAm[language]));
}

TEST_F(TimeSettingWidgetTest, TimeWigetDisplayValue5)
{
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringInRect(strPm[language],_,_)).Times(1);

	GUI_RECT Rect;
	language = 0;
	TimeWigetDisplayValue(eAmPmSettingId,1,Rect);

	EXPECT_EQ("午後",std::string(strPm[language]));
}

TEST_F(TimeSettingWidgetTest, TimeWigetDisplayValue6)
{
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispDecAt(_,_,_,2)).Times(1);

	GUI_RECT Rect;
	language = 0;
	TimeWigetDisplayValue(eSecondSettingId,1,Rect);
}

TEST_F(TimeSettingWidgetTest, TimeWigetDisplayValue7)
{
	EXPECT_CALL(*_WMLib,GUI_DispStringInRect(_,_,GUI_TA_HCENTER | GUI_TA_VCENTER)).Times(1);

	GUI_RECT Rect;
	language = 1;
	TimeWigetDisplayValue(eMonthSettingId,1,Rect);

	EXPECT_EQ("Jan",std::string(monthStrEng[eMonthSettingId - 1]));
}

TEST_F(TimeSettingWidgetTest, TimeWigetDisplayValue8)
{
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringInRect(strAm[language],_,GUI_TA_HCENTER | GUI_TA_VCENTER)).Times(1);

	GUI_RECT Rect;
	language = 1;
	TimeWigetDisplayValue(eAmPmSettingId,0,Rect);

	EXPECT_EQ("AM",std::string(strAm[language]));
}

TEST_F(TimeSettingWidgetTest, TimeWigetDisplayValue9)
{
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringInRect(strPm[language],_,GUI_TA_HCENTER | GUI_TA_VCENTER)).Times(1);

	GUI_RECT Rect;
	language = 1;
	TimeWigetDisplayValue(eAmPmSettingId,1,Rect);

	EXPECT_EQ("PM",std::string(strPm[language]));
}

TEST_F(TimeSettingWidgetTest, TimeWigetDisplayValue10)
{
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispDecAt(_,_,_,4)).Times(1);

	GUI_RECT Rect;
	language = 1;
	TimeWigetDisplayValue(eYearSettingId,1,Rect);
}

TEST_F(TimeSettingWidgetTest, TimeWigetDisplayValue11)
{
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispDecAt(_,_,_,2)).Times(1);

	GUI_RECT Rect;
	language = 1;
	TimeWigetDisplayValue(eSecondSettingId,1,Rect);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetCustom1)
{
	EXPECT_CALL(*_WMLib,GUI_SetColor(TIMEWIDGET_UNSELECTED_BK_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRoundedRect(_,_,_,_,3)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(TIMEWIDGET_UNSELECTED_VALUE_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetBkColor(TIMEWIDGET_UNSELECTED_BK_COLOR)).Times(1);

	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_RIGHT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringAt(_,_,_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_LEFT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispDecAt(_,_,_,2)).Times(1);

	language = 0;
	timeWidget[eDateSettingId - eFirstTimeWidgetId].status = eRelease;
	TimeWidgetCustom(eDateSettingId);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetCustom2)
{
	EXPECT_CALL(*_WMLib,GUI_SetColor(TIMEWIDGET_SELECTED_BK_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRoundedRect(_,_,_,_,3)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(TIMEWIDGET_UNSELECTED_VALUE_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetBkColor(TIMEWIDGET_SELECTED_BK_COLOR)).Times(1);

	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_RIGHT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringAt(_,_,_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_LEFT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispDecAt(_,_,_,2)).Times(1);

	language = 0;
	timeWidget[eDateSettingId - eFirstTimeWidgetId].status = ePoint;
	TimeWidgetCustom(eDateSettingId);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetCustom3)
{
	EXPECT_CALL(*_WMLib,GUI_SetColor(TIMEWIDGET_SELECTED_BK_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRoundedRect(_,_,_,_,3)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(TIMEWIDGET_SELECTED_VALUE_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetBkColor(TIMEWIDGET_SELECTED_BK_COLOR)).Times(1);

	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_RIGHT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringAt(_,_,_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_LEFT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispDecAt(_,_,_,2)).Times(1);

	language = 0;
	timeWidget[eDateSettingId - eFirstTimeWidgetId].status = eEnter;
	TimeWidgetCustom(eDateSettingId);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetCallback)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eDateSettingId));
	EXPECT_CALL(*_WMLib,GUI_SetColor(TIMEWIDGET_UNSELECTED_BK_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRoundedRect(_,_,_,_,3)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(TIMEWIDGET_UNSELECTED_VALUE_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetBkColor(TIMEWIDGET_UNSELECTED_BK_COLOR)).Times(1);

	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_RIGHT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringAt(_,_,_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_LEFT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispDecAt(_,_,_,2)).Times(1);

	language = 0;
	timeWidget[eDateSettingId - eFirstTimeWidgetId].status = eRelease;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	TimeWidgetCallback(&pMsg);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetSetStatus1)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eDateSettingId));

	TimeWidgetSetStatus(nullptr, eRelease);

	EXPECT_EQ(eRelease,timeWidget[eDateSettingId - eFirstTimeWidgetId].status);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetSetStatus2)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eMonthSettingId));

	TimeWidgetSetStatus(nullptr, ePoint);

	EXPECT_EQ(ePoint,timeWidget[eMonthSettingId - eFirstTimeWidgetId].status);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetSetStatus3)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eYearSettingId));

	TimeWidgetSetStatus(nullptr, eEnter);

	EXPECT_EQ(eEnter,timeWidget[eYearSettingId - eFirstTimeWidgetId].status);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetIncreaseValue1)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(eDateSettingId)).WillOnce(Return(eDateSettingId)).WillOnce(Return(eDateSettingId));
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	timeWidget[eDateSettingId - eFirstTimeWidgetId].value = 31;
	TimeWidgetIncreaseValue(nullptr);

	EXPECT_EQ(1,timeWidget[eDateSettingId - eFirstTimeWidgetId].value);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetIncreaseValue2)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(eMonthSettingId)).WillOnce(Return(eMonthSettingId)).WillOnce(Return(eMonthSettingId));
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	timeWidget[eMonthSettingId - eFirstTimeWidgetId].value = 15;
	TimeWidgetIncreaseValue(nullptr);

	EXPECT_EQ(1,timeWidget[eMonthSettingId - eFirstTimeWidgetId].value);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetIncreaseValue3)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(eHourSettingId)).WillOnce(Return(eHourSettingId)).WillOnce(Return(eHourSettingId));
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	timeWidget[eHourSettingId - eFirstTimeWidgetId].value = 18;
	TimeWidgetIncreaseValue(nullptr);

	EXPECT_EQ(1,timeWidget[eHourSettingId - eFirstTimeWidgetId].value);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetIncreaseValue4)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(eMinuteSettingId)).WillOnce(Return(eMinuteSettingId)).WillOnce(Return(eMinuteSettingId));
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	timeWidget[eMinuteSettingId - eFirstTimeWidgetId].value = 60;
	TimeWidgetIncreaseValue(nullptr);

	EXPECT_EQ(0,timeWidget[eMinuteSettingId - eFirstTimeWidgetId].value);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetIncreaseValue5)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(eSecondSettingId)).WillOnce(Return(eSecondSettingId)).WillOnce(Return(eSecondSettingId));
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	timeWidget[eSecondSettingId - eFirstTimeWidgetId].value = 70;
	TimeWidgetIncreaseValue(nullptr);

	EXPECT_EQ(0,timeWidget[eSecondSettingId - eFirstTimeWidgetId].value);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetIncreaseValue6)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(eAmPmSettingId)).WillOnce(Return(eAmPmSettingId)).WillOnce(Return(eAmPmSettingId));
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	timeWidget[eAmPmSettingId - eFirstTimeWidgetId].value = 2;
	TimeWidgetIncreaseValue(nullptr);

	EXPECT_EQ(0,timeWidget[eAmPmSettingId - eFirstTimeWidgetId].value);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetDecreaseValue1)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(eDateSettingId)).WillOnce(Return(eDateSettingId)).WillOnce(Return(eDateSettingId));
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	timeWidget[eDateSettingId - eFirstTimeWidgetId].value = 1;
	TimeWidgetDecreaseValue(nullptr);

	EXPECT_EQ(31,timeWidget[eDateSettingId - eFirstTimeWidgetId].value);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetDecreaseValue2)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(eMonthSettingId)).WillOnce(Return(eMonthSettingId)).WillOnce(Return(eMonthSettingId));
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	timeWidget[eMonthSettingId - eFirstTimeWidgetId].value = 1;
	TimeWidgetDecreaseValue(nullptr);

	EXPECT_EQ(12,timeWidget[eMonthSettingId - eFirstTimeWidgetId].value);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetDecreaseValue3)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(eHourSettingId)).WillOnce(Return(eHourSettingId)).WillOnce(Return(eHourSettingId));
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	timeWidget[eHourSettingId - eFirstTimeWidgetId].value = 1;
	TimeWidgetDecreaseValue(nullptr);

	EXPECT_EQ(12,timeWidget[eHourSettingId - eFirstTimeWidgetId].value);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetDecreaseValue4)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(eMinuteSettingId)).WillOnce(Return(eMinuteSettingId)).WillOnce(Return(eMinuteSettingId));
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	timeWidget[eMinuteSettingId - eFirstTimeWidgetId].value = 0;
	TimeWidgetDecreaseValue(nullptr);

	EXPECT_EQ(59,timeWidget[eMinuteSettingId - eFirstTimeWidgetId].value);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetDecreaseValue5)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(eSecondSettingId)).WillOnce(Return(eSecondSettingId)).WillOnce(Return(eSecondSettingId));
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	timeWidget[eSecondSettingId - eFirstTimeWidgetId].value = 0;
	TimeWidgetDecreaseValue(nullptr);

	EXPECT_EQ(59,timeWidget[eSecondSettingId - eFirstTimeWidgetId].value);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetDecreaseValue6)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(eAmPmSettingId)).WillOnce(Return(eAmPmSettingId)).WillOnce(Return(eAmPmSettingId));
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	timeWidget[eAmPmSettingId - eFirstTimeWidgetId].value = 0;
	TimeWidgetDecreaseValue(nullptr);

	EXPECT_EQ(1,timeWidget[eAmPmSettingId - eFirstTimeWidgetId].value);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetSetValue)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eAmPmSettingId));

	TimeWidgetSetValue(nullptr,10);

	EXPECT_EQ(10,timeWidget[eAmPmSettingId - eFirstTimeWidgetId].value);
}

TEST_F(TimeSettingWidgetTest, TimeWidgetGetValue)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eAmPmSettingId));

	timeWidget[eAmPmSettingId - eFirstTimeWidgetId].value = 100;
	TimeWidgetGetValue(nullptr);

	EXPECT_EQ(100,timeWidget[eAmPmSettingId - eFirstTimeWidgetId].value);
}

}


