/*
 * titlebar.cpp
 *
 *  Created on: May 2, 2018
 *      Author: Quoc Viet
 */

#include "titlebar.h"

#include <setting.h>
#include <stdbool.h>
//#include "fonts.h"
#include "strings.h"
#include "guiglobal.h"
#include "WMMocks.h"

//define color of title bar
//#define TITLE_BAR_TOP_COLOR				COLOR_ULTRA_LIGHT_BLUE
//#define	TITLE_BAR_BOTTOM_COLOR			0xA24E03
//#define TITLEBAR_HOME_RELEASE_COLOR		COLOR_ULTRA_LIGHT_BLUE
//#define TITLEBAR_HOME_SELECT_COLOR		COLOR_LIGHT_ORANGE

TitleBarStruct titleBarContent[NUM_OF_SCREEN] =
{
		{ strPatientSetting, ePoint },
		{ strHealthcareWorker, ePoint },
		{ strMaintenance, ePoint },
		{ strHistory, ePoint }
};

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//font 16
//static const GUI_FONT* guiFont16[] = { &GUI_FontMeiryo16B_2bpp, &GUI_FontJPAPJPFont16B };
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TitleBarCustom()
//
//    Processing:
//		This function is to custom titlebar
//
//    Input Parameters:
//		BUTTON_Handle hObj:	button object
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TitleBarCustom(void* hObj) {
	GUI_RECT Rect;
	WM_GetClientRect(&Rect);
	const char* homeString = strHome[language];
	const char* nameString = titleBarContent[WM_GetId(hObj) - eFirstTitleBarId].nameStr[language];
	//set status
	int status = titleBarContent[WM_GetId(hObj) - eFirstTitleBarId].status;
	//set font
//	GUI_SetFont(guiFont16[language]);
	GUI_SetBkColor(GUI_WHITE);
	GUI_AA_SetFactor(6);
	GUI_SetPenShape(GUI_PS_FLAT);
	GUI_SetTextMode(GUI_TM_TRANS);
	if(WM_GetId(hObj) != ePtTitleBarId)
		GUI_DrawGradientV(Rect.x0, Rect.y0, Rect.x1, Rect.y1, TITLE_BAR_TOP_COLOR, TITLE_BAR_BOTTOM_COLOR);

	GUI_SetColor(GUI_WHITE);

	GUI_SetTextAlign(GUI_TA_RIGHT);
	GUI_DispStringAt(nameString, Rect.x1 - 20, 5);

	switch (status) {
	case eRelease:
		GUI_SetColor(TITLEBAR_HOME_RELEASE_COLOR);
		GUI_AA_FillRoundedRect(Rect.x0 + 10, Rect.y0 + 3, 80, Rect.y1 - 3, 10);
		break;
	case ePoint:
		GUI_SetColor(TITLEBAR_HOME_SELECT_COLOR);
		GUI_AA_FillRoundedRect(Rect.x0 + 10, Rect.y0 + 3, 80, Rect.y1 - 3, 10);
		break;
	default:
		break;
	}

	GUI_SetColor(GUI_WHITE);
	GUI_SetTextAlign(GUI_TA_CENTER);
	GUI_DispStringAt(homeString, Rect.x0 + 45, 3);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TitleBarCallback()
//
//    Processing:
//		This is callback function for titlebar
//
//    Input Parameters:
//		WM_MESSAGE * pMsg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TitleBarCallback(WM_MESSAGE * pMsg) {
	switch (pMsg->MsgId) {
	case WM_PAINT:
		TitleBarCustom(nullptr);//(pMsg->hWin);
		break;
	default:
//		BUTTON_Callback(pMsg); // The original callback
		break;
	}
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: TitleBarSetStatus()
//
//    Processing:
//		This function set status for titlebar
//
//    Input Parameters:
//		BUTTON_Handle hObj: button object
//		int status
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void TitleBarSetStatus(void* hObj, E_ButtonStatus stt)
{
	titleBarContent[WM_GetId(hObj) - eFirstTitleBarId].status = stt;
}

unsigned char TitleBarGetStatus(void* hObj)
{
	return titleBarContent[WM_GetId(hObj) - eFirstTitleBarId].status;
}

#if defined(__cplusplus)
}
#endif

