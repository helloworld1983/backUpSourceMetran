/*
 * titlebar.h
 *
 *  Created on: May 2, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_GUI_TITLEBAR_H_
#define UNITTEST_GUI_TITLEBAR_H_

#include "WM.h"
//#include "BUTTON.h"
#include "guidefine.h"

//define color of title bar
#define TITLE_BAR_TOP_COLOR				COLOR_ULTRA_LIGHT_BLUE
#define	TITLE_BAR_BOTTOM_COLOR			0xA24E03
#define TITLEBAR_HOME_RELEASE_COLOR		COLOR_ULTRA_LIGHT_BLUE
#define TITLEBAR_HOME_SELECT_COLOR		COLOR_LIGHT_ORANGE

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void TitleBarCallback(WM_MESSAGE * pMsg);
void TitleBarSetStatus(void* hObj, E_ButtonStatus stt);
unsigned char TitleBarGetStatus(void* hObj);
void TitleBarCustom(void* hObj);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_GUI_TITLEBAR_H_ */
