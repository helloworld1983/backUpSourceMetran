/*
 * titlebarTest.cpp
 *
 *  Created on: May 2, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "titlebar.h"
#include "guiglobal.h"
#include "strings.h"
#include "WMMocks.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern TitleBarStruct titleBarContent[];

namespace EmbeddedCUnitTest {

class TitleBarTest : public TestFixture
{
public:
	TitleBarTest() : TestFixture(new ModuleMock) {}
};

TEST_F(TitleBarTest, TitleBarCustom1)
{
	EXPECT_CALL(*_WMLib,WM_GetClientRect(_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(ePtTitleBarId)).WillOnce(Return(ePtTitleBarId)).WillOnce(Return(ePtTitleBarId));
	EXPECT_CALL(*_WMLib,GUI_SetBkColor(GUI_WHITE)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_AA_SetFactor(6)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetPenShape(GUI_PS_FLAT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextMode(GUI_TM_TRANS)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(GUI_WHITE)).Times(2);
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_RIGHT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringAt(_,_, 5)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(TITLEBAR_HOME_SELECT_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_AA_FillRoundedRect(_,_,80,_, 10)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_CENTER)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringAt(_,_,3)).Times(1);

	language = 1;
	TitleBarCustom(nullptr);

	EXPECT_EQ("Home",std::string(strHome[language]));
	EXPECT_EQ("User setting",std::string(titleBarContent[ePtTitleBarId - eFirstTitleBarId].nameStr[language]));
	EXPECT_EQ(ePoint,titleBarContent[ePtTitleBarId - eFirstTitleBarId].status);
}

TEST_F(TitleBarTest, TitleBarCustom2)
{
	EXPECT_CALL(*_WMLib,WM_GetClientRect(_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(eHcwTitleBarId)).WillOnce(Return(eHcwTitleBarId)).WillOnce(Return(eHcwTitleBarId));
	EXPECT_CALL(*_WMLib,GUI_SetBkColor(GUI_WHITE)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_AA_SetFactor(6)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetPenShape(GUI_PS_FLAT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextMode(GUI_TM_TRANS)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DrawGradientV(_, _,_,_, TITLE_BAR_TOP_COLOR, TITLE_BAR_BOTTOM_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(GUI_WHITE)).Times(2);
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_RIGHT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringAt(_,_, 5)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(TITLEBAR_HOME_RELEASE_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_AA_FillRoundedRect(_,_,80,_, 10)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_CENTER)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringAt(_,_,3)).Times(1);

	language = 1;
	titleBarContent[eHcwTitleBarId - eFirstTitleBarId].status = eRelease;
	TitleBarCustom(nullptr);

	EXPECT_EQ("Home",std::string(strHome[language]));
	EXPECT_EQ("Clinician menu",std::string(titleBarContent[eHcwTitleBarId - eFirstTitleBarId].nameStr[language]));
}

TEST_F(TitleBarTest, TitleBarCallback)
{
	EXPECT_CALL(*_WMLib,WM_GetClientRect(_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(3).WillOnce(Return(ePtTitleBarId)).WillOnce(Return(ePtTitleBarId)).WillOnce(Return(ePtTitleBarId));
	EXPECT_CALL(*_WMLib,GUI_SetBkColor(GUI_WHITE)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_AA_SetFactor(6)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetPenShape(GUI_PS_FLAT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextMode(GUI_TM_TRANS)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(GUI_WHITE)).Times(2);
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_RIGHT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringAt(_,_, 5)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(TITLEBAR_HOME_SELECT_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_AA_FillRoundedRect(_,_,80,_, 10)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextAlign(GUI_TA_CENTER)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_DispStringAt(_,_,3)).Times(1);

	language = 1;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	TitleBarCallback(&pMsg);

	EXPECT_EQ("Home",std::string(strHome[language]));
	EXPECT_EQ("User setting",std::string(titleBarContent[ePtTitleBarId - eFirstTitleBarId].nameStr[language]));
	EXPECT_EQ(ePoint,titleBarContent[ePtTitleBarId - eFirstTitleBarId].status);
}

TEST_F(TitleBarTest, TitleBarSetStatus)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eMtnTitleBarId));
	TitleBarSetStatus(nullptr,eEnter);

	EXPECT_EQ(eEnter,titleBarContent[2].status);
}

TEST_F(TitleBarTest, TitleBarGetStatus)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eHtrTitleBarId));

	titleBarContent[3].status = ePoint;
	TitleBarGetStatus(nullptr);

	EXPECT_EQ(ePoint,titleBarContent[3].status);
}

}



