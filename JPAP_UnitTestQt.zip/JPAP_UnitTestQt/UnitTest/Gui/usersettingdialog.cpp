/*
 * usersettingdialog.cpp
 *
 *  Created on: May 2, 2018
 *      Author: Quoc Viet
 */
//#include "debuguart.h"
#include "titlebar.h"
//#include "GUI.h"
//#include "DIALOG.h"
#include <stdio.h>
#include <stdlib.h>
#include "settingbutton.h"
#include "confirmbutton.h"
#include "mode.h"
//#include "pwm.h"
//#include "systemlog.h"
#include "string.h"
//#include "systemconfig.h"
#include "strings.h"
#include <stddef.h>
#include "usersettingdialog.h"

#include <setting.h>
#include <systeminterface.h>

//#include "softtimer.h"
#include "guiglobal.h"
#include "timesettingdialog.h"
//#include "fonts.h"
#include "WMMocks.h"
#include "SoftTimerMocks.h"
#include "SettingBtnMocks.h"
#include "TitleBarMock.h"
#include "SettingMocks.h"

////define parameters of dialog
//#define USER_SETTING_SCREEN_X			30
//#define USER_SETTING_SCREEN_Y			20
//#define USER_SETTING_SCREEN_LENGTH		260
//#define USER_SETTING_SCREEN_WDRYING_HEIGHT		128
//#define USER_SETTING_SCREEN_WoDRYING_HEIGHT		96
////define color
//#define USER_SETTING_BK_COLOR			GUI_WHITE
//#define USER_SETTING_TITLE_BK_COLOR		COLOR_LIGHT_BLUE
//#define USER_SETTING_BORDER_COLOR		COLOR_ULTRA_LIGHT_BLUE
//#define USER_SETTING_LINE_COLOR			COLOR_GRAY
//#define USER_SETTING_EXPAND_SETTING_COLOR	COLOR_GRAY

E_SettingScreenState userScrCurrentState = eDialogState;
short userScrCurrentItem = 0;

short usersecondItem = 1;
short userendItem = USERSCREEN_WDRYING_NUM_BUTTON;
short userpreEndSetting = USERSCREEN_WDRYING_NUM_BUTTON - 1;
bool userisLogSetting = false;
short userScrCurrentId = 0;
short userNumOfButton = USERSCREEN_WDRYING_NUM_BUTTON;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//void UserScrCallback(WM_MESSAGE * pMsg);
//void UserScrSetItemStatus();
//function to handle enter key on user option screen
//void UserSettingHandleEnterKey();
//function to handle left key on user option screen
//void UserSettingHandleLeftKey();
//function to handle right key on user option screen
//void UserSettingHandleRightKey();
//function to relayout user option screen
//void UserScrRelayout();
//function to enter item
//void UserScrEnterItem();
//function to release item
//void UserScrReleaseItem();

//extern WM_HWIN operationScreen;					//main window instance
//static short userScrCurrentItem = 0;			//define current setting
//static short userScrCurrentId = 0;
//static short userNumOfButton = USERSCREEN_WDRYING_NUM_BUTTON;

//static short usersecondItem = 1;
//static short userendItem = USERSCREEN_WDRYING_NUM_BUTTON;
//static short userpreEndSetting = USERSCREEN_WDRYING_NUM_BUTTON - 1;

//WM_HWIN userOptionScreen;					//declare patient setting screen
//static BUTTON_Handle ptTitleBar;			//define title bar
//static BUTTON_Handle inhSupportBtn;			//define button inhalation
//static BUTTON_Handle exhSupportBtn;			//define button exhalation
//static BUTTON_Handle dryingModeBtn;
//static WM_HWIN buttonList[USERSCREEN_WDRYING_NUM_BUTTON];	//create button list

//static bool userisLogSetting = false;
//static bool isFocusTitle = false;

//static E_SettingScreenState userScrCurrentState = eDialogState;	//define current state
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: UserSettingDialogInit(void)
//
//    Processing:
//		The function creates patient screen
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void UserSettingDialogInit(void)
{
	userScrCurrentState = eDialogState;
	//init patient setting screen
//	userOptionScreen = WM_CreateWindowAsChild(USER_SETTING_SCREEN_X, USER_SETTING_SCREEN_Y, USER_SETTING_SCREEN_LENGTH, USER_SETTING_SCREEN_WDRYING_HEIGHT, operationScreen, WM_CF_HIDE | WM_CF_MEMDEV | WM_CF_LATE_CLIP  | WM_CF_HASTRANS , UserScrCallback, 0);
//	//init TITLE button
//	ptTitleBar = BUTTON_CreateEx(0, TITLE_BAR_Y, USER_SETTING_SCREEN_LENGTH, TITLE_BAR_HEIGHT, userOptionScreen, WM_CF_SHOW, WM_CF_MEMDEV, ePtTitleBarId);
//	WM_SetCallback(ptTitleBar, TitleBarCallback);
//	//init inhalation button
//	inhSupportBtn = BUTTON_CreateEx(0, BUTTON_Y, USER_SETTING_SCREEN_LENGTH, BUTTON_HEIGHT, userOptionScreen, WM_CF_SHOW, WM_CF_MEMDEV, eInhSupBtnId);
//	WM_SetCallback(inhSupportBtn, SettingBtnCallback);
//	//init exhalation button
//	exhSupportBtn = BUTTON_CreateEx(0, BUTTON_Y*2, USER_SETTING_SCREEN_LENGTH, BUTTON_HEIGHT, userOptionScreen, WM_CF_SHOW, WM_CF_MEMDEV, eExhSupBtnId);
//	WM_SetCallback(exhSupportBtn, SettingBtnCallback);
//	//init button drying mode
//	dryingModeBtn = BUTTON_CreateEx(0, BUTTON_Y*3, USER_SETTING_SCREEN_LENGTH, BUTTON_HEIGHT, userOptionScreen, WM_CF_SHOW, WM_CF_MEMDEV, eDryingModeBtnId);
//	WM_SetCallback(dryingModeBtn, SettingBtnCallback);
//	//create button list
//	buttonList[0] = ptTitleBar;
//	buttonList[1] = inhSupportBtn;
//	buttonList[2] = exhSupportBtn;
//	buttonList[3] = dryingModeBtn;
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: UserScrCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		The callback function of parent dialog (patient setting)
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void UserScrCallback(WM_MESSAGE * pMsg)
{
	GUI_RECT Rect;
	switch (pMsg->MsgId) {
	case WM_PAINT:
		//get size: x0, x1, y0, y1
		WM_GetClientRect(&Rect);
		GUI_SetPenShape(GUI_PS_ROUND);
		GUI_SetTextMode(GUI_TM_TRANS);

		//draw background
		GUI_SetColor(USER_SETTING_BK_COLOR);
		GUI_AA_FillRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1, 10);

		//draw title background
		GUI_SetColor(USER_SETTING_TITLE_BK_COLOR);
		GUI_AA_FillRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y0+31, 10);
		GUI_FillRect(Rect.x0, Rect.y0+15, Rect.x1, Rect.y0+31);

		//draw 2 lines between buttons
		GUI_SetColor(USER_SETTING_LINE_COLOR);
		GUI_DrawLine(Rect.x0, Rect.y0+64, Rect.x1, Rect.y0+64);
		GUI_DrawLine(Rect.x0, Rect.y0+96, Rect.x1, Rect.y0+96);

		//draw expand area
		if((userScrCurrentState == eSettingBarState)&&(userNumOfButton == USERSCREEN_WDRYING_NUM_BUTTON))
		{
			if(userScrCurrentId == eInhSupBtnId)
			{
				GUI_SetColor(USER_SETTING_EXPAND_SETTING_COLOR);
				GUI_FillRect(Rect.x0, Rect.y0+64, Rect.x1, Rect.y0+96);
			}
			else
			{
				GUI_SetColor(USER_SETTING_EXPAND_SETTING_COLOR);
				GUI_AA_FillRoundedRect(Rect.x0, Rect.y0+96, Rect.x1, Rect.y0+128, 10);
				GUI_FillRect(Rect.x0, Rect.y0+96, Rect.x1, Rect.y0+110);
			}
		}else if((userScrCurrentState == eSettingBarState)&&(userNumOfButton == USERSCREEN_WODRYING_NUM_BUTTON)){
			GUI_SetColor(USER_SETTING_EXPAND_SETTING_COLOR);
			GUI_AA_FillRoundedRect(Rect.x0, Rect.y0+64, Rect.x1, Rect.y0+96, 10);
			GUI_FillRect(Rect.x0, Rect.y0+64, Rect.x1, Rect.y0+80);
		}


		//draw border of dialog
		GUI_SetColor(USER_SETTING_BORDER_COLOR);
//		GUI_AA_DrawRoundedRect(Rect.x0, Rect.y0, Rect.x1, Rect.y1, 10);
		break;
	case WM_KEY:
	{
		SoftTimerResetMocks(eSoftTimer1Id);
		//		TimerReset(eTimer1Id);
		switch (((WM_KEY_INFO*)(pMsg->Data.p))->Key) {
		case GUI_KEY_RIGHT://GUI_KEY_LEFT:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
				UserSettingHandleRightKey();
			break;
		case GUI_KEY_LEFT://GUI_KEY_RIGHT:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
				UserSettingHandleLeftKey();
			break;
		case GUI_KEY_HOME:
			if(((WM_KEY_INFO*)(pMsg->Data.p))->PressedCnt == 1)
				UserSettingHandleEnterKey();
			break;
		case GUI_KEY_OPER:
			//send back this event to operation screen
			WM_SendMessage(nullptr, pMsg);//(operationScreen, pMsg);
			break;
		}
	}
	break;
	default:
		WM_DefaultProc(pMsg);
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: UserScrSetItemStatus()
//
//    Processing:
//		The function is to set status for all button
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void UserScrSetItemStatus()
{
	int id;
	for(int i = 0; i < userNumOfButton; i++)
	{
		//get id
		id = WM_GetId(nullptr);//(buttonList[i]);
		if((id >= eFirstSettingBtnId)&&(id <= eLastSettingBtnId))
		{
			if(id == WM_GetId(nullptr))//(buttonList[userScrCurrentItem]))
				SettingBtnSetStatusMocks(nullptr, ePoint);//(buttonList[userScrCurrentItem], ePoint);
			else
				SettingBtnSetStatusMocks(nullptr, eRelease);//(buttonList[i], eRelease);
		}
		else if(id == ePtTitleBarId)
		{
			if(id == WM_GetId(nullptr))//(buttonList[userScrCurrentItem]))
				TitleBarSetStatusMocks(nullptr, ePoint);//(ptTitleBar, ePoint);
			else
				TitleBarSetStatusMocks(nullptr, eRelease);//(ptTitleBar, eRelease);
		}
		WM_Paint(nullptr);//(buttonList[i]);
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: UserSettingHandleEnterKey()
//
//    Processing:
//		The function operates when a enter key is received
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void UserSettingHandleEnterKey()
{
	userScrCurrentId = WM_GetId(nullptr);//(buttonList[userScrCurrentItem]);//get current setting ID
	switch (userScrCurrentState)
	{
	case eDialogState:
		UserScrEnterItem();
		break;
	case eSettingBarState:
		UserScrReleaseItem();
		break;
	default:
		break;
	}
}
/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: UserScrEnterItem()
//
//    Processing:
//		The function enters current item
//
//    Input Parameters:
//		WM_HWIN hWin
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void UserScrEnterItem()
{
	if(userScrCurrentId == ePtTitleBarId)
	{
		SettingSaveMocks();									//save setting to EEPROM
		GuiTaskSendEvent(eGuiUserOptionHideId, 0);		//send event to hide user option setting
	}
	else if((userScrCurrentId >= eFirstSettingBtnId)&&(userScrCurrentId <= eLastSettingBtnId))
	{
		userScrCurrentState = eSettingBarState;							//change state of pt screen
		WM_SetYSize(nullptr, EXPAND_BUTTON_HEIGHT);//(buttonList[userScrCurrentItem], EXPAND_BUTTON_HEIGHT);	//resize current setting
		SettingBtnSetStatusMocks(nullptr, eEnter);//(buttonList[userScrCurrentItem], eEnter);		//enter current setting
		WM_Paint(nullptr);//(buttonList[userScrCurrentItem]);							//repaint current setting
		//set previous end setting
		userpreEndSetting = userendItem;
		if(userScrCurrentItem < (userNumOfButton - 1))
		{
			usersecondItem = 1;
			userendItem = 2;
		}
		else if(userScrCurrentItem == (userNumOfButton - 1))
		{
			usersecondItem = 2;
			userendItem = 3;
		}
		//relayout screen
		UserScrRelayout();

	}
	//	else if(userScrCurrentId == eDryingModeBtnId)
	//		GuiTaskSendEvent(eGuiPopupConfirmDryingModeId, 0);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: UserScrReleaseItem()
//
//    Processing:
//		The function release current item
//
//    Input Parameters:
//		WM_HWIN hWin
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void UserScrReleaseItem()
{
	WM_ShowWindow(nullptr);//(buttonList[1]);
	WM_ShowWindow(nullptr);//(buttonList[2]);
	WM_ShowWindow(nullptr);//(buttonList[3]);
	if((userScrCurrentId >= eFirstSettingBtnId)&&(userScrCurrentId <= eLastSettingBtnId))
	{
		WM_SetFocus(nullptr);//(userOptionScreen);								//focus pt screen
		SettingBtnSetStatusMocks(nullptr, ePoint);//(buttonList[userScrCurrentItem], ePoint);//point current setting
		WM_Paint(nullptr);//(buttonList[userScrCurrentItem]);					//repaint current setting
		userScrCurrentState = eDialogState;					//change state of pt screen
		WM_SetYSize(nullptr, BUTTON_HEIGHT);//(buttonList[userScrCurrentItem], BUTTON_HEIGHT);	//resize current setting
		if(userisLogSetting == true)
		{
			SettingbtnLogMocks(nullptr);//(buttonList[userScrCurrentItem]);
			userisLogSetting = false;
		}
		if(userScrCurrentId == eDryingModeBtnId)
		{
			GuiTaskSendEvent(eGuiPopupConfirmDryingModeId, 0);
		}
	}

	//relayout
	WM_MoveChildTo(nullptr,0,0);//(buttonList[0], 0, 0);
	WM_MoveChildTo(nullptr, 0, WM_GetYSize(nullptr));//(buttonList[1], 0, WM_GetYSize(buttonList[0]));
	WM_MoveChildTo(nullptr, 0, WM_GetYSize(nullptr)+WM_GetYSize(nullptr));//(buttonList[2], 0, WM_GetYSize(buttonList[0])+WM_GetYSize(buttonList[1]));
	WM_MoveChildTo(nullptr, 0, WM_GetYSize(nullptr)+WM_GetYSize(nullptr)+WM_GetYSize(nullptr));//(buttonList[3], 0, WM_GetYSize(buttonList[0])+WM_GetYSize(buttonList[1])+WM_GetYSize(buttonList[2]));
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: UserSettingHandleLeftKey()
//
//    Processing:
//		The function operates when a right key is received
//
//    Input Parameters:
//		WM_HWIN hWin
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void UserSettingHandleLeftKey()
{
	switch(userScrCurrentState)
	{
	case eDialogState:
		//increase current button
		userScrCurrentItem++;
		if(userScrCurrentItem >= userNumOfButton)
		{
			userScrCurrentItem = 0;
			usersecondItem = 1;	//front item is information dialog
			userendItem = userNumOfButton - 1;
		}
		//set status for all items
		UserScrSetItemStatus();
		break;
	case eSettingBarState:
		SettingBtnDecThumpPosMocks(nullptr);//(buttonList[userScrCurrentItem]);	//decrease setting bar
		userisLogSetting = true;
		break;
	default:
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: UserSettingHandleRightKey()
//
//    Processing:
//		The function operates when a left key is received
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void UserSettingHandleRightKey()
{
	switch(userScrCurrentState)
	{
	case eDialogState:
		//decrease current button
		userScrCurrentItem--;
		if(userScrCurrentItem < 0)
		{
			userScrCurrentItem = userNumOfButton - 1;
			userendItem = userScrCurrentItem;
			usersecondItem = userendItem - 2;
		}
		//set status for all settings
		UserScrSetItemStatus();
		break;
	case eSettingBarState:
		SettingBtnIncThumpPosMocks(nullptr);//(buttonList[userScrCurrentItem]);
		userisLogSetting = true;
		break;
	default:
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: MtnEnterLayout()
//
//    Processing:
//		The function layouts when ENTER key is pressed
//
//    Input Parameters:
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void UserSettingReload(E_GuiOperState operState)
{
	userScrCurrentState = eDialogState;
	userScrCurrentItem = 0;
	TitleBarSetStatusMocks(nullptr, ePoint);//(ptTitleBar, ePoint);
	WM_Paint(nullptr);//(ptTitleBar);
	SettingBtnSetStatusMocks(nullptr, eRelease);//(inhSupportBtn, eRelease);
	WM_SetYSize(nullptr, BUTTON_HEIGHT);//(inhSupportBtn, BUTTON_HEIGHT);	//resize current setting
	WM_ShowWindow(nullptr);//(inhSupportBtn);
	SettingBtnSetStatusMocks(nullptr, eRelease);//(exhSupportBtn, eRelease);
	WM_SetYSize(nullptr, BUTTON_HEIGHT);//(exhSupportBtn, BUTTON_HEIGHT);	//resize current setting
	WM_ShowWindow(nullptr);//(exhSupportBtn);
	SettingBtnSetStatusMocks(nullptr, eRelease);//(dryingModeBtn, eRelease);
	WM_MoveChildTo(nullptr, 0, 0);//(buttonList[0], 0, 0);
	WM_MoveChildTo(nullptr, 0, WM_GetYSize(nullptr));//(buttonList[1], 0, WM_GetYSize(buttonList[0]));
	WM_MoveChildTo(nullptr, 0, WM_GetYSize(nullptr)+WM_GetYSize(nullptr));//(buttonList[2], 0, WM_GetYSize(buttonList[0])+WM_GetYSize(buttonList[1]));
	WM_MoveChildTo(nullptr, 0, WM_GetYSize(nullptr)+WM_GetYSize(nullptr)+WM_GetYSize(nullptr));//(buttonList[3], 0, WM_GetYSize(buttonList[0])+WM_GetYSize(buttonList[1])+WM_GetYSize(buttonList[2]));
	//reset inhalation support
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(eInhPressSupportSettingId));//(inhSupportBtn, SettingGet(eInhPressSupportSettingId));
	//reset exhalation support
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(eExhPressSupportSettingId));//(exhSupportBtn, SettingGet(eExhPressSupportSettingId));
	//reset drying mode
	SettingBtnSetValueMocks(nullptr, SettingGetMocks(eCircuitTypeSettingId));//(dryingModeBtn, SettingGet(eCircuitTypeSettingId));

	if(operState == eGuiOperRunning){
		WM_HideWindow(nullptr);//(dryingModeBtn);
		userNumOfButton = USERSCREEN_WODRYING_NUM_BUTTON;
//		buttonList[0] = ptTitleBar;
//		buttonList[1] = inhSupportBtn;
//		buttonList[2] = exhSupportBtn;
		WM_SetYSize(nullptr, USER_SETTING_SCREEN_WoDRYING_HEIGHT);//(userOptionScreen, USER_SETTING_SCREEN_WoDRYING_HEIGHT);	//resize current setting
	}else{
		WM_ShowWindow(nullptr);//(dryingModeBtn);
		userNumOfButton = USERSCREEN_WDRYING_NUM_BUTTON;
//		buttonList[0] = ptTitleBar;
//		buttonList[1] = inhSupportBtn;
//		buttonList[2] = exhSupportBtn;
//		buttonList[3] = dryingModeBtn;
		WM_SetYSize(nullptr, USER_SETTING_SCREEN_WDRYING_HEIGHT);//(userOptionScreen, USER_SETTING_SCREEN_WDRYING_HEIGHT);	//resize current setting
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: UserScrRelayout()
//
//    Processing:
//		This operation relayout screen
//
//    Input Parameters:
//		None
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void UserScrRelayout()
{
	//show item from second to end and hide the rest
	for(int i = 1; i < userNumOfButton; i++)
	{
		if((i >= usersecondItem) && (i <= userendItem))
			WM_ShowWindow(nullptr);//(buttonList[i]);
		else
			WM_HideWindow(nullptr);//(buttonList[i]);
	}
	//bring front button to top
	WM_MoveChildTo(nullptr, 0 , BUTTON_HEIGHT);//(buttonList[usersecondItem], 0 , BUTTON_HEIGHT);
	WM_MoveChildTo(nullptr, 0 , BUTTON_HEIGHT + WM_GetYSize(nullptr));//(buttonList[userendItem], 0 , BUTTON_HEIGHT + WM_GetYSize(buttonList[usersecondItem]));
}

#if defined(__cplusplus)
}
#endif
