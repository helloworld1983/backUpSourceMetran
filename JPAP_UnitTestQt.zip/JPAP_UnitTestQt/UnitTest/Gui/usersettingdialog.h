/*
 * usersettingdialog.h
 *
 *  Created on: May 2, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_GUI_USERSETTINGDIALOG_H_
#define UNITTEST_GUI_USERSETTINGDIALOG_H_

#include <guiinterface.h>

#include "WM.h"
#include "guidefine.h"

//define parameters of dialog
#define USER_SETTING_SCREEN_X			30
#define USER_SETTING_SCREEN_Y			20
#define USER_SETTING_SCREEN_LENGTH		260
#define USER_SETTING_SCREEN_WDRYING_HEIGHT		128
#define USER_SETTING_SCREEN_WoDRYING_HEIGHT		96
//define color
#define USER_SETTING_BK_COLOR			GUI_WHITE
#define USER_SETTING_TITLE_BK_COLOR		COLOR_LIGHT_BLUE
#define USER_SETTING_BORDER_COLOR		COLOR_ULTRA_LIGHT_BLUE
#define USER_SETTING_LINE_COLOR			COLOR_GRAY
#define USER_SETTING_EXPAND_SETTING_COLOR	COLOR_GRAY

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//extern WM_HWIN userOptionScreen;

//function to initialize user option screen
void UserSettingDialogInit(void);
//function to load setting before display
void UserSettingReload(E_GuiOperState operState);
//set focus title bar
//void UserSettingFocusTitleBar(bool);
void UserScrCallback(WM_MESSAGE * pMsg);
void UserSettingHandleRightKey();
void UserScrSetItemStatus();
void UserSettingHandleLeftKey();
void UserScrEnterItem();
void UserScrRelayout();
void UserScrReleaseItem();
void UserSettingHandleEnterKey();

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_USERSETTINGDIALOG_H_ */
