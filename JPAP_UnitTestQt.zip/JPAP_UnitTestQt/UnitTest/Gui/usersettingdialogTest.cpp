/*
 * usersettingdialogTest.cpp
 *
 *  Created on: May 2, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "usersettingdialog.h"

#include <setting.h>
#include "WMMocks.h"
#include "SoftTimerMocks.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern E_SettingScreenState userScrCurrentState;
extern short userScrCurrentItem;
extern short usersecondItem;
extern short userendItem;
extern short userpreEndSetting;
extern bool userisLogSetting;
extern short userScrCurrentId;
extern short userNumOfButton;

namespace EmbeddedCUnitTest {


class UserSettingDialogTest : public TestFixture
{
public:
	UserSettingDialogTest() : TestFixture(new ModuleMock) {}
};

TEST_F(UserSettingDialogTest, UserSettingDialogInit)
{
	UserSettingDialogInit();
	EXPECT_EQ(eDialogState,userScrCurrentState);
}

TEST_F(UserSettingDialogTest, UserScrSetItemStatus)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(8)
									.WillOnce(Return(eDryingModeBtnId))
									.WillOnce(Return(eDryingModeBtnId))
									.WillOnce(Return(eFLBtnId))
									.WillOnce(Return(eAutoOffBtnId))
									.WillOnce(Return(ePtTitleBarId))
									.WillOnce(Return(ePtTitleBarId))
									.WillOnce(Return(eNaturalSupportTypeBtnId))
									.WillOnce(Return(eDisplayOffTimerBtnId));

	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_, eRelease)).Times(2);
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(4);

	UserScrSetItemStatus();
}

TEST_F(UserSettingDialogTest, UserSettingHandleRightKey1)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(8)
										.WillOnce(Return(eDryingModeBtnId))
										.WillOnce(Return(eDryingModeBtnId))
										.WillOnce(Return(eFLBtnId))
										.WillOnce(Return(eAutoOffBtnId))
										.WillOnce(Return(ePtTitleBarId))
										.WillOnce(Return(ePtTitleBarId))
										.WillOnce(Return(eNaturalSupportTypeBtnId))
										.WillOnce(Return(eDisplayOffTimerBtnId));

	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_, eRelease)).Times(2);
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(4);

	userScrCurrentItem = 0;
	userScrCurrentState = eDialogState;
	UserSettingHandleRightKey();

	EXPECT_EQ(3,userScrCurrentItem);
	EXPECT_EQ(3,userendItem);
	EXPECT_EQ(1,usersecondItem);
}

TEST_F(UserSettingDialogTest, UserSettingHandleRightKey2)
{
	EXPECT_CALL(*_settingBtnLib,SettingBtnIncThumpPosMocks(_)).Times(1);

	userScrCurrentState = eSettingBarState;
	UserSettingHandleRightKey();

	EXPECT_EQ(true,userisLogSetting);
}

TEST_F(UserSettingDialogTest, UserSettingHandleLeftKey1)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(8)
										.WillOnce(Return(eDryingModeBtnId))
										.WillOnce(Return(eDryingModeBtnId))
										.WillOnce(Return(eFLBtnId))
										.WillOnce(Return(eAutoOffBtnId))
										.WillOnce(Return(ePtTitleBarId))
										.WillOnce(Return(ePtTitleBarId))
										.WillOnce(Return(eNaturalSupportTypeBtnId))
										.WillOnce(Return(eDisplayOffTimerBtnId));

	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_, eRelease)).Times(2);
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(4);

	userScrCurrentState = eDialogState;
	userScrCurrentItem = 5;
	UserSettingHandleLeftKey();

	EXPECT_EQ(0,userScrCurrentItem);
	EXPECT_EQ(1,usersecondItem);
	EXPECT_EQ(3,userendItem);
}

TEST_F(UserSettingDialogTest, UserSettingHandleLeftKey2)
{
	EXPECT_CALL(*_settingBtnLib,SettingBtnDecThumpPosMocks(_)).Times(1);

	userScrCurrentState = eSettingBarState;
	UserSettingHandleLeftKey();

	EXPECT_EQ(true,userisLogSetting);
}

TEST_F(UserSettingDialogTest, UserScrRelayout1)
{
	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(3);
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,_,_)).Times(2);
	EXPECT_CALL(*_WMLib,WM_GetYSize(_)).Times(1);

	usersecondItem = 1;
	userendItem = 4;
	UserScrRelayout();
}

TEST_F(UserSettingDialogTest, UserScrRelayout2)
{
	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(2);
	EXPECT_CALL(*_WMLib,WM_HideWindow(_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,_,_)).Times(2);
	EXPECT_CALL(*_WMLib,WM_GetYSize(_)).Times(1);

	usersecondItem = 2;
	userendItem = 4;
	UserScrRelayout();
}

TEST_F(UserSettingDialogTest, UserScrEnterItem1)
{
	EXPECT_CALL(*_settingLib,SettingSaveMocks()).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	userScrCurrentId = ePtTitleBarId;
	UserScrEnterItem();
}

TEST_F(UserSettingDialogTest, UserScrEnterItem2)
{
	EXPECT_CALL(*_WMLib,WM_SetYSize(_, EXPAND_BUTTON_HEIGHT)).Times(1);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_, eEnter)).Times(1);
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(2);
	EXPECT_CALL(*_WMLib,WM_HideWindow(_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,_,_)).Times(2);
	EXPECT_CALL(*_WMLib,WM_GetYSize(_)).Times(1);

	userendItem = 2;
	userScrCurrentId = eLanguageSettingBtnId;
	UserScrEnterItem();

	EXPECT_EQ(eSettingBarState,userScrCurrentState);
	EXPECT_EQ(2,userpreEndSetting);
	EXPECT_EQ(1,usersecondItem);
	EXPECT_EQ(2,userendItem);
}

TEST_F(UserSettingDialogTest, UserScrEnterItem3)
{
	EXPECT_CALL(*_WMLib,WM_SetYSize(_, EXPAND_BUTTON_HEIGHT)).Times(1);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_, eEnter)).Times(1);
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(2);
	EXPECT_CALL(*_WMLib,WM_HideWindow(_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,_,_)).Times(2);
	EXPECT_CALL(*_WMLib,WM_GetYSize(_)).Times(1);

	userendItem = 3;
	userScrCurrentId = eLanguageSettingBtnId;
	UserScrEnterItem();

	EXPECT_EQ(eSettingBarState,userScrCurrentState);
	EXPECT_EQ(1,usersecondItem);
	EXPECT_EQ(2,userendItem);
}

TEST_F(UserSettingDialogTest, UserScrReleaseItem)
{
	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(3);
	EXPECT_CALL(*_WMLib,WM_SetFocus(_)).Times(1);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_,ePoint)).Times(1);
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_SetYSize(_, BUTTON_HEIGHT)).Times(1);
	EXPECT_CALL(*_settingBtnLib,SettingbtnLogMocks(_)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,_,_)).Times(4);
	EXPECT_CALL(*_WMLib,WM_GetYSize(_)).Times(6);

	userScrCurrentId = eDryingModeBtnId;
	userisLogSetting = true;
	UserScrReleaseItem();

	EXPECT_EQ(eDialogState,userScrCurrentState);
	EXPECT_EQ(false,userisLogSetting);
}

TEST_F(UserSettingDialogTest, UserSettingHandleEnterKey1)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(ePtTitleBarId));

	EXPECT_CALL(*_settingLib,SettingSaveMocks()).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	userScrCurrentState = eDialogState;
	UserSettingHandleEnterKey();
}

TEST_F(UserSettingDialogTest, UserSettingHandleEnterKey2)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(eDryingModeBtnId));
	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(3);
	EXPECT_CALL(*_WMLib,WM_SetFocus(_)).Times(1);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_,ePoint)).Times(1);
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_SetYSize(_, BUTTON_HEIGHT)).Times(1);
	EXPECT_CALL(*_settingBtnLib,SettingbtnLogMocks(_)).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,_,_)).Times(4);
	EXPECT_CALL(*_WMLib,WM_GetYSize(_)).Times(6);

	userisLogSetting = true;
	userScrCurrentState = eSettingBarState;
	UserSettingHandleEnterKey();

	EXPECT_EQ(eDialogState,userScrCurrentState);
	EXPECT_EQ(false,userisLogSetting);
}

TEST_F(UserSettingDialogTest, UserScrCallback1)
{
	EXPECT_CALL(*_WMLib,WM_GetClientRect(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetPenShape(GUI_PS_ROUND)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextMode(GUI_TM_TRANS)).Times(1);

	EXPECT_CALL(*_WMLib,GUI_SetColor(USER_SETTING_BK_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_AA_FillRoundedRect(_,_,_,_, 10)).Times(2);

	EXPECT_CALL(*_WMLib,GUI_SetColor(USER_SETTING_TITLE_BK_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRect(_,_,_,_)).Times(2);

	EXPECT_CALL(*_WMLib,GUI_DrawLine(_,_,_,_)).Times(2);

	EXPECT_CALL(*_WMLib,GUI_SetColor(USER_SETTING_EXPAND_SETTING_COLOR)).Times(2);
	EXPECT_CALL(*_WMLib,GUI_SetColor(USER_SETTING_BORDER_COLOR)).Times(1);

	userScrCurrentState = eSettingBarState;
	userNumOfButton = USERSCREEN_WDRYING_NUM_BUTTON;
	userScrCurrentId = eInhSupBtnId;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	UserScrCallback(&pMsg);
}

TEST_F(UserSettingDialogTest, UserScrCallback2)
{
	EXPECT_CALL(*_WMLib,WM_GetClientRect(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetPenShape(GUI_PS_ROUND)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextMode(GUI_TM_TRANS)).Times(1);

	EXPECT_CALL(*_WMLib,GUI_SetColor(USER_SETTING_BK_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_AA_FillRoundedRect(_,_,_,_, 10)).Times(3);

	EXPECT_CALL(*_WMLib,GUI_SetColor(USER_SETTING_TITLE_BK_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRect(_,_,_,_)).Times(2);

	EXPECT_CALL(*_WMLib,GUI_DrawLine(_,_,_,_)).Times(2);

	EXPECT_CALL(*_WMLib,GUI_SetColor(USER_SETTING_EXPAND_SETTING_COLOR)).Times(2);
	EXPECT_CALL(*_WMLib,GUI_SetColor(USER_SETTING_BORDER_COLOR)).Times(1);

	userScrCurrentState = eSettingBarState;
	userNumOfButton = USERSCREEN_WDRYING_NUM_BUTTON;
	userScrCurrentId = eExhSupBtnId;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	UserScrCallback(&pMsg);
}

TEST_F(UserSettingDialogTest, UserScrCallback3)
{
	EXPECT_CALL(*_WMLib,WM_GetClientRect(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetPenShape(GUI_PS_ROUND)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextMode(GUI_TM_TRANS)).Times(1);

	EXPECT_CALL(*_WMLib,GUI_SetColor(USER_SETTING_BK_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_AA_FillRoundedRect(_,_,_,_, 10)).Times(3);

	EXPECT_CALL(*_WMLib,GUI_SetColor(USER_SETTING_TITLE_BK_COLOR)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRect(_,_,_,_)).Times(2);

	EXPECT_CALL(*_WMLib,GUI_DrawLine(_,_,_,_)).Times(2);

	EXPECT_CALL(*_WMLib,GUI_SetColor(USER_SETTING_EXPAND_SETTING_COLOR)).Times(2);
	EXPECT_CALL(*_WMLib,GUI_SetColor(USER_SETTING_BORDER_COLOR)).Times(1);

	userScrCurrentState = eSettingBarState;
	userNumOfButton = USERSCREEN_WODRYING_NUM_BUTTON;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	UserScrCallback(&pMsg);
}

TEST_F(UserSettingDialogTest, UserScrCallback4)
{
	EXPECT_CALL(*_SoftTimerLib,SoftTimerResetMocks(eSoftTimer1Id)).Times(1);

	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(6)
										.WillOnce(Return(eDryingModeBtnId))
										.WillOnce(Return(eDryingModeBtnId))
										.WillOnce(Return(eFLBtnId))
										.WillOnce(Return(eAutoOffBtnId))
										.WillOnce(Return(ePtTitleBarId))
										.WillOnce(Return(ePtTitleBarId));

	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_, eRelease)).Times(1);
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(3);

	userScrCurrentItem = 0;
	userScrCurrentState = eDialogState;

	WM_KEY_INFO *keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_RIGHT;
	keyData->PressedCnt = 1;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	pMsg.Data.p = keyData;
	UserScrCallback(&pMsg);

	EXPECT_EQ(2,userScrCurrentItem);
	EXPECT_EQ(2,userendItem);
	EXPECT_EQ(0,usersecondItem);
}

TEST_F(UserSettingDialogTest, UserScrCallback5)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(6)
											.WillOnce(Return(eDryingModeBtnId))
											.WillOnce(Return(eDryingModeBtnId))
											.WillOnce(Return(eFLBtnId))
											.WillOnce(Return(eAutoOffBtnId))
											.WillOnce(Return(ePtTitleBarId))
											.WillOnce(Return(ePtTitleBarId));

	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_, eRelease)).Times(1);
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(3);

	userScrCurrentState = eDialogState;
	userScrCurrentItem = 5;

	WM_KEY_INFO *keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_LEFT;
	keyData->PressedCnt = 1;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	pMsg.Data.p = keyData;
	UserScrCallback(&pMsg);


	EXPECT_EQ(0,userScrCurrentItem);
	EXPECT_EQ(1,usersecondItem);
	EXPECT_EQ(2,userendItem);
}

TEST_F(UserSettingDialogTest, UserScrCallback6)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(ePtTitleBarId));

	EXPECT_CALL(*_settingLib,SettingSaveMocks()).Times(1);
	EXPECT_CALL(*_queueLib,xQueueSendToBack(_,_,_)).Times(1);

	userScrCurrentState = eDialogState;

	WM_KEY_INFO *keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_HOME;
	keyData->PressedCnt = 1;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	pMsg.Data.p = keyData;
	UserScrCallback(&pMsg);
}

TEST_F(UserSettingDialogTest, UserScrCallback7)
{
	EXPECT_CALL(*_WMLib,WM_SendMessage(_,_)).Times(1);

	WM_KEY_INFO *keyData = new WM_KEY_INFO;
	keyData->Key = GUI_KEY_OPER;
	keyData->PressedCnt = 1;
	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_KEY;
	pMsg.Data.p = keyData;
	UserScrCallback(&pMsg);
}

TEST_F(UserSettingDialogTest, UserScrCallback8)
{
	EXPECT_CALL(*_WMLib,WM_DefaultProc(_)).Times(1);

	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_TOUCH;
	UserScrCallback(&pMsg);
}

TEST_F(UserSettingDialogTest, UserSettingReload1)
{
	EXPECT_CALL(*_TitleBarLib,TitleBarSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_SetYSize(_, BUTTON_HEIGHT)).Times(2);
	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(2);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_, eRelease)).Times(3);
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,_,_)).Times(4);
	EXPECT_CALL(*_WMLib,WM_GetYSize(_)).Times(6);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetValueMocks(_,_)).Times(3);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eInhPressSupportSettingId)).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eExhPressSupportSettingId)).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eCircuitTypeSettingId)).Times(1);
	EXPECT_CALL(*_WMLib,WM_HideWindow(_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_SetYSize(_, USER_SETTING_SCREEN_WoDRYING_HEIGHT)).Times(1);

	UserSettingReload(eGuiOperRunning);

	EXPECT_EQ(eDialogState,userScrCurrentState);
	EXPECT_EQ(0,userScrCurrentItem);
	EXPECT_EQ(USERSCREEN_WODRYING_NUM_BUTTON,userNumOfButton);
}

TEST_F(UserSettingDialogTest, UserSettingReload2)
{
	EXPECT_CALL(*_TitleBarLib,TitleBarSetStatusMocks(_, ePoint)).Times(1);
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);
	EXPECT_CALL(*_WMLib,WM_SetYSize(_, BUTTON_HEIGHT)).Times(2);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetStatusMocks(_, eRelease)).Times(3);
	EXPECT_CALL(*_WMLib,WM_MoveChildTo(_,_,_)).Times(4);
	EXPECT_CALL(*_WMLib,WM_GetYSize(_)).Times(6);
	EXPECT_CALL(*_settingBtnLib,SettingBtnSetValueMocks(_,_)).Times(3);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eInhPressSupportSettingId)).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eExhPressSupportSettingId)).Times(1);
	EXPECT_CALL(*_settingLib,SettingGetMocks(eCircuitTypeSettingId)).Times(1);
	EXPECT_CALL(*_WMLib,WM_ShowWindow(_)).Times(3);
	EXPECT_CALL(*_WMLib,WM_SetYSize(_, USER_SETTING_SCREEN_WDRYING_HEIGHT)).Times(1);

	UserSettingReload(eGuiOperIdle);

	EXPECT_EQ(eDialogState,userScrCurrentState);
	EXPECT_EQ(0,userScrCurrentItem);
	EXPECT_EQ(USERSCREEN_WDRYING_NUM_BUTTON,userNumOfButton);
}

}


