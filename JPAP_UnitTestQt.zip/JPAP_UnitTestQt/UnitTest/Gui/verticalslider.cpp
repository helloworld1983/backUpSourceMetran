/*
 * verticalslider.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#include "verticalslider.h"
#include "WM.h"
#include "guidefine.h"
#include "WMMocks.h"
//#include "debuguart.h"

//#define LENGTH_OF_THUMP								64
////define color of slider bar
//#define VERTSLIDER_COLOR						COLOR_LIGHT_BLUE
////define color of thump
//#define VERTSLIDER_THUMP_COLOR					COLOR_LIGHT_ORANGE

int maxValue[NUM_OF_SCREEN] = {0, 0, 0, 0};
int setValue[NUM_OF_SCREEN] = {0, 0, 0, 0};
int testVerSliderCustom = 0;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: VerSliderCustom(SLIDER_Handle hObj)
//
//    Processing:
//		This function is to custom vertical slider
//
//    Input Parameters:
//		BUTTON_Handle hObj:	button object
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void VerSliderCustom(void* hObj)
{
	GUI_RECT Rect;
	//get position
	int pos = 96*setValue[WM_GetId(hObj) - eFirstVerSliderId]/maxValue[WM_GetId(hObj) - eFirstVerSliderId] - 1;
	testVerSliderCustom = pos;

	WM_GetClientRect(&Rect);
	GUI_SetBkColor(GUI_WHITE);
	GUI_AA_SetFactor(6);
	GUI_SetPenShape(GUI_PS_FLAT);
	GUI_SetTextMode(GUI_TM_TRANS);
	GUI_SetColor(VERTSLIDER_COLOR);
	//draw the bar
	GUI_FillRect(Rect.x0 + 8, Rect.y0, Rect.x0 + 12, Rect.y1);

	GUI_SetColor(VERTSLIDER_THUMP_COLOR);
	//draw the thump
	GUI_FillRoundedRect(Rect.x0 + 6, Rect.y0 + pos, Rect.x0 + 14, Rect.y0 + LENGTH_OF_THUMP + pos, 2);
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: VerSliderCallback(WM_MESSAGE * pMsg)
//
//    Processing:
//		This is callback function for vertical slider
//
//    Input Parameters:
//		WM_MESSAGE * pMsg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void VerSliderCallback(WM_MESSAGE * pMsg)
{
	switch (pMsg->MsgId)
	{
	case WM_PAINT:
		VerSliderCustom(nullptr);//(pMsg->hWin);
		break;
	default:
//		SLIDER_Callback(pMsg); // The original callback
		break;
	}
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SliderSetMax(SLIDER_Handle hObj, int value)
//
//    Processing:
//		This operation set max for the slider
//
//    Input Parameters:
//		WM_MESSAGE * pMsg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SliderSetMax(void* hObj, int value)
{
	maxValue[WM_GetId(hObj) - eFirstVerSliderId] = value;
}

/******************************************************************************/
//$COMMON.OPERATION$
//    Operation Name: SliderUpdate(SLIDER_Handle hObj, int value)
//
//    Processing:
//		This operation set value for the slider
//
//    Input Parameters:
//		WM_MESSAGE * pMsg
//
//    Output Parameters:
//      None
//
//    Return Values:
//      None
//
//    Pre-Conditions:
//      None
//
//    Miscellaneous:
//      None
//
//    Requirements:
//
/******************************************************************************/
void SliderUpdate(void* hObj, int value)
{
	setValue[WM_GetId(hObj) - eFirstVerSliderId] = value;
	WM_Paint(hObj);
}

#if defined(__cplusplus)
}
#endif
