/*
 * verticalslider.h
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_GUI_VERTICALSLIDER_H_
#define UNITTEST_GUI_VERTICALSLIDER_H_

//#include "SLIDER.h"
#include "WM.h"

#define LENGTH_OF_THUMP								64
//define color of slider bar
#define VERTSLIDER_COLOR						COLOR_LIGHT_BLUE
//define color of thump
#define VERTSLIDER_THUMP_COLOR					COLOR_LIGHT_ORANGE

typedef enum
{
	eFirstVerSliderId,
	ePtVertSliderId = eFirstVerSliderId,
	eHcwVertSliderId,
	eMtnVertSliderId,
	eHtrVertSliderId,
	eLastVertSliderId = eHtrVertSliderId,
} E_VerticalSliderId;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void VerSliderCallback(WM_MESSAGE * pMsg);
void SliderSetMax(void* hObj, int value);
void SliderUpdate(void* hObj, int value);
void VerSliderCustom(void* hObj);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_GUI_VERTICALSLIDER_H_ */
