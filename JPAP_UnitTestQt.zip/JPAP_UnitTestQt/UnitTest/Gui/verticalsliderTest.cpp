/*
 * verticalsliderTest.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#include "stdafx.h"
#include "Fixture.h"
#include "verticalslider.h"
#include "WMMocks.h"

using namespace std;
using namespace EmbeddedC;
using namespace ::testing;

extern int maxValue[];
extern int setValue[];
extern int testVerSliderCustom;

namespace EmbeddedCUnitTest {


class VerticalSliderTest : public TestFixture
{
public:
	VerticalSliderTest() : TestFixture(new ModuleMock) {}
};

TEST_F(VerticalSliderTest, VerSliderCustom)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(eHcwVertSliderId)).WillOnce(Return(ePtVertSliderId));
	EXPECT_CALL(*_WMLib,WM_GetClientRect(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetBkColor(GUI_WHITE)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_AA_SetFactor(6)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetPenShape(GUI_PS_FLAT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextMode(GUI_TM_TRANS)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(0x835D00)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRect(_,_,_,_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(0x24D3FF)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRoundedRect(_,_,_,_,2)).Times(1);

	setValue[eHcwVertSliderId - eFirstVerSliderId] = 1;
	maxValue[ePtVertSliderId - eFirstVerSliderId] = 2;

	VerSliderCustom(nullptr);

	EXPECT_EQ(47,testVerSliderCustom);
}

TEST_F(VerticalSliderTest, VerSliderCallback)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(2).WillOnce(Return(eHcwVertSliderId)).WillOnce(Return(ePtVertSliderId));
	EXPECT_CALL(*_WMLib,WM_GetClientRect(_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetBkColor(GUI_WHITE)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_AA_SetFactor(6)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetPenShape(GUI_PS_FLAT)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetTextMode(GUI_TM_TRANS)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(0x835D00)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRect(_,_,_,_)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_SetColor(0x24D3FF)).Times(1);
	EXPECT_CALL(*_WMLib,GUI_FillRoundedRect(_,_,_,_,2)).Times(1);

	setValue[eHcwVertSliderId - eFirstVerSliderId] = 1;
	maxValue[ePtVertSliderId - eFirstVerSliderId] = 1;

	WM_MESSAGE pMsg;
	pMsg.MsgId = WM_PAINT;
	VerSliderCallback(&pMsg);

	EXPECT_EQ(95,testVerSliderCustom);
}

TEST_F(VerticalSliderTest, SliderSetMax)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(0));

	SliderSetMax(nullptr,10);

	EXPECT_EQ(10,maxValue[0]);
}

TEST_F(VerticalSliderTest, SliderUpdate)
{
	EXPECT_CALL(*_WMLib,WM_GetId(_)).Times(1).WillOnce(Return(1));
	EXPECT_CALL(*_WMLib,WM_Paint(_)).Times(1);

	SliderUpdate(nullptr,50);

	EXPECT_EQ(50,setValue[1]);
}

}


