/*
 * AnalyzeDataMocks.h
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_ANALYZEDATAMOCKS_H_
#define UNITTEST_INC_ANALYZEDATAMOCKS_H_


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//function to get pressure at user's nose from AnalyzeData
//return true if getting data success
//return false if getting data failure
bool AnalyzeDataGetFilteredNosePressureMocks(float* valuePtr);

//function to get treatment pressure from AnalyzeData
//return true if getting data success
//return false if getting data failure
bool AnalyzeDataGetTreatmentPressureMocks(float* valuePtr);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_INC_ANALYZEDATAMOCKS_H_ */
