/*
 * ArmMath.h
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_INC_ARMMATH_H_
#define UNITTEST_INC_ARMMATH_H_

#include "stdint.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void arm_mean_f32(float * pSrc,uint32_t blockSize,float * pResult);
void arm_min_f32(float * pSrc,uint32_t blockSize,float * pResult,uint32_t * pIndex);
void arm_max_f32(float * pSrc,uint32_t blockSize,float * pResult,uint32_t * pIndex);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_ARMMATH_H_ */
