/*
 * Crc.h
 *
 *  Created on: Mar 22, 2018
 *      Author: WINDOWS
 */

#ifndef UNITTEST_INC_CRC_H_
#define UNITTEST_INC_CRC_H_


#if defined(__cplusplus)
namespace EmbeddedC {
#endif



unsigned short CrcCheckNoInit(long nBytes, char* pData );




#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_CRC_H_ */
