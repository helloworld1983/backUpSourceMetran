/*
 * CrcMocks.h
 *
 *  Created on: Apr 24, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_INC_CRCMOCKS_H_
#define UNITTEST_INC_CRCMOCKS_H_


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

unsigned short CrcCheckNoInitMocks(long nBytes, char *pData);


#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_CRCMOCKS_H_ */
