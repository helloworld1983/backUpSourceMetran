/*
 * EventMocks.h
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_INC_EVENTMOCKS_H_
#define UNITTEST_INC_EVENTMOCKS_H_

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void EventResetMocks();
void EventSetFLEnableMocks(bool isEnable);
void EventHandleDataMocks(float flow, float pressure);
void EventCSresetMocks();
void EventCSaddDataMocks(float data);
void EventCScheckBreathMocks();
void EventCScheckCancelMocks();
void EventCScheckApneaMocks(unsigned long time);
short EventCSgetCountMocks();
void EventCSexitApneaMocks(unsigned long time);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_INC_EVENTMOCKS_H_ */
