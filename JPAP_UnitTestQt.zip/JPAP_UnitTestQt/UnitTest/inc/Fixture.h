#ifndef __FIXTURE_H__
#define __FIXTURE_H__

#include "ServicesMocks.h"
#include "ModuleMock.h"
#include "queue.h"
#include "gtest.h"

namespace EmbeddedCUnitTest {

class TestFixture : public ::testing::Test
{
public:
	TestFixture(BaseModuleMock *mocks)
	{

		_crc.reset(new ::testing::NiceMock<CRCService>());
		_spi_flash.reset(new ::testing::NiceMock<SpiFlashService>());
		_memcp.reset(new ::testing::NiceMock<memcpyService>());
		_wstring.reset(new ::testing::NiceMock<WstringService>());
		_timeLib.reset(new ::testing::NiceMock<TimeLibService>());
		_queueLib.reset(new ::testing::NiceMock<QueueOsService>());
		_settingLib.reset(new ::testing::NiceMock<SettingService>());
		_settingBtnLib.reset(new ::testing::NiceMock<SettingBtnService>());
		_MainScreenLib.reset(new ::testing::NiceMock<MainScreenService>());
		_PWMLib.reset(new ::testing::NiceMock<PWMService>());
		_WWDTLib.reset(new ::testing::NiceMock<WWDTService>());
		_LogTableLib.reset(new ::testing::NiceMock<LogTableService>());
		_SliderLib.reset(new ::testing::NiceMock<SliderService>());
		_TitleBarLib.reset(new ::testing::NiceMock<TitleBarService>());
		_TimeDialogLib.reset(new ::testing::NiceMock<TimeDialogService>());
		_WMLib.reset(new ::testing::NiceMock<WMService>());
		_InforDlgLib.reset(new ::testing::NiceMock<InforDlgService>());
		_SysInforTableLib.reset(new ::testing::NiceMock<SystemInforTableService>());
		_AnalyzeDataLib.reset(new ::testing::NiceMock<AnalyzeDataService>());
		_ProgbarLib.reset(new ::testing::NiceMock<ProgbarService>());
		_UserSettingLib.reset(new ::testing::NiceMock<UserSettingService>());
		_SoftTimerLib.reset(new ::testing::NiceMock<SoftTimerService>());
		_SleepScrLib.reset(new ::testing::NiceMock<SleepScrService>());
		_EEPROMLib.reset(new ::testing::NiceMock<EEPROMService>());
		_FFLib.reset(new ::testing::NiceMock<FFService>());
		_CRCJAPLib.reset(new ::testing::NiceMock<CRCJPAPService>());
		_RTCLib.reset(new ::testing::NiceMock<RTCService>());
		_PowerMonitorLib.reset(new ::testing::NiceMock<PoweMonitorService>());
		_EventLib.reset(new ::testing::NiceMock<EventService>());
		_PhaseLib.reset(new ::testing::NiceMock<PhaseService>());
		_BreathDataLib.reset(new ::testing::NiceMock<BreathDataService>());
		_MaskOffLib.reset(new ::testing::NiceMock<MaskOffService>());
		_MotorDataLib.reset(new ::testing::NiceMock<MotorDataService>());
		_RtBufferLib.reset(new ::testing::NiceMock<RtBufferService>());
		_ArmMathLib.reset(new ::testing::NiceMock<ArmMathService>());
		_VolumeLib.reset(new ::testing::NiceMock<VolumeService>());
		_modulesMocks.reset(mocks);
	}

	~TestFixture()
	{
		_crc.reset();
		_spi_flash.reset();
		_memcp.reset();
		_wstring.reset();
		_timeLib.reset();
		_queueLib.reset();
		_settingLib.reset();
		_settingBtnLib.reset();
		_MainScreenLib.reset();
		_PWMLib.reset();
		_WWDTLib.reset();
		_LogTableLib.reset();
		_SliderLib.reset();
		_TitleBarLib.reset();
		_TimeDialogLib.reset();
		_WMLib.reset();
		_InforDlgLib.reset();
		_SysInforTableLib.reset();
		_AnalyzeDataLib.reset();
		_ProgbarLib.reset();
		_UserSettingLib.reset();
		_SoftTimerLib.reset();
		_SleepScrLib.reset();
		_EEPROMLib.reset();
		_FFLib.reset();
		_CRCJAPLib.reset();
		_RTCLib.reset();
		_PowerMonitorLib.reset();
		_EventLib.reset();
		_PhaseLib.reset();
		_BreathDataLib.reset();
		_MaskOffLib.reset();
		_MotorDataLib.reset();
		_RtBufferLib.reset();
		_ArmMathLib.reset();
		_VolumeLib.reset();
		_modulesMocks.reset();
	}

	template<typename T>
	static T& GetMock()
	{
		auto ptr = dynamic_cast<T*>(_modulesMocks.get());
		if (ptr == nullptr)
		{
			auto errMsg = "The test does not provide mock of \"" + std::string(typeid(T).name()) + "\"";
			throw std::exception(errMsg.c_str());
		}
		return *ptr;
	}

	// Services

	static std::unique_ptr<CRCService> _crc;
	static std::unique_ptr<SpiFlashService> _spi_flash;
	static std::unique_ptr<memcpyService> _memcp;
	static std::unique_ptr<WstringService> _wstring;
	static std::unique_ptr<TimeLibService> _timeLib;
	static std::unique_ptr<QueueOsService> _queueLib;
	static std::unique_ptr<SettingService> _settingLib;
	static std::unique_ptr<SettingBtnService> _settingBtnLib;
	static std::unique_ptr<MainScreenService> _MainScreenLib;
	static std::unique_ptr<PWMService> _PWMLib;
	static std::unique_ptr<WWDTService> _WWDTLib;
	static std::unique_ptr<LogTableService> _LogTableLib;
	static std::unique_ptr<SliderService> _SliderLib;
	static std::unique_ptr<TitleBarService> _TitleBarLib;
	static std::unique_ptr<TimeDialogService> _TimeDialogLib;
	static std::unique_ptr<WMService> _WMLib;
	static std::unique_ptr<InforDlgService> _InforDlgLib;
	static std::unique_ptr<SystemInforTableService> _SysInforTableLib;
	static std::unique_ptr<AnalyzeDataService> _AnalyzeDataLib;
	static std::unique_ptr<ProgbarService> _ProgbarLib;
	static std::unique_ptr<UserSettingService> _UserSettingLib;
	static std::unique_ptr<SoftTimerService> _SoftTimerLib;
	static std::unique_ptr<SleepScrService> _SleepScrLib;
	static std::unique_ptr<EEPROMService> _EEPROMLib;
	static std::unique_ptr<FFService> _FFLib;
	static std::unique_ptr<CRCJPAPService> _CRCJAPLib;
	static std::unique_ptr<RTCService> _RTCLib;
	static std::unique_ptr<PoweMonitorService> _PowerMonitorLib;
	static std::unique_ptr<EventService> _EventLib;
	static std::unique_ptr<PhaseService> _PhaseLib;
	static std::unique_ptr<BreathDataService> _BreathDataLib;
	static std::unique_ptr<MaskOffService> _MaskOffLib;
	static std::unique_ptr<MotorDataService> _MotorDataLib;
	static std::unique_ptr<RtBufferService> _RtBufferLib;
	static std::unique_ptr<ArmMathService> _ArmMathLib;
	static std::unique_ptr<VolumeService> _VolumeLib;
	// Modules mocks
	static std::unique_ptr<BaseModuleMock> _modulesMocks;
};

}


#endif
