/*
 * InforDlgMocks.h
 *
 *  Created on: Apr 17, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_INFORDLGMOCKS_H_
#define UNITTEST_INC_INFORDLGMOCKS_H_


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void InforDlgSetStatus(int status);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_INC_INFORDLGMOCKS_H_ */
