/*
 * LogTableMocks.h
 *
 *  Created on: Apr 13, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_LOGTABLEMOCKS_H_
#define UNITTEST_INC_LOGTABLEMOCKS_H_


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void LogTableInitMocks();
void LogTableDeleteLastRowMocks();
void LogTableReloadMocks();
int SysLogGetNumRecordsMocks();
unsigned char SysLogGetEndByteMocks();
unsigned char SysLogGetEndPageMocks();
void SysLogReadMocks(unsigned char page, char* buffer);
void LogTableAddRowMocks(int numericalOrder,unsigned char* data, unsigned char rowIndex);
void LogTableSetSelMocks(int row);
void LogTableIncSelMocks();
int LogTableGetSelMoc();
void LogTableDeleteFirstRowMocks();
void LogTableDecSelMocks();

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_LOGTABLEMOCKS_H_ */
