/*
 * MainScreenMocks.h
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_MAINSCREENMOCKS_H_
#define UNITTEST_INC_MAINSCREENMOCKS_H_

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//function to handle event on GUI
void MainScreenHandleEventMocks(void* guiEvent);
void StartupScreenShowMocks(void);
bool MainUpgradeCheckMocks();

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_MAINSCREENMOCKS_H_ */
