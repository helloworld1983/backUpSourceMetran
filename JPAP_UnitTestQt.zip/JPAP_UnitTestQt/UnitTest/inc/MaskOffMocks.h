/*
 * MaskOffMocks.h
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_INC_MASKOFFMOCKS_H_
#define UNITTEST_INC_MASKOFFMOCKS_H_

#include <stdbool.h>
#include "stdint.h"

//define 2 state of mask is OFF and ON
typedef enum
{
	eMaskOn = 0,		// mask on
	eMaskOffDry,	// mask off for dry
	eMaskOffStop	// mask off for stop
} E_MaskState;


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void MaskOffSetStateMocks(uint8_t state);
void MaskOffSetEnableMocks(bool isEnable);
void MaskOffHandleDataMocks(float flow, float pressure);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_MASKOFFMOCKS_H_ */
