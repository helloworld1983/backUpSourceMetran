/*
 * MotorDataMocks.h
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_INC_MOTORDATAMOCKS_H_
#define UNITTEST_INC_MOTORDATAMOCKS_H_


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

bool MotorDataGetFlowMocks(float* valuePtr);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_MOTORDATAMOCKS_H_ */
