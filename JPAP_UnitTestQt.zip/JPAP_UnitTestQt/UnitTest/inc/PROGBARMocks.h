/*
 * PROGBARMocks.h
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_PROGBARMOCKS_H_
#define UNITTEST_INC_PROGBARMOCKS_H_


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void PROGBAR_GetMinMax(void* hObj, int * pMin, int * pMax);
void PROGBAR_SetValue(void* hObj, int v);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_PROGBARMOCKS_H_ */
