/*
 * PWMLib.h
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_PWMLIB_H_
#define UNITTEST_INC_PWMLIB_H_

#include "stdint.h"

#define PWM_LCDBL_MIN		30		// mininum 30% LCD back light brightness
#define PWM_LCDBL_MAX		100		// maximun 100% PWM at LCD backlight
#define PWM_LCDBL_STEP		10		//((PWM_LCDBL_MAX - PWM_LCDBL_MIN)/PWM_LCDBL_NUMSTEP)	//step of changing

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

typedef enum
{
	ePWMLCDBLId = 0,		//LCD back light pwm Id
	ePWMBuzzerId			//buzzer pwm id
} E_PWMId;

void PWMSetDutyMocks(uint8_t id, unsigned int duty);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_PWMLIB_H_ */
