/*
 * PhaseMocks.h
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_INC_PHASEMOCKS_H_
#define UNITTEST_INC_PHASEMOCKS_H_


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void PhaseResetMocks();
void PhaseHandleDataMocks(float flow, float pressure);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_PHASEMOCKS_H_ */
