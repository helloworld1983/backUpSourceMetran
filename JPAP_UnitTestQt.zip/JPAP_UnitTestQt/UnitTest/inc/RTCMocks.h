/*
 * RTCMocks.h
 *
 *  Created on: Apr 26, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_INC_RTCMOCKS_H_
#define UNITTEST_INC_RTCMOCKS_H_

#include "stdint.h"

/** @brief Time structure definitions for easy manipulate the data */
typedef struct
{
	/** Seconds Register */
	uint32_t SEC;
	/** Minutes Register */
	uint32_t MIN;
	/** Hours Register */
	uint32_t HOUR;
	/** Day of Month Register */
	uint32_t DOM;
	/** Day of Week Register */
	uint32_t DOW;
	/** Day of Year Register */
	uint32_t DOY;
	/** Months Register */
	uint32_t MONTH;
	/** Years Register */
	uint32_t YEAR;
} RTC_TIME_Type;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

RTC_TIME_Type RTCGetMocks();
void RTCSetMocks(void* time);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_RTCMOCKS_H_ */
