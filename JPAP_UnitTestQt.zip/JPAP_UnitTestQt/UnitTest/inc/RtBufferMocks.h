/*
 * RtBufferMocks.h
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_INC_RTBUFFERMOCKS_H_
#define UNITTEST_INC_RTBUFFERMOCKS_H_


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void RtBufferHandleDataMocks(float flow, float pressure);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_RTBUFFERMOCKS_H_ */
