#ifndef __SERVICEMOCK_H__
#define __SERVICEMOCK_H__
#include <string>

using namespace std;
namespace EmbeddedCUnitTest {


class CRCService
{
public:
	virtual ~CRCService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD2(CrcCheckNoInit, unsigned short(long, char*));
};

class SpiFlashService
{
public:
	virtual ~SpiFlashService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD3( spi_flash_read, int(size_t, void*, size_t));
	MOCK_METHOD3( spi_flash_write, int(size_t, const void*, size_t));
	MOCK_METHOD1( spi_flash_erase_sector, int(size_t));
};

class TimeLibService
{
public:
	virtual ~TimeLibService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD0(year, int());
	MOCK_METHOD0(month, int());
	MOCK_METHOD0(day, int());
	MOCK_METHOD0(hour, int());
	MOCK_METHOD0(minute, int());
	MOCK_METHOD0(second, int());
};

class memcpyService
{
public:
	virtual ~memcpyService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD3(memcpy, void*(void*, const void*, size_t));
};

class WstringService
{
public:
	virtual ~WstringService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD1(String, string(int));
	MOCK_METHOD1(strlen, size_t(const char*));
	MOCK_METHOD3(StrAppend, unsigned char(char*, const char*, unsigned char));
	MOCK_METHOD3(StrToolItoA, int(long int a, char* buff, int numOfDigit));
	MOCK_METHOD2(strcat, char*(char*, const char*));
	MOCK_METHOD3(strncat, char*(char*, const char*, size_t));
	MOCK_METHOD3(StrToolItoHexS, int(unsigned int,char*, int));
	MOCK_METHOD3(StrToolFtoA, int(float, char*, int));
	MOCK_METHOD2(StrToolTtoS, int(char*, int));
	MOCK_METHOD3(itoa, char *(int, char *, unsigned int));
	MOCK_METHOD2(strcmp, int(const char *, const char *));
	MOCK_METHOD1(atof, double(const char *));
	MOCK_METHOD1(atoi, int(const char *));
	MOCK_METHOD3(memset, void *(void *,int,size_t));
};

class QueueOsService
{
public:
	virtual ~QueueOsService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD3(xQueueSend,long(void*,const void* const, uint32_t));
	MOCK_METHOD1(xQueueReset,long(void*));
	MOCK_METHOD3(xQueueReceive,long(void*,const void* const, uint32_t));
	MOCK_METHOD3(xQueueSendToBack,long(void*,const void* const, uint32_t));
	MOCK_METHOD1(vTaskDelay,void(uint32_t));
	MOCK_METHOD2(xSemaphoreTake,long(void*,unsigned long));
	MOCK_METHOD0(taskENTER_CRITICAL,void());
	MOCK_METHOD1(xSemaphoreGive,long(void*));
	MOCK_METHOD0(taskEXIT_CRITICAL,void());
	MOCK_METHOD0(xTaskGetTickCount,long());
	MOCK_METHOD1(MotorTaskSendEvent,bool(unsigned char));
	MOCK_METHOD2(SystemTaskSendEvent,bool(uint8_t, long));
	MOCK_METHOD2(GuiTaskSendEventMocks,bool(unsigned char, long));
};

class SettingService
{
public:
	virtual ~SettingService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD0(SettingSaveMocks,void());
	MOCK_METHOD1(SettingGetMocks,uint8_t(uint8_t));
	MOCK_METHOD0(SettingReadFromSdMocks,bool());
	MOCK_METHOD0(SettingSetRequestReadSdMocks,void());
	MOCK_METHOD0(SettingSetDefaultMocks,void());
	MOCK_METHOD2(SettingSetMocks,void(uint8_t id, unsigned char value));
};

class SettingBtnService
{
public:
	virtual ~SettingBtnService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD2(SettingBtnSetValueMocks,void(void*,int));
	MOCK_METHOD2(SettingBtnSetStatusMocks,void(void*,int));
	MOCK_METHOD1(SettingbtnLogMocks,void(void*));
	MOCK_METHOD1(SettingBtnDecThumpPosMocks,void(void*));
	MOCK_METHOD1(SettingBtnIncThumpPosMocks,void(void*));
};

class MainScreenService
{
public:
	virtual ~MainScreenService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD1(MainScreenHandleEventMocks,void(void*));
	MOCK_METHOD0(StartupScreenShowMocks,void());
	MOCK_METHOD0(MainUpgradeCheckMocks,bool());
};

class PWMService
{
public:
	virtual ~PWMService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD2(PWMSetDutyMocks,void(uint8_t, unsigned int));
};

class WWDTService
{
public:
	virtual ~WWDTService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD1(WWDT_CmdMocks,void(uint8_t));
	MOCK_METHOD0(WatchDogFeedMocks,void());
};

class LogTableService
{
public:
	virtual ~LogTableService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD0(LogTableInitMocks,void());
	MOCK_METHOD0(LogTableDeleteLastRowMocks,void());
	MOCK_METHOD0(LogTableReloadMocks,void());
	MOCK_METHOD0(SysLogGetNumRecordsMocks,int());
	MOCK_METHOD0(SysLogGetEndByteMocks,unsigned char());
	MOCK_METHOD0(SysLogGetEndPageMocks,unsigned char());
	MOCK_METHOD2(SysLogReadMocks,void(unsigned char, char*));
	MOCK_METHOD3(LogTableAddRowMocks, void(int,unsigned char*, unsigned char));
	MOCK_METHOD1(LogTableSetSelMocks,void(int));
	MOCK_METHOD0(LogTableIncSelMocks,void());
	MOCK_METHOD0(LogTableGetSelMoc,int());
	MOCK_METHOD0(LogTableDeleteFirstRowMocks,void());
	MOCK_METHOD0(LogTableDecSelMocks,void());
};

class SliderService
{
public:
	virtual ~SliderService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD2(SliderSetMaxMocks,void(void*, int));
	MOCK_METHOD2(SliderUpdateMocks,void(void*, int));
};

class TitleBarService
{
public:
	virtual ~TitleBarService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD2(TitleBarSetStatusMocks,void(void*, uint8_t));
};

class TimeDialogService
{
public:
	virtual ~TimeDialogService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD0(TimeDialogReloadMocks,void());
	MOCK_METHOD1(TimeDialogSetStatusMocks,void(int));
	MOCK_METHOD2(TimeWidgetSetStatusMocks,void(void*, uint8_t));
	MOCK_METHOD1(TimeWidgetIncreaseValueMocks,void(void*));
	MOCK_METHOD1(TimeWidgetGetValueMocks,int(void*));
	MOCK_METHOD1(TimeWidgetDecreaseValueMocks,void(void*));
	MOCK_METHOD2(TimeWidgetSetValueMocks,void(void*, int));
};

class WMService
{
public:
	virtual ~WMService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD1(WM_GetId,int(void*));
	MOCK_METHOD1(WM_GetInsideRect,void(void *));
	MOCK_METHOD1(GUI_SetBkColor,void(uint32_t));
	MOCK_METHOD1(GUI_SetColor,void(uint32_t));
	MOCK_METHOD1(GUI_ClearRectEx,void(const void*));
	MOCK_METHOD1(GUI_SetPenSize,uint8_t(uint8_t));
	MOCK_METHOD4(GUI_DrawLine,void(int,int,int,int));
	MOCK_METHOD1(WM_DefaultProc,void(void*));
	MOCK_METHOD1(WM_HideWindow,void(void*));
	MOCK_METHOD1(WM_ShowWindow,void(void*));
	MOCK_METHOD3(WM_MoveChildTo,void(void*,int,int));
	MOCK_METHOD1(WM_GetClientRect,void(void*));
	MOCK_METHOD4(GUI_FillRect,void(int,int,int,int));
	MOCK_METHOD1(WM_SetFocus,int(void*));
	MOCK_METHOD1(GUI_AA_SetFactor,void(int));
	MOCK_METHOD1(GUI_SetPenShape,uint8_t(uint8_t));
	MOCK_METHOD1(GUI_SetTextMode,int(int));
	MOCK_METHOD2(WM_SetYSize,int(void*, int));
	MOCK_METHOD5(GUI_FillRoundedRect,void(int,int,int,int,int));
	MOCK_METHOD1(WM_Paint,void(void*));
	MOCK_METHOD1(GUI_SetTextAlign,int(int));
	MOCK_METHOD3(GUI_DispStringAt, void(const char *,int,int));
	MOCK_METHOD4(GUI_DispDecAt,void(int,int16_t,int16_t,uint8_t));
	MOCK_METHOD3(GUI_DispStringInRect, void(const char *,void *,int));
	MOCK_METHOD6(GUI_DrawGradientV, void(int,int,int,int,uint32_t,uint32_t));
	MOCK_METHOD5(GUI_AA_FillRoundedRect,void(int,int,int,int,int));
	MOCK_METHOD2(WM_SendMessage,void(void*,void*));
	MOCK_METHOD1(WM_GetYSize,int(void*));
};

class InforDlgService
{
public:
	virtual ~InforDlgService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD1(InforDlgSetStatus,void(int));
};

class SystemInforTableService
{
public:
	virtual ~SystemInforTableService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD0(SystemInfortableReloadMocks,void());
	MOCK_METHOD2(SystemInforSetSerialNumberMocks,int(char*, int));
	MOCK_METHOD2(SystemInforGetSwVersionMocks,int(char*, int));
	MOCK_METHOD2(SystemInforGetBootVersionMocks,int(char*, int));
	MOCK_METHOD0(OpertimeGetUsedHourMocks,unsigned short());
	MOCK_METHOD2(SystemInforGetSerialNoMocks,int(char*, int));
	MOCK_METHOD2(SystemInforGetMotorVersionMocks,int(char*, int));
};

class AnalyzeDataService
{
public:
	virtual ~AnalyzeDataService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD1(AnalyzeDataGetFilteredNosePressureMocks,bool(float*));
	MOCK_METHOD1(AnalyzeDataGetTreatmentPressureMocks,bool(float*));
};

class ProgbarService
{
public:
	virtual ~ProgbarService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD3(PROGBAR_GetMinMax,void(void*, int*,int*));
	MOCK_METHOD2(PROGBAR_SetValue,void(void*, int));
};

class UserSettingService
{
public:
	virtual ~UserSettingService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD1(UserSettingReloadMocks,void(int));
	MOCK_METHOD0(UserSettingDialogInitMocks,void());
};

class SoftTimerService
{
public:
	virtual ~SoftTimerService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD1(SoftTimerResetMocks,void(int));
	MOCK_METHOD1(SoftTimerStopMocks,void(int));
	MOCK_METHOD1(SoftTimerStartMocks,void(int));
};

class SleepScrService
{
public:
	virtual ~SleepScrService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD0(SleepScrUpdatePressureMocks,void());
	MOCK_METHOD1(SleepScrSetTypeMocks,void(int));
};

class EEPROMService
{
public:
	virtual ~EEPROMService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD4(EEPROMWriteMocks,void(int,int,char*,int));
	MOCK_METHOD1(EEPROM_EraseMocks,void(uint16_t));
	MOCK_METHOD4(EEPROMReadMocks,void(int, int, char*, int));
};

class FFService
{
public:
	virtual ~FFService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD3(f_open,int(void*,const void*,int));
	MOCK_METHOD1(f_close,int(void*));
	MOCK_METHOD1(f_unlink,int(const void*));
	MOCK_METHOD3(f_gets,void*(void*,int,void*));
};

class CRCJPAPService
{
public:
	virtual ~CRCJPAPService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD2(CrcCheckNoInitMocks,unsigned short(long, char *));
};

class RTCService
{
public:
	virtual ~RTCService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD0(RTCGetMocks,void*());
	MOCK_METHOD1(RTCSetMocks,void(void*));
};

class PoweMonitorService
{
public:
	virtual ~PoweMonitorService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD0(PowerMonitorCheckMocks,bool());
	MOCK_METHOD0(PowerMonitorClearMocks,void());
};

class EventService
{
public:
	virtual ~EventService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD0(EventResetMocks,void());
	MOCK_METHOD1(EventSetFLEnableMocks,void(bool));
	MOCK_METHOD2(EventHandleDataMocks,void(float,float));
	MOCK_METHOD0(EventCSresetMocks,void());
	MOCK_METHOD1(EventCSaddDataMocks,void(float));
	MOCK_METHOD0(EventCScheckBreathMocks,void());
	MOCK_METHOD0(EventCScheckCancelMocks,void());
	MOCK_METHOD1(EventCScheckApneaMocks,void(unsigned long));
	MOCK_METHOD0(EventCSgetCountMocks,short());
	MOCK_METHOD1(EventCSexitApneaMocks,void(unsigned long));
};

class PhaseService
{
public:
	virtual ~PhaseService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD0(PhaseResetMocks,void());
	MOCK_METHOD2(PhaseHandleDataMocks,void(float,float));
};

class BreathDataService
{
public:
	virtual ~BreathDataService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD0(BreathDataResetMocks,void());
	MOCK_METHOD0(BaseFlowResetMocks,void());
};

class MaskOffService
{
public:
	virtual ~MaskOffService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD1(MaskOffSetStateMocks,void(uint8_t));
	MOCK_METHOD1(MaskOffSetEnableMocks,void(bool));
	MOCK_METHOD2(MaskOffHandleDataMocks,void(float,float));
};

class MotorDataService
{
public:
	virtual ~MotorDataService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD1(MotorDataGetFlowMocks,bool(float*));
};

class RtBufferService
{
public:
	virtual ~RtBufferService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD2(RtBufferHandleDataMocks,void(float,float));
};

class ArmMathService
{
public:
	virtual ~ArmMathService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD3(arm_mean_f32,void(float *,uint32_t,float *));
	MOCK_METHOD4(arm_min_f32,void(float *,uint32_t,float *,uint32_t *));
	MOCK_METHOD4(arm_max_f32,void(float *,uint32_t,float *,uint32_t *));
};

class VolumeService
{
public:
	virtual ~VolumeService() {} // IMPORTANT: This is needed by std::unique_ptr

	MOCK_METHOD0(VolumeGetMocks,float());
	MOCK_METHOD1(VolumeBeginMocks,void(float));
	MOCK_METHOD1(VolumeAddMocks,void(float));
	MOCK_METHOD0(VolumeEndMocks,void());
};

}

#endif
