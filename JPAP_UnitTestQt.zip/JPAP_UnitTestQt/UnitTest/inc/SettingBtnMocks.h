/*
 * SettingBtnMocks.h
 *
 *  Created on: Apr 11, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_SETTINGBTNMOCKS_H_
#define UNITTEST_INC_SETTINGBTNMOCKS_H_

#include "stdint.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void SettingBtnSetValueMocks(void *obj, int pos);
void SettingBtnSetStatusMocks(void *obj, int stt);
void SettingbtnLogMocks(void *obj);
void SettingBtnDecThumpPosMocks(void *hObj);
void SettingBtnIncThumpPosMocks(void *hObj);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_INC_SETTINGBTNMOCKS_H_ */
