/*
 * SettingMocks.h
 *
 *  Created on: Apr 11, 2018
 *      Author: QUOCVIET
 */

#include "stdint.h"

#ifndef UNITTEST_INC_SETTINGMOCKS_H_
#define UNITTEST_INC_SETTINGMOCKS_H_


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void SettingSaveMocks();
uint8_t SettingGetMocks(uint8_t  id);
bool SettingReadFromSdMocks();
void SettingSetRequestReadSdMocks();
void SettingSetDefaultMocks();	//set settings as default
void SettingSetMocks(uint8_t id, unsigned char value);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_SETTINGMOCKS_H_ */
