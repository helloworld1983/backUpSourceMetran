/*
 * SleepScrMocks.h
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_SLEEPSCRMOCKS_H_
#define UNITTEST_INC_SLEEPSCRMOCKS_H_

typedef enum
{
	eDispIdleType = 0,	//display as idle type
	eDispOperType		//display as operation type
} E_SleepDispType;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//function to update treatment pressure on sleep screen
void SleepScrUpdatePressureMocks();

//function to set type of display
void SleepScrSetTypeMocks(E_SleepDispType type);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_SLEEPSCRMOCKS_H_ */
