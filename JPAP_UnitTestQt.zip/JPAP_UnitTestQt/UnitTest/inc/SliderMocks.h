/*
 * SliderMocks.h
 *
 *  Created on: Apr 13, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_SLIDERMOCKS_H_
#define UNITTEST_INC_SLIDERMOCKS_H_


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void SliderSetMaxMocks(void* hObj, int value);
void SliderUpdateMocks(void* hObj, int value);


#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_SLIDERMOCKS_H_ */
