/*
 * SoftTimerMocks.h
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_SOFTTIMERMOCKS_H_
#define UNITTEST_INC_SOFTTIMERMOCKS_H_

//define timer ID
typedef enum
{
	eSoftTimer0Id = 0,		//timer 0 responsible for button anti vibration
	eSoftTimer1Id,			//timer 1 responsible for sleep screen entrance
	eSoftTimer2Id			//timer 2 responsible for Clinic, Maintenance, History entrance
} E_SoftTimerId;


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//function to reset counter for timer
void SoftTimerResetMocks(E_SoftTimerId timerId);

//function to stop timer 0
void SoftTimerStopMocks(E_SoftTimerId timerId);

//function to start timer 0
void SoftTimerStartMocks(E_SoftTimerId timerId);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_SOFTTIMERMOCKS_H_ */
