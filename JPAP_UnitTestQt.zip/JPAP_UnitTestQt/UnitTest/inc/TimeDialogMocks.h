/*
 * TimeDialogMocks.h
 *
 *  Created on: Apr 17, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_TIMEDIALOGMOCKS_H_
#define UNITTEST_INC_TIMEDIALOGMOCKS_H_

#include "stdint.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void TimeDialogReloadMocks();
void TimeDialogSetStatusMocks(int status);
void TimeWidgetSetStatusMocks(void* hObj, uint8_t status);
void TimeWidgetIncreaseValueMocks(void* hObj);
int TimeWidgetGetValueMocks(void* hObj);
void TimeWidgetDecreaseValueMocks(void* hObj);
void TimeWidgetSetValueMocks(void* hObj, int value);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_INC_TIMEDIALOGMOCKS_H_ */
