/*
 * TimeLib.h
 *
 *  Created on: Mar 23, 2018
 *      Author: ThienVu
 */

#ifndef UNITTEST_INC_TIMELIB_H_
#define UNITTEST_INC_TIMELIB_H_

#if defined(__cplusplus)
namespace EmbeddedC {
#endif


int year();

int month();

int day();

int hour();

int minute();

int second();



#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_INC_TIMELIB_H_ */
