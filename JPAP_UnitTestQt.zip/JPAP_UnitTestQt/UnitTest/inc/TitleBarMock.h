/*
 * TitleBarMock.h
 *
 *  Created on: Apr 13, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_TITLEBARMOCK_H_
#define UNITTEST_INC_TITLEBARMOCK_H_

#include "stdint.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void TitleBarSetStatusMocks(void* hObj, uint8_t stt);

#if defined(__cplusplus)
}
#endif

#endif /* UNITTEST_INC_TITLEBARMOCK_H_ */
