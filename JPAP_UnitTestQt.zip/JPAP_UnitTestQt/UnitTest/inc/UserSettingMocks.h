/*
 * UserSettingMocks.h
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_USERSETTINGMOCKS_H_
#define UNITTEST_INC_USERSETTINGMOCKS_H_

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//function to load setting before display
void UserSettingReloadMocks(int operState);
void UserSettingDialogInitMocks();

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_INC_USERSETTINGMOCKS_H_ */
