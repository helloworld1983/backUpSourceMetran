/*
 * VolumeMocks.h
 *
 *  Created on: May 4, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_INC_VOLUMEMOCKS_H_
#define UNITTEST_INC_VOLUMEMOCKS_H_

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

float VolumeGetMocks();				// get last volume value
void VolumeBeginMocks(float flow);	//start calculate new volume at new breath
void VolumeAddMocks(float flow);		//add volume during breath
void VolumeEndMocks();				//finish data of the last breath

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_INC_VOLUMEMOCKS_H_ */
