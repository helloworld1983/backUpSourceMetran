/*
 * WDTLib.h
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_WDTLIB_H_
#define UNITTEST_INC_WDTLIB_H_

#include "stdint.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void WWDT_CmdMocks(uint8_t flag);
void WatchDogFeedMocks();

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_INC_WDTLIB_H_ */
