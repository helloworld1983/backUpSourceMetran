/*
 * WString.h
 *
 *  Created on: Mar 22, 2018
 *      Author: WINDOWS
 */

#ifndef UNITTEST_INC_WSTRING_H_
#define UNITTEST_INC_WSTRING_H_

#include <string>
using namespace std;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif


string String(int digit);

size_t strlen(const char* str);

unsigned char StrAppend(char* des, const char* source, unsigned char bufferOfDes);

//convert integer to Ascii, same as IntToStr()
int StrToolItoA(long int a, char* buff, int numOfDigit);

char *strcat (char *des, const char *source);

char *strncat (char *des, const char *source, size_t size);

//convert number in unsigned integer to hex string
int StrToolItoHexS(unsigned int num,char* buff, int size);

//convert float to string
int StrToolFtoA(float n, char *res, int afterpoint);

//convert time in sec to string in format: HH:MM:SS
int StrToolTtoS(char* str, int timeInSec);

char * itoa(int value, char *vstring, unsigned int base);

int	strcmp(const char * str1, const char * str2);

double atof(const char *__nptr);

int atoi(const char *nptr);

void * memset (void * buffer, int byte, size_t size);

#if defined(__cplusplus)
}
#endif

#endif /* UNITTEST_INC_WSTRING_H_ */





