/*
 * alarminterface.h
 *
 *  Created on: Feb 18, 2016
 *      Author: computer
 */

#ifndef ALARMINTERFACE_H
#define ALARMINTERFACE_H

#include <stdbool.h>
//#include "debuguart.h"
//#include "FreeRTOS.h"
//#include "queue.h"

typedef enum
{
	eAlarmTaskNoEventId = 0,
	eAlarmTaskEnableId = 1,				//enable alarm task, allow to run
	eAlarmTaskDisableId,				//disable alarm task, do not allow to run
	eBlowerErrorActivatedId,			//blower error activated
	eBlowerErrorDeActivatedId,			//blower error was confirmed
	ePressSensorErrorActivatedId,		//pressure sensor error activated
	ePressSensorErrorDeActivatedId,	//pressure sensor error was confirmed
	eFlowSensorErrorActivatedId,		//flow sensor error activated
	eFlowSensorErrorDeActivatedId,		//flow sensor error was confirmed
	eSdCardErrorActivatedId,			//SD card error activated
	eSdCardErrorDeActivatedId,			//SD card error was confirmed
	ePowerFailedActivatedId,			//power failed error activated
	ePowerFailedDeActivatedId,			//power failed error was confirmed
	eLeakActivatedId,			//circuit leak activated
	eLeakDeActivatedId,		//circuit leak deactivated
} E_AlarmEventId;

//define alarm status
typedef enum
{
	eDeactivated = 1,
	eActivated,
	eAutoReset,
} E_AlarmStatus;

//define alarm priority
typedef enum
{
	eAlarmHighPriority = 1,
	eALarmMediumPriority,
	eALarmLowPriority
} E_AlarmPriority;

//define all alarm ID
typedef enum
{
	eFirsAlarmId = 0,
	eBlowerErrorId = eFirsAlarmId,
	ePressSensorErrorId,
	eFlowSensorErrorId,
	ePowerFailureId,
	eSdCardErrorId,
	eLeakErrorId,
	eLastAlarmId
} E_AlarmId;

typedef struct
{
	E_AlarmId id;
	E_AlarmStatus status;
	E_AlarmPriority priority;
} AlarmItemStruct;

//define structure for alarm event communication
typedef struct
{
	E_AlarmEventId id;
	long data;
} AlarmEventStruct;

//declare alarm queue
//extern xQueueHandle alarmQueue;

//function to send event to alarm task
//return true if event was sent successful
//return false is event was sent failed
//inline bool ALarmTaskSendEvent(E_AlarmEventId alarmId, long alarmData)
//{
//	bool rtn = true;
////	char sendEvent = event;
//	AlarmEventStruct event;
//	event.id = alarmId;
//	event.data = alarmData;
//	if(xQueueSendToBack(alarmQueue, &event, 2) != pdPASS)
//	{
//		DebugStr("\n send failed: event to alarm task");
//		rtn = false;
//	}
//	return rtn;
//}


#endif /* ALARMINTERFACE_H */
