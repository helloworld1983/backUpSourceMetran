/*
 * eepromMocks.h
 *
 *  Created on: Apr 20, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_INC_EEPROMMOCKS_H_
#define UNITTEST_INC_EEPROMMOCKS_H_

//#include "lpc_eeprom.h"
#include "stdint.h"

//1. define parameters of internal EEPROM
#define EEPROM_NUM_PAGE					63
#define EEPROM_PAGE_SIZE				64


/***************************************************************/
/***************************PAGE 0******************************/
/***************************************************************/
//2. define address to store SETTINGS
#define EEPROM_SETTING_PAGE_ADDR		0
#define EEPROM_SETTING_BYTE_ADDR		0
#define EEPROM_SETTING_SIZE				30

//3. define address to store ARNORAMAL SHUTDOWN
#define EEPROM_ABSHUTDOWN_PAGE_ADDR		0
#define EEPROM_ABSHUTDOWN_BYTE_ADDR		(EEPROM_SETTING_BYTE_ADDR+EEPROM_SETTING_SIZE)
#define EEPROM_ABSHUTDOWN_SIZE			3		//1 byte flag + 2 byte CRC

//4. define address to store OPERATION TIME
#define EEPROM_TOTALTIME_PAGE_ADDR		0
#define EEPROM_TOTALTIME_BYTE_ADDR		(EEPROM_ABSHUTDOWN_BYTE_ADDR + EEPROM_ABSHUTDOWN_SIZE)
#define EEPROM_TOTALTIME_SIZE			6		//4 byte data + 2 byte CRC

//5. define address to store SERIAL NUMBER
#define EEPROM_SERIALNUMBER_PAGE_ADDR	0
#define EEPROM_SERIALNUMBER_BYTE_ADDR	(EEPROM_TOTALTIME_BYTE_ADDR+EEPROM_TOTALTIME_SIZE)
#define EEPROM_SERIALNUMBER_SIZE		16 //fill here

/***************************************************************/
/***************************PAGE 1******************************/
/***************************************************************/
//6. define address to store the upgrading flag of main unit
#define EEPROM_SW_UPGRADE_PAGE_ADDR		1	//software version upgrade flag indicator
#define EEPROM_SW_UPGRADE_BYTE_ADDR		0
#define EEPROM_SW_UPGRADE_SIZE			3

//8. define address to store the circuit resistance
#define CIRCUIT_RESISTANCE_PAGE			1	//patient circuit resistance
#define CIRCUIT_RESISTANCE_BYTE			(EEPROM_SW_UPGRADE_BYTE_ADDR+EEPROM_SW_UPGRADE_SIZE)
#define CIRCUIT_RESISTANCE_SIZE			14	//8 byte for float value + 2 byte CRC

//7. define address to store parameters of log event
#define EEPROM_LOGPTR_PAGE_ADDR			1

#define LOG_ENDPAGE_BYTE				(CIRCUIT_RESISTANCE_BYTE+CIRCUIT_RESISTANCE_SIZE)
#define LOG_ENDPAGE_SIZE				3	//1 byte flag + 2 byte CRC

#define LOG_ENDBYTE_BYTE				(LOG_ENDPAGE_BYTE+LOG_ENDPAGE_SIZE)
#define LOG_ENDBYTE_SIZE				3	//1 byte flag + 2 byte CRC

#define LOG_NUM_ROCORDS_BYTE			(LOG_ENDBYTE_BYTE+LOG_ENDBYTE_SIZE)
#define LOG_NUM_RECORDS_SIZE			4	//2 byte flag + 2 byte CRC

//8. define address to store parameters of bootloader
#define BOOT_VERSION_PAGE_ADDR			1	//page to store bootloader version
#define BOOT_VERSION_BYTE_ADDR			(LOG_NUM_ROCORDS_BYTE + LOG_NUM_RECORDS_SIZE)
#define BOOT_VERSION_SIZE				4  //4 byte data

//9. define address to store flag indicate new system log has come
#define SYSTEM_NEWLOG_PAGE_ADDR			1
#define SYSTEM_NEWLOG_BYTE_ADDR			(BOOT_VERSION_BYTE_ADDR+BOOT_VERSION_SIZE)
#define SYSTEM_NEWLOG_SIZE				(3)	//1 byte flag + 2 byte CRC

/***************************************************************/
/***************************PAGE 2******************************/
/***************************************************************/
//10. define start-page address to store log event
#define LOG_EVENT_START_PAGE			2

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void EEPROMWriteMocks(int page, int byte, char* data, int num);
void EEPROM_EraseMocks(uint16_t address);
void EEPROMReadMocks(int page, int byte, char* data, int num);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_INC_EEPROMMOCKS_H_ */
