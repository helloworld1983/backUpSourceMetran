/*
 * Spi.h
 *
 *  Created on: Mar 22, 2018
 *      Author: ThienVu
 */

#ifndef UNITTEST_INC_ESP_SPI_FLASH_H_
#define UNITTEST_INC_ESP_SPI_FLASH_H_

#include "stddef.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif



int spi_flash_read(size_t addr, void* dest , size_t size);

int spi_flash_write(size_t dest, const void* src, size_t size);

int spi_flash_erase_sector(size_t sector);



#if defined(__cplusplus)
}
#endif

#endif /* UNITTEST_INC_ESP_SPI_FLASH_H_ */
