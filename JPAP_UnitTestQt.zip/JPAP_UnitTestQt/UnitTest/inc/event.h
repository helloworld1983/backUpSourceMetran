/*
 * event.h
 *
 *  Created on: Apr 16, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_EVENT_H_
#define UNITTEST_INC_EVENT_H_

#include <stdbool.h>
//#include "systemconfig.h"
#include "motorctrlinterface.h"

#define EVENT_IDLE_TIME		3*60*1000		//3 minute waiting system stable
#define EVENT_COLLECT_TIME	1*60*1000		//1 minute to collect average data

//define event id
#define EVENT_FL_ID			(0x01 << 5)		// flow limitation event id
#define EVENT_H_ID			(0x01 << 4)		// hypo apnea event id
#define EVENT_S_ID			(0x01 << 2)		// snoring event id
#define EVENT_MSK_ON_ID		(0x01 << 1)		// mask on event id
#define EVENT_MSK_OFF_ID 	(0x01 << 0)		// mask off event id
#define EVENT_OA_ID			(0x01 << 6)		// obstructive event id
#define EVENT_CA_ID			(0x01 << 7)		// central apnea event id
#define EVENT_CS_ID			(0x01 << 3)		// cheyne stokes event id
#define EVENT_NOMAL_ID		(0x00)			//normal breath found

#define EVENT_CANCEL_LMT			((float)0.7)
#define EVENT_FL_UPPER_LMT			((float)0.6)
#define EVENT_FL_LOWER_LMT			((float)0.4)
#define EVENT_H_UPPER_LMT			EVENT_FL_LOWER_LMT
#define EVENT_H_LOWER_LMT			((float)0.0)
#define EVENT_APNEA_UPPER_LMT		EVENT_H_LOWER_LMT
#define EVENT_APNEA_LOWER_LMT		((float)0.0)
#define EVENT_CS_DETECT_LMT			((float)0.2)
#define EVENT_CS_CANCEL_LMT			((float)0.5)

//define vibration time for 1 cycle
#define EVENT_VIBRATION_CYCLE		(1000/MOTOR_VIBRATION_FREQ)
//define vibration time for 1 section (12s)
#define EVENT_VIBRATION_SECTION		(12*1000)
//flow amplitude limit to determine obstructive apnea
#define EVENT_VIBRATION_LMT			5		// 6 LPM
//flow amplitude limit to exit vibration
#define EVENT_VIBRATION_EXIT_LMT	7	//5LPM

//define number of cycle per section
#define EVENT_CYCLE_PER_SECTION		(EVENT_VIBRATION_SECTION/EVENT_VIBRATION_CYCLE)
//define number of sample per cycle
#define EVENT_SAMPLE_PER_CYCLE		(EVENT_VIBRATION_CYCLE/MOTOR_TASK_PRIODIC)

//define for snoring detection
#define SNORE_FREQ_LMT			20		//snore is counted from 10Hz
#define SNORE_INDEX_LMT			((int)((SNORE_FREQ_LMT*FFT_SAMPLE)/100))	//100 sampling rate
#define SNORE_FFT_DETECT_LMT	((float)1.2)
#define SNORE_COUNT_DETECT_LMT	7
#define SNORE_MAX_PRESSURE		12 		//12 cmH2O maximum for snoring

#define EVENT_CONFIRM_S			3	// 3 times of event Snore to make sure that event actually occur
#define EVENT_CONFIRM_FL_H		5	// number of breath that an FL or H occur to make sure that FL or H is actually occur

//define max pressure increase when event happen continuously
#define EVENT_PRESS_INC_MAX		(2)		//2 cmH2O

//number of sample for FFT calculation
#define FFT_SAMPLE	64//128

#if 1//SUPPORT_EVENT_DISPLAY
//current breathing event
extern unsigned char eventBreath;
#endif

typedef enum
{
	eEventDetectionIdle = 0,
	eEventCollectData,		//collect data at first 2 minutes
	eEventDoDetection,		//detect event after first 2 minutes
	eEventHandleVibration	//handle vibration data
} E_EventDetectionProcess;

typedef enum
{
	eEventNotDetected = 0,
	eEventDoubted
//	eEventDetected
} E_EventDetectionState;

typedef enum
{
	eEventIncreasePressure = 0,
	eEventKeepPressure,
	eEventDescreasePressure
} E_EventHandlePressureState;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

//function to handle data to do event detection
void EventHandleData(float flow, float pressure);

//function to reset event variable
void EventReset();

//function to check breath data to do event detection
void EventCheckBreathData();

//function to check time from previous breath to detect apnea
//apnea is defined as more than 8s without a breath
void EventCheckApnea();

//function to set enable FL event detection
void EventSetFLEnable(bool isEnable);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_INC_EVENT_H_ */
