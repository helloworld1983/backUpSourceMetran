/*
 * guiinterface.h
 *
 *  Created on: Apr 10, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_GUIINTERFACE_H_
#define UNITTEST_INC_GUIINTERFACE_H_

#include "queue.h"

//define time to update operation pressure
#define GUI_PRESS_UPDATE_TIMER		150	//timer update pressure 100ms

typedef enum
{
	eGuiFirstEventId = 0,
	//event support for title bar
	eGuiFirstTitleBarId = eGuiFirstEventId,
	eGuiShowSdIconId = eGuiFirstTitleBarId,			// SD card show event
	eGuiHideSdIconId,			// SD card hide event
	eGuiShowSdErrIconId,		// SD card Error icon show
	eGuiShowBleIconId,			// show bluetooth icon
	eGuiHideBleIconId,			// hide bluetooth icon
	eGuiShowErrIconId,			// show error icon, never hide
	eGuiUpdateRtcId,			// RTC hardware interrupt event
	eGuiLastTitleBarId = eGuiUpdateRtcId,

	//event support for pop up dialog
	eGuiFirstPopUpDialogId,
	eGuiPopupMotorUpgradeErrorId = eGuiFirstPopUpDialogId,			// error while doing motor upgrade
	eGuiPopupMotorUpgradeEndId,			// end motor upgrade
	eGuiPopupMotorUpgradeRunId,			// motor upgrade is running
	eGuiPopupMotorUpgradeStartId,		// start motor upgrade
	eGuiPopupMotorUpgradeResetId,		// reset motor after upgrade
	eGuiPopupMotorUpgradeShowId,
	eGuiPopupControlUpgradeShowId,
	eGuiPopupBLEUpgradeErrorId,			// error while upgrading BLE
	eGuiPopupBLEUpgradeEndId,			// end of upgrading process
	eGuiPopupBLEUpgradeRunId,			// update percentage on the LCD
	eGuiPopupBLEUpgradeStartId,			// start BLE upgrade
	eGuiPopupBLEUpgradeResetId,			// show reseting after upgrade
	eGuiBLEUpgradeShowId,
	eGuiPopupCircuitCalibrateShowId,	// start circuit calibration	(should be continue)
	eGuiPopupCircuitCalibrateDoneId,	// end of circuit calibration
	eGuiPopupMaskCalibrateDoneId, 		//end of circuit calibration with mask
	eGuiPopupCircuitCalibrateErrorId,	// error at circuit calibration	(should be continue)
	eGuiPopupTimeSettingShowId,		// show dialog to save or ignore time setting
	eGuiPopupExportLogSuccessId,			// show export system log success
	eGuiPopupExportLogFailId,			// show export system log failed
	eGuiPopupExportLogShowId,			// show pop up to export log data
	eGuiPopupRestoreDefaultsShowId,
	eGuiPopupClearUsedHoursShowId,
//	eGuiPopupConnectBLEDeviceId,
//	eGuiPopupDisconnectBLEId,
//	eGuiPopupFailedToConnectBLEId,
//	eGuiPopupSuccessToConnectBLEId,
	eGuiPopupConfirmDryingModeId,
	eGuiLastPopUpDialogId = eGuiPopupConfirmDryingModeId,

	//event support for operation screen
	eGuiFirstOperScreenId,
	eGuiOperationStartId = eGuiFirstOperScreenId,			// start operation
	eGuiOperationStopId,			// stop operation
	eGuiOperationRunId,				// enter operation running
	eGuiOperationDryId,				// drying circuit
	eGuiOperationMaskOffId,			// mask off state
	eGuiRampTimeStartId,			// start ramp counter
	eGuiRampTimeEndId,				// end ramp counter
	eGuiRampTimeCountId,			// 1 seconds timer expired
	eGuiRealPressUpdateId,			// update pressure during operation
	eGuiTreatPressUpdateId,			// update treatment pressure
	eGuiUserOptionShowId,			// show user option
	eGuiUserOptionHideId,			// hide user option
	eGuiAlarmDialogShowId, 			// show alarm dialog
	eGuiAlarmDialogHideId, 			// hide alarm dialog
	eGuiSleepScreenShowId,			// show sleep screen
	eGuiSleepScreenHideId,			// hide sleep screen
	eGuiRequestReadSdId,			// event to read setting from SD card
	eGuiChangeScreenTimerId,
	eGuiOperUpdateSettingId,
	eGuiLastOperScreenId = eGuiOperUpdateSettingId,

	//event for factory screen
	eGuiFirstFactoryScreenId,
	eGuiFactoryRestoreDefaultsId = eGuiFirstFactoryScreenId,
	eGuiFactoryScrReleaseTimeSettingId,
	eGuiFactoryClearUsedHoursId,		// reset operation time
	eGuiFactoryReleaseTimeSettingId,
	eGuiFactoryRepaint,
	eGuiLastFactoryScreenId = eGuiFactoryRepaint,

	//event for clinician screen
	eGuiFirstClinicScreenId,
	eGuiClinicChangeVentModeId = eGuiFirstClinicScreenId,
	eGuiLastClinicScreenId = eGuiClinicChangeVentModeId,

	//event for main screen
	eGuiChangeToOperScreenId,			// request change to operation screen
	eGuiChangeToClinicScreenId,			// request change to clinic screen	(should be continue)
	eGuiChangeToMaintenaceScreenId,		// request change to maintenance screen	(should be continue)
	eGuiChangeToHistoryScreenId,		// request change to history screen	(should be continue)
	eGuiChangeSettingFromCloudId,		// request to change setting from cloud device

	eGuiUpdateMotorVersion,			// signal to update string of motor version
#if SUPPORT_EVENT_DISPLAY
	eGuiUpdateAvgVolumeEventId,
	eGuiUpdateLastVolumeEventId,
	eGuiUpdatePercentageEventId,
#endif
} E_GuiEventId;

typedef struct
{
	E_GuiEventId id;
	long data;
} GuiEventStruct;


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

#include <stdbool.h>
//#include "FreeRTOS.h"
//#include "systemconfig.h"
//#include "debuguart.h"

//declare GUI queue
//extern xQueueHandle guiQueue;

////function to send event to GUI task
////return true if event was sent successful
////return false is event was sent failed
//inline bool GuiTaskSendEvent(unsigned char id, long data)
//{
//	//return value
//	bool rtn = true;
//	//event to send
//	GuiEventStruct event;
//	event.id = id;
//	event.data = data;
//	//send event
//	if(xQueueSendToBack(guiQueue, &event, 2) != pdPASS)
//	{
//		DebugStr("\n send failed: event to GUI task");
//		xQueueReset(guiQueue);
//		rtn = false;
//	}
//	return rtn;
//}
bool GuiTaskSendEvent(unsigned char id, long data);

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_GUIINTERFACE_H_ */
