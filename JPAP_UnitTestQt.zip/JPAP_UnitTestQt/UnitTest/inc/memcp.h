/*
 * memcp.h
 *
 *  Created on: Mar 22, 2018
 *      Author: WINDOWS
 */

#ifndef UNITTEST_INC_MEMCP_H_
#define UNITTEST_INC_MEMCP_H_

#include "stddef.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif



void* memcpy(void* src, const void* dest, size_t size);


#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_MEMCP_H_ */
