/*
 * motorctrlinterface.h
 *
 *  Created on: Apr 17, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_MOTORCTRLINTERFACE_H_
#define UNITTEST_INC_MOTORCTRLINTERFACE_H_

#include <stdbool.h>
//#include "FreeRTOS.h"
//#include "semphr.h"
//#include "task.h"
//#include "debuguart.h"
//#include "circuitcalibrate.h"

//define queue size for motor task communication
#define 	MOTOR_QUEUE_SIZE		8
//define motor task priodic
#define 	MOTOR_TASK_PRIODIC		10
//define frequency for pressure vibration in case of detecting CA and OA
#define MOTOR_VIBRATION_FREQ 	2	//2 Hz
//define vibration pressure amplitude
#define MOTOR_VIBRATION_AMP		((float)0.5)	//0.5 cmH2O

typedef enum
{
	eMotorNoEventId = 0,
	eMotorStartEventId,			// start motor command
	eMotorStopEventId,			// stop motor command
	eMotorSuspendEventId,		// suspend motor command
	eMotorResumeEventId,		// resume motor command
	eMotorShutdownEventId,		// motor status error
	eMotorChangeInhId,			// signal inhalation setting change
	eMotorChangeExhId,			// signal exhalation setting change
	eMotorIncPress05EventId,			// increase pressure 0.5 cmH2O
	eMotorDesPress05EventId,			// decrease pressure 0.5 cmH2O
	eMotorEnterInhTrigEventId,		// start inhalation trigger phase
	eMotorEnterInhMainEventId,		// start inhalation maintain phase
	eMotorEnterExhTrigEventId,			// start exhalation trigger phase
	eMotorEnterExhMainEventId,		// start exhalation maintain phase
	eMotorEnterMaskOffEventId,			// start low speed control, support for leak
	eMotorEnterStrongDryEventId,	// start drying strong mode
	eMotorEnterWeakDryEventId,		// start weak drying mode
	eMotorEnterOperateEventId,		// exit low speed control
	eMotorEnterVibrateEventId,		// start vibration
	eMotorExitVibrateEventId			// stop vibration
} E_MotorCtrlEventId;


//declare motor property
typedef struct
{
	unsigned char code;		//code number
	float flow;				//flow value from blower
	float pressure;			//pressure value from blower
	unsigned short speed;	//blower speed
	unsigned char status;	//blower status
	unsigned char error;	//error code
} MotorDataStruct;			//motor property structure

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

////structure to store motor data
//extern MotorDataStruct MotorData;
//
////function to reset motor property
//void MotorDataReset();
//
////function to get flow value from motor data
////return true if getting data success
////return false if getting data failure
//bool MotorDataGetFlow(float* valuePtr);
//
////function to get pressure value from motor data
////return true if getting data success
////return false if getting data failure
//bool MotorDataGetPressure(float* valuePtr);
//
////function to get status of motor
////return true if getting data success
////return false if getting data failure
//bool MotorDataGetStatus(unsigned char* valuePtr);
//
////function to get code communication of motor
////return true if getting data success
////return false if getting data failure
//bool MotorDataGetCode(unsigned char* valuePtr);
//
////function to process motor data from Rs 485
//void MotorProcessData();
//
////function to update circuit resistance for motor control
//void MotorUpdateResistance();
//
////declare motor queue
//extern xQueueHandle motorQueue;
//
//// declare a mutex to protect motor property device acess
//extern xSemaphoreHandle motorDataMutex;
//
////declare motor task  handler
////extern xTaskHandle motorTaskHandle;
//
////function to send event to motor task
////return true if event was sent successful
////return false is event was sent failed
//inline bool MotorTaskSendEvent(unsigned char event)
//{
//	bool rtn = true;
//	unsigned char sendEvent = event;
//	if(xQueueSendToBack(motorQueue, &sendEvent, 2) != pdPASS)
//	{
//		DebugStr("\n send failed: event to motor task");
//		rtn = false;
//	}
//	return rtn;
//}

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_MOTORCTRLINTERFACE_H_ */
