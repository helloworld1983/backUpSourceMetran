/*
 * queue.h
 *
 *  Created on: Mar 27, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_QUEUE_H_
#define UNITTEST_INC_QUEUE_H_

#include "stdint.h"
#include "stdbool.h"

typedef long BaseType_t;
typedef uint32_t TickType_t;
typedef unsigned long portTickType;

#define portMAX_DELAY ( portTickType ) 0xffffffff
#define portBASE_TYPE	long

#define pdPASS 1
#define pdFAIL 0

#define pdFALSE		0
#define pdTRUE		1

typedef void * QueueHandle_t;
typedef void * xQueueHandle;

typedef xQueueHandle xSemaphoreHandle;

#if defined(__cplusplus)
namespace EmbeddedC {
#endif


BaseType_t xQueueSend(QueueHandle_t xQueue, const void * const pvItemToQueue, TickType_t xTcksToWait);
BaseType_t xQueueReset(xQueueHandle xQueue);
BaseType_t xQueueReceive(xQueueHandle xQueue, const void * const pvBuffer, TickType_t xTcksToWait);
BaseType_t xQueueSendToBack(xQueueHandle xQueue, const void * const pvItemToQueue, TickType_t xTcksToWait);
portBASE_TYPE xSemaphoreTake(xQueueHandle xQueue,portTickType xTicksToWait);
void taskENTER_CRITICAL();
portBASE_TYPE xSemaphoreGive(xQueueHandle xQueue);
void taskEXIT_CRITICAL();
portTickType xTaskGetTickCount( void );
bool MotorTaskSendEvent(unsigned char event);
bool SystemTaskSendEvent(uint8_t id, long data);
bool GuiTaskSendEventMocks(unsigned char id, long data);

void vTaskDelay(uint32_t ms);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_INC_QUEUE_H_ */
