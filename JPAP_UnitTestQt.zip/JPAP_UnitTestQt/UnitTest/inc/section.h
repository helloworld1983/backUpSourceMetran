/*
 * section.h
 *
 *  Created on: Apr 23, 2018
 *      Author: Quoc Viet
 */

#ifndef UNITTEST_INC_SECTION_H_
#define UNITTEST_INC_SECTION_H_


//define log Id for log task
typedef enum
{
	eFirstSessionLogId = 1,
	eHDevNoLogId = eFirstSessionLogId,
	eHPtIdLogId,
	eHStartTiLogId,
	eHPiniLogId,
	eHPminLogId,
	eHPmaxLogId,
	eHPdelayLogId,
	eHDevSetInfoLogId,
	eHNSLogId,
	eHRDTiLogId,
	eLeakLogId,
	eHDevRunTiLogId,
	eSleepLogId,
	ePressLogId,
	eErrLogId,
	eRtDataLogId,
	eLastSessionLogId
} E_LogId;

//define an log event structure
typedef struct
{
	E_LogId id;
	unsigned short data;
} LogEventStruct;

//Parameter Format of device setting information
typedef struct
{
	unsigned char ventilationMode:1;		//Ventilation Mode 1:AutoCPAP Mode, 0:CPAP Mode  1
	unsigned char naturalSupportType:1; 	//NS Type, 0: E-Type,       1:S-type
	unsigned char bluetoothStat:1;			//Bluetooth status, 0:OFF    1:ON
	unsigned char circuitType:1; 			//circuit Type  0
	unsigned char snoring:1; 				//Process Snoring  0
	unsigned char autoOFF:1; 					//Process FL  0
	unsigned char fL:1;						//Process CA  0
	unsigned char pressureUnit:1; 			//Pressure unit (0:cmH2O, 1:hPa)
} DevSetInfoStruct;

typedef union
{
	DevSetInfoStruct devSetInfoStruct;
	unsigned char data;
} DevSetInfoUnion;

//Parameter Format of ramp delay time
typedef struct
{
	unsigned char delayTime:4; 	// Value*5 = Actual delay time used
	unsigned char rampTime:4; 	// Valued*5 = Actual ramp time used
} RampDelayTimeStruct;

typedef union
{
	RampDelayTimeStruct rampDelayTimeStruct;
	unsigned char data;
} RampDelayTimeUnion;

//Parameter Format of Natural support
typedef struct
{
	unsigned char inhSupport:4;
	unsigned char exhSupport:4;
} NaturalSupportStruct;

typedef union
{
	NaturalSupportStruct naturalSupportStruct;
	unsigned char data;
} NaturalSupportUnion;



#endif /* UNITTEST_INC_SECTION_H_ */
