/*
 * setting.h
 *
 *  Created on: Apr 10, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_SETTING_H_
#define UNITTEST_INC_SETTING_H_

//define pressure scale
#define PRESS_SCALE				(10)
#define HPA_CMH2O_FACTOR		((float)1.02)

//define ramp time step
#define RAMP_TIME_SETTING_STEP					5

#define NUM_OF_SETTING			eLastSettingId

//declare a mutex to protect setting
//extern xSemaphoreHandle settingMutex;

//define 2 ventilation mode in Swell machine are: CPAP and AUTO-CPAP
typedef enum
{
	eCpapMode = 0,
	eAutoMode
} E_OperationMode;

//define unit of pressure used in Swell machine: cmH2O or Pa
typedef enum
{
	ecmH2O = 0,
	ehPa
} E_PressUnit;

//define unit of initial pressure
typedef enum
{
	e2cmH2O = 0,
	e4cmH2O
} E_InitialPress;
//define 2 discrete of digital GPIO on chip
typedef enum
{
	eOff = 0,
	eOn
} E_OnOff;

typedef enum
{
	eQE = 0,
	eOthers
} E_DryingMode;

//define 2 state of yes/no question
typedef enum
{
	eNo = 0,
	eYes
} E_YesNo;

//define all language that Swell machine supported: here are English and Japanese
typedef enum
{
	eJapanese = 0,
	eEnglish
} E_Language;

//define all types of natural support setting
typedef enum
{
	eEType = 0,
	eSType
} E_NsType;

//define 2 state of bluetooth setting. here are enable blue tooth or disable bluetooth
typedef enum
{
	eDisable = 0,
	eEnable
} E_BluetoothSetting;

//define all settings ID
typedef enum
{
	eFirstSettingId = 0,
	eVentModeSettingId = eFirstSettingId,			//ventilation mode setting (CPAP or AUTO-CPAP)
	eBrightnessSettingId,
	eLanguageSettingId,
	ePressUnitSettingId,
	eBluetoothSettingId,							//blue tooth enable/disable
	eOperPressSettingId,							//operation pressure setting
	eDelayPressSettingId,							//pressure at delay time
	eDelayTimeSettingId,							//delay time
	eRampTimeSettingId,								//ramp time
	eCircuitTypeSettingId,							//auto on/off setting
	eExhPressSupportSettingId, 						//exhalation pressure trigger
	eInhPressSupportSettingId,						//inhalation pressure trigger
	eAutoUpperPressSettingId,						//upper limit pressure
	eAutoLowerPressSettingId,						//lower limit pressure
	eAutoAdjustPressSettingId,						//auto adjust pressure setting (on/off)
	eAutoCADetectSettingId,							//CA detection enable (on/off)
	eAutoOADetectSettingId,							//OA detection enable (on/off)
	eAutoHDetectSettingId,							//hypo apnea detection enable (on/off)
	eAutoSDetectSettingId,							//snore detection enable (on/off)
	eAutoFLDetectSettingId,							//flow limitation enable (on/off)
	eSleepTimerSettingId,							//dispLAY off timer
	eNsTypeSettingId,								//natural support type setting
	eAutoOFFSettingId,								//auto Off setting
	eFLSettingId,									//FL setting
//	eDryingModeSettingId,
	eLastSettingId
} E_SettingId;

typedef enum
{
	eNsSettingLogId,
	ePtreatSettingLogid,
	ePminSettingLogId,
	ePmaxSettingLogId,
	ePdelaySettingLogId,
	eDevSetInfoSettingLogId,
	eRDTiSettingLogId
} E_SettingHeaderId;

//define setting item structure
typedef struct
{
	E_SettingId id;
	unsigned char data;
} SettingItem;


#if defined(__cplusplus)
namespace EmbeddedC {
#endif

bool SettingRestore();		//restore setting from EEPROM
void SettingInit();
//function to set request update setting from SD card
void SettingSetRequestReadSd();
//function to get request read setting from SD card
bool SettingGetRequestReadSd();
void SettingSetDefault();	//set settings as default
void SettingSet(E_SettingId id, unsigned char value);		//set value for a setting
unsigned char SettingGet(E_SettingId id);					//get value of a  setting id
void SettingSave();											//save setting to EEPROM
bool SettingReadFromSd();
void SettingSetDefaultNoOS();
void SettingSaveNoOS();
bool SettingReadOperInfor();
bool SettingReadSystemInfor();
bool SettingGetStringFromFile();
void SettingParseData(unsigned char id, int value);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_INC_SETTING_H_ */
