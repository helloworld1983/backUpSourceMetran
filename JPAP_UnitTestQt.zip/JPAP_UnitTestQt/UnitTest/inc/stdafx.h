#pragma once

#include <stdio.h>
#include "gtest.h"
#include "gmock.h"
