/*
 * systeminfortableMocks.h
 *
 *  Created on: Apr 17, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_SYSTEMINFORTABLEMOCKS_H_
#define UNITTEST_INC_SYSTEMINFORTABLEMOCKS_H_

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

void SystemInfortableReloadMocks();
int SystemInforSetSerialNumberMocks(char* buff, int buffSize);
int SystemInforGetSwVersionMocks(char* buff, int buffSize);
int SystemInforGetBootVersionMocks(char* buff, int buffSize);
unsigned short OpertimeGetUsedHourMocks();
int SystemInforGetSerialNoMocks(char* buff, int buffSize);
int SystemInforGetMotorVersionMocks(char* buff, int buffSize);

#if defined(__cplusplus)
}
#endif



#endif /* UNITTEST_INC_SYSTEMINFORTABLEMOCKS_H_ */
