/*
 * systeminterface.h
 *
 *  Created on: Apr 16, 2018
 *      Author: QUOCVIET
 */

#ifndef UNITTEST_INC_SYSTEMINTERFACE_H_
#define UNITTEST_INC_SYSTEMINTERFACE_H_

#include <stdbool.h>
//#include "FreeRTOS.h"
#include "queue.h"
//#include "task.h"
//#include "semphr.h"
//#include "debuguart.h"
//#include "circuitcalibrate.h"


//define system event ID
typedef enum
{
	eSystemDoCalibrationId = 0,			//0. event to do circuit calibration
	eSystemCalibrateWithMask,			//1. event to calibrate with mask
	eSystemDoMotorUpgradeId,			//2. event to do motor software upgrade
	eSystemDoBleUpgradeId,				//3. event to do Bluetooth software upgrade
	eSystemBeginOperationId,			//3. event to begin a log record section
	eSystemEndOperationId,				//4. event to end a log record section
	eSystemLogLeakEventId,				//5. event to record a leak event
	eSystemLogApneaEventId,				//6. event to record a sleep apnea event
	eSystemLogPressChangeId, 			//7. event to record a press event
	eSystemLogErrorEventId,				//8. event to record a error
	eSystemLogRtDataEventId,			//9. event to record real time data
	/******save to EEPROM**********/
	eSystemResetOperationTimeId,		//10. event to reset operation time
	eSystemLogSettingChangedId,			//11. setting changed
	eSettingResetLogId,					//12. setting reset (on/off)
	eSystemStateLogId,					//13. state of system(0: power ON, 1: start blower, 2: stop blower)
	eMainUnitUpgradeLogId,				//14. main unit upgrade
	eBlowerUnitUpgradeLogId,			//15. blower unit upgrade
	eTimeSettingLogId,					//16. time setting change
	eTransferSdDataId,					//17. export log data to SD card
	eClearUsedHoursLogId,				//18. event to log clear used hour
	eCalibrateSuccessLogId,				//19. event to log calibration successfully
	eCalibrateFailLogId,				//20. event to log calibration fail
	eSDCardLogId,						//21. event to log SD card (0: insert, 1:remove)
	eBLEUnitUpgradeLogId,				//22. event to log BLE upgrade
	eLastLogId = eBLEUnitUpgradeLogId,
	/* */
	eSystemLogExportLogDataEventId,		//23. event to export log data to .csv file
} E_SystemEventId;

//define system log ID
typedef enum
{
	eSystemPowerOn,			//power on by connecting to power supply
	eSystemPowerOff,
	eSystemAutoStart,		//auto start blower by auto detect breathing
	eSystemManualStart,		//start blower by press ON/OFF while stop
	eSystemAutoOFF,			//enter drying mode by mask leak
	eSystemStrongDrying,	//event log for QE circuit drying
	eSystemWeakDrying,		//event log for Others circuit drying
	eSystemAutoStop,		//auto stop after 3 hours drying
	eSystemCompleteDrying,	//finish for complete drying
	eSystemManualStop,		//stop blower by press ON/OFF button while operating
	eSystemInterruptionDrying,	//event log for stopping drying by pressing Power Key
	eSystemReturnOperate,	//back to operation from mask off
	//	eSystemMaskLeak			//event to log mask leak
} E_SystemStateLog;

typedef enum
{
	eInsert,
	eRemove
} E_SDCardStateLog;

//define structure for circuit resistance
typedef struct
{
	float aCoefficient;
	float bCoefficient;
} CircuitResistanceStruct;

//declare system property which content all information related to system
typedef struct
{
	//variable related to circuit resistance
//	CircuitResistanceFomula circuitResistance;		//pressure compensated formula
	//variables related to motor software upgrade
	unsigned long upgradeTotalBlock;		//total block need to be transfered during upgrade
	unsigned char upgradeStatus;			//upgrade status
	unsigned char upgradeCode;				//upgrade code
} SystemDataStruct;

//structure to store system data
extern SystemDataStruct SystemData;

//define union of system event data
typedef union
{
	long type1;		//define type 1 as a number of long integer
	short type2[2];	//define type 2 as array of short integer
} SystemEventData;

//define event structure
typedef struct
{
	unsigned char Id;
	SystemEventData Data;
} SystemEventStruct;


#if defined(__cplusplus)
namespace EmbeddedC {
#endif


////declare GUI queue
//extern xQueueHandle systemQueue;
//
////declare system mutex
//extern xSemaphoreHandle systemMutex;
//
////declare a binary semaphore for motor upgrade synchronization
//extern xSemaphoreHandle motorUpgradeSemphr;
//
////declare a binary semaphore for BLE upgrade synchronization
//extern xSemaphoreHandle bleUpgradeSemphr;
//
////function to get system operation status
//bool SystemGetOperationStatus();
//
///******************************************************************************/
////$COMMON.OPERATION$
////    Operation Name: SystemTaskSendEvent()
////
////    Processing:
////    	This operation support sending event to system task from other place
////
////    Input Parameters:
////      E_SystemEventId id: id of the event
////		long data		: data of the event
////
////    Output Parameters:
////      None
////
////    Return Values:
////      bool: 	- true if event was sent successful
////				- false if event was sent failed
////
////    Pre-Conditions:
////      None
////
////    Miscellaneous:
////      None
////
////    Requirements:
////
///******************************************************************************/
//inline bool SystemTaskSendEvent(E_SystemEventId id, long data)
//{
//	//return value
//	bool rtn = true;
//	//event to send
//	SystemEventStruct event;
//	event.Id = id;
//	event.Data.type1 = data;
//	//send event to queue
//	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
//	{
//		DebugStr("\n send failed: event to system task");
//		rtn = false;
//	}
//	return rtn;
//}
//
///******************************************************************************/
////$COMMON.OPERATION$
////    Operation Name: SystemTaskSendEventType2()
////
////    Processing:
////    	This operation support sending event to system task from other place
////
////    Input Parameters:
////      E_SystemEventId id: 	id of the event to send
////		short data0:		data field number 1
////		short data1:		data field number 2
////
////    Output Parameters:
////      None
////
////    Return Values:
////      bool: 	- true if event was sent successful
////				- false if event was sent failed
////
////    Pre-Conditions:
////      None
////
////    Miscellaneous:
////      None
////
////    Requirements:
////
///******************************************************************************/
//inline bool SystemTaskSendEventType2(E_SystemEventId id, short data0, short data1)
//{
//	//return value
//	bool rtn = true;
//	//event to send
//	SystemEventStruct event;
//	event.Id = id;
//	event.Data.type2[0] = data0;
//	event.Data.type2[1] = data1;
//	//send event to queue
//	if(xQueueSendToBack(systemQueue, &event, 2) != pdPASS)
//	{
//		DebugStr("\n send failed: event to system task");
//		rtn = false;
//	}
//	return rtn;
//}

#if defined(__cplusplus)
}
#endif


#endif /* UNITTEST_INC_SYSTEMINTERFACE_H_ */
