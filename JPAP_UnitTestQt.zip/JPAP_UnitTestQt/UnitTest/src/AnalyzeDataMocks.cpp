/*
 * AnalyzeDataMocks.cpp
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#include "AnalyzeDataMocks.h"


bool AnalyzeDataGetFilteredNosePressureMocks(float* valuePtr)
{
	return true;
}

bool AnalyzeDataGetTreatmentPressureMocks(float* valuePtr)
{
	return true;
}
