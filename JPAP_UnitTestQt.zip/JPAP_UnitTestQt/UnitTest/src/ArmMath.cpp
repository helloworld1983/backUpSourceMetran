/*
 * ArmMath.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#include "ArmMath.h"

void arm_mean_f32(float * pSrc,uint32_t blockSize,float * pResult)
{

}

void arm_min_f32(float * pSrc,uint32_t blockSize,float * pResult,uint32_t * pIndex)
{

}

void arm_max_f32(float * pSrc,uint32_t blockSize,float * pResult,uint32_t * pIndex)
{

}
