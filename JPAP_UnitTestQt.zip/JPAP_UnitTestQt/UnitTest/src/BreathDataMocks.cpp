/*
 * BreathDataMocks.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */


#include "BreathDataMocks.h"

void BreathDataResetMocks()
{

}

void BaseFlowResetMocks()
{

}
