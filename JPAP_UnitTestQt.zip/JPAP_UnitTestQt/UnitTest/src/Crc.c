/*
 * Crc.c
 *
 *  Created on: Mar 22, 2018
 *      Author: WINDOWS
 */



#include "Crc.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif


unsigned short CrcCheckNoInit(long size, char* buffer )
{
	// Code of CrcCheckNoInit, we don't care
	return 0;
}



#if defined(__cplusplus)
}
#endif

