/*
 * CrcMocks.cpp
 *
 *  Created on: Apr 24, 2018
 *      Author: Quoc Viet
 */

#include "CrcMocks.h"


unsigned short CrcCheckNoInitMocks(long nBytes, char *pData)
{
	return 0;
}
