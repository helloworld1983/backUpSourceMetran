/*
 * EventMocks.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#include "EventMocks.h"

void EventResetMocks()
{

}

void EventSetFLEnableMocks(bool isEnable)
{

}

void EventHandleDataMocks(float flow, float pressure)
{

}

void EventCSresetMocks()
{

}

void EventCSaddDataMocks(float data)
{

}

void EventCScheckBreathMocks()
{

}

void EventCScheckCancelMocks()
{

}

void EventCScheckApneaMocks(unsigned long time)
{

}

short EventCSgetCountMocks()
{
	return 0;
}

void EventCSexitApneaMocks(unsigned long time)
{

}
