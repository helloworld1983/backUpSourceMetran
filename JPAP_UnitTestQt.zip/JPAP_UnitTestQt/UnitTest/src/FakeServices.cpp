#include "stdafx.h"

#include "Fixture.h"
#include "SoftTimerMocks.h"
#include "SleepScrMocks.h"
#include "queue.h"
#include "ff.h"
#include <string>

using namespace std;
using namespace EmbeddedCUnitTest;

namespace EmbeddedC {



unsigned short CrcCheckNoInit(long size, char* buffer )
{
	return TestFixture::_crc->CrcCheckNoInit(size, buffer);
}

int spi_flash_read(size_t addr, void* dest , size_t size)
{
	return TestFixture::_spi_flash->spi_flash_read(addr, dest, size);
}

int spi_flash_write(size_t dest, const void* src, size_t size)
{
	return TestFixture::_spi_flash->spi_flash_write(dest, src, size);
}

int spi_flash_erase_sector(size_t sector)
{
	return TestFixture::_spi_flash->spi_flash_erase_sector(sector);
}

void* memcpy(void* src, const void* dest , size_t size)
{
	return TestFixture::_memcp->memcpy(src, dest, size);
}

int year()
{
	return TestFixture::_timeLib->year();
}

int month()
{
	return TestFixture::_timeLib->month();
}

int day()
{
	return TestFixture::_timeLib->day();
}

int hour()
{
	return TestFixture::_timeLib->hour();
}

int minute()
{
	return TestFixture::_timeLib->minute();
}

int second()
{
	return TestFixture::_timeLib->second();
}

string String( int digit)
{
	return TestFixture::_wstring->String(digit);
}

size_t strlen(const char* str)
{
	return TestFixture::_wstring->strlen(str);
}

unsigned char StrAppend(char* des, const char* source, unsigned char bufferOfDes)
{
	return TestFixture::_wstring->StrAppend(des,source,bufferOfDes);
}

//convert integer to Ascii, same as IntToStr()
int StrToolItoA(long int a, char* buff, int numOfDigit)
{
	return TestFixture::_wstring->StrToolItoA(a,buff,numOfDigit);
}

char *strcat (char *des, const char *source)
{
	return TestFixture::_wstring->strcat(des,source);
}

char *strncat (char *des, const char *source, size_t size)
{
	return TestFixture::_wstring->strncat(des,source,size);
}

//convert number in unsigned integer to hex string
int StrToolItoHexS(unsigned int num,char* buff, int size)
{
	return TestFixture::_wstring->StrToolItoHexS(num,buff,size);
}

int StrToolFtoA(float n, char *res, int afterpoint)
{
	return TestFixture::_wstring->StrToolFtoA(n,res,afterpoint);
}

//convert time in sec to string in format: HH:MM:SS
int StrToolTtoS(char* str, int timeInSec)
{
	return TestFixture::_wstring->StrToolTtoS(str,timeInSec);
}

char * itoa(int value, char *vstring, unsigned int base)
{
	return TestFixture::_wstring->itoa(value,vstring,base);
}

int	strcmp(const char * str1, const char * str2)
{
	return TestFixture::_wstring->strcmp(str1,str2);
}

double atof(const char *__nptr)
{
	return TestFixture::_wstring->atof(__nptr);
}

int atoi(const char *nptr)
{
	return TestFixture::_wstring->atoi(nptr);
}

void * memset (void * buffer, int byte, size_t size)
{
	return TestFixture::_wstring->memset(buffer,byte,size);
}

BaseType_t xQueueSend(QueueHandle_t xQueue, const void * const pvItemToQueue, TickType_t xTcksToWait)
{
	return TestFixture::_queueLib->xQueueSend(xQueue,pvItemToQueue,xTcksToWait);
}

BaseType_t xQueueReset(xQueueHandle xQueue)
{
	return TestFixture::_queueLib->xQueueReset(xQueue);
}

BaseType_t xQueueReceive(xQueueHandle xQueue, const void * const pvBuffer, TickType_t xTcksToWait)
{
	return TestFixture::_queueLib->xQueueReceive(xQueue,pvBuffer,xTcksToWait);
}

BaseType_t xQueueSendToBack(xQueueHandle xQueue, const void * const pvItemToQueue, TickType_t xTcksToWait)
{
	return TestFixture::_queueLib->xQueueSendToBack(xQueue,pvItemToQueue,xTcksToWait);
}

void vTaskDelay(uint32_t ms)
{
	TestFixture::_queueLib->vTaskDelay(ms);
}

portBASE_TYPE xSemaphoreTake( xQueueHandle xQueue, portTickType xTicksToWait)
{
	return TestFixture::_queueLib->xSemaphoreTake(xQueue,xTicksToWait);
}

void taskENTER_CRITICAL()
{
	TestFixture::_queueLib->taskENTER_CRITICAL();
}

portBASE_TYPE xSemaphoreGive(xQueueHandle xQueue)
{
	return TestFixture::_queueLib->xSemaphoreGive(xQueue);
}

void taskEXIT_CRITICAL()
{
	TestFixture::_queueLib->taskEXIT_CRITICAL();
}

portTickType xTaskGetTickCount( void )
{
	return TestFixture::_queueLib->xTaskGetTickCount();
}

bool MotorTaskSendEvent(unsigned char event)
{
	return TestFixture::_queueLib->MotorTaskSendEvent(event);
}

bool SystemTaskSendEvent(uint8_t id, long data)
{
	return TestFixture::_queueLib->SystemTaskSendEvent(id,data);
}

bool GuiTaskSendEventMocks(unsigned char id, long data)
{
	return TestFixture::_queueLib->GuiTaskSendEventMocks(id,data);
}

void SettingSaveMocks()
{
	TestFixture::_settingLib->SettingSaveMocks();
}

uint8_t SettingGetMocks(uint8_t id)
{
	return TestFixture::_settingLib->SettingGetMocks(id);
}

bool SettingReadFromSdMocks()
{
	return TestFixture::_settingLib->SettingReadFromSdMocks();
}

void SettingSetRequestReadSdMocks()
{
	TestFixture::_settingLib->SettingSetRequestReadSdMocks();
}

void SettingSetDefaultMocks()
{
	TestFixture::_settingLib->SettingSetDefaultMocks();
}

void SettingSetMocks(uint8_t id, unsigned char value)
{
	TestFixture::_settingLib->SettingSetMocks(id, value);
}

void SettingBtnSetValueMocks(void *obj, int pos)
{
	TestFixture::_settingBtnLib->SettingBtnSetValueMocks(obj,pos);
}

void SettingBtnSetStatusMocks(void *obj, int stt)
{
	TestFixture::_settingBtnLib->SettingBtnSetStatusMocks(obj,stt);
}

void SettingbtnLogMocks(void *obj)
{
	TestFixture::_settingBtnLib->SettingbtnLogMocks(obj);
}

void SettingBtnDecThumpPosMocks(void *hObj)
{
	TestFixture::_settingBtnLib->SettingBtnDecThumpPosMocks(hObj);
}

void SettingBtnIncThumpPosMocks(void *hObj)
{
	TestFixture::_settingBtnLib->SettingBtnIncThumpPosMocks(hObj);
}

void MainScreenHandleEventMocks(void* guiEvent)
{
	TestFixture::_MainScreenLib->MainScreenHandleEventMocks(guiEvent);
}

void StartupScreenShowMocks(void)
{
	TestFixture::_MainScreenLib->StartupScreenShowMocks();
}

bool MainUpgradeCheckMocks()
{
	return TestFixture::_MainScreenLib->MainUpgradeCheckMocks();
}

void PWMSetDutyMocks(uint8_t id, unsigned int duty)
{
	TestFixture::_PWMLib->PWMSetDutyMocks(id,duty);
}

void WWDT_CmdMocks(uint8_t flag)
{
	TestFixture::_WWDTLib->WWDT_CmdMocks(flag);
}

void WatchDogFeedMocks()
{
	TestFixture::_WWDTLib->WatchDogFeedMocks();
}

void LogTableInitMocks()
{
	TestFixture::_LogTableLib->LogTableInitMocks();
}

void LogTableDeleteLastRowMocks()
{
	TestFixture::_LogTableLib->LogTableDeleteLastRowMocks();
}

void LogTableReloadMocks()
{
	TestFixture::_LogTableLib->LogTableReloadMocks();
}

int SysLogGetNumRecordsMocks()
{
	return TestFixture::_LogTableLib->SysLogGetNumRecordsMocks();
}

unsigned char SysLogGetEndByteMocks()
{
	return TestFixture::_LogTableLib->SysLogGetEndByteMocks();
}

unsigned char SysLogGetEndPageMocks()
{
	return TestFixture::_LogTableLib->SysLogGetEndPageMocks();
}

void SysLogReadMocks(unsigned char page, char* buffer)
{
	TestFixture::_LogTableLib->SysLogReadMocks(page,buffer);
}

void LogTableAddRowMocks(int numericalOrder,unsigned char* data, unsigned char rowIndex)
{
	TestFixture::_LogTableLib->LogTableAddRowMocks(numericalOrder,data,rowIndex);
}

void LogTableSetSelMocks(int row)
{
	TestFixture::_LogTableLib->LogTableSetSelMocks(row);
}

void LogTableIncSelMocks()
{
	TestFixture::_LogTableLib->LogTableIncSelMocks();
}

int LogTableGetSelMoc()
{
	return TestFixture::_LogTableLib->LogTableGetSelMoc();
}

void LogTableDeleteFirstRowMocks()
{
	TestFixture::_LogTableLib->LogTableDeleteFirstRowMocks();
}

void LogTableDecSelMocks()
{
	TestFixture::_LogTableLib->LogTableDecSelMocks();
}

void SliderSetMaxMocks(void* hObj, int value)
{
	TestFixture::_SliderLib->SliderSetMaxMocks(hObj,value);
}

void SliderUpdateMocks(void* hObj, int value)
{
	TestFixture::_SliderLib->SliderUpdateMocks(hObj,value);
}

void TitleBarSetStatusMocks(void* hObj, uint8_t stt)
{
	TestFixture::_TitleBarLib->TitleBarSetStatusMocks(hObj,stt);
}

void TimeDialogReloadMocks()
{
	TestFixture::_TimeDialogLib->TimeDialogReloadMocks();
}

void TimeDialogSetStatusMocks(int status)
{
	TestFixture::_TimeDialogLib->TimeDialogSetStatusMocks(status);
}

void TimeWidgetSetStatusMocks(void* hObj, uint8_t status)
{
	TestFixture::_TimeDialogLib->TimeWidgetSetStatusMocks(hObj,status);
}

void TimeWidgetIncreaseValueMocks(void* hObj)
{
	TestFixture::_TimeDialogLib->TimeWidgetIncreaseValueMocks(hObj);
}

int TimeWidgetGetValueMocks(void* hObj)
{
	return TestFixture::_TimeDialogLib->TimeWidgetGetValueMocks(hObj);
}

void TimeWidgetDecreaseValueMocks(void* hObj)
{
	TestFixture::_TimeDialogLib->TimeWidgetDecreaseValueMocks(hObj);
}

void TimeWidgetSetValueMocks(void* hObj, int value)
{
	TestFixture::_TimeDialogLib->TimeWidgetSetValueMocks(hObj,value);
}

int WM_GetId(void* hWin)
{
	return TestFixture::_WMLib->WM_GetId(hWin);
}

void WM_GetInsideRect(void * pRect)
{
	TestFixture::_WMLib->WM_GetInsideRect(pRect);
}

void GUI_SetBkColor(uint32_t color)
{
	TestFixture::_WMLib->GUI_SetBkColor(color);
}

void GUI_SetColor(uint32_t color)
{
	TestFixture::_WMLib->GUI_SetColor(color);
}

void GUI_ClearRectEx(const void * pRect)
{
	TestFixture::_WMLib->GUI_ClearRectEx(pRect);
}

uint8_t GUI_SetPenSize(uint8_t Size)
{
	return TestFixture::_WMLib->GUI_SetPenSize(Size);
}

void GUI_DrawLine(int x0, int y0, int x1, int y1)
{
	TestFixture::_WMLib->GUI_DrawLine(x0,y0,x1,y1);
}

void WM_DefaultProc(void * pMsg)
{
	TestFixture::_WMLib->WM_DefaultProc(pMsg);
}

void WM_HideWindow(void* hWin)
{
	TestFixture::_WMLib->WM_HideWindow(hWin);
}

void WM_ShowWindow(void* hWin)
{
	TestFixture::_WMLib->WM_ShowWindow(hWin);
}

void WM_MoveChildTo(void* hWin, int x, int y)
{
	TestFixture::_WMLib->WM_MoveChildTo(hWin,x,y);
}

void WM_GetClientRect(void * pRect)
{
	TestFixture::_WMLib->WM_GetClientRect(pRect);
}

void GUI_FillRect(int x0, int y0, int x1, int y1)
{
	TestFixture::_WMLib->GUI_FillRect(x0,y0,x1,y1);
}

int WM_SetFocus(void* hWin)
{
	return TestFixture::_WMLib->WM_SetFocus(hWin);
}

void GUI_AA_SetFactor(int Factor)
{
	TestFixture::_WMLib->GUI_AA_SetFactor(Factor);
}

uint8_t GUI_SetPenShape(uint8_t Shape)
{
	return TestFixture::_WMLib->GUI_SetPenShape(Shape);
}

int GUI_SetTextMode(int Mode)
{
	return TestFixture::_WMLib->GUI_SetTextMode(Mode);
}

int WM_SetYSize(void* hWin, int ySize)
{
	return TestFixture::_WMLib->WM_SetYSize(hWin,ySize);
}

void GUI_FillRoundedRect(int x0, int y0, int x1, int y1, int r)
{
	TestFixture::_WMLib->GUI_FillRoundedRect(x0,y0,x1,y1,r);
}

void WM_Paint(void* hObj)
{
	TestFixture::_WMLib->WM_Paint(hObj);
}

int GUI_SetTextAlign(int Align)
{
	return TestFixture::_WMLib->GUI_SetTextAlign(Align);
}

void GUI_DispStringAt(const char * s, int x, int y)
{
	TestFixture::_WMLib->GUI_DispStringAt(s,x,y);
}

void GUI_DispDecAt(int v, int16_t x, int16_t y, uint8_t Len)
{
	TestFixture::_WMLib->GUI_DispDecAt(v,x,y,Len);
}

void GUI_DispStringInRect(const char * s, void * pRect, int TextAlign)
{
	TestFixture::_WMLib->GUI_DispStringInRect(s,pRect,TextAlign);
}

void GUI_DrawGradientV(int x0, int y0, int x1, int y1, uint32_t Color0, uint32_t Color1)
{
	TestFixture::_WMLib->GUI_DrawGradientV(x0,y0,x1,y1,Color0,Color1);
}

void GUI_AA_FillRoundedRect(int x0, int y0, int x1, int y1, int r)
{
	TestFixture::_WMLib->GUI_AA_FillRoundedRect(x0,y0,x1,y1,r);
}

void WM_SendMessage(void* hWin, void* p)
{
	TestFixture::_WMLib->WM_SendMessage(hWin,p);
}

int WM_GetYSize(void* hWin)
{
	return TestFixture::_WMLib->WM_GetYSize(hWin);
}

void InforDlgSetStatus(int status)
{
	TestFixture::_InforDlgLib->InforDlgSetStatus(status);
}

void SystemInfortableReloadMocks()
{
	TestFixture::_SysInforTableLib->SystemInfortableReloadMocks();
}

int SystemInforSetSerialNumberMocks(char* buff, int buffSize)
{
	return TestFixture::_SysInforTableLib->SystemInforSetSerialNumberMocks(buff,buffSize);
}

int SystemInforGetSwVersionMocks(char* buff, int buffSize)
{
	return TestFixture::_SysInforTableLib->SystemInforGetSwVersionMocks(buff,buffSize);
}

int SystemInforGetBootVersionMocks(char* buff, int buffSize)
{
	return TestFixture::_SysInforTableLib->SystemInforGetBootVersionMocks(buff,buffSize);
}

unsigned short OpertimeGetUsedHourMocks()
{
	return TestFixture::_SysInforTableLib->OpertimeGetUsedHourMocks();
}

int SystemInforGetSerialNoMocks(char* buff, int buffSize)
{
	return TestFixture::_SysInforTableLib->SystemInforGetSerialNoMocks(buff,buffSize);
}

int SystemInforGetMotorVersionMocks(char* buff, int buffSize)
{
	return TestFixture::_SysInforTableLib->SystemInforGetMotorVersionMocks(buff,buffSize);
}

bool AnalyzeDataGetFilteredNosePressureMocks(float* valuePtr)
{
	return TestFixture::_AnalyzeDataLib->AnalyzeDataGetFilteredNosePressureMocks(valuePtr);
}

bool AnalyzeDataGetTreatmentPressureMocks(float* valuePtr)
{
	return TestFixture::_AnalyzeDataLib->AnalyzeDataGetTreatmentPressureMocks(valuePtr);
}

void PROGBAR_GetMinMax(void* hObj, int * pMin, int * pMax)
{
	TestFixture::_ProgbarLib->PROGBAR_GetMinMax(hObj,pMin,pMax);
}

void PROGBAR_SetValue(void* hObj, int v)
{
	TestFixture::_ProgbarLib->PROGBAR_SetValue(hObj,v);
}

//function to load setting before display
void UserSettingReloadMocks(int operState)
{
	TestFixture::_UserSettingLib->UserSettingReloadMocks(operState);
}

void UserSettingDialogInitMocks()
{
	TestFixture::_UserSettingLib->UserSettingDialogInitMocks();
}

//function to reset counter for timer
void SoftTimerResetMocks(E_SoftTimerId timerId)
{
	TestFixture::_SoftTimerLib->SoftTimerResetMocks(timerId);
}

//function to stop timer 0
void SoftTimerStopMocks(E_SoftTimerId timerId)
{
	TestFixture::_SoftTimerLib->SoftTimerStopMocks(timerId);
}

//function to start timer 0
void SoftTimerStartMocks(E_SoftTimerId timerId)
{
	TestFixture::_SoftTimerLib->SoftTimerStartMocks(timerId);
}

//function to update treatment pressure on sleep screen
void SleepScrUpdatePressureMocks()
{
	TestFixture::_SleepScrLib->SleepScrUpdatePressureMocks();
}

//function to set type of display
void SleepScrSetTypeMocks(E_SleepDispType type)
{
	TestFixture::_SleepScrLib->SleepScrSetTypeMocks(type);
}

void EEPROMWriteMocks(int page, int byte, char* data, int num)
{
	TestFixture::_EEPROMLib->EEPROMWriteMocks(page,byte,data,num);
}

void EEPROM_EraseMocks(uint16_t address)
{
	TestFixture::_EEPROMLib->EEPROM_EraseMocks(address);
}

void EEPROMReadMocks(int page, int byte, char* data, int num)
{
	TestFixture::_EEPROMLib->EEPROMReadMocks(page,byte,data,num);
}

FRESULT f_open (FIL* file, const TCHAR* tchar, BYTE byte)
{
	return (FRESULT)TestFixture::_FFLib->f_open(file,tchar,byte);
}

FRESULT f_close (FIL* file)
{
	return (FRESULT)TestFixture::_FFLib->f_close(file);
}

FRESULT f_unlink (const TCHAR* tchar)
{
	return (FRESULT)TestFixture::_FFLib->f_unlink(tchar);
}

TCHAR* f_gets (TCHAR* tchar, int byte, FIL* file)
{
	return (TCHAR*)TestFixture::_FFLib->f_gets(tchar,byte,file);
}

unsigned short CrcCheckNoInitMocks(long nBytes, char *pData)
{
	return TestFixture::_CRCJAPLib->CrcCheckNoInitMocks(nBytes,pData);
}

void* RTCGetMocks()
{
	return TestFixture::_RTCLib->RTCGetMocks();
}

void RTCSetMocks(void* time)
{
	TestFixture::_RTCLib->RTCSetMocks(time);
}

bool PowerMonitorCheckMocks()
{
	return TestFixture::_PowerMonitorLib->PowerMonitorCheckMocks();
}

void PowerMonitorClearMocks()
{
	TestFixture::_PowerMonitorLib->PowerMonitorClearMocks();
}

void EventResetMocks()
{
	TestFixture::_EventLib->EventResetMocks();
}

void EventSetFLEnableMocks(bool isEnable)
{
	TestFixture::_EventLib->EventSetFLEnableMocks(isEnable);
}

void EventHandleDataMocks(float flow, float pressure)
{
	TestFixture::_EventLib->EventHandleDataMocks(flow,pressure);
}

void EventCSresetMocks()
{
	TestFixture::_EventLib->EventCSresetMocks();
}

void EventCSaddDataMocks(float data)
{
	TestFixture::_EventLib->EventCSaddDataMocks(data);
}

void EventCScheckBreathMocks()
{
	TestFixture::_EventLib->EventCScheckBreathMocks();
}

void EventCScheckCancelMocks()
{
	TestFixture::_EventLib->EventCScheckCancelMocks();
}

void EventCScheckApneaMocks(unsigned long time)
{
	TestFixture::_EventLib->EventCScheckApneaMocks(time);
}

short EventCSgetCountMocks()
{
	return TestFixture::_EventLib->EventCSgetCountMocks();
}

void EventCSexitApneaMocks(unsigned long time)
{
	TestFixture::_EventLib->EventCSexitApneaMocks(time);
}

void PhaseResetMocks()
{
	TestFixture::_PhaseLib->PhaseResetMocks();
}

void PhaseHandleDataMocks(float flow, float pressure)
{
	TestFixture::_PhaseLib->PhaseHandleDataMocks(flow,pressure);
}

void BreathDataResetMocks()
{
	TestFixture::_BreathDataLib->BreathDataResetMocks();
}

void BaseFlowResetMocks()
{
	TestFixture::_BreathDataLib->BaseFlowResetMocks();
}

void MaskOffSetStateMocks(uint8_t state)
{
	TestFixture::_MaskOffLib->MaskOffSetStateMocks(state);
}

void MaskOffSetEnableMocks(bool isEnable)
{
	TestFixture::_MaskOffLib->MaskOffSetEnableMocks(isEnable);
}

void MaskOffHandleDataMocks(float flow, float pressure)
{
	TestFixture::_MaskOffLib->MaskOffHandleDataMocks(flow,pressure);
}

bool MotorDataGetFlowMocks(float* valuePtr)
{
	return TestFixture::_MotorDataLib->MotorDataGetFlowMocks(valuePtr);
}

void RtBufferHandleDataMocks(float flow, float pressure)
{
	TestFixture::_RtBufferLib->RtBufferHandleDataMocks(flow,pressure);
}

void arm_mean_f32(float * pSrc,uint32_t blockSize,float * pResult)
{
	TestFixture::_ArmMathLib->arm_mean_f32(pSrc,blockSize,pResult);
}

void arm_min_f32(float * pSrc,uint32_t blockSize,float * pResult,uint32_t * pIndex)
{
	TestFixture::_ArmMathLib->arm_min_f32(pSrc,blockSize,pResult,pIndex);
}

void arm_max_f32(float * pSrc,uint32_t blockSize,float * pResult,uint32_t * pIndex)
{
	TestFixture::_ArmMathLib->arm_max_f32(pSrc,blockSize,pResult,pIndex);
}

float VolumeGetMocks()
{
	return TestFixture::_VolumeLib->VolumeGetMocks();
}

void VolumeBeginMocks(float flow)
{
	TestFixture::_VolumeLib->VolumeBeginMocks(flow);
}

void VolumeAddMocks(float flow)
{
	TestFixture::_VolumeLib->VolumeAddMocks(flow);
}

void VolumeEndMocks()
{
	TestFixture::_VolumeLib->VolumeEndMocks();
}

}
