#include "stdafx.h"

#include "Fixture.h"

namespace EmbeddedCUnitTest {

// Services

std::unique_ptr<CRCService> TestFixture::_crc;
std::unique_ptr<SpiFlashService> TestFixture::_spi_flash;
std::unique_ptr<memcpyService> TestFixture::_memcp;
std::unique_ptr<WstringService> TestFixture::_wstring;
std::unique_ptr<TimeLibService> TestFixture::_timeLib;
std::unique_ptr<QueueOsService> TestFixture::_queueLib;
std::unique_ptr<SettingService> TestFixture::_settingLib;
std::unique_ptr<SettingBtnService> TestFixture::_settingBtnLib;
std::unique_ptr<MainScreenService> TestFixture::_MainScreenLib;
std::unique_ptr<PWMService> TestFixture::_PWMLib;
std::unique_ptr<WWDTService> TestFixture::_WWDTLib;
std::unique_ptr<LogTableService> TestFixture::_LogTableLib;
std::unique_ptr<SliderService> TestFixture::_SliderLib;
std::unique_ptr<TitleBarService> TestFixture::_TitleBarLib;
std::unique_ptr<TimeDialogService> TestFixture::_TimeDialogLib;
std::unique_ptr<WMService> TestFixture::_WMLib;
std::unique_ptr<InforDlgService> TestFixture::_InforDlgLib;
std::unique_ptr<SystemInforTableService> TestFixture::_SysInforTableLib;
std::unique_ptr<AnalyzeDataService> TestFixture::_AnalyzeDataLib;
std::unique_ptr<ProgbarService> TestFixture::_ProgbarLib;
std::unique_ptr<UserSettingService> TestFixture::_UserSettingLib;
std::unique_ptr<SoftTimerService> TestFixture::_SoftTimerLib;
std::unique_ptr<SleepScrService> TestFixture::_SleepScrLib;
std::unique_ptr<EEPROMService> TestFixture::_EEPROMLib;
std::unique_ptr<FFService> TestFixture::_FFLib;
std::unique_ptr<CRCJPAPService> TestFixture::_CRCJAPLib;
std::unique_ptr<RTCService> TestFixture::_RTCLib;
std::unique_ptr<PoweMonitorService> TestFixture::_PowerMonitorLib;
std::unique_ptr<EventService> TestFixture::_EventLib;
std::unique_ptr<PhaseService> TestFixture::_PhaseLib;
std::unique_ptr<BreathDataService> TestFixture::_BreathDataLib;
std::unique_ptr<MaskOffService> TestFixture::_MaskOffLib;
std::unique_ptr<MotorDataService> TestFixture::_MotorDataLib;
std::unique_ptr<RtBufferService> TestFixture::_RtBufferLib;
std::unique_ptr<ArmMathService> TestFixture::_ArmMathLib;
std::unique_ptr<VolumeService> TestFixture::_VolumeLib;
// Modules mocks
std::unique_ptr<BaseModuleMock> TestFixture::_modulesMocks;

}
