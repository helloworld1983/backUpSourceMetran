/*
 * InforDlgMocks.cpp
 *
 *  Created on: Apr 17, 2018
 *      Author: QUOCVIET
 */

#include "InforDlgMocks.h"


void InforDlgSetStatus(int status)
{

}
