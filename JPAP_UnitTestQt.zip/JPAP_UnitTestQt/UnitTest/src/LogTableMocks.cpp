/*
 * LogTableMocks.cpp
 *
 *  Created on: Apr 13, 2018
 *      Author: QUOCVIET
 */

#include "LogTableMocks.h"

void LogTableInitMocks()
{

}

void LogTableDeleteLastRowMocks()
{

}

void LogTableReloadMocks()
{

}

int SysLogGetNumRecordsMocks()
{
	return 0;
}

unsigned char SysLogGetEndByteMocks()
{
	return 0;
}

unsigned char SysLogGetEndPageMocks()
{
	return 0;
}

void SysLogReadMocks(unsigned char page, char* buffer)
{

}

void LogTableAddRowMocks(int numericalOrder,unsigned char* data, unsigned char rowIndex)
{

}

void LogTableSetSelMocks(int row)
{

}

void LogTableIncSelMocks()
{

}

int LogTableGetSelMoc()
{
	return 0;
}

void LogTableDeleteFirstRowMocks()
{

}

void LogTableDecSelMocks()
{

}
