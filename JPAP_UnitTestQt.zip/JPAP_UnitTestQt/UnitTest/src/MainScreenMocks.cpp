/*
 * MainScreenMocks.cpp
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#include "MainScreenMocks.h"

//#if defined(__cplusplus)
//namespace EmbeddedC {
//#endif

void MainScreenHandleEventMocks(void* guiEvent)
{

}

void StartupScreenShowMocks(void)
{

}

bool MainUpgradeCheckMocks()
{
	return true;
}

//#if defined(__cplusplus)
//}
//#endif
