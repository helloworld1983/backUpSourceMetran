/*
 * MaskOffMocks.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */


#include "MaskOffMocks.h"

void MaskOffSetStateMocks(uint8_t state)
{

}

void MaskOffSetEnableMocks(bool isEnable)
{

}

void MaskOffHandleDataMocks(float flow, float pressure)
{

}
