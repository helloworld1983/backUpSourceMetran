/*
 * MotorDataMocks.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#include "MotorDataMocks.h"

bool MotorDataGetFlowMocks(float* valuePtr)
{
	return true;
}
