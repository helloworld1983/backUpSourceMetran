/*
 * PROGBARMocks.cpp
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#include "PROGBARMocks.h"

void PROGBAR_GetMinMax(void* hObj, int * pMin, int * pMax)
{

}

void PROGBAR_SetValue(void* hObj, int v)
{

}
