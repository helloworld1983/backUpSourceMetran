/*
 * PWMLib.cpp
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#include "PWMLib.h"

void PWMSetDutyMocks(uint8_t id, unsigned int duty)
{

}
