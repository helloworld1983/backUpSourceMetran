/*
 * PhaseMocks.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#include "PhaseMocks.h"

void PhaseResetMocks()
{

}

void PhaseHandleDataMocks(float flow, float pressure)
{

}
