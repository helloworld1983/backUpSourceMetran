/*
 * PowerMonitorMocks.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */

#include "PowerMonitorMocks.h"


bool PowerMonitorCheckMocks()
{
	return true;
}

void PowerMonitorClearMocks()
{

}
