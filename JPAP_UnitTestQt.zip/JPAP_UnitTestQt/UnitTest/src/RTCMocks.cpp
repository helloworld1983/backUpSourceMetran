/*
 * RTCMocks.cpp
 *
 *  Created on: Apr 26, 2018
 *      Author: Quoc Viet
 */

#include "RTCMocks.h"


RTC_TIME_Type RTCGetMocks()
{
	RTC_TIME_Type time;
	return time;
}

void RTCSetMocks(void* time)
{

}
