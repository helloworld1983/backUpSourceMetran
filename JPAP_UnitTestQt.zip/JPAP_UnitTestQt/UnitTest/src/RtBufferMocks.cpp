/*
 * RtBufferMocks.cpp
 *
 *  Created on: May 3, 2018
 *      Author: Quoc Viet
 */


#include "RtBufferMocks.h"

void RtBufferHandleDataMocks(float flow, float pressure)
{

}
