/*
 * SettingBtnMocks.cpp
 *
 *  Created on: Apr 11, 2018
 *      Author: QUOCVIET
 */

#include "SettingBtnMocks.h"

//#if defined(__cplusplus)
//namespace EmbeddedC {
//#endif

void SettingBtnSetValueMocks(void *obj, int pos)
{

}

void SettingBtnSetStatusMocks(void *obj, int stt)
{

}

void SettingbtnLogMocks(void *obj)
{

}

void SettingBtnDecThumpPosMocks(void *hObj)
{

}

void SettingBtnIncThumpPosMocks(void *hObj)
{

}

//#if defined(__cplusplus)
//}
//#endif


