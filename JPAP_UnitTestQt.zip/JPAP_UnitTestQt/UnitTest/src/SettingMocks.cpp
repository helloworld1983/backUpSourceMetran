/*
 * SettingMocks.cpp
 *
 *  Created on: Apr 11, 2018
 *      Author: QUOCVIET
 */
#include "SettingMocks.h"

//#if defined(__cplusplus)
//namespace EmbeddedC {
//#endif

void SettingSaveMocks()
{

}

uint8_t SettingGetMocks(uint8_t  id)
{
	return 0;
}

bool SettingReadFromSdMocks()
{
	return true;
}

void SettingSetRequestReadSdMocks()
{

}

void SettingSetDefaultMocks()
{

}

void SettingSetMocks(uint8_t id, unsigned char value)
{

}

//#if defined(__cplusplus)
//}
//#endif

