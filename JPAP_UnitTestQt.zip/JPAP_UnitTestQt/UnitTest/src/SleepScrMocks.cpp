/*
 * SleepScrMocks.cpp
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#include "SleepScrMocks.h"

//function to update treatment pressure on sleep screen
void SleepScrUpdatePressureMocks()
{

}

//function to set type of display
void SleepScrSetTypeMocks(E_SleepDispType type)
{

}
