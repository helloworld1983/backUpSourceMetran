/*
 * SliderMocks.cpp
 *
 *  Created on: Apr 13, 2018
 *      Author: QUOCVIET
 */

#include "SliderMocks.h"

void SliderSetMaxMocks(void* hObj, int value)
{

}

void SliderUpdateMocks(void* hObj, int value)
{

}
