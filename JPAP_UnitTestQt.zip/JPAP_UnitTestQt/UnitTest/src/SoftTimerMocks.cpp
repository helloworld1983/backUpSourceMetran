/*
 * SoftTimerMocks.cpp
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#include "SoftTimerMocks.h"

//function to reset counter for timer
void SoftTimerResetMocks(E_SoftTimerId timerId)
{

}

//function to stop timer 0
void SoftTimerStopMocks(E_SoftTimerId timerId)
{

}

//function to start timer 0
void SoftTimerStartMocks(E_SoftTimerId timerId)
{

}
