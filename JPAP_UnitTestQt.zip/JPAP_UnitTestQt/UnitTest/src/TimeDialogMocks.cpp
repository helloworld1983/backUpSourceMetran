/*
 * TimeDialogMocks.cpp
 *
 *  Created on: Apr 17, 2018
 *      Author: QUOCVIET
 */

#include "TimeDialogMocks.h"


void TimeDialogReloadMocks()
{

}

void TimeDialogSetStatusMocks(int status)
{

}

void TimeWidgetSetStatusMocks(void* hObj, uint8_t status)
{

}

void TimeWidgetIncreaseValueMocks(void* hObj)
{

}

int TimeWidgetGetValueMocks(void* hObj)
{
	return 0;
}

void TimeWidgetDecreaseValueMocks(void* hObj)
{

}

void TimeWidgetSetValueMocks(void* hObj, int value)
{

}
