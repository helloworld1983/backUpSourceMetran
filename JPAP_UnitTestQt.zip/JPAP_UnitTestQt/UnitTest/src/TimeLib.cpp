/*
 * TimeLib.cpp
 *
 *  Created on: Mar 23, 2018
 *      Author: ThienVu
 */

#include "TimeLib.h"

int year()
{
	// Code of year, we don't care
	return 0;
}

int month()
{
	// Code of month, we don't care
	return 0;
}

int day()
{
	// Code of day, we don't care
	return 0;
}

int hour()
{
	// Code of hour, we don't care
	return 0;
}

int minute()
{
	// Code of minute, we don't care
	return 0;
}

int second()
{
	// Code of day, we don't care
	return 0;
}



