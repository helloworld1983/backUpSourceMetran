/*
 * TitleBarMock.cpp
 *
 *  Created on: Apr 13, 2018
 *      Author: QUOCVIET
 */

#include "TitleBarMock.h"


void TitleBarSetStatusMocks(void* hObj, uint8_t stt)
{

}
