/*
 * UserSettingMocks.cpp
 *
 *  Created on: Apr 18, 2018
 *      Author: QUOCVIET
 */

#include "UserSettingMocks.h"

//function to load setting before display
void UserSettingReloadMocks(int operState)
{

}

void UserSettingDialogInitMocks()
{

}
