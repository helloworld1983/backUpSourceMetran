/*
 * VolumeMocks.cpp
 *
 *  Created on: May 4, 2018
 *      Author: Quoc Viet
 */


#include "VolumeMocks.h"

float VolumeGetMocks()
{
	return 0;
}

void VolumeBeginMocks(float flow)
{

}

void VolumeAddMocks(float flow)
{

}

void VolumeEndMocks()
{

}
