/*
 * WDTLib.cpp
 *
 *  Created on: Apr 12, 2018
 *      Author: QUOCVIET
 */

#include "WDTLib.h"

void WWDT_CmdMocks(uint8_t flag)
{

}

void WatchDogFeedMocks()
{

}
