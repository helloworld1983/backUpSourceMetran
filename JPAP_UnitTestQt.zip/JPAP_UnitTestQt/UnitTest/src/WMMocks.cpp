/*
 * WMMocks.cpp
 *
 *  Created on: Apr 17, 2018
 *      Author: QUOCVIET
 */

#include "WMMocks.h"


int WM_GetId(void* hWin)
{
	return 0;
}

void WM_GetInsideRect(void * pRect)
{

}

void GUI_SetBkColor(uint32_t color)
{

}

void GUI_SetColor(uint32_t color)
{

}

void GUI_ClearRectEx(const void * pRect)
{

}

uint8_t GUI_SetPenSize(uint8_t Size)
{
	return 0;
}

void GUI_DrawLine(int x0, int y0, int x1, int y1)
{

}

void WM_DefaultProc(void * pMsg)
{

}

void WM_HideWindow(void* hWin)
{

}

void WM_ShowWindow(void* hWin)
{

}

void WM_MoveChildTo(void* hWin, int x, int y)
{

}

void WM_GetClientRect(void * pRect)
{

}

void GUI_FillRect(int x0, int y0, int x1, int y1)
{

}

int WM_SetFocus(void* hWin)
{
	return 0;
}

void GUI_AA_SetFactor(int Factor)
{

}

uint8_t GUI_SetPenShape(uint8_t Shape)
{
	return 0;
}

int GUI_SetTextMode(int Mode)
{
	return 0;
}

int WM_SetYSize(void* hWin, int ySize)
{
	return 0;
}

void GUI_FillRoundedRect(int x0, int y0, int x1, int y1, int r)
{

}

void WM_Paint(void* hObj)
{

}

int GUI_SetTextAlign(int Align)
{
	return 0;
}

void GUI_DispStringAt(const char * s, int x, int y)
{

}

void GUI_DispDecAt(int v, int16_t x, int16_t y, uint8_t Len)
{

}

void GUI_DispStringInRect(const char * s, void * pRect, int TextAlign)
{

}

void GUI_DrawGradientV(int x0, int y0, int x1, int y1, uint32_t Color0, uint32_t Color1)
{

}

void GUI_AA_FillRoundedRect(int x0, int y0, int x1, int y1, int r)
{

}

void WM_SendMessage(void* hWin, void* p)
{

}

int WM_GetYSize(void* hWin)
{
	return 0;
}
