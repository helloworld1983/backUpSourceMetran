/*
 * Wstring.cpp
 *
 *  Created on: Mar 22, 2018
 *      Author: WINDOWS
 */


#include <WString.h>
#include <string>
using namespace std;


string String(int digit){

	return "";
}

size_t strlen(const char* str)
{
	return 0;
}

unsigned char StrAppend(char* des, const char* source, unsigned char bufferOfDes)
{
	return 0;
}

//convert integer to Ascii, same as IntToStr()
int StrToolItoA(long int a, char* buff, int numOfDigit)
{
	return 0;
}

char *strcat (char *des, const char *source)
{
	return "";
}

char *strncat (char *des, const char *source, size_t size)
{
	return "";
}

//convert number in unsigned integer to hex string
int StrToolItoHexS(unsigned int num,char* buff, int size)
{
	return 0;
}

int StrToolFtoA(float n, char *res, int afterpoint)
{
	return 0;
}

//convert time in sec to string in format: HH:MM:SS
int StrToolTtoS(char* str, int timeInSec)
{
	return 0;
}

char * itoa(int value, char *vstring, unsigned int base)
{
	return 0;
}

int	strcmp(const char * str1, const char * str2)
{
	return 0;
}

double atof(const char *__nptr)
{
	return 0;
}

int atoi(const char *nptr)
{
	return 0;
}

void * memset (void * buffer, int byte, size_t size)
{
	return (void*)0;
}
