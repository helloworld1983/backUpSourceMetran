/*
 * eepromMocks.cpp
 *
 *  Created on: Apr 20, 2018
 *      Author: Quoc Viet
 */

#include "eepromMocks.h"

void EEPROMWriteMocks(int page, int byte, char* data, int num)
{

}

void EEPROM_EraseMocks(uint16_t address)
{

}

void EEPROMReadMocks(int page, int byte, char* data, int num)
{

}
