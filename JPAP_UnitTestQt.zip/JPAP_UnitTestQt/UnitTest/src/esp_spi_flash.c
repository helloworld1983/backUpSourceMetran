/*
 * Spi.c
 *
 *  Created on: Mar 22, 2018
 *      Author: WINDOWS
 */


#include "esp_spi_flash.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif




int spi_flash_read(size_t addr, void* dest , size_t size)
{
	// Code of spi_flash_read, we don't care
	return 0;
}

int spi_flash_write(size_t dest, const void* src, size_t size)
{
	// Code of spi_flash_write, we don't care
	return 0;
}

int spi_flash_erase_sector(size_t sector)
{
	// Code of spi_flash_erase_sector, we don't care
	return 0;
}

#if defined(__cplusplus)
}
#endif


