/*
 * ff.cpp
 *
 *  Created on: Apr 23, 2018
 *      Author: Quoc Viet
 */

#include "ff.h"


FRESULT f_open (FIL* file, const TCHAR* tchar, BYTE byte)
{
	return FR_OK;
}

FRESULT f_close (FIL* file)
{
	return FR_OK;
}

FRESULT f_unlink (const TCHAR* tchar)
{
	return FR_OK;
}

TCHAR* f_gets (TCHAR* tchar, int, FIL* file)
{
	return 0;
}
