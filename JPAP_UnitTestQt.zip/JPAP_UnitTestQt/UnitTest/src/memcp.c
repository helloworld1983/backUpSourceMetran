/*
 * memcp.c
 *
 *  Created on: Mar 22, 2018
 *      Author: WINDOWS
 */


#include "memcp.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif




void* memcpy(void* src, const void* dest, size_t size)
{
	// Code of memcpy, we don't care
	return 0;
}


#if defined(__cplusplus)
}
#endif


