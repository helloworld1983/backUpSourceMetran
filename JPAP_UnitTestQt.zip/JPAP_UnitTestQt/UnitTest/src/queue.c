/*
 * queue.c
 *
 *  Created on: Mar 27, 2018
 *      Author: QUOCVIET
 */
#include "queue.h"
#include "stdbool.h"

#if defined(__cplusplus)
namespace EmbeddedC {
#endif

BaseType_t xQueueSend(QueueHandle_t xQueue, const void * const pvItemToQueue, TickType_t xTcksToWait)
{
	return pdPASS;
}

BaseType_t xQueueReset(xQueueHandle xQueue)
{
	return pdPASS;
}

BaseType_t xQueueReceive(xQueueHandle xQueue, const void * const pvBuffer, TickType_t xTcksToWait)
{
	return pdPASS;
}

BaseType_t xQueueSendToBack(xQueueHandle xQueue, const void * const pvItemToQueue, TickType_t xTcksToWait)
{
	return pdPASS;
}

void vTaskDelay(uint32_t ms)
{

}

portBASE_TYPE xSemaphoreTake(xQueueHandle xQueue,portTickType xTicksToWait)
{
	return pdTRUE;
}

void taskENTER_CRITICAL()
{

}

portBASE_TYPE xSemaphoreGive(xQueueHandle xQueue)
{
	return pdTRUE;
}

void taskEXIT_CRITICAL()
{

}

portTickType xTaskGetTickCount( void )
{
	return 0;
}

bool MotorTaskSendEvent(unsigned char event)
{
	return true;
}

bool SystemTaskSendEvent(uint8_t id, long data)
{
	return true;
}

bool GuiTaskSendEventMocks(unsigned char id, long data)
{
	return true;
}

#if defined(__cplusplus)
}
#endif
