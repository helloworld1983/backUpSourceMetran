/*
 * systeminfortableMocks.cpp
 *
 *  Created on: Apr 17, 2018
 *      Author: QUOCVIET
 */

#include "systeminfortableMocks.h"

void SystemInfortableReloadMocks()
{

}

int SystemInforSetSerialNumberMocks(char* buff, int buffSize)
{
	return 0;
}

int SystemInforGetSwVersionMocks(char* buff, int buffSize)
{
	return 0;
}

int SystemInforGetBootVersionMocks(char* buff, int buffSize)
{
	return 0;
}

unsigned short OpertimeGetUsedHourMocks()
{
	return 0;
}

int SystemInforGetSerialNoMocks(char* buff, int buffSize)
{
	return 0;
}

int SystemInforGetMotorVersionMocks(char* buff, int buffSize)
{
	return 0;
}
